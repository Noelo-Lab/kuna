#include <stdio.h>
#include <stdlib.h>
typedef unsigned char xunknown1;
typedef unsigned long long xunknown8;
typedef long long int8;
typedef unsigned long long uint8;
typedef struct {int8 result0,result1;} __kuna_go_pair_i64_i64;
typedef struct {uint8 result0,result1;} __kuna_go_pair_u64_u64;
typedef struct {int8 result0;uint8 result1;} __kuna_go_pair_i64_u64;
static uint8 calls;
__kuna_go_pair_i64_i64 pair(int8 a,int8 b)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax | rcx
  
  v1.result1 = a - b;
  v1.result0 = a + b;
  return v1;
}
__kuna_go_pair_i64_i64 divmod(int8 a,int8 b)
{
  int8 v1; // rax
  __kuna_go_pair_i64_i64 v2; // rbx:rax | rdx
  
  if (b != -1) { // branch-flip
    v1 = a / b;
    a %= b;
  }
  else {
    v1 = -a;
    a = 0;
  }
  v2.result1 = a;
  v2.result0 = v1;
  return v2;
}
__kuna_go_pair_u64_u64 unsignedPair(uint8 a,uint8 b)
{
  __kuna_go_pair_u64_u64 v1; // rbx:rax | rcx
  
  v1.result1 = b ^ a;
  v1.result0 = a + b;
  return v1;
}
__kuna_go_pair_i64_i64 branchPair(int8 a,int8 b)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax | rcx
  __kuna_go_pair_i64_i64 v2; // rbx:rax | rcx
  
  if (a < b) {
    v1.result1 = a;
    v1.result0 = b;
    return v1;
  }
  v2.result1 = b;
  v2.result0 = a;
  return v2;
}
int8 consume(int8 a,int8 b)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  v1 = pair(a,b);
  return v1.result0 ^ v1.result1;
}
int8 first(int8 a,int8 b)
{
  return pair(a,b).result0;
}
int8 second(int8 a,int8 b)
{
  return pair(a,b).result1;
}
__kuna_go_pair_i64_i64 forward(int8 a,int8 b)
{
  return pair(a,b);
}
__kuna_go_pair_i64_i64 effect(int8 a)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  calls += 1;
  v1.result1 = a + 1;
  v1.result0 = a;
  return v1;
}
int8 consumeEffect(int8 a)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  v1 = effect(a);
  return v1.result0 ^ v1.result1;
}
__kuna_go_pair_u64_u64 zeroPair(void)
{
  return (__kuna_go_pair_u64_u64){0,0};
}
__kuna_go_pair_u64_u64 lowPair(uint8 a)
{
  __kuna_go_pair_u64_u64 v1; // rbx:rax
  
  v1.result1 = 0;
  v1.result0 = a;
  return v1;
}
__kuna_go_pair_i64_i64 signedLowPair(int8 a)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  v1.result1 = 0;
  v1.result0 = a;
  return v1;
}
__kuna_go_pair_u64_u64 highPair(uint8 a)
{
  xunknown1 v1 [16]; // rax | rbx
  
  *(xunknown8 *)&v1[8] = 0;
  *(xunknown8 *)v1 = a;
  return (__kuna_go_pair_u64_u64){0,*(unsigned __int128 *)v1};
}
__kuna_go_pair_i64_i64 onesPair(void)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  v1.result1 = 0xffffffffffffffff;
  v1.result0 = 0xffffffffffffffff;
  return v1;
}
__kuna_go_pair_u64_u64 choosePair(uint8 a,uint8 b)
{
  __kuna_go_pair_u64_u64 v1; // rbx:rax
  
  if (!a)
    return (__kuna_go_pair_u64_u64){0,0};
  v1.result1 = b;
  v1.result0 = a;
  return v1;
}
int main(int argc,char **argv){int8 a=strtoll(argv[1],0,10),b=strtoll(argv[2],0,10);__kuna_go_pair_i64_i64 v=pair(a,b);printf("%lld %lld\n",v.result0,v.result1);v=forward(a,b);printf("%lld %lld\n",v.result0,v.result1);v=branchPair(a,b);printf("%lld %lld\n",v.result0,v.result1);__kuna_go_pair_u64_u64 u=unsignedPair((uint8)a,(uint8)b);printf("%llu %llu\n",u.result0,u.result1);printf("%lld %lld %lld\n",consume(a,b),first(a,b),second(a,b));calls=0;int8 e=consumeEffect(a);printf("%lld %llu\n",e,calls);u=zeroPair();printf("%llu %llu\n",u.result0,u.result1);u=lowPair((uint8)a);printf("%llu %llu\n",u.result0,u.result1);v=signedLowPair(a);printf("%lld %lld\n",v.result0,v.result1);u=highPair((uint8)a);printf("%llu %llu\n",u.result0,u.result1);v=onesPair();printf("%lld %lld\n",v.result0,v.result1);u=choosePair((uint8)a,(uint8)b);printf("%llu %llu\n",u.result0,u.result1);if(b!=0){v=divmod(a,b);printf("%lld %lld\n",v.result0,v.result1);}return 0;}
