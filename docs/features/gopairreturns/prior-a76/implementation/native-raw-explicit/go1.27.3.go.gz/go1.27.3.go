package main
import("encoding/binary";"unsafe")
var calls int
func pair(a,b int64)(v [16]byte){calls++;binary.LittleEndian.PutUint64(v[:8],uint64(a+b));binary.LittleEndian.PutUint64(v[8:],uint64(a-b));return}
func forward(a int64, b int64) (int64, int64) {
  return func(v struct { result0 int64; result1 int64 }) (int64, int64) { return v.result0, v.result1 }(func(v [16]byte) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{*(*int64)(unsafe.Pointer(&v[0])), *(*int64)(unsafe.Pointer(&v[8]))} }(pair(a,b)))
}
func main(){for _,a:=range []int64{-9223372036854775808,-4294967297,-1,0,1,4294967297,9223372036854775807}{for _,b:=range []int64{-9223372036854775808,-1,0,1,9223372036854775807}{calls=0;x,y:=forward(a,b);if x!=a+b||y!=a-b||calls!=1{panic("opaque carrier")}}}}
