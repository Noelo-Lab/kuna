use kuna_console::engine::bootstrap_from_object;
use kuna_console::ifacedecomp::{execute,register_decomp_commands,IfaceDecompData,DECOMPILE_MODULE};
use kuna_console::ifaceterm::ConsoleCommands;
fn main(){
 let args:Vec<_>=std::env::args().collect();
 let mut program=bootstrap_from_object(&args[1],"",&[args[2].clone()]).unwrap();
 for option in ["godwarfsig","gopairreturns"]{program.arch_mut().set_kuna_option(option,"on").unwrap();}
 program.commit_pending_analysis().unwrap();
 let ty=program.arch().types().find_by_name("uint8").unwrap().unwrap();
 program.arch().types().get_base_named(16,ty.get_metatype(),"RawCarrier").unwrap();
 for name in ["pair","forward"]{
  let addr=program.lookup_symbol(&format!("main.{name}")).unwrap();
  let size=program.function_extent_at(addr.get_offset());
  program.declare_function(addr,Some(name),size as i32).unwrap();
 }
 let commands=vec![format!("option outlang {}",args[3]),"option ctypes off".into(),"option realtypes off".into(),"map prototype pair RawCarrier pair(int8 a,int8 b);".into(),"load function forward".into(),"decompile".into(),"print C".into()];
 let mut status=ConsoleCommands::into_status(commands);register_decomp_commands(&mut status);kuna_console::kuna_console::register_kuna_commands(&mut status);
 status.get_data_mut(DECOMPILE_MODULE).unwrap().as_any_mut().downcast_mut::<IfaceDecompData>().unwrap().conf=Some(program);
 for _ in 0..6{execute(&mut status);assert!(!status.inerror,"{}",status.optr);}
 let start=status.optr.len();execute(&mut status);assert!(!status.inerror,"{}",status.optr);print!("{}",status.optr[start..].trim());
}
