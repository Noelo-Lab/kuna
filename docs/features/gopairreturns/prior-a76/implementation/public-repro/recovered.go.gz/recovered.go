package main
import "fmt"
// main.pair
func pair(a int64, b int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax | rcx
  
  v1.result1 = a - b
  v1.result0 = a + b
  return v1.result0,v1.result1
}
func main(){fmt.Println(pair(7,3))}
