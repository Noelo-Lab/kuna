# 09 — Emission

```yaml
Anchors:
  - decompiler/crates/kuna-decomp/src/p9_emit
```

An integer SUBPIECE of an implied struct value preserves the extracted width
when rendered as a field access (`kuna_fieldextract.rs`). If the field is wider
than the result, the emitter converts the field to the operation's integer type
before surrounding expressions can widen it again. Thus narrowing a 64-bit
field to signed 32 bits and then returning 64 bits keeps both conversions.
The same extraction uses C casts, Go conversions, or Rust `as` expressions;
the diagnostic `nocastprinting` setting still suppresses those conversions.
An interior slice shifts the field first; its shift follows the input storage's
byte order, so offset zero within a big-endian field denotes its high bytes.
The field expression is evaluated once. Complete integer fields of the same
type retain their existing spelling. Enum, float, pointer, boolean, volatile,
incomplete and bitfield cases retain their existing paths, as do accesses
through an explicit symbol. This corrects field extraction; it does not supply
missing Rust signedness conversions in surrounding expressions.

Standalone C output qualifies whole function-address expressions through
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_funcptrnames.rs`. A named
SPACEBASE reference must have code type and resolve to the exact function entry.
The recovered global symbol and live function database must agree on its leaf
name and complete namespace path at the instruction's use point. This preserves
explicit high-variable renames and declines conflicting aliases, data objects,
interior addresses and remote-provider contexts.
The shared `kuna_namespaces.rs (plain_scope)` spelling check also guards P1
DWARF alias reconciliation. Every namespace component must be a plain ASCII
C++ identifier rather than a keyword. Rust reference/pointer type names, template spellings, anonymous scopes
and other unspellable paths retain their previous expression: prefixing `fmt`
with a raw `*mut T::` or `char::` would not name a C++ function.
The existing `namespacestrategy` policy controls the prefix: `minimal` uses the
caller namespace and local-name collisions, `all` includes every named namespace
and any global root needed to disambiguate a local, and `none` emits the bare
name. Local scopes belong to the function's detached database; namespace lookup
uses only scope identities from the live architecture database. Scope tokens
precede the existing symbol atom, preserving its instruction and varnode tags.
Rust and Go output retain their own existing function-value spelling.

Typed byte-copy stores explicitly convert a pointer initializer to its declared
pointer type when the rendered operand is not already a pointer that type accepts
implicitly. The operand may carry the pointer bits through an unsigned integer
cast, be a raw constant, or point to an unrelated type; a pointer compound literal
cannot accept those expressions implicitly. The conversion preserves the bits
before `__builtin_memcpy` copies the object. An operand of the same pointer type,
or a `void *` on either side, is printed without the extra conversion.

C declarators preserve explicit type qualification. Qualifiers on a base or a
named typedef precede its name; qualifiers on a pointer follow its own `*`.
The declarator walk keeps those layers through arrays and function pointers,
so `volatile uint4 *p` and `uint4 * volatile p` remain distinct. This applies to
parameters, return types, declarations, and casts with either internal or target
C scalar names. A named typedef is printed by its alias rather than expanding
its inherited qualifiers.
When an access needs a cast for its width, the cast retains the pointee's
qualification. Value conversions ignore qualifiers (`cast.rs (cast_standard)`),
so a store through `volatile float *p` prints `*p = x;` with no cast; only a
pointer conversion that drops a `volatile` pointee still needs one.

A volatile annotation that covers only part of its mapped symbol renders the
covered member. An element of an array of scalars prints as `name[index]`;
every other partial cover (a struct field, an element of a multidimensional
array, a field inside an array element) uses the partial-symbol walk, including
through typedefs. A four-byte read at offset 20 in `volatile int cursor[3][2]` prints
`cursor[2][1]`, and one at offset 4 in `volatile struct S s` (`int a; int b;`)
prints `s.b`, not the bare symbol name. Each annotation still represents one
access of the original width.

A scalar access covering an entire array or aggregate still descends to the
covered element or field; a one-element array does not decay to its address.
The scalar-array shortcut requires the operation width to equal the element
width. Other widths retain their byte range through the partial-symbol walk.
With `partialaccess` enabled, pointer views of volatile annotations retain a
volatile pointee, including sixteen-byte views, so changing the spelling does
not change the access width or permit the C compiler to merge the accesses.

This phase renders the finished decompilation: it inserts the explicit
cast/field-access operations a C compiler would need to *see* the recovered
types (§9.1), then walks the structured block tree of chapter 08 and the SSA
expression graph to build a token stream (§9.2), naming every value on the way
out (§9.3), folding in string literals and analysis comments (§9.4), and
choosing between pointer-arithmetic and array notation (§9.5). Everything here
is presentation: after `ActionSetCasts` the IR is only mutated by inserting
print-support ops (CAST, `PTRSUB #0`), never by changing computation. In the
registry (`decompiler/crates/kuna-decomp/phases.toml`) P9 carries the
sub-decisions `cast-policy`, `naming-policy`, `literal-format`,
`pointer-notation`, `condition-form`, `brace-form`, `warning-style`,
`type-definition-preamble`, `constant-address-global`, and `external-refinement` — plus, via the `presentcompare` group row, the P9 half of the P3-declared `comparison-canonicalization` decision
(the console/`kassert` assertion writer — an output *consumer* that writes P0
assertions for the next run, not an algorithm of this folder). One P9-registered
pass lives outside the folder: the (kuna, GH-558) comparison canonicalizer
`decompiler/crates/kuna-decomp/src/p3_dataflow/kuna_compareform.rs
(ActionPresentCompareForm)`, group `presentcompare`, is described with its
folder in chapter [03](03-ssa-and-simplification.md). Option defaults, tiers,
and flip guidance for the kuna settable options named below live in the
generated catalog ([docs/options.md](../options.md)); the upstream console
knobs (`nocastprinting`, `integerformat`, `nullprinting`, `inplaceops`,
`maxlinewidth`, `indentincrement`) are surfaceTable rows in `phases.toml`, set
via the console `option` command, and are not part of the settable catalog.
The intentional default divergences are DIV-1/2/5/6/7 and the C-surface
normalization defaults (DIV-34 brace placement, DIV-35 NULL printing,
DIV-36 compound assignments, DIV-37 truthy conditions, DIV-38 single-statement
brace elision, DIV-39 inline warning slugs) in `docs/history.md`.

An address-only local is declared from its mapped object's type
(`kuna_addressdecl.rs`), rather than the pointer-width constant used to reference
it. Thus a four-byte scalar reached through a saved `int *` remains an `int`,
even on a 64-bit target. Real storage representatives still determine their
own declarations, including wider and overlapping accesses. When another
directly accessed Symbol lies wholly inside the address width from the object's
start, the frame map has likely split one wider object, so the declaration keeps
the address width rather than shrink to the piece. A buffer whose other part
is reached only through pointer arithmetic leaves no such neighbour, so its
first piece is declared at the piece's type, as a directly accessed piece
already is. This corrects the declaration without extending `castobject`'s
permission to retype escaped locals.

A local mapped or declared as a struct or union keeps that whole record type
when its storage representative is an array member. The array-declaration
fallback must not replace the record with its first member: later field accesses
still require the complete object, including fields after that array.

With `stackviews`, a physical stack declaration can contain the scalar being
cast rather than itself being that scalar. Bit-transfer classification descends
through an exact member at the symbol offset and access width; a declared
FloatStorage or DoubleStorage therefore contributes its float member's C type.
An implied arithmetic expression retains its own type. Numeric FLOAT_* operators
keep their ordinary conversions.

Pointer field notation also uses the type facing the particular `PTRSUB` read.
A pointer loaded from a selected member of shared frame storage remains a pointer
to that member's pointee, even when an object name introduces a union backing.
The whole backing type cannot replace that pointer type: doing so would turn a
native `head->next` dereference into an unresolved `PTRSUB(head,0)` expression.

An isolated pointer declaration may name the value copied into an integer member of a declared frame array or record. C emission checks the type that the destination actually prints, rather than treating the pointer type carried by the COPY as the member's declaration. When a pointer is copied to a same-width integer member, it emits an explicit cast to that member's integer type. This preserves the native address value and produces valid C without changing numeric conversions or other output languages (`kuna_pointerstorecast.rs`). The same holds for any integer variable or member that a pointer-valued statement assigns: a plain copy, and a pointer addition or member address (`frame[0] = (unsigned long)&value[1];`). A copied variable that is itself declared as a same-width integer takes no cast, since only its storage was typed as a pointer; a source declared as a record, union or array keeps the cast, because it prints as the pointer member it reads (`x = (long)w.p;`), and a null pointer constant copied into integer storage prints as `0` rather than a cast `NULL`.

`decompiler/crates/kuna-decomp/src/p9_emit/kuna_stackversions.rs` separates memory
SSA bookkeeping from writes under `stackviews`. Generated-backing definitions
without the native stack-store mark describe reconstructed memory versions, not
additional C assignments. They retain their IR and provenance but do not print.
ABI-input materializations and original stores remain visible. COPY, CAST,
MULTIEQUAL and piece temporaries used only by those versions also do not print;
a reverse liveness walk retains any temporary reaching a real computation or
return, including a cached word read before later writes. Closed bookkeeping
cycles do not make a snapshot live. Unused temporaries cannot determine the type
of a live register value with which they were previously coalesced. In particular,
initializing four bytes must not read and rewrite an uninitialized eight-byte word.

When a changed-byte assignment replays a safe LOAD through a floating pointer,
it reinterprets the loaded float or double as an equal-width unsigned word before
constructing the byte-copy source or extracting subranges. Initializing an integer
compound literal directly from that LOAD would numerically convert its value.
The storage reinterpretation evaluates the LOAD once and preserves its bit pattern.

`decompiler/crates/kuna-decomp/src/p9_emit/kuna_stackmarkers.rs` distinguishes a
non-creating INDIRECT version over physical frame bytes from a C assignment.
With `stackviews`, cast insertion, statement emission and body counting
skip that placeholder and unique-space merge copies consumed exclusively by
such placeholders. Copies that feed an ordinary read and actual frame stores
retain their assignments. The native owner still executes and the memory version
remains in the IR for reaching definitions and alias effects; the printer neither
restores the preceding value nor copies bytes out of a constant's fictitious
fields. Register effects and creation markers keep their existing handling.

A `SUBPIECE` that extracts a four-byte float from an eight-byte scalar preserves
the selected bits (`kuna_floatslice.rs`). C shifts an unsigned representation,
narrows it to four bytes, and reinterprets it through an anonymous union; Rust
uses the corresponding unsigned shift and `f32::from_bits`. A floating source
first contributes its bit representation, without a numeric conversion. The
byte offset is a significance offset in either byte order. Partial-structure
intermediates use the stripped scalar type that their declarations expose.
The printer checks
the scalar widths, rejects out-of-range offsets, and evaluates the source once.
An implied source whose type is still undefined, such as an untyped load read
only by the extraction, takes the same path; one that traces back to an untyped
call result keeps its existing rendering, by the rule `kuna_bitcast.rs` applies
to same-width casts, because the slice does not infer a callee's return
prototype. Explicit floating conversion opcodes retain their numeric
conversion, and structured member extraction retains priority.

(kuna) Under `option nanignore none`, a retained widening `FLOAT_FLOAT2FLOAT`
whose input may be a signaling NaN and whose result reaches a conversion back
to the source format materializes its C result in a volatile compound literal
(`decompiler/crates/kuna-decomp/src/p9_emit/printc.rs (PrintC::op_float_quiet_ir)`,
`decompiler/crates/kuna-decomp/src/p3_dataflow/kuna_floatquiet.rs (feeds_round_trip)`):
`(float)(*&(volatile double){ (double)x })`. A C compiler erases a plain
`(float)(double)x` pair even with strict rounding flags. The literal evaluates
its input once and forces the wider format to exist in storage. The read goes
through `*&` because GCC drops a bare volatile literal assigned to a variable
(`v = (volatile double){ (double)x };`), which is how a widening shared by
several readers prints. Widenings that
feed arithmetic, comparisons, calls or stores, and every narrowing, keep
ordinary casts, because the compiler must perform those conversions. Already
quiet inputs also keep ordinary casts, and the default `nanignore compare`
never produces the literal. This applies to C emission; other output languages
retain their cast syntax.

A `SUBPIECE` whose destination is typed as a byte array, such as a temporary that
carries one word of a double into a declared `unsigned char` member, cannot cast
to that array type, and the functional `SUBnm` form names no declared function
(`kuna_bytearrayslice.rs`). The printer instead narrows the source's bits to an
unsigned word of the destination width, shifting by the byte offset as a
significance offset. A `float` or `double` source contributes its representation
through the same union reinterpretation, and a pointer is first widened to an
unsigned word of its own width. Integer sources shift directly, since the selected
bits lie inside the source. Sources of any other type, and destinations wider than
four bytes, keep the existing rendering.

Finite 32-bit floating constants in C carry an `f` suffix when the target
uses 32-bit `float`. Unsuffixed literals have type `double`: printing `0.1`
for a float constant changes both comparisons at `0.1f` and arithmetic
precision. A value `double` holds exactly is suffixed too, since the literal's
type still decides the type of the arithmetic around it: `(int)(x + 11.0)`
adds in `double` and truncates `x = 0.99999994f` to 11, where the binary's
float add rounds to 12. Double constants retain their ordinary unsuffixed spelling. This
does not change the pseudo-C `NAN`, `INFINITY`, or unknown-format tokens,
or the literal spelling of other output languages.

A same-width `CAST` between an integer and a 32- or 64-bit float is a bit
reinterpretation, not a numeric conversion (`kuna_bitcast.rs`). For this
path, `ActionSetCasts` inserts a `CAST` wherever the merged types of a value
and its reader disagree, so a `COPY` between the two kinds is either fed by
such a `CAST` already or writes an undefined destination that takes the bits
as they are. Each side's kind is the type the printed C gives it: a named
variable's declared type (a parameter's prototype type), and the value's own
type for an unnamed intermediate. A member varnode's own type can be stale
after merging and is not consulted for a named variable; reading it would print
a float constant stored to a float global as its integer bits, and would send a
value copied between registers through two opposite unions. C emits an
anonymous union compound literal,
`((union { unsigned int from; float to; }){ .from = x }).to`, which evaluates
`x` once; a signed result names the signed word (`int`, `long long`) as the
member instead of adding a cast. Rust
emits `f32::from_bits`/`f64::from_bits`, converting the operand with `as
u32`/`as u64` unless its declared type already is that word, or `to_bits()`;
a literal operand is narrowed to the transfer's width first. A
floating constant read as an integer prints its stored bits, preserving NaN
payloads. An untyped call result does not establish an integer return contract
and keeps its existing conversion, unless the callee declares what it returns
(`kuna_bitcast.rs (states_a_return)`): a locked output, the return its own
decompile stated to `callrettype`, or a value other than a float its last
decompile returned (`voidret`'s record; raw bytes print as `unsigned int`), each
of which the listing prints as its prototype. A statement counts only in the
storage and width the caller reads the result from (through the temporary the
cast pass gives the call): a callee recovered returning `rax` says nothing of
the `xmm0` its caller reads. A float callee is not counted, because a cast to
a float of its untyped result converts nothing. In the other direction, a call
whose callee states a float, or was last recovered returning one, in the storage
and width of the call's output, a floating register of the call's model, and
whose result the caller holds as an integer
of that width, or as raw bytes it does not only keep in memory
(`kuna_callrettype.rs (float_held_as_bits)`, chapter 04), writes a float
temporary that a `CAST` reads
(`coreaction_casts.rs (Funcdata::cast_narrowed_call)`), so the move of its bits
prints as a reinterpretation: `return getd(a0,a1);` from an `unsigned long`
function, beside `double getd(..)`, now prints
`((union { double from; unsigned long long to; }){ .from = getd(a0,a1) }).to`.
crazyflie's `fabsf` clears the sign bit in a core register and hands the word
back in `s0`; its readers printed `(float)sub_80043b8(a0)` beside `unsigned int
sub_80043b8(unsigned int a0)`, a conversion of the bits, and now reinterpret
them. These operations stay visible under cosmetic
cast suppression. `FLOAT_INT2FLOAT`, `FLOAT_TRUNC` and `FLOAT_FLOAT2FLOAT` keep
their numeric conversion behavior. The representation uses the target's
ordinary 32-/64-bit integer and IEEE float storage widths. A same-width storage
`CAST` between a float and a native byte-addressed pointer also preserves bits.
C first reinterprets a float as the unsigned word before casting that word to
the requested pointer type; the reverse direction casts the pointer to the
unsigned word before reinterpreting it as a float. These pointer casts remain
visible with cosmetic cast suppression. Rust uses the corresponding unsigned
word casts with `from_bits` or `to_bits`. Other pointer widths and addressable
unit sizes do not enter this path.

The x87 integer conversions (`x87_float_to_int16/32/64`, chapter 02) produce
signed integer bits of their own width (`coreaction_infertypes.rs
(output_type_local)`), even when the memory they store to is later read as a
float. Without that type an unknown output adopted the float reader's type and
the store printed as an implicit numeric conversion: `*(float *)&storage[4] =
x87_float_to_int32(..)` wrote the float `1.0f` where `FISTP` writes the word
`1`. When such a result lands in a same-width float output, `cast_output`
routes it through an integer temporary (`coreaction_casts.rs
(Funcdata::cast_narrowed_call)`) so the move prints as the union
reinterpretation above. A byte-array global's merged high type can be an
unresolved aggregate while the store prints a scalar float view; for a
float-typed `CAST` output, `storage_transfer` then judges by the output's own
type instead of that aggregate, keeping the reinterpretation.

A `COPY` can join a float and an integer without any `CAST`: into or out of a
scalar member of a declared aggregate, where the merged varnode keeps the type
of the value it carries while the C prints the member's declared type; through
a varnode whose own type is an unresolved partial struct or union; or between
plain scalar variables whose C declarations differ, such as a float stored into
a variable declared as an equal-width word. A `COPY` moves bits, so whenever
the two sides print as a float and an integer (or native pointer) of the same
width it takes the same bit transfer (`kuna_bitcast.rs (storage_transfer)`).
A scalar global whose recovered type is unknown does not qualify, so a float
stored to it keeps its value spelling. Each side's kind is the type the C prints it with: a side whose bytes
no member names, printed by partial access as `*(T *)&storage[k]`, has that
`T` (`printc.rs (PrintC::partial_piece_type)`), so a word moved between two
such pieces stays a plain copy rather than reading the unsigned word into a
float. A side printed through a named member path, with or without partial
access, has the scalar type of the member or truncating cast that path ends in
when it is the side's width, the same walk that prints it, so a float stored to
`store.real[2]` keeps its bits even when another incarnation merged into that
global supplies an unsigned word type. That printed type decides the side before
the unresolved-aggregate rules above and below, for a `CAST` as for a `COPY`.
The walk is operation-facing, so it resolves the union member the access
actually prints even when the variable's declared member agrees with the
varnode: an indexed word `items.integer[index]` copied into `items.real[16]`
reinterprets its bits. A named member of a stack-frame variable gives its
printed type only under `stackviews`; with that option off the frame side is
judged by its declared member type. A partial struct or union is never taken as a side's C type;
the value's own type stands in for it, except for a side that is a variable of
its own, not part of a struct or union symbol, whose declared type is that
partial aggregate: the declaration prints it as `undefinedN`, so the side is an
integer whatever union field its value resolves to, and a union word carried
through such a variable keeps its bits on the way in and out. A side that
prints as a whole scalar global (the global symbol covering it starts at its
address with its size and is not an aggregate or array) takes that global's declared
type ahead of the merged value's type, so a union `int` word copied into an
`int` global stays `g = k;`. A float an x87 `fstps` writes into a union record
therefore stores `((union { float from; int to; }){ .from = .. }).to` into
`record.first.tag`, a float `memcpy`'d into an `int` member stores its bits
rather than `r.tag = x;`, and a member holding a float's bits that is copied out
reads them back rather than converting the integer. A `COPY` whose two sides
print the same kind is unchanged.

The same `undefinedN` rule decides each side of a same-width storage `CAST`,
ahead of the scalar piece a frame-backed declaration would resolve to. When a
register holds both a union word and such a variable, the variable is still an
integer, so a float-typed `CAST` between it and an integer prints as a plain
integer conversion. Treating it as a float would convert the integer's value
rather than keep its bits.

A low-end integer `SUBPIECE` of a named 32- or 64-bit float similarly reads
storage bits before narrowing (`kuna_bitcast.rs (truncated_float_storage)`).
The selected storage view or declared scalar member type governs this decision,
even when a merged member's own type is integer: casting that float directly to a short performs a numeric conversion
and loses an integer result transported through FPU storage. C first reads the
same-width unsigned member of a union compound literal, then casts that word to
the truncated integer type; Rust applies `to_bits()` before the narrowing cast.
A float-facing input uses the same lowering instead of an opaque `SUB42`
intrinsic. Each input is evaluated once. Nonzero-offset extraction, integer
storage and numeric `FLOAT_TRUNC` operations keep their existing handling.
The canonical union members must match the target widths (`float`/`unsigned
int` at four bytes, or `double`/`unsigned long long` at eight); enums and
nonmatching data organizations keep their existing handling.
This is a storage-semantics repair without an inference option.

**Floating comparison negation.** `printc.rs (PrintC::check_print_negation)`
uses the shared opcode complement table, which excludes ordered float
comparisons. Negating `FLOAT_LESS` or `FLOAT_LESSEQUAL`, whether through a
branch flip or `BOOL_NEGATE`, therefore prints `!(a < b)` or `!(a <= b)`.
The printer must not absorb the negation into `>=` or `>`: those ordered
comparisons are false on NaN, whereas the negated expressions are true.
Integer comparisons and floating equality/inequality still use their
complementary tokens. `tests/stages/kuna-minss-nan.xml` pins MINSS selection
with defaults and `nanignore none`; the CLI regression compiles the printed C
and checks its NaN payloads, signed zeros, finite values and infinities against
the authored instructions.
With `stackviews`, a variable whose C declaration is a 32- or 64-bit integer
word can carry a float's bits: a cached integer snapshot of generated
frame-union storage, or a variable the user retyped to a word. Every edge
between that word and floating arithmetic moves bits rather than converting
the value (`kuna_bitcast.rs (stack_float_input, word_result)`). A native
`FLOAT_*` op that consumes the variable, and a `RETURN` of it from a function
whose prototype returns a float of the same width, read it through the
single-evaluation union transfer for C or `from_bits` for Rust at that use only.
In C, a float result assigned to it, from a native floating op of that width
or from a call whose prototype returns a float or double, is stored through
the reverse union: `v1 = ((union { float from; unsigned int to; }){ .from =
adjust_value(first) }).to;`. The call is judged by its prototype's logical
result width, not the ABI register (an x87 `ST0` result is wider than the
`float` it holds). Integer operations such as the sign-bit XOR keep the word
as integer, and values already declared as floats keep their ordinary
expression. Unnamed expressions and declarations that are not integer words
keep ordinary emission. `FLOAT_INT2FLOAT` remains a numeric conversion of its
input; `FLOAT_TRUNC` and `FLOAT_FLOAT2FLOAT` still perform their numeric
conversions after any required input reinterpretation.

**Condition form (P9/`condition-form`, `option truthycond`).** In boolean
contexts — an if/while/for/ternary condition, or an operand of `&&`/`||`/`!`
— a comparison against zero carries no information beyond the value's own
truthiness, so the kuna default (DIV-37) renders `if (x != 0)` as `if (x)`
and `if (p == NULL)` as `if (!p)`. The printer threads a
`CONDITION_CONTEXT` mod bit from the condition push sites
(`printc.rs (PrintC::op_push_ir)` scopes it off across every
non-boolean-preserving operator, so a value use like `v = (x != 0)` never
rewrites), and `printc.rs (PrintC::op_binary_ir)` consumes it — after the
negate-token flip has settled which comparison prints — by eliding the one
eligible zero operand (`printc.rs (PrintC::truthy_other_operand)`: a plain
constant zero, directly or through one implied CAST, that is not
float-typed, enum-typed, or equate-named). The surviving operand keeps the
context bit, so stacked boolean comparisons collapse fully. `option
truthycond off` restores upstream Ghidra's explicit comparisons, exercised
by `tests/stages/kuna-cnorm-truthycond.xml`.

**Brace form (P9/`brace-form`, `option braceelide`).** A single-statement if
body renders braceless with the statement indented on the next line (kuna
default, DIV-38): `printc.rs (PrintC::emit_block_if)` consults
`printc.rs (PrintC::if_body_elides)` — the body must be a plain
single-statement `BlockCopy` leaf (exactly one op that the statement walk
would print, no label line, no comment positioned in the block), which also
rules out a nested `if` body so eliding can never capture a dangling else.
Multi-statement bodies, else arms, and loop/switch bodies always keep their
braces; the pre-existing `if (cond) goto L;` one-liner and the `else if`
collapse are unaffected. `option braceelide off` restores upstream Ghidra's
braced form, exercised by `tests/stages/kuna-cnorm-braceelide.xml`.

**(kuna) Decode-failure halt statements (`option decodehalt`, default `on`).**
A `CPUI_RETURN` the flow follower planted because the bytes would not decode
(chapter 02) is not a return, and printing it as one asserts something about the
program that the analysis never established. `printc.rs` renders the three
decode-failure halt causes as upstream `PrintC::opReturn`'s pseudo-calls —
`halt_baddata()`, `halt_unimplemented()`, `halt_missing()`
(`kuna_decodehalt.rs (halt_call_name)`) — and the P2 warnings land beside them
through the ordinary comment channel. `noreturn` halts keep the plain `return;`.
The elision below is suppressed for exactly those three causes while the option
is on: that statement is the truncation marker, not the source falling off the
end of a void body, and eliding it deletes the only thing saying the body is
incomplete — leaving its warning attached to whatever decoded before it. A
`noreturn` halt keeps whatever the elision already did with it, and `option
decodehalt off` restores both halves together.

**Void tail-return elision (P9/`brace-form`, `option voidtailreturn`, default
OFF).** kuna prints the function's final `CPUI_RETURN` unconditionally, so a void
function ends `... }` / `return;` / `}` — a statement the C source it was compiled
from does not have, because the source simply falls off the end of the body.
`printc.rs (PrintC::emit_function_body)` computes at most one elidable op per
function via `printc.rs (elidable_void_tail_return)` and
`printc.rs (PrintC::emit_basic_block_ops)` skips exactly that op. Four conditions
must all hold, and each has a named counterexample:

- the prototype returns void — a `return <value>;` is never redundant;
- the op is the tail of the LAST structured leaf, reached by descending only the
  containers that print no construct of their own (`Graph`, `Ls`), so a return
  nested inside an `if`/loop/switch arm is never touched;
- that leaf is not an unstructured goto target — bash `rl_echo_signal_char`
  prints `label_115e79:` directly above its trailing `return;`, and eliding the
  statement would leave a label with nothing after it, which is invalid C;
- exactly one structured leaf carries that RETURN op. `returndup` and `taildup`
  clone a shared epilogue by ALIASING one op across several leaves, so
  suppressing by identity would also delete genuine mid-body early returns; a
  unique owner makes the elision positional rather than identity-based.

A `BlockCopy` mirror is resolved through to the bblocks block it stands for
(`printc.rs (structured_leaf_tail)`) — the normal shape of a structured
function's trailing block, and the reason the direct `sblocks_basic_tail` lookup
is not sufficient. The motivation is measured and structural as well as
stylistic: pyjoern merges `FUNCTION_END` into its predecessor only when that
predecessor's sole successor is `FUNCTION_END`, so a source function whose tail
is an `if` or a loop has NO node there at all, while kuna's printed `return;`
re-materialises one — one extra node, one or two extra edges, and an
`is_exitpoint` role flip that on its own defeats the GED isomorphism test.

**Warning style (P9/`warning-style`, `option warnstyle`).** Analysis warnings
render as terse `// slug` end-of-line comments on the line they describe
(kuna default `inline`, DIV-39): `printc.rs (PrintC::emit_comment_group)`
maps each WARNING-type comment through the slug table
(`printc.rs (warning_slug)` — `no-return`, `branch-flip`, `return-dupe`,
`jump-as-call`, count-suffixed slugs like the header's `early-return x3` and
the `int3-pad x4` chapter 02 buffers for a decoded `int3`, where the count is
the pad's length in bytes; an
unrecognized text keeps its full body behind a `warn:` marker) and collects
it; `printc.rs (PrintC::flush_eol_warnings)` appends the collected slugs as
one `// slug, slug` token at the owning line's last token — the statement
semicolon, the `if (cond)` header (braced, braceless, goto, and ternary
forms), the loop-header brace, and the function prototype for header
warnings. Non-warning comments (user comments, `dwarf_lines`) always keep
their banner-line form, and a body whose only pending comments are
inline-rendered warnings still qualifies for `braceelide`. `option
warnstyle banner` restores upstream Ghidra's full
`/* WARNING: ... */` lines, exercised by
`tests/stages/kuna-cnorm-warnstyle.xml`.

## 9.1 Casts

An equal-width `CAST` involving a complete struct or union transfers its object
representation in C (`kuna_aggregatecast.rs`). Emission uses a union compound
literal with the actual declared source and destination types, evaluating the
source once. Both types and both varnodes must have the same positive size;
field accesses use their field type. Numeric floating-point conversion opcodes,
incomplete records, arrays, and unequal widths are excluded. Recursive layout
checks exclude padding, bitfields, and unions with shorter members; aggregate-typed
constant inputs are also excluded.
The operation's input-facing or definition-facing type must itself be an
aggregate; a scalar access backed by an aggregate stack declaration does not
establish a whole-object transfer. The destination is the type the printed
destination has: the declared variable or field type when the CAST's output is an
explicit variable, else the definition-facing type of the implied value. When an
explicit scalar variable receives a scalar source the transfer is not an aggregate
one and the scalar bit-transfer rules apply instead.

**The pass.** `ActionSetCasts` (registry row P9/`cast-policy`, group `casts`)
is scheduled near the very end of the pass tree — after `ActionNameVars` and
before `ActionFinalStructure`
(`decompiler/crates/kuna-decomp/src/infra/universalaction.rs
(universal_sched)`); its driver is
`decompiler/crates/kuna-decomp/src/p9_emit/coreaction_casts.rs
(Funcdata::action_set_casts)`. It walks basic blocks in order and the ops of
each block in sequence (a snapshot per block, so ops it inserts are never
revisited), skipping unprinted ops and existing CASTs. Per op, in a fixed
order: repair PTRADD/PTRSUB ops whose pointer type no longer fits (below),
give every unresolved union edge a last chance to resolve, cast the *inputs*
first (the output token may depend on them), then the output.

**The decision oracle.** The per-edge question — "does this conversion need a
visible token?" — is delegated to the language's cast strategy,
`decompiler/crates/kuna-decomp/src/p9_emit/cast.rs (CastStrategy)`, with
`cast.rs (CastStrategyC)` the C rules (`CastStrategyJava` exists for the
deferred Java back-end, §9.6). The strategy answers four kinds of question:
does an assignment between two data-types need a cast (`cast_standard`); is a
ZEXT/SEXT/SUBPIECE representable as a cast at all
(`is_zext_cast`/`is_sext_cast`/`is_subpiece_cast`); does C integer promotion
already imply a conversion (`int_promotion_type` and friends); and what type
does integer arithmetic naturally produce (`arithmetic_output_standard`). The
simple case of `cast_standard`: identical types (or typedefs of the same base)
never cast; a value coming from `void` always casts; a size change always
casts; and within same-size integers the int/uint/bool/unknown family is
mutually cast-free unless the operator *cares* about signedness (the
`care_uint_int` flag comparisons and pointer targets set). Pointer pairs are
peeled in parallel first — different word sizes or different address spaces
force a cast, `void *` never does, and once inside a pointer the signedness
care is always on.

An unknown scalar destination prints as integer storage, so assignments from
pointers still require a conversion when `care_ptr_uint` is set. The unknown
metatype cannot suppress that conversion merely because its bit width matches
the pointer. Numeric values and compatible unknown pointees keep the existing
cast-free behavior. This also preserves the pointer bits stored through an
inferred integer pointer without changing the inferred destination contract.
An unknown call-argument type is instead an ABI placeholder unless that
parameter is type-locked. `kuna_unknowncasts.rs` checks the declared contract
before requesting the pointer conversion; untyped calls and internal user-op
arguments retain their pointer expressions and string literals.
With stackviews enabled, a volatile write uses its locked storage contract when
inserting casts. Its stored value is an assignment to declared C storage rather
than an untyped user-op argument, including a pointer view retyped by an object
assertion.

`FLOAT_TRUNC` converts a floating value to a signed integer of its output
width. If a merged variable is unsigned (including an unsigned enum), cast
insertion keeps a signed conversion temporary before converting its integer
bits to that variable's type. Boolean destinations retain their existing
conversion of the truncated signed value to a truth value. An unsigned
destination must not turn the floating conversion itself into a C
floating-to-unsigned cast: negative values in the signed range would
then acquire undefined behavior. Ordinary signed destinations retain their
existing conversion. This correctness repair is architecture independent and
needs no option; it does not model floating exception state or define C casts
outside the signed integer's representable range.

**Integer promotion.** C silently promotes small integers, so many extensions
must *not* print. The strategy classifies a sub-`int` value's promotion as
unsigned, signed, either, or unknown (`cast.rs
(CastStrategyC::int_promotion_type)`, an IR walk that recurses through the
value's defining ops; the promotion width is the target's `sizeof(int)`,
`cast.rs (CastStrategyC::new)`). A ZEXT/SEXT whose input promotes compatibly
is *implied* and emits nothing (`is_extension_cast_implied`, consumed by the
printer's extension arms in §9.2); comparisons and the signedness-sensitive
div/rem/shift ops only accept a cast-free operand when both sides promote the
same way (`check_int_promotion_for_compare`/`check_int_promotion_for_extension`).
When a constant's printed form would change its arithmetic class, the strategy
instead flags the constant for suffixing — `mark_explicit_unsigned` (the `U`
suffix) and `mark_explicit_long_size` (the `L`/`LL` suffix) — which the
literal formatter reads back at §9.2's constant push.

**Casting an input.** `coreaction_casts.rs (Funcdata::cast_input)` asks the
per-opcode `getInputCast` surface (`coreaction_casts.rs (get_input_cast)`)
what type the operator requires at that slot: LOAD/STORE coerce the pointer to
match the moved value, EQUAL-class compares coerce both sides to the more
ordered of the two operand types (an integer `==`/`!=` with a float operand
excepted, below), LESS-class compares and div/rem/shift gate on promotion, PIECE/SUBPIECE/INSERT never cast, and everything else falls to
the default `cast_standard(input-type-local, read-facing-high-type)`. A `None`
answer means no cast — only the constant-suffix marking runs; the STORE's value
slot returns `None` for a `code` pointee under `codescalar` (chapter 05), which
is the printing half of that option. Otherwise the
machinery avoids stacking tokens: a value already produced by a CAST is
retyped or bypassed rather than double-cast; a constant is simply retyped;
and a pointer-to-struct being read as pointer-to-its-first-field inserts a
`PTRSUB(ptr, #0)` — rendered as `&ptr->field` / `ptr->field` — instead of a
cast (`coreaction_casts.rs (test_struct_offset0)`). Only when all of that
fails is a real `CPUI_CAST` op inserted before the reader, with an implied
unique output carrying the required type. The new CAST inherits the union
field the reader had selected at that slot, both for a high whose own type
needs resolution and for the high's declared storage symbol when that symbol
is a union but the high's preferred type is scalar. The operand then prints as
`storage.integer` rather than a cast of the whole `storage` union, which C
rejects. Only an existing selection is copied; no field is chosen anew.

**A float stored into unknown bytes (kuna).** `cast_standard` needs no cast
into `TYPE_UNKNOWN`, so upstream prints a float stored through a pointer to
unknown bytes as `*puVar1 = fVar2`, a bit copy into an `undefined4`. kuna's C
declares unknown bytes as an integer, and the same assignment is C's numeric
float-to-integer conversion: a pointer whose other stores are integer bit
patterns (clang stores a `1.0f` constant as `0x3f800000` from an integer
register) printed its `vstr`, `movss` or `str s0` store as `v1[2] = a0 * a1 +
0.5f;` beside `unsigned int *v1`. At the STORE's pointer slot, when the
pointee (through typedefs and qualifiers) is unknown bytes and the stored value
is a float of the same size, `get_input_cast_store` asks for a pointer to the
value's type with the pointee's qualifiers (`kuna_floatstore.rs (pointer)`),
and the store prints as `*(float *)&v1[2] = a0 * a1 + 0.5f;`; the value slot
then matches its pointee and takes no cast. It applies only while unknown bytes
print as an integer (`realtypes` on, or an output language with no
unknown-bytes type, such as Rust's `*mut u32`): with `realtypes` off in C the
pointee prints as `xunknown4`, upstream's bit copy, and the store keeps
upstream's text. A float narrower than C's `float` (a half float) has no C type
to point at and is left alone. This is a correctness fix with no option.

**A signed read of an unsigned-printing expression (kuna).** The `U` suffix
`mark_explicit_unsigned` gives a constant makes its whole C expression
unsigned (`a0 - 1U`), and so does an operand declared `unsigned` or
`undefinedN` at the expression's own width or wider, but the Varnode the
expression computes keeps the signed type the rest of the function gave it.
A reader that treats its input as signed -- `INT_SEXT`, `INT_SRIGHT`'s value,
`INT_SLESS`/`INT_SLESSEQUAL`, `INT_SDIV`/`INT_SREM`, `FLOAT_INT2FLOAT` -- checks
that signed type, finds nothing to cast, and the printed C applied unsigned
semantics where the machine applies signed ones: glibc's `__sigismember`
indexed its set by `(unsigned long)(long)(a1 - 1U) >> 6`, a zero extension
of `sig - 1`, and `v34 - 0x18U >> 6` shifted logically where the binary shifts
arithmetically. When the input of such a reader is an implied expression of
an operation that takes the sign of its operands, and one operand prints
unsigned at least as wide as the expression (a `U` literal is an
`unsigned int` unless its value needs eight bytes, so `0x80U - (long)s` stays
a signed `long`), `get_input_cast` asks for the signed integer of the input's
size (`decompiler/crates/kuna-decomp/src/p9_emit/kuna_signedread.rs (cast)`),
and the read prints `(unsigned long)(int)(a1 - 1U) >> 6`. The suffix stays: an
unsigned reader of the same expression (`4 < a4 + 2U`) still needs it. This is
a correctness fix with no option.

**An unsigned read of an expression C evaluates as signed (kuna).** The
mirror case: C promotes an operand narrower than `int` to `int`, so
`(*a1 ^ 0x80) - 0x80` over an `unsigned short *a1` is an `int` in C, and so
is `(int)a0 + 1`, while `arithmeticOutputStandard` types the 32-bit Varnode
they compute `unsigned int` (it takes the most ordered operand type and
knows no promotion). A reader that treats its input as unsigned --
`INT_ZEXT`, `INT_RIGHT`'s value, `INT_LESS`/`INT_LESSEQUAL`,
`INT_DIV`/`INT_REM` -- found nothing to cast, and the C read the value as
signed: `(unsigned long)((*a1 ^ 0x80) - 0x80)` sign-extended where the
32-bit operation zero-extends, and `>> 3` shifted in copies of the sign bit.
When such a reader's input is an implied expression at least as wide as
`int`, typed unsigned, whose C type is a signed `int` or `long`, the read
makes it unsigned (`decompiler/crates/kuna-decomp/src/p9_emit/kuna_unsignedread.rs
(cast)`): a plain non-negative constant operand of the expression's top
operation gets the `U` suffix when that operation's result bits do not depend
on its sign (`+`, `-`, `*`, `&`, `|`, `^`, negation; never a division,
remainder or shift, whose meaning the suffix would change),
or `UL` at eight bytes, so `(int)a0 + 1` prints `(int)a0 + 1U`; otherwise
`get_input_cast` asks for the unsigned integer of the input's size, and the
read prints `(unsigned long)(unsigned int)((*a1 ^ 0x80) - 0x80)`. The C
type is worked out bottom-up from what the text states: a literal from its
suffix and magnitude, a variable, a cast or a load from its type, an
extension the cast strategy hides from its input, and arithmetic by C's usual
conversions over promoted operands; anything else leaves the read alone. Neither
happens when the input's nonzero-bit mask clears the top bit (the
value is never negative, so both readings agree), or when the other operand
of a compare, divide or remainder is unsigned at least as wide (C then
converts this one itself). Expressions narrower than `int` are left to the
upstream integer-promotion checks (`checkIntPromotionForCompare`,
`checkIntPromotionForExtension`). This is a correctness fix with no option.

**A switch on an expression narrower than `int` (kuna).** A `BRANCHIND`
selector of one or two bytes is computed at its own width, so a byte
`a0 + 1` is 0x80 when `a0` is 0x7f, but C adds the promoted operands as
`int`: `switch(a0 + '\x01')` switched on 128 and missed the `case -0x80:`
the binary takes. The upstream promotion checks cast such an expression where
an extension or a comparison reads it, and nothing reads it at a switch. The
printer now casts an implied selector narrower than `int` to its own type,
`switch((char)(a0 + '\x01'))`, unless `intPromotionType` says its promoted
value already extends the way that type does
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_narrowselector.rs (cast)`). The
case labels already follow the selector's type. Only output languages with C's
integer promotion get the cast. This is a correctness fix with no option.

**A narrow equality of mixed sign (kuna).** An `INT_EQUAL` or `INT_NOTEQUAL`
of operands narrower than `int` compares their bytes, but C promotes each side
to `int` by the sign of its own type before it compares. The upstream rule casts
both sides to the more ordered of the two types only where an operand's
promotion is unknown (an implied sum, a product); an operand that prints as its
own type (a load, a call, a declared variable, a constant) keeps it. So a byte
sum cast to `unsigned char` met a constant that kept the `char` type of the
loaded byte, and `(unsigned char)(a1 + *a0) == '\x80'` was never true, since C
compares 0..255 with -128; a `char` load beside an `unsigned char` variable
differed the same way whenever the top bit was set. `coreaction_casts.rs
(get_input_cast_equal)` now also casts an operand whose integer type has the
other sign than the compared type, unless the nonzero-bit mask of either side
says its top bit is clear (a constant like `0x7f`, a value masked to seven
bits): such a side promotes the same either way, and the comparison then holds
exactly when the bytes do (`promotes_with_other_sign`). The constant
above is retyped and prints `0x80`, and a variable prints `(unsigned char)v`.
The more ordered type can also be `bool`, and casting an integer to `bool`
turns every nonzero value into 1: `(bool)*a0 == (a1 != 0)` held for a byte of 2
where the binary's byte compare does not. An integer operand beside a `bool`
of its size is the compared type instead (`integer_beside_bool`), and the
comparison prints `*a0 == (a1 != 0)`. This is a correctness fix with no option.

**Integer equality on float bits (kuna).** An `INT_EQUAL` or `INT_NOTEQUAL`
compares bits, but when the more ordered operand type is a 4- or 8-byte float
the upstream rule coerces both sides to the float, and the comparison printed
as a C float `==`: `(v.u == 0x80000000u)` printed `a0 == -0.0`, true for
`+0.0` too; `(v.u & 0x7fffffff) == 0x7fc00000` printed `ABS(a0) == NAN`, never
true; and an `==` of two floats' bits printed `a0 == a1`, false for equal NaNs.
The ordered integer compares already require an integer type and reinterpret
the float. `coreaction_casts.rs (get_input_cast_equal)` now requires the
integer operand's type, or `unsigned int` / `unsigned long long` of the width
(`float_bits_type`), so each float side takes a `CAST` that prints as the union
reinterpretation above and a constant is retyped to the integer and prints in
hex (`((union { float from; unsigned int to; }){ .from = a0 }).to !=
0x80000000`; Rust `(a0).to_bits() != 0x80000000`). The float comparison is kept
where, under the default (non-flushing) floating-point environment, it decides
exactly what the bit test does (`float_compare_is_exact`; with DAZ/FTZ set a
denormal's `ABS` compares equal to `0.0`): against a constant that is a normal number or an
infinity whose shortest digits, read back as a `double`, are its value
(`kuna_floatbits.rs (compares_as_a_float)`, chapter 05), so the bits of `1.0f`
still print `a0 == 1.0f`; and against `+0.0` when the other side is a
`FLOAT_ABS`, which is never `-0.0` and as a NaN equals neither, so
`ABS(a0) == 0.0f` stays. A constant whose shortest digits spell another double
(`-7.4544637e-06`, `1.4013e-45`) prints its bits instead.
`FLOAT_EQUAL`/`FLOAT_NOTEQUAL` are other opcodes and still print `a == b`.

**Narrowed call arguments (kuna).** Dead-code analysis counts only the
possibly-nonzero bits of a call input as consumed, so when a caller
zero-extends a sub-`int` value into its argument register the subvariable-flow
rules (chapter [03](03-ssa-and-simplification.md)) trim the input to the narrow
value: `RDI = ZEXT(x:2)` becomes the 2-byte `x`. The p-code is right, but C
promotes a sub-`int` argument expression to `int` before the call, so the
default arm alone printed `sink(a0 * 3)` for a callee that reads the whole
register, passing a value the binary never passed.

That trim is the evidence that the binary zero-extended. When
`decompiler/crates/kuna-decomp/src/p3_dataflow/subflow.rs
(SubvariableFlow::try_call_pull)` narrows a call input whose non-zero mask lies
inside the logical mask (`decompiler/crates/kuna-decomp/src/p9_emit/kuna_truncarg.rs
(drops_only_zero_bits)`), `do_replacement` records the slot, its new size and
the call's input count on the call's `FuncCallSpecs`
(`kuna_truncarg.rs (note_trimmed_arg)`). A later trim of the same slot that
drops possibly-nonzero bits clears the record. A narrow input with no record
keeps its promoted form, because nothing says which extension the binary
used. Three kinds of input have no record: a narrow parameter forwarded
untouched, a sign-extension trimmed because the callee reads only its low
bytes, and an input that was narrow from the start. clang forwards a narrow
parameter as the register it received (`mov %dil,acc8; jmp sinki`), relying on
the caller's extension, so an unsigned cast there would pass 255 where the
binary passed -1.

The default arm consults `kuna_truncarg.rs (narrowed_arg_cast)` whenever
`cast_standard` asks for nothing. The input must be recorded, still at the
recorded size in a call with the recorded input count, narrower than
`sizeof(int)`, integer- or unknown-typed and not an enum, and in a slot no
declared prototype type-locks. For such an input it asks whether the
argument's promoted C value is already the zero-extension of the p-code value:
`int_promotion_type` answers for an expression, the natural extension of the
type the value prints as for a variable, a load or a cast, and a ZEXT always
is. The type it prints as is not always the one the cast strategy sees. A
one-byte value no pass ever typed is TYPE_UNKNOWN, which upstream's promotion
tables treat as unsigned, but `realtypes` spells it `char` in C output, and C
sign-extends a `char` wherever it is signed. A trimmed byte load (`movzbl`)
reads exactly that way, `sink(*(char *)(a0 + 3))`. The check therefore runs
through a view of the cast context (`coreaction_casts.rs
(FuncdataCastContext::with_unknown_byte_as)`) that reports a non-constant
one-byte TYPE_UNKNOWN as the signed `int1`, for the argument and for the
operands its promotion looks at. The view is on only when the per-function
`ArchContext::unknown_byte_is_char` says the printer spells such a byte
`char` (`realtypes` on, C output); with `realtypes` off the byte prints as
`xunknown1` and keeps the unsigned reading. When the promoted value is not the
zero-extension, the argument is cast to the unsigned integer of its own width,
as in `sink((uint2)(a0 * 3))` and `sink((uint1)*(char *)(a0 + 3))`. The cast
restores the zero-extension the trim removed. Two cases get no cast. The first
is an expression whose C value provably lies in `[0, 2^(8*size))`, such as
`(a0 != 2) + 6`, where promotion cannot change the value
(`kuna_truncarg.rs (c_range)`). The bound is taken over constants with a clear
sign bit, truth values, and `+ * & | ^` of those. The second is a slot whose
parameter type a declared prototype locks, because C converts the argument to
that narrow type itself. An argument that already prints as a truncating cast
(a SUBPIECE rendered `(char)v2`, every read of which is a call argument) is
retyped to the unsigned type rather than given a second cast
(`kuna_truncarg.rs (retype_truncation)`). Upstream Ghidra prints the promoted
form. Where the callee's own definition also declares the narrow parameter the
cast is redundant, though never wrong. Only an output language whose
`LangCaps::integer_promotion` is set gets the cast (C, read through
`ArchContext::int_promotion`). Rust arithmetic keeps its operands' width, so
`sink(a0 * 3)` with a `u16` `a0` already carries the truncation there. The rule
has no option because it only restores a conversion the binary performed.
Pinned by `tests/stages/kuna-truncarg.xml`.

**An `int`-wide trimmed argument.** The same trim cuts an 8-byte register the
binary zero-extended a 32-bit value into (`mov %edi,%edi`, any 32-bit write on
x86-64, `uxtw` or a `w` register on AArch64) back to the 4-byte value. C then
converts that `int`-wide argument to the callee's parameter by its own sign: a
signed `int` whose top bit is set reaches a `long` parameter sign-extended, the
opposite of what the binary passed, though promotion itself changes nothing at
this width. `narrowed_arg_cast` therefore also takes a recorded input exactly
`sizeof(int)` wide (`kuna_truncarg.rs (int_arg_cast)`), but only where the
callee is known to read the register wider: `decompile-all`'s callee-first
`protoorder` statement for the callee gives the parameter in the same storage
more bytes than the argument (`kuna_truncarg.rs (callee_reads_wider)`). Without
that statement the parameter may be exactly the argument's width, and C
converts to it exactly. Under it, an argument whose C type is signed
(`kuna_unsignedread.rs (c_int)`, else its read-facing type) and whose
nonzero-bit mask leaves the top bit possibly set is cast to the unsigned
integer of its width: `sinkl((unsigned int)v1)`. A declared prototype that
locks the slot again gets no cast. The signedness walk counts the same reader
as an unsigned demand (`kuna_truncarg.rs (zext_trimmed_arg)`), so a variable
it would otherwise re-declare `int` for a signed comparison stays `unsigned
int` there, and `sul(v2)` keeps zero-extending. A value the binary
sign-extended (`movsxd`, `sxtw`) leaves no record and keeps `sinkl((long)v)`.
Pinned by `tests/cli/zero-extended-int-argument-keeps-its-extension.json`.

The default arm has one more fallback, for the target of an indirect call. A
pointer to the prototype-less `code`, or to `void`, needs no cast under
`cast_standard`, which never casts to or from either, but C cannot call it.
When `calltargettype` recorded the type the call states for a target it could
not give that type -- its uses disagree, or a declaration fixes another type --
and the target is still such a pointer,
`decompiler/crates/kuna-decomp/src/p5_types/kuna_calltargettype.rs
(uncallable_target_cast)` returns that type and the target is cast to it at the
call (chapter [05](05-types.md)), in C output only. With the same option on in
C output, `cast_standard` also prints no cast between a record's declaration and
its completed definition, which the factory holds as two types and C spells
alike (`CastStrategyC::with_record_identity`).

One value-changing case is still open. A 32-bit argument trimmed out of a
64-bit register keeps its `int` type, so `sink64(a0 * 3)` with `int a0`
reaches a callee defined as `void sink64(unsigned long a0)` sign-extended,
where the binary's 32-bit write zero-extended it. It is left alone because
nearly every `int` argument on x86-64 is such a trim, and the cast would land
on all of them to fix the few whose callee reads the full register.

**Byte-pointer arguments
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_pointerargs.rs`).** Buffered
`decompile-all`, `decompile-project` and `decompile-graph` reconcile C calls after selecting their
final successful function results. When a caller passes the address of a whole
scalar local or parameter to a character-pointer parameter (`char *`,
`unsigned char *`, or an undefined byte printed as `char`), the call is cast to
that emitted parameter's type: `sink((unsigned char *)&v1)` for `unsigned long
v1`. Parameter position and finalized ABI storage must agree. The local keeps
its declared type and width; C allows a character pointer to access its bytes.

The printer records declarations and exact argument positions with each result,
only for a driver that asks; the batch that returns the final results applies them.
The buffered driver uses only the accepted results, after any type convergence
or worker structure renaming. Failed, omitted, and conflicting definitions
cannot supply a cast. Workers transport the records; this reconciliation never
re-decompiles a function. Address order, recursive call ordering, filtered
selections and `protoorder off` do not disable the conversion. `protoorder`
continues to control inference independently.

Arrays, structures, unions, members, other pointer expressions, varargs and
per-call prototype overrides abstain. A byte local of another signedness also
retains the existing spelling. No text search identifies a call: each recorded
position must still contain its recorded expression before its cast is added. A
position that does not (an emitter defect) leaves only that argument uncast.
The inserted text contains no newlines. No buffered driver captures token maps;
a result that did would have its map withdrawn rather than left misaligned.
Structure renaming first adjusts the recorded byte columns. Streamed exports, non-C output and standalone `decompile` do not
reconcile incomplete batches. The worker path still matches
serial output with `--option protoorder off` on both.

**Casts C already performs (kuna `castimplied`).** `is_extension_cast_implied`
hides an extension only when integer arithmetic, or a comparison against an
explicit operand of the same metatype, reads it; for every other reader, and for
any extension at the top of a statement, it answers no. So upstream prints
`memchr(v10,(int)v4,n)` where `memchr` declares an `int`, `v2 = (long)v1;` into
a `long v2`, `return (unsigned long)v1;` from an `unsigned long` function, and
`(long)(int)(unsigned int)(unsigned char)c` for one byte widened to 64 bits. C
performs each of those conversions itself: an argument is converted to its
parameter's type when a prototype is in scope, the right side of `=` to the type
of the left, a returned value to the return type, and a conversion between
integer types depends only on the value converted. With the option
`castimplied` on (the default; `off` restores upstream's rendering), the printer
leaves such a cast out
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_castimplied.rs (ImpliedCasts::drops)`,
asked from `printc.rs (PrintC::implied_cast_drops)` by the `CPUI_CAST` arm and
by both extension arms). The IR keeps every CAST op; only the token is omitted,
and the operand is pushed bare, as a `signedness`-dropped cast's is (§9.3).

Only integer conversions are considered: a `CPUI_CAST` between integer types,
or an INT_SEXT/INT_ZEXT the strategy renders as a cast. Consecutive conversions
form a chain whose top is the first one read by something that is not an
integer conversion. The top fixes the type of the whole chain, so a conversion
below it goes when it keeps its operand's value: every value of the operand's
printed C type lies in the conversion's target range (`kuna_castimplied.rs
(preserves)`). The operand's C type is taken as known only where the text states
it: a declared variable (the spelling the declaration line wrote), a conversion
that still prints (its target), a conversion this rule leaves out (its own
operand's type, which it preserved), a truncation printed as a cast, a load
`*(T *)p` through a pointer printed with that cast or declared `T *`, and a
subscript `((T *)p)[k]` whose base prints with that cast (the form `castarith`
below gives a load). With `elemptr` on (05-types §5.2), whose declarations
produce subscripts of declared pointers, a subscript `p[k]` of a variable the text
declares `T *`, or of a constant printed as an array name or behind its own cast,
reads a `T` as well (`ImpliedCasts::subscript_base_type`), so the `(int)` a `?:`
arm of `a0[i]` carries is the conversion C performs. So does a subscript of a
global no symbol names that `elemptr` typed, `dat_5068[k]`: the export header
declares it at the one type the function reads and writes it at (`kuna_globalref.rs
(Plan::declared_type)`, what `extract_global_objects` writes, §9.9), and a
subscript reads that type's pointee when it is the pointer the base is read at. An
arithmetic operand is not known, because C promotes `a - b` over two
`unsigned char`s to a negative `int` where the p-code wraps; neither is a
constant or a call. Under that rule `(long)(int)(unsigned int)(unsigned char)c`
becomes `(long)(unsigned char)c`: the `unsigned char` value passes through
`unsigned int` and `int` unchanged. A sign change or a narrowing below the top
always stays, as does anything under a pointer or float conversion.

The top itself goes when it is an identity (its operand already has exactly
that C type), or when it is a value-preserving widening whose value flows
straight into one of three places C converts at. The first is an argument of a
direct call whose parameter is type-locked (a declared prototype or a measured
libc signature), spelled exactly as the cast; a trial prototype, a varargs
position, a call carrying a per-call-site prototype override (a resolved format
string closes its varargs into ordinary parameters that way), and an argument
`truncarg` narrowed on purpose are all refused (`kuna_castimplied.rs
(trusted_param)`). The second is the right side of a `lhs = e;` statement whose
left side is a local or parameter the printer declared with exactly that
spelling. The arms of `c ? a : b` do not count here: their type is the two
arms' common type, not the destination's (`castternary`, below, handles them).
The third is `return` from a function whose
printed return type is that spelling. The declarations are recorded as the
printer writes them (the header's return type and parameters, each local's
declaration line), so the comparison is on the text C will see. One more
destination counts when `castsign` is on (§9.3): the left side of `lhs = e;`
whose declaration `signedness` re-signed, when the declared type is as wide as
the cast's target (`kuna_castimplied.rs (ImpliedCasts::assigns_to)`). A
conversion to an N-bit integer depends only on the value modulo 2^N (C11
6.3.1.3 for the unsigned case; gcc and clang define the signed case the same
way), so `lhs = e;` stores the bits `lhs = (T)e;` stored whatever `e`'s C type
is. Without it, re-declaring `unsigned long v18;` as `long v18;` would bring
back the `(unsigned long)` this rule dropped from `v18 = dat_dd86c << 3;`
because the spellings used to match. An implied
COPY prints as its operand and is looked through (`kuna_castimplied.rs
(through_copies)`). `truncarg`'s argument casts and `boolbyte`'s
`(bool)(unsigned char)` are never candidates, and nothing is dropped for an
output language without implicit integer conversions (Rust). The ported
`CastStrategyC` and its pinned decision matrix are unchanged. Pinned by
`tests/stages/kuna-castimplied.xml`, and by a compiled round trip
(`kuna-cli/tests/decompile_all_cli.rs`, `an_implied_cast_round_trips_through_the_printed_c`)
whose functions print the same values with the option off and on, under gcc and
clang.

**Casts the conditional performs (kuna `castternary`).** `iteregion` prints an
assignment diamond as `dest = c ? a : b;`, and each arm keeps the cast the IR
put on it: a table-driven decoder reads `v2 = (s[i] != '=') ? (int)*(char *)(t +
s[i]) : 0;`. The same diamond printed as if/else has no cast, because
`castimplied` leaves the widening out of `v2 = *(char *)(t + s[i]);`. The second
and third operands of `?:` undergo the usual arithmetic conversions (C11
6.5.15p5, integer promotion first), so the conditional converts the `char` arm
to `int` by itself. Leaving one arm's cast out can change the type of the whole
conditional, though: `c ? (long)i : u` is a `long`, while `c ? i : u` is an
`unsigned int` for an `int i` and an `unsigned int u`, and a negative `i` then
reaches the destination as a large positive value. With the option
`castternary` on (the default; `off` keeps every arm cast), the printer asks,
once per conditional, which arm casts to leave out
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_castternary.rs (arm_drops)`,
from `printc.rs (PrintC::conditional_arm_drops)` in `emit_block_if_ite`); the
chosen ops are then left out wherever `printc.rs (PrintC::implied_cast_drops)`
is asked about them. An arm's cast goes when it is an integer widening that
keeps its operand's value (never a narrowing, a sign change, a conversion from
or to `bool`, an enum, a float or a pointer), when the usual arithmetic
conversions of the two arms give the cast's target type both as printed today
and with the cast left out, and when the conditional is assigned to a variable
declared with an integer type. The conditional then converts the arm to the
target itself, which is the conversion the cast spelled, and keeps its own type
and value, so the assignment stores what it stored before, whatever integer type
the destination has. A destination declared as a pointer (a merged variable
whose other pieces are addresses) keeps its casts. Each arm's C type is carried
as the set of promoted types (`int`, `unsigned int`, and the 8-byte signed and
unsigned integers) it may have (`kuna_castternary.rs (value_set)`): exactly one
for what `castimplied` knows the type of (a declared variable, a cast that
stays, a load through a pointer printed with its pointee type), every promotion
its width allows for any other expression, and for a literal the type C gives
the token the printer writes for it (`kuna_castternary.rs (literal_type)`, from
`printc.rs (PrintC::integer_constant_token)`, which shares the formatting of
`push_vn_explicit_ir`): the base, the suffix, and the first candidate type that
holds the magnitude, so `0xffffffff` is an `unsigned int` and an unsuffixed
`3000000000` a `long`. The conversions must give the target for every
combination of the two sets (`kuna_castternary.rs (common)`). When both arms
carry a cast, both go only when the conditional over the two bare operands still
has the target type, else one of them (`kuna_castternary.rs (choose)`):
`c ? (unsigned long)a0 : (unsigned long)a1` over `int a0` and `unsigned int a1`
keeps the sign-changing first cast and prints `c ? (unsigned long)a0 : a1`. Only
where `int` is 4 bytes, and only for C output. Pinned by
`tests/stages/kuna-castternary.xml` and by a compiled round trip
(`kuna-cli/tests/decompile_all_cli.rs`,
`a_conditional_arm_cast_round_trips_through_the_printed_c`) over a textbook
base64 decoder and arms of `char`, `unsigned char`, `short` and `int` against
`int`, unsigned, `long` and negative arms, built with gcc and clang at -O0 and
-O2, printing the binary's values with the option off and on.

**Widenings C performs by itself (kuna `castwiden`).** Upstream hides an
INT_SEXT/INT_ZEXT under arithmetic only when the other operand is an explicit
variable of the same metatype (or a constant no wider than `int`), so a widened
`int` beside a loaded `long` prints `((long *)a0)[1] + (long)a1`, beside a
structure field `a0->field_0x8 % (long)a1`, beside a literal `(long)i * 0xc + 7`,
and into a store through a `long` pointer `((long *)a0)[1] = (long)a1;`. With the
option `castwiden` set to `on` (`off` keeps them; `literal`, the default, is
described below), the printer leaves out a 64-bit widening where C's own
conversions give the same type and value. The IR is unchanged; the decision is
made per arithmetic op, once, and cached for the function
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_castimplied.rs (ImpliedCasts::widen_plan)`,
computed by `decompiler/crates/kuna-decomp/src/p9_emit/kuna_castwiden.rs (plan)`
and read by `printc.rs (PrintC::implied_cast_drops)`).

An operand of `+ - * / % & | ^` qualifies when it is an INT_SEXT or INT_ZEXT
printed as a cast to an 8-byte integer, or a `CPUI_CAST` to one over an operand
`castimplied` left narrower, and the extension is the one C performs on the
operand's printed type: a sign-extension of a signed type, a zero-extension of
an unsigned one (`kuna_castwiden.rs (widening)`). Its cast goes when, for every
promoted type the other operand may have as printed, the usual arithmetic
conversions give the operation the same type with and without the cast, and
that type is the cast's own or the cast keeps every value of its operand
(`kuna_castwiden.rs (fits)`): C then converts the operand to the operation's
type itself, and an integer conversion depends only on the value it converts.
The other operand's type is the set `castternary` uses, derived from the
printed text (`kuna_castwiden.rs (operand_set)`): a declared variable, a
conversion that stays, a literal's C type, a load through a pointer printed as a
declared variable, a cast, a structure field or an element of such a base
(`kuna_castwiden.rs (load_type)`), and for a nested arithmetic op the usual
conversions of its own operands after its own decision (`kuna_castwiden.rs
(expr_set)`). Anything else is unknown and keeps the cast. Of two widened
operands only the right one's cast goes, so `(long)a * (long)b` prints
`(long)a * b` and the survivor keeps the product 64-bit. An op that reads one
widened value in both slots, `(long)i * (long)i`, keeps both casts: the printer
asks about a cast per reading op, not per slot, so leaving one out would leave
out both and print a 32-bit square. A zero-extension beside a signed 8-byte
operand keeps its cast, because the bare operand would make the operation signed
(`*a0 + (unsigned long)*a1`), and so does every widening a comparison, a shift
or unary minus reads.

Leaving a cast out must not change how C groups the text. The operand prints as
upstream's hidden extension does (`printc.rs (PrintC::widen_drops)` pushes the
hidden-function token instead of the cast), which parenthesizes it whenever its
operator binds no tighter than the reader's: `((long *)a0)[1] + (long)(a1 + a2)`
prints `((long *)a0)[1] + (a1 + a2)`, never `((long *)a0)[1] + a1 + a2`, which C
would compute as two 64-bit additions. And since the printer writes `x + (y + z)`
as `x + y + z` (the same associative operator on the right takes no
parentheses), which C groups as `(x + y) + z`, the left operand of `+ * & | ^`
whose right operand is such a chain meets the chain's first leaf in C, not the
chain: its cast goes only when that leaf, as printed, would let it go
(`kuna_castwiden.rs (first_leaf_fits)`), so `(long)a + ((long)b + *p)` prints
`(long)a + b + *p` and not `a + b + *p`.

`on` also widens `castimplied`'s destinations for a widening to eight bytes
(`kuna_castimplied.rs (ImpliedCasts::converts_exactly)`,
`(ImpliedCasts::fits_dest)`; a narrower widening keeps what `castimplied`
decides): a widening that does not keep its value, `(unsigned long)i` of an `int`, goes into an
assignment, prototyped argument or return declared with exactly its spelling,
because that conversion is the one the cast spelled; a value-keeping widening
also goes into an integer of the cast's width with the other signedness, as
`memchr(a0,0x78,a1)` for an `int a1` does; and a store through a pointer printed
as a declared variable, a cast, a field or an element is such a destination
(`kuna_castwiden.rs (store_pointee)`).

With `literal`, the operand beside an integer literal qualifies too. The literal
is an 8-byte constant in the IR, but C types `8` as `int`, so today the cast is
what makes `(long)i * 8` a 64-bit product. The literal is printed with the
suffix of its width, `L` (`LL` where `long` is 4 bytes), or `UL` as the unsigned
value of its bits for an unsigned target (`printc.rs
(IntegerLiteral::suffix_as_long)`, asked through `printc.rs
(PrintC::widen_suffix)`), and the cast goes when the suffixed literal has the
cast's type and the operation keeps its type (`kuna_castwiden.rs
(literal_suffix)`): `a0 * 0xcL + 7`, `a0 / 3UL`. A negated literal C types as
unsigned (`-0x80000000`, whose C value is 2^31) keeps the cast, because the
suffix would change its value. Only where `int` is 4 bytes, and only for C
output. Pinned by `tests/stages/kuna-castwiden.xml` (three passes) and by a
compiled round trip (`kuna-cli/tests/decompile_all_cli.rs`,
`an_implied_widening_round_trips_through_the_printed_c`) over gcc and clang
builds at -O0 and -O2, printed with each value and compiled with gcc and clang
at -O0 and -O2 (`-fwrapv`, so the 32-bit arithmetic kuna prints as `int` wraps as
the machine's does), all printing the binary's values for negative inputs,
0x80000000..0xffffffff, sums past 32 bits and squares past 2^32, including the
shared, parenthesized and regrouped shapes above.

**Narrowings C performs by itself (kuna `castnarrow`).** `castimplied` leaves
a widening out where the destination converts the value anyway, and keeps every
truncation and sign change. So a value narrowed into a destination of exactly
the narrow type kept its cast: `v1 = (unsigned int)a0;` into an
`unsigned int v1` from a `long a0`, `*a1 = (char)a0;` through a `char *a1`,
`toupper((int)a0)`, and `return (int)x;` from a function declared `int`. The
destination performs that very conversion (C11 6.5.16.1p2 for `=`, 6.5.2.2p7 for
a prototyped argument, 6.8.6.4p3 for `return`), and a conversion between
integer types depends only on the value converted and the type converted to
(6.3.1.3), so `T v = (T)e;` stores what `T v = e;` stores whatever integer type
`e` has. With the option `castnarrow` on (the default; `off` keeps every
narrowing cast), the printer leaves such a cast out
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_castnarrow.rs (drops)`, asked
from `kuna_castimplied.rs (ImpliedCasts::drops)` and so from
`printc.rs (PrintC::implied_cast_drops)`, which the `CPUI_CAST` arm and now the
cast arm of `printc.rs (PrintC::op_subpiece_ir)` consult with the op that reads
the value). The IR is unchanged. Three printed forms are candidates: a low
SUBPIECE printed as a cast, a `CPUI_CAST` between integer types, and the
`(T)name` the partial-symbol printer writes when an access reads the low piece
of a wider variable (`kuna_castnarrow.rs (drops_partial)`, from
`printc.rs (PrintC::partial_cast_drops)` in `push_partial_symbol_ir`, only when
the cast covers the bare name).

The cast goes when two things hold. First, the value lands whole in a
destination whose printed type is spelled exactly as the cast
(`kuna_castnarrow.rs (destination)`): a plain `lhs = (T)e;` statement whose left
side is a local or parameter declared with that spelling, also inside a comma
condition, but not an arm of `c ? a : b` and not the compound literal a stack
view or a byte-wise store writes (`kuna_castnarrow.rs (plain_statement)`); a
store through a pointer printed with that pointee, as `castwiden` finds it
(`kuna_castwiden.rs (store_pointee)`), but not a bitfield store or a stack-view
`__builtin_memcpy`; a direct call argument whose parameter is type-locked
(`kuna_castimplied.rs (trusted_param)`, which refuses trials, varargs
positions, per-call-site overrides and `truncarg` arguments); or `return` from a
function whose declared return type is that spelling. Implied COPYs are looked
through. Second, the target is a plain integer (not `bool`, not an enum) and the
operand prints as an integer (`kuna_castnarrow.rs (integer_operand)`): a
declared variable, including one of an unknown type the printer spells as an
integer, a cast, a load through a typed pointer, an integer expression whose
operands are all such (`kuna_castwiden.rs (operand_set)`), or a shift of one,
which has its left operand's promoted type. For a piece of a variable, the
variable must be declared with exactly its own type. A constant, a call, a
pointer or a float operand keeps the cast, since C would not convert it
implicitly or would warn. Anything else that reads the narrowed value keeps the
cast too: `v = (unsigned int)a + b` converts `a` before the addition, a
comparison and a conversion over it depend on its narrowed type, and a
destination of another spelling (`*a1 = (int)a0;` through an
`unsigned int *a1`) is left as it is. Only where `int` is 4 bytes, and only for
C output. Pinned by a compiled round trip
(`kuna-cli/tests/castnarrow_round_trip.rs`) over gcc and clang builds at -O0 and
-O2 of `castnarrow_x86_64.c`, printed with the option off and on and compiled
with gcc and clang at -O0 and -O2, each build computing what the source computes
for every input.

**Casting an output.** `coreaction_casts.rs (Funcdata::cast_output)` compares
the *token* type the operator naturally produces — `coreaction_casts.rs
(get_output_token)`: COPY/PTRADD echo the input, arithmetic takes the
promoted meet of its inputs, shifts take the shiftee (bool→int), LOAD reads
through the pointer, PTRSUB/SUBPIECE/PIECE walk composite geometry, default is
the opcode's local output type — against the declared type of the output
HighVariable. An implied output is usually just retyped in place; an explicit
one gets a CAST (or a `PTRSUB #0`, by the same struct-offset-0 test) inserted
*after* the op, splitting the output into a fresh implied unique. A type-locked
implied value that is not feeding a RETURN forces the cast even when the
lattice would allow silence — the user's declared type must stay visible.
A LOAD's token, and the type a STORE asks of its value, is the pointee of the
address; when that pointee is a synthesized structure's pointer to its own
incomplete shell (`structsynth nest`, chapter 05), both take the pointer to the
completed structure instead (`coreaction_casts.rs (resolve_self_pointer)`), the
same type the lattice gave the value, so no cast is printed between a node and
the link it was loaded from. A CALL or CALLIND whose own output type says
nothing (an unlocked callee this caller took no statement from) takes as its
token the return its callee stated to `callrettype` when the caller refused or
withdrew that statement and keeps the result as the other class, an integer
beside a pointer, or holds a float statement's result as a float or raw bytes
(`kuna_callrettype.rs (refused_token)`, chapter 04): the listing declares that
return, so the caller prints the conversion (`v1 = (long)sub_eecc(a0,v3)`)
instead of an assignment C rejects or pointer arithmetic it would scale, and
stores a float through a `float *`. (kuna `floatbits`) Before any of that, a
call to a callee whose float return is the bits of its float-register input
(chapter 05), whose output the caller holds as an integer of the float's width
in another register than the callee returns in (what the call left there),
takes the float as its token (`kuna_floatbits.rs (held_bits_token)`), so the
cast it gains prints as a reinterpretation of the bits, where C would convert
the value.
An unlocked callee recovered returning more of the register than the call's
output holds (`kuna_voidret.rs (narrowed_call_result)`, chapter 04: a 64-bit
`unsigned long` whose caller compares only `eax`) gets its truncation
spelled where the expression the output is printed in uses its sign or width:
an extension, an ordering, a right shift, a division, a conversion to a float,
an equality with a variable or a negative constant, or any equality or
zero-extension after arithmetic that C would carry past the narrow value; a
zero-extension casts to the unsigned word, so `(unsigned int)z32m(a0) + 1 ==
a1` wraps the sum at 32 bits as the binary's `add $1,%eax` does.
`coreaction_casts.rs (Funcdata::cast_narrowed_call)` makes the call write the
callee's whole return, typed as the callee states it, into a fresh implied
unique, and the output a CAST of it, so `(int)z32m(a0) == a1` prints where
`a1 == z32m(a0)` compared a sign-extended `a1` with the zero-extended result
that the binary compares in 32 bits. A result tested for zero, or assigned to a
variable that the assignment converts, keeps the plain call. Over the decbench
binaries most of these are `(int)f(..) == -1` beside a callee recovered
returning 8 bytes.

**Union edges.** A value whose data-type still `needs_resolution()` (a union,
or a pointer to one) is resolved per read/write edge: `coreaction_casts.rs
(Funcdata::cast_resolve_union)` consults the per-function resolution cache and,
on a miss, runs the inference-time scorer once more (`resolve_in_flow`) — the
same last-chance the C++ takes. A resolved pointer edge materializes as a
`PTRSUB #0` carrying the chosen field; a resolved implied value is marked
`implied_field` so §9.2 renders `<def-expr>.field`. Two adjustment passes
(`cast_try_resolution_adjustment`, `cast_try_resolution_copy`) record a
compatible field choice instead of casting when one exists, so unions prefer
field syntax over cast syntax.

**Pointer arithmetic in pointer terms (kuna, `castarith`).** A pointer plus a
constant byte offset reaches this pass as a plain `INT_ADD` whenever chapter 05
could build no `PTRSUB` or `PTRADD` for it: a `void *` base has no field at the
offset and no element size, and a typed base whose element is not the access
width has neither either. The rules above price an `INT_ADD` as integer
arithmetic, so the default arm casts the pointer to `long` on the way in and
the output arm casts the sum back to a pointer on the way out, and a 4-byte
read at `+0xac` prints `*(unsigned int *)((long)a0 + 0xac)`, two casts for one
read. With `option castarith` on (the default, C output only) the driver hands
every such `INT_ADD` to `decompiler/crates/kuna-decomp/src/p9_emit/kuna_castarith.rs
(rewrite)` right after the PTRADD/PTRSUB repairs, so a sum that a repair has just
demoted is seen too, and before any input or output of the op is cast.

`kuna_castarith.rs (plan)` accepts it when one input is a non-constant whose
read-facing type is a pointer into a byte-addressed space, the other is a
constant, and the sum is used as a `T *`. When a lone LOAD reads through the
sum, or a lone STORE writes through it, `T` is the value it moves, which is the
type the LOAD/STORE input cast would otherwise have recast the pointer to
(`kuna_castarith.rs (access_type)`); the sum's own pointee takes precedence when
it is the same type or an integer of the same width, so the pointer keeps the
spelling the old output had. Any other use takes the sum's own pointee, and a
`void` pointee counts in bytes (`char`) only for a value that stays inside the
function (`kuna_castarith.rs (stays_in_function)`): a call argument or return
value carries its type to the whole-program prototype votes of chapter 04, which
must not learn a `char *` the analysis never derived. `T` must be a scalar or a
pointer whose size equals its aligned size. When the offset, read as a signed
constant, is a whole number of `T`s, the op becomes `PTRADD(base, #k,
#sizeof T)` with `k` typed as a signed pointer-sized integer, so a negative
offset is a negative index.

The base is cast to `T *` by a new implied `CPUI_CAST` inserted before the op,
with two exceptions. A variable whose own type is its read-facing type and whose
printed declaration (a parameter's prototype type or a local's declared type,
`decompiler/crates/kuna-decomp/src/p9_emit/printc.rs (declared_variable_type)`,
the lookup the switch printer uses) points at `T` or at an integer of `T`'s width
is used bare (`kuna_castarith.rs (declared_as)`), so the declaration a reader
sees scales the index the same way; a float element never counts, because
converting it changes the bits. An implied CAST read only by this op is
retargeted to `T *`, the way the input machinery above retypes a cast rather
than stack a second one. An implied CAST that other ops read too is left alone,
and the new cast reads that cast's input instead, when the input is an integer
or a pointer (`kuna_castarith.rs (implied_cast_source)`): both casts only
reinterpret the same pointer-sized bits, so `*(uint1 *)(a0[1] + 10)`, whose
integer `a0[1]` the integer form converted to a pointer and straight back,
becomes `((uint1 *)a0[1])[10]` and not `((uint1 *)(unsigned long *)a0[1])[10]`.
The printer then renders the `PTRADD` like any other (§9.2, §9.5):
`((unsigned int *)a0)[0x2b]` under a dereference, and
`&((T *)p)[k]` as a value, or `(T *)p + k` with `arraynotation off`, so the one
spelling decision stays with that option.

The computed value is unchanged: `k * sizeof(T)` is the original offset, the
base is converted pointer to pointer with no integer in between (or, under a
shared cast, from the integer the integer form converted too), the element
is the access width, C's `sizeof` of the printed `T` is that same width, and
the printed index reads back as `k`. The `sizeof` condition is why an enum
element keeps the integer form (`kuna_castarith.rs (plan)`). kuna prints every
enum as a plain `enum`, whose size C leaves to the implementation (an `int`
under gcc and clang), while a packed enum, one compiled with `-fshort-enums`,
or a C++ `enum class : uint8_t` is 1 or 2 bytes in the binary, so
`((color *)p)[3]` would read 12 bytes past `p` instead of 3. For the same
reason the element must be a type the target's data model names at exactly its
width (`kuna_castarith.rs (c_sizeof_is_size)`): an integer of a width the model
has, a one-byte `bool`, a `float` or `double`, or a pointer of the model's
pointer size. A `long double`, whose `sizeof` is 16, 12 or 8 by target, and a
16-byte integer keep the integer form. The index condition is why a negative
index of 2^31 elements or more keeps the integer form too. C gives the literals `0x80000000` through
`0xffffffff` the type `unsigned int`, so `-0x80000000` is +2^31 and
`((long *)a0)[-0x80000000]` would index forward. The integer form's byte offset
is then at least 2^32 in magnitude for any element wider than a byte, a `long`
literal that negates correctly. A positive index keeps its value whatever type C
gives the literal. A one-byte element's offset in the unsigned range is misread
by the integer form as well; that is how the printer spells a negative constant,
and this rule leaves it as it was. The integer form stays wherever the printed C could
otherwise convert a value or cost a cast. An offset that is not a whole number of
elements (`*(unsigned int *)((long)a0 + 0x6a)`), a variable index, an aggregate,
enum or padded element, and a word-addressed space keep it. So does a sum read as an
integer (integer arithmetic on it, a store of it into an integer slot, or an
assignment to a variable declared as an integer, where the pointer form costs
more casts than the integer form), and an address several LOADs or
STOREs share, since only a lone access fixes the element. A STORE of a value
whose defining op the pass has not reached keeps it too, because that op's own
output cast may still retype the value (a float operation's result becomes
`float`) and an integer element would then convert it; it is accepted only when
the opcode fixes the kind, float arithmetic for a float element and integer
arithmetic for a non-`bool` integer one (`kuna_castarith.rs
(store_value_settled)`). Finally, a constant that names a global keeps it, and
so does an address-like constant beside an integer that was cast to a pointer:
`table[i]` compiles to the same `INT_ADD`, with the table as the constant and the
subscript as the "pointer" (`decompiler/crates/kuna-decomp/src/p5_types/kuna_ptrfromuse.rs
(constant_may_be_global_base)`). A record base keeps `p->field` wherever the
offset lands on a field, because chapter 05 already made that access a `PTRSUB`.
An offset where the record has no field is still an `INT_ADD` here and is
converted like any other: a read past the record's extent
(`((unsigned int *)teb)[0x410]`, `0x1040` bytes into a TEB32 that ends before
it) or inside a field (`((int *)&a0->field_0x10)[1]`, the upper half of an
8-byte field). Upstream Ghidra prints the integer round trip. Pinned by
`tests/stages/kuna-castarith.xml` and by the compiled round trip
`a_pointer_plus_whole_elements_round_trips_through_the_printed_c` in
`decompiler/crates/kuna-cli/tests/decompile_all_cli.rs`.

The rewrite only removes ops: the integer form's two casts become one or none.
That can move one structuring decision. The tail
duplication passes of chapter 08 (`gotoreduce`, `taildup`, `crossjumprevert`)
run after this pass and bound the tail they copy by its op count, `CAST`s
included, so a tail that was just over the bound can fit after the rewrite, and
a `goto` to it becomes a duplicated `return` marked `// return-dupe`. The
duplicate computes what the goto reached. It is rare: when this shipped, 4 of
75,296 functions over 201 binaries changed their control flow, all of them this
way and all through `taildup`, and with `option taildup off` both arms printed
the same `goto`s.

The JSON surface loses a little provenance: a subscript is a surround token and
carries no op, as for every native subscript, so an instruction whose only
printed ops were the add and the access through it maps to no line in
`line_mappings` and drops out of its variable's `addresses`.

**A variable index and a byte-pointer difference (kuna, `castindex`).** The
same `INT_ADD` reaches this pass when the addend is a variable, and an `INT_SUB`
of two pointers reaches it as integer arithmetic too: the default input arm
converts both operands to the signed integer of their width. An array walk
through a `void *` base prints `*(long *)((long)v7 + v19 * 8)` and the length of
a `char *` span prints `(long)v24 - (long)v14`. With `option castindex` on (the
default, C output only), the driver hands each `INT_ADD` that `castarith` left
alone to `decompiler/crates/kuna-decomp/src/p9_emit/kuna_castarith.rs
(rewrite_index)`, and asks `kuna_castarith.rs (pointer_difference)` about each
`INT_SUB`; the two options act on disjoint ops (a constant addend or a
variable one), so either can be flipped alone.

`kuna_castarith.rs (plan_index)` accepts an `INT_ADD` of exactly one
pointer-typed operand and one non-constant, and chooses the element `T` exactly
as `castarith` does (`kuna_castarith.rs (element)`), with every refusal that
choice makes. The addend is taken apart by `kuna_castarith.rs (scaled_index)`:
when it is an implied `x * S` or `x << s` that only this add reads and `S` is
`sizeof(T)`, the op becomes `PTRADD(base, x, #S)` and the scaling op is
destroyed; when `T` is one byte, the addend itself is the index, whatever it
computes. Any other scale keeps the integer form (a 16-byte record read at 8
bytes, `p + i * 16 + 8`, has no element that divides it, and a record is not
invented here). The scaling op must already have been cast, and the index must
be an integer of the pointer's width that is not an enum and not a cast the
pass inserted (`kuna_castarith.rs (integer_index)`). An implied `SEXT`/`ZEXT`
as the index prints bare under the `PTRADD` (`is_extension_cast_implied` has
always treated a `PTRADD` reader so), which is C's own conversion of the
subscript: the extension-input rule above has already cast the input to the
signedness the extension needs, so `p[i]` of an `int` sign-extends and of an
`unsigned int` zero-extends, as the binary does. A sum that is itself another
pointer's subscript is an integer and keeps the form
(`kuna_castarith.rs (subscripts_another)`). The base is chosen by `castarith`'s
rules.

The rewrite happens only where it saves a cast, counted part by part against
the integer form: the index's extension (`kuna_castarith.rs (extension_saved)`),
the base (`kuna_castarith.rs (base_saved)`: a base declared as a `T *` saves its
`(long)`, a cast base costs what `(long)` cost, and a base that is an integer
the pass already cast to a pointer cost the integer form nothing), and the sum
(`kuna_castarith.rs (sum_saved)`): a lone LOAD or STORE through it always saves
the conversion back to a pointer, while a value is counted only when every
reader takes it with no cast of its own. That question is the pass's own
input-cast rule for a sum that keeps its type, and `castStandard`'s `void *`
rule for a `void *` stepped in bytes. So `(unsigned long *)((long)v4 + v1)`
copied into an `unsigned long *` keeps its form, where the subscript would only
trade one cast for another.

`kuna_castarith.rs (pointer_difference)` accepts an `INT_SUB` whose operands
are both pointers to the same one-byte integer type (after typedefs), neither a
constant, and whose result is an integer of the pointer's width. The pass then
leaves both operands uncast, and casts the result against the signed integer of
that width, which is the token the two `(long)` operands produced and the type
`ptrdiff_t` that C gives `p - q`, so the result's own cast (`(unsigned
long)(v8 - v18)` where it is compared unsigned) is decided exactly as before.
C's `p - q` of two `char *` is their byte difference, the value the integer
form computes. Wider pointees keep the form, because their element difference
is not the byte difference (`((long)v28 - (long)v30) >> 3` stays); so do two
different byte types and `void *`, which C does not subtract. An operand the
pass already cast is counted as `castInput` would have spent it
(`kuna_castarith.rs (operand_saved)`), and the difference keeps the integer
form unless the two operands together save a cast. Every printed value is
unchanged: the index is the element count the integer form scaled, C scales it
by the same `sizeof`, and the difference and its type are C's own. Upstream
Ghidra prints the integer round trips. Pinned by `tests/stages/kuna-castindex.xml`
and by the compiled round trip
`a_variable_index_and_a_byte_pointer_difference_round_trip_through_the_printed_c`
in `decompiler/crates/kuna-cli/tests/decompile_all_cli.rs`; `castindex off`
prints byte-for-byte what the build without it prints.

**Repairs and failure mode.** Late type propagation can invalidate the pointer
model a PTRADD/PTRSUB was built on; the driver demotes them back to raw
arithmetic (`cast_fixup_ptradd` undoes the scaling; `cast_fixup_ptrsub`
becomes COPY or INT_ADD) rather than print a field access into the wrong type.
The fit test for a PTRSUB off a spacebase
(`decompiler/crates/kuna-decomp/src/p6_variables/funcdata_spacebase.rs
(Funcdata::is_ptrsub_matching_scope)`, shared with `RulePtrsubUndo`) looks the
offset up in the scope the spacebase selects, as upstream `TypeSpacebase::getSubType`
does: the global symbol table for a global reference, the function's frame map
for the stack. A reference into a mapped global therefore keeps its symbol and
field (`mapped_samples[i & 3].imag`, `&g_recs[0x30]`) instead of falling back
to the absolute address, which recompiled C would read from the wrong place.
The upstream LOAD/STORE pointer diagnostics (`checkPointerIssues`) are
warnings-only in C++, and in kuna the hook `coreaction_casts.rs
(Funcdata::cast_check_pointer_issues)` is a faithful no-op — a missing
diagnostic comment, never a changed expression. Apart from the narrowed
call arguments above, including the open 32-to-64-bit case, when the cast
strategy loses the failure is cosmetic: a spurious `(int4)` token or a missing
one —
the computation is unchanged, and the upstream console knob
`option nocastprinting` suppresses every cast token at print time without
touching the inserted ops.

Indirect ABI parameters retain their source value type in C (option
`indirectargs`, default on). A parameter marked as indirect storage — one the
locked prototype declares by value but a cspec `convert_to_ptr` or `pointermax`
rule passes through a hidden pointer — represents a value carried by a
pointer, unlike an ordinary pointer parameter. Direct and indirect calls render
a dereferenced argument, using the existing member/array notation when
possible, so `&v` collapses to `v`. Function pointer declarators and callee
parameters use the pointee value type. In the callee, the ABI input pointer
stands for the address of that C parameter: a bare read prints `&v`, while a
field access, load or store through it prints the value itself (`v.f`, `v`)
rather than `(&v)->f`. If that input belongs to a mutable pointer variable, a
distinct pointer local is initialized to the parameter address and subsequent
pointer updates use it. This changes no register, stack, copy-extent, or
memory-effect recovery. Rendering follows the locked source prototype:
required by-value storage is a callee-owned copy. A caller that deliberately
passes aliased storage is still shown passing a copy, so callee writes through
that ABI pointer are not reflected in the caller's C. Ordinary pointer
parameters retain aliasing. Array parameter types keep their ABI pointer view;
C adjusts array parameters to pointers, so they do not denote by-value objects.
`option indirectargs off` prints the ABI pointer everywhere (parameter `T *v`,
argument `&local`, function pointer `(T *)`), as upstream Ghidra does.

## 9.2 PrintC

**Three layers.** The C back-end is a stack of three components in this
folder: the token emitter `decompiler/crates/kuna-decomp/src/p9_emit/printc.rs
(PrintC)` (the `c-language` capability, the registered default), the RPN
expression driver it embeds (the `PrintLanguage` machinery — its pure data
model and decision function live in
`decompiler/crates/kuna-decomp/src/p9_emit/printlanguage.rs`, the driving
methods in `printc.rs`), and the low-level emitters in
`decompiler/crates/kuna-decomp/src/p9_emit/prettyprint.rs`: a line-breaking
`EmitPrettyPrint` wrapping either the plain-text `EmitNoMarkup` (the
byte-exact datatest path) or the XML `EmitMarkup` (the Ghidra-client path).
The whole-document entry is `printc.rs (PrintC::doc_function_full)`, driven by
`decompiler/crates/kuna-decomp/src/infra/decompile_drive.rs` after analysis
completes.

**A render that panics.** The architecture owns the printer, and a render needs
the printer mutably while it reads the rest of the architecture, so every render
runs inside `decompiler/crates/kuna-decomp/src/infra/architecture.rs
(Architecture::with_print)`, which lends the printer out and moves it back. It
moves back on every exit, a panic included: the printer is first cleared of the
partial document by `printc.rs (PrintC::clear)` (the emitter's indent and paren
levels and pending brace, the RPN stacks, the pushed mods and scopes, the scoped
`Funcdata` pointer, unflushed end-of-line warnings, the declared locals and
pointer-argument record, and a markup back-end, which returns to plain text),
keeping every option; its printing modifiers go back to the ones in force when
the render began; then the panic resumes. Upstream `docFunction` catches, calls
`clear()` and rethrows the same way, but its `clear()` takes the modifiers from
the bottom of the pushed stack, which misses a modifier saved and set without a
push: a panic while a load's pointer prints under `print_load_value` would
leave it on, and every later function would drop the `&` from its array
element addresses. A batch that contains a
render panic as that one function's error record
(`decompiler/crates/kuna-console/src/project.rs (decompile_pulled)`, serial or
inside a `--jobs` worker) therefore renders every later function with the
printer settings the run configured (`indentincrement`, `arraynotation`,
`truthycond`, ...), not a default printer's. The test-only
`KUNA_RENDER_FAULT=<addr>` (`decompiler/crates/kuna-decomp/src/p9_emit/kuna_renderfault.rs`)
panics the render of the function at that entry just after its opening brace.

A HighVariable linked to a local Symbol is classified for declaration emission
by that Symbol's category. A linked parameter whose name belongs to the
prototype is emitted only in the signature. A later register local may have
the same storage while carrying a different Symbol, so storage containment
cannot override an existing link. Otherwise the input can be declared again
under a suffixed local name and its entry checks read an uninitialized object.
HighVariables without a recorded link retain the storage-based fallback.

**The document walk.** `printc.rs (PrintC::emit_function_document)` emits, in
order: the function's header warning comments (§9.4), the prototype (return
type from the recovered proto, else `void`; parameters with their declared or
default names; `, ...` for varargs), the open brace, one declaration line per
named local (§9.3), and then the body — a recursive walk of the structured
block tree S8 produced, `printc.rs (PrintC::emit_block_graph)` dispatching each
node by block type: basic/copy blocks emit their statement list; condition
nodes glue two clauses with `&&`/`||` inside parens; if-nodes print
`if (cond)` with a *pending-brace* mechanism so an else-clause consisting of a
single if collapses to `else if` — unless a goto label or comment forces the
brace; while-do nodes render `while (cond)`, or a `for (init; cond; iter)`
header when the loop carries the recovered initialize/iterate statements
(`printc.rs (PrintC::emit_for_loop)`); do-while and infinite loops, switches
with their case labels (`printc.rs (PrintC::emit_block_switch)`), goto blocks,
and — when the S8 `iteregion` pass marked an assignment diamond — the ternary
render `dest = cond ? a : b` (`printc.rs (PrintC::emit_block_if_ite)`), or —
when the S8 `iteboolean` pass marked a short-circuit `0`/`1` select — the
boolean-assignment render `dest = ( cond );` / `dest = !( cond );`
(`printc.rs (PrintC::emit_block_if_bool)`; checked first, so the more specific
form wins when both marks are present). Both re-derive their S8 match from the
addl-flag on the condition's `CBRANCH` and emit the condition through the same
`ONLY_BRANCH` renderer the `if (...)` header uses, so the condition's
parenthesization, short-circuiting and any comma-expression side effects are
identical to the `if` form they replace.

The `infloopstyle while|do` option controls unconditional C loop spelling.
By default an infinite-loop node emits `while (true) { ... }`; `do` restores
`do { ... } while (true);`. A constant true condition has no side effects,
so both spellings execute the same body and preserve `break`, `continue`,
returns, and loop-head labels. Conditional do-while nodes retain their bottom
test, and Rust output retains `loop { ... }`. The option parser lives in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_infloopstyle.rs`.

Every non-default switch arm emits its recovered numeric label even when the
arm has no p-code op available as a token-markup anchor. Such labels use the
same switch-width, signedness, and integer-format rules as op-backed labels,
but are emitted as plain syntax with no fabricated `opref`; `default:` remains
an unvalued label.

Native jump-table labels use the signedness of the emitted selector's integer
type, falling back to the BRANCHIND input's read-facing type for an expression.
Label values are masked to the BRANCHIND input width, discarding bits retained
from a widened normalization intermediate. Thus a signed two-byte selector
with a recovered label `0xfff3` emits `case -0xd:`, while an unsigned selector
keeps `case 0xfff3:`. This applies to byte and wider integer selectors too:
positive high-bit labels cannot match a signed byte or short after C integer
promotion. Synthetic lowered switches retain their recorded label signedness
and the existing `loweredswitchexact` selector-type and cast reconciliation.
The Rust back-end's `match` arms take their value, width and signedness from
the same decision (`printc.rs (switch_case_label)`), so a `match` on an `i16`
selector emits `-0xd =>` where it once printed `0xfff3 =>`, a pattern rustc
rejects as out of range for `i16`, and a sign-extended `i16` selector no
longer carries the widened `0xfffffff3`.

**(kuna) Dynamic ARM LSL in C.** ARM register-controlled `LSL` uses the low
eight bits of its count, so counts 32 through 255 must produce zero for a
32-bit value. C makes a shift by 32 or more undefined. The selector and
repeatability proof live in
`p9_emit/kuna_armregistershift.rs (plan_arm_register_lsl)`; the C printer emits
the plan as a guarded conditional. It preserves the lifted count expression,
compares its unsigned same-width cast with the shifted value's bit width, and
casts the shiftee to unsigned so a valid 31-bit shift is defined. When the
original result type is signed, the true arm is cast back to the signed width
and the false arm is signed zero, preserving consumers such as signed compare
and arithmetic right shift. The expression is not changed to `count & 31`: with
the existing ARM low-byte mask, count 256 still shifts by zero and count 288
still produces zero. When this guard applies, the C in-place compound-assignment
shortcut is declined so the guarded expression stays on the right-hand side of
an ordinary assignment. The rewrite applies only to the C back-end, ARM targets,
and non-constant 32-bit LSLs whose input expressions can be emitted twice
without repeating effects. Volatile values are rejected even when unwritten
because they can print as direct reads. Implied values are accepted only when
their definitions recursively use the listed pure operations; an explicit
written value can be reused by name after its defining statement has materialized
it, including a call or load result. Other architectures, constant shifts, and
non-repeatable ARM inputs keep their existing output. Under `regnarrow` (chapter
[03](03-ssa-and-simplification.md)) a count that is the implied zero extension of
an unsigned narrow value prints as that value, since the guard already casts it
and the shift reads it the same (`(unsigned int)v4 < 32u ? (unsigned int)1 << v4 :
0u` where a narrowed counter printed `(unsigned int)(unsigned int)v4`;
`unsigned_extension_source`). The 12-byte reproduction
and emitted-form checks are in `tests/stages/kuna-arm-register-shift.xml`; signed
comparison and ASR consumers are in
`tests/stages/kuna-arm-register-shift-signed.xml`.

**(kuna) Fixed ARM LSL with a signed operand in C.** A constant-count 32-bit
`INT_LEFT` still computes the low 32 bits when its declared operand is signed.
C11 instead makes a negative signed shiftee or signed overflow undefined,
including when the function converts the result to unsigned on return.
`p9_emit/kuna_armconstantshift.rs (plan_arm_constant_lsl)` selects ARM shifts
with a constant count below 32, equal four-byte input/output widths, and a
signed integer or signed enum shiftee. The C printer casts that operand to
`uint4` before the shift, preserving locked declarations. If the output type
is signed, it casts the whole unsigned shift back to `int4` to preserve signed
comparisons and arithmetic right shifts. That signed conversion and negative
arithmetic right shift retain C11's implementation-defined semantics, as in
the register-count renderer; GCC and Clang implement the ARM interpretation.
Each operand prints once, so a call result or volatile load needs no
repeatability restriction. Signed compound assignment is declined so this
conversion remains on the assignment's right-hand side. Unsigned shiftees,
other widths, out-of-range constants, other architectures and other output
languages retain their existing rendering. Count zero is ordinarily removed
before emission. The repair runs only under option `armconstshift` (default
off, and kept out of the `aggressive` preset): firmware tests nearly every
register flag with a sign-bit shift such as `x << 0x18 < 0`, and the defined
form `(int)((unsigned int)x << 0x18) < 0` adds a cast pair to each one, so the
shipped default keeps the shorter spelling. `tests/stages/kuna-arm-constant-shift.xml`
pins the unconverted default pass and the casts and signed consumers with the
option on; `kuna-cli/tests/arm_constant_shift.rs` compiles the unchanged bodies
as C11 at `-O0` and `-O2`, with and without UBSan, and compares counts 0, 1, 2,
3 and 31 against an independent unsigned 64-bit model truncated to 32 bits.
The runtime checks cover both return signs, ASR, signed comparisons, a stored
result, a repeated shift in a loop, a signed call result, a volatile load and
variable-count controls.

A whole four-byte signed mapped symbol printed by an implied volatile-read
annotation also qualifies, even when the userop output metadata is unsigned.
The planner follows only the `NO_OPERATOR` annotation form and requires an
exact whole-symbol type match; it preserves the single volatile read. Runtime
signed-comparison probes pass the shifted result to a typed comparison helper
so the comparison cannot canonicalize the shift into signed multiplication.
Defining signed multiplication on overflow is outside this repair.

**Every label labels a statement.** Label placement in the printed C is valid
C99/C11/C17 and does not rely on C23. In those dialects a label is part of a
labeled statement, so `case 2:`, `default:` or `label_10ad:` directly before a
closing brace is a syntax error ("label at end of compound statement"). The shape arises whenever the labeled code prints nothing: a switch
arm whose jump-table entry is a branch-only block that leaves the switch, a
`default:` that is also a goto target at the end of the switch, or a goto target
that is only the jump back to a loop head or the join before a closing brace.
The emitter keeps a record of whether a label was the last thing printed
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_labelstmt.rs`, held on the emitter
state so both the plain-text and the markup leaf see it): the case, default and
goto label writers set it, and starting a statement or opening a brace clears
it, while a comment does not. The last arm of a switch that still ends on a
label gets `break;` (`printc.rs (PrintC::emit_block_switch_c)`), which leaves the
switch exactly as falling off its end does. Any other closing brace reached
with the record set, including a loop body's and the function's own, first
prints the null statement `;` on its own line. A label followed by another
label, a statement, or a nested block is untouched, so output that was already
valid does not change. The Rust back-end (§9.6) needs no counterpart: it prints
labels as comments and an empty arm as `N => { }`. The ARM and x86-64 shapes are
pinned by `tests/stages/kuna-labelstmt-arm.xml` and
`tests/stages/kuna-labelstmt-x64.xml`, and the kuna-cli round trip
`emitted_label_statements.rs` compiles the printed functions with
`-std=c11 -pedantic-errors` and checks that they behave like their source.

**Pending-brace ownership.** The `else if` collapse is a *lazy* brace. An
if-node that is itself the else-clause of its parent registers a brace with the
emitter (`printc.rs (PrintC::emit_block_if)`); the brace opens only if
something forces a line break before that clause prints its own `if (` header —
a statement in the clause's condition block, a goto label, or a comment. If
nothing does, the frame cancels its own registration and the header prints on
the `else` line, giving `else if`. The cancel decision belongs to the
*registering frame*, not to whoever happens to be printing when the emitter's
shared slot is non-empty: a clause's condition block can itself lead with a
whole nested if-statement (S8 folds a run of sibling guards into one `BlockIf`
whose condition component is a `BlockList` of the earlier guards), and that
nested frame must let the ancestor's brace fire instead of consuming it. This
mirrors upstream's pointer-identity test (`emit->hasPendingPrint(&pendingBrace)`
against the frame's own object) and is not cosmetic: a nested frame that
cancels the ancestor's brace renders *itself* as the `else if` and leaves the
real clause's `if` header on a fresh line at the parent's indent, so that
clause's body executes on the then-path too. It is reachable whenever a
statement-carrying clause lands in the else slot — in practice after a
§8.1 `branchflip` arm swap. A debug-build assertion in
`printc.rs (PrintC::emit_block_if)` requires every registered brace to be
resolved by its own frame, either fired or self-cancelled; the shape is pinned
end-to-end by `tests/stages/ghdec-branchflip-armswap.xml`.

**The declined-structure shell.** If the structured tree is *absent* (S8
produced no `sblocks`), the printer does not emit a flat op listing: it keeps
the brace-matched prototype shell and plants a single comment in the body
(`printc.rs (PrintC::emit_function_document)`). The failure mode is
deliberately loud and syntactically valid, so batch consumers (`kuna
decompile-all --json`) get a parseable function with an explicit tombstone
rather than pseudo-C garbage. The comment distinguishes the two ways a
function can arrive here, because they call for different investigations: when
the drive recorded *why* the pipeline aborted for this function
(`decompiler/crates/kuna-decomp/src/substrate/funcdata.rs
(Funcdata::set_kuna_pipeline_failure)` — chapter [00](00-overview.md) §0.2), the tombstone is
`/* WARNING: decompilation failed: <reason> */`, naming the recoverable error
verbatim; otherwise the pipeline genuinely ran and structuring produced
nothing, and the tombstone is `/* WARNING: structured blocks unavailable
(structuring declined) */`. The reason text is flattened to one line and any
`*/` neutralized, so it can never break out of the comment.

**Expressions: the push/pop opcode walk.** A statement is one op tree:
`printc.rs (PrintC::emit_statement)` opens a statement group, and `printc.rs
(PrintC::emit_expression_ir)` pushes an assignment token plus the output's
symbol if the root op has one, then recurses via the per-opcode push dispatch
`printc.rs (PrintC::op_push_ir)` (the `PrintC::op*` overrides; the
opcode→token mapping is the data table `printc.rs (op_emit_kind)`). Each
operand is fetched by `printc.rs (PrintC::push_vn_ir)` with the simple rule of
the whole emitter: an **implied** Varnode expands in place — its defining op
is pushed recursively (threading the reading op down so the ZEXT/SEXT arms can
ask §9.1's is-the-extension-implied question); an **explicit** Varnode becomes
a leaf token (`printc.rs (PrintC::push_vn_explicit_ir)`) — a constant
(dispatched by read-facing metatype to the float, enum-flag decomposition,
character, string-pointer (§9.4), or integer formatter, the last honoring
per-symbol display formats, the `U`/`L`/`LL` suffix flags from §9.1, and
signedness from the type), or a named variable, including the partial-cover
walk that renders `name.field`, `name[index]`, a `(int4)name` truncation cast,
or the artificial `name._8_4_` member when a Varnode covers only part of its
mapped symbol (`printc.rs (PrintC::push_partial_symbol_ir)`).

(kuna) The character formatter prints a byte above 0x7f of a `signed char` or
`unsigned char` type (a character type that is not the target's own `char`,
chapter 01's DWARF reader makes them) as a number of the type's sign, not as
`'\xc8'`: that literal is -56 or 200 by the sign of the compiling target's
`char`, so `c == '\xc8'` with `unsigned char c` is never true on x86. So does a
plain `char` constant that a comparison sets against such a value printed
without a cast (`compared_byte_sign`): C promotes that value by its own sign,
and the constant prints as `-0x38` or `200` to match. Otherwise plain `char`
keeps upstream's escape, which is that type's value. An extension
whose input is a one-element array read whole (`unsigned char b[1]` loaded as
one byte) asks the cast question of the element, so it prints `(int)b[0]`
where it printed the functional `ZEXT14(b[0])`
(`printc.rs (sext_zext_facing_types)`).

**Which symbols enter the partial walk.** Upstream routes *every* partial cover
of a mapped Symbol through that walk — the walk itself decides, per type, what
token describes the access — and kuna does the same: STRUCT, UNION and ARRAY
symbols all enter it. The array case is the one worth stating, because an array
is the only composite whose member token can be chosen without looking at the
access size, and doing so is wrong. The walk's ARRAY arm applies upstream's
`TypeArray::getSubEntry` test — the access maps to element `off /
elementAlignSize` **only if** what remains of it after that division still fits
inside one element — so a one-byte read at offset 3 of a `char[16]` renders
`g[3]`, while an eight-byte read at offset 0 of the same symbol does not
describe any element and falls to the artificial member `g._0_8_`. That
distinction is not cosmetic: rendering the eight-byte access as `g[0]` names a
single `char`, so the emitted statement claims a width the program does not
use, and a reader (or a consumer diffing against a source build) cannot tell a
byte store from a word store. The rule is therefore that an array subscript is
emitted only where the subscript is the *whole* truth about the access, and the
sized `._<off>_<size>_` member carries every access that spans elements. The
same walk keeps descending afterwards, so an array of unions resolves past the
subscript into the cached field (`arr[3].ffield`).

**The whole-array cover** reaches the walk but not its ARRAY arm, because
upstream breaks out at the top of the walk whenever the request is the symbol
in full (offset 0, size equal to the symbol's) and leaves the caller to render
a bare name. For an array that break is the same size-blindness one level up:
kuna's caller then took its own whole-array `name[index]` branch, and a
sixteen-byte `movaps` transfer through a `char v30[16]` VM register bank
printed `v30[0] = v32[0];` — one byte named on each side of a sixteen-byte
copy — while the four-byte accesses to the same bank a few lines away printed
`v30._0_4_`. **(kuna) arraycoverwidth** (default **on**,
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_arraycoverwidth.rs
(spans_multiple_elements)`) suppresses that break for a TYPE_ARRAY whose
element stride is smaller than the access, so a full-width cover falls to the
same artificial `._<off>_<size>_` member a partial one gets and the two
spellings agree: `v30._0_16_ = v32._0_16_;`. The predicate is deliberately
narrow — a scalar, a struct, a union, and any access that fits inside one
element are all left with the upstream break, so `g[3]` and the bare
whole-symbol name for a non-array are unchanged. Turning the option off
restores the upstream break and with it the element-zero subscript.

This is what makes the 16-byte register-pair return legible. P5's type factory
has no integer primitive wider than `max_basetype_size`, so a
`CONCAT88`-shaped return value is typed `undefined1[16]` (upstream behavior,
§5), and P6 merges the two halves the callee writes into that one local. The
halves are then eight-byte writes into a byte array — exactly the access the
subscript cannot describe — and they render `v1._0_8_` / `v1._8_8_`. The
whole-container operand reads `return v1._0_16_ << 0x40;` under
`arraycoverwidth`, which states the width but is still not compilable C: it
shifts a member of an array. What this does **not** fix is that container type
itself. Recovering it needs either a scalar wide-integer type or a mid-end fold
of the `CONCAT88(0,x) << 64` idiom; neither is done here.

For C output with `partialaccess` enabled on a 64-bit target, an inferred
sixteen-byte register temporary used only for bit extraction, copying, merging,
or bitwise operations is declared `unsigned __int128` instead of `char[16]`
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_widelocal.rs`). This keeps a
whole-width scalar load and its local assignment consistent. The rule requires
unmapped, unlocked, non-address-tied values whose type is an inferred array of
unknown bytes. A value loaded through a pointer, or copied out of another array
variable, keeps its array declaration: its right-hand side prints as an array
(`*(char (*)[16])p`), which C would convert to a pointer and assign to the
integer as an address instead of rejecting the statement. It does not retype
explicit arrays, parameters, globals, or addressable storage, and does not
change the IR or the volatile access count. GCC/Clang's wide-integer extension
is the same one used by the existing sixteen-byte pointer views. Other
wide-container cases retain their existing rendering.

**Standard C for mapped byte arrays.** `bytearrayc` (default **off**,
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_bytearrayc.rs`) provides a C11
rendering choice for direct integer accesses of two, four or eight bytes within
a mapped global array of one-byte integer elements. A one-byte access retains
its subscript; a whole one-element byte array explicitly uses element zero.
Partial and whole-array covers use the same checked interval:
the offset plus access size must fit within the mapped object. This does not
change the declared array type or the recovered operations.

Reads call an emitted `kuna_bytearray_load<bits>_<le|be>` helper through the
address of the first byte, then convert to the read-facing integer type. Stores
call the matching `kuna_bytearray_store<bits>_<le|be>` helper with the value
expression evaluated once. Same-width integer casts into an array view use
scalar bits instead of an invalid C array cast. The helper reads or writes exactly the requested
bytes through character pointers; it neither dereferences a wider pointer nor
requires alignment or an effective integer type for the mapped object. Explicit
unsigned shifts encode the target storage space's byte order, independently of
the host byte order. A read used in a store argument completes before the store
helper starts, preserving overlapping copies. Each width/endian pair has guarded
static inline definitions so independently emitted functions can share one C
translation unit. The preamble includes `<stdint.h>` and `<limits.h>` and asserts
that a C byte has eight bits. The `kuna_bytearray_` helper names and
`KUNA_BYTEARRAY_C_` guards belong to this generated support surface.

The option deliberately leaves volatile accesses in their existing form:
splitting a wide device access into several volatile byte accesses changes the
observable access width and count, while casting a byte array to a wider volatile
pointer would invent alignment and aliasing guarantees. Their standard-C
representation requires an additional device/type contract. Read helpers accept
`const void *`, store helpers accept `void *`, and neither casts away a qualifier
on a source or destination argument. This option does not repair qualifier loss
in declaration recovery. Arrays nested in aggregates, stack/register containers,
noninteger values, non-byte-addressed spaces and other transfer widths also
retain their existing representation. Off retains all existing emitted C.
The authored CLI round trips in
`decompiler/crates/kuna-cli/tests/mapped_array_c.rs` compile unchanged emitted
bodies at `-O0` and `-O2` with strict aliasing and UBSan, including unaligned
transfers, overlapping stores, signed reads, const sources, both ARM endian
variants and an unchanged named-struct control.

**Partial accesses as C (kuna `partialaccess`, default `off`, on in
`aggressive`, `fast` and at every `auto` size).** Everywhere else the walk ends
on the artificial member, which is Ghidra's notation and not C: `v1._4_2_ ==
2`. With the option on, `printc.rs (PrintC::push_partial_walk)` takes the
trailing `._<off>_<size>_` entry off the member stack and prints what it
describes (`printc.rs (PrintC::push_piece_open)`, `kuna_partialaccess.rs
(Piece::plan)`). An access of a width C has a scalar for is the pointer access
it is: `((T *)&v1)[k]` when the offset is a multiple of the access width, with
`k` the offset divided by the width; `*(T *)&v1` at offset 0; `*(T *)((char
*)&v1 + off)` at an unaligned offset; `*(T *)&buf[off]`, and `*(T *)buf` at
offset 0, when the walk took the bytes out of a byte array (a `char[16]` local,
a synthesized record's `undefined1` filler), whose subscripts already count
bytes, as IDA prints `*(_DWORD *)&buf[8]`; and `((char *)&v1)[off]` when the
caller asked for the address of a position inside the symbol (the `sz == 0`
request of the spacebase arm, which wraps the result in `&`). The first form
is the spelling the cast pass already gives the same bytes reached through a
pointer (`((unsigned char *)a0)[7]`) and IDA's `BYTEn`/`WORDn` macros. `T` is
the type of the Varnode being printed when that type is exactly the access
width and is a scalar (an integer, boolean, float, pointer or unknown of 1, 2,
4 or 8 bytes, or a float of its own width); otherwise it is the unknown type of
the width, spelled by the active type speller -- except that an unknown-typed
access that carries a float (a float operation or a copy of a float wrote it,
or a float operation reads it) takes the float of its width, because an
integer `T` would make C convert the value where the binary moves its bits
(`*(double *)&v1[8] = a0 * a0;` for an AArch64 `d1:d0` pair). A 16-byte access
on a target with 8-byte pointers reads through `unsigned __int128`, the GCC
and Clang 16-byte integer (`return *(unsigned __int128 *)v1;`), which is local
to this rendering: the variable keeps the declaration it had.

C has no scalar of 3, 5, 6, 7 or 9 to 15 bytes, and no form may compile to a
different meaning, so those widths are handled by what the statement does.
`printc.rs (PrintC::emit_wide_copy)` prints a plain `COPY` into such bytes, or
into 16 bytes, as `memset` when the source is a constant whose bytes are all
equal and as `memcpy` when it is another such piece or a variable, with the
exact byte count (`memset(&v2,0,0x10);`, `memcpy((char *)&v1 + 0x10,(char
*)&d + 0x10,0x38);`); a whole array variable that takes a copy out of such
bytes is copied the same way, since an array cannot be assigned. A read of 3,
5, 6 or 7 bytes out of a scalar prints as the `SUB<in><out>(v,k)` intrinsic
the surrounding output already uses for a truncation, `k` counted from the
value's low end (the memory offset on a little-endian space, the bytes after
the access on a big-endian one). Any other access of such a width -- a store
of an intrinsic's value (`v47._0_12_ = ZEXT412(1) << 0x40;`), or a 16-byte
access on a 32-bit target -- keeps Ghidra's token, which no compiler accepts:
an array-typed spelling would compile, as an assignment error at best and as
the address of the bytes at worst. The member path stays inside the
address-of (`((unsigned int *)&v1.flagfield)[1]`, `*(unsigned long
*)&v11[0]`), every form is an lvalue so a partial store prints the same way,
and the offset is still the byte offset into the symbol's storage, so the
reading is the target's memory order whatever its endianness. The rendering is
C only (the Rust printer keeps its own spelling) and reinterprets the variable
through another type exactly as IDA's macros do, so recompiling it wants
`-fno-strict-aliasing`, as decompiled C generally does. The catalog default
stays off because the datatest corpus pins Ghidra's notation in two assertions
and applies no mode; the presets are what make the C spelling the default
rendering for a real binary. Over 36 stripped decbench binaries
(O0 and O2) under `--mode aggressive` the option replaces the 4,964 artificial
members of 805 functions: the 4,306 of a scalar width become pointer accesses;
of the 658 wider or odd ones, 211 read through `unsigned __int128`, the plain
stores and copies become 292 `memset` and 15 `memcpy` statements, 43 odd-width
reads become `SUB` intrinsics, and 89 keep the token, each a store of an
intrinsic's value. Nothing else changes.

**Leaves with no Symbol.** Not every leaf has one. When no mapped symbol covers
the storage the leaf falls through to the upstream `pushUnnamedLocation`
naming, `printc.rs (kuna_unnamed_location_name)`: the register name covering
`(address, size)` if the translator has one, else the angr-style `dat_<addr>`
for a data space (§9.3), else the capitalized `Space<hex>` form —
`Stack00000008`, `Unique00001a80`. These name the *storage*, not a variable,
and are deliberately never declared: they are extern-like markers that a value
lives somewhere the analysis never resolved to a variable, exactly as upstream's
`stack0x00000008` is (kuna capitalizes the space and drops the `0x` so the
token is at least a legal C identifier).

One unnamed high-variable case is deliberately canonicalized before that
choice. If any member is the unaffected input stack pointer, every member uses
that member's storage-form leaf (`Register0000000000000000` on x86-64), with
the translator's register-name shortcut disabled. Copy propagation can merge
the input stack pointer with register and unique-space members; printing each
member's own address would otherwise make one value appear under unrelated,
undeclared names such as `RAX` and `Unique10000064`. This spelling change does
not synthesize the definition that may be absent after the merge.

The same leaf serves the **spacebase** arm of `printc.rs
(PrintC::op_ptrsub_ir)`. A `PTRSUB(sp, off)` is a reference into the stack (or
global) frame; P6 binds a Symbol to the offset constant whenever the recovered
frame layout has one, and the arm then renders `&local_10` / `&myval.b`
through the partial-symbol walk above. When P6 bound nothing — the frame's
spacebase could not be tracked to a constant, so every reference stays relative
to the *entry* stack pointer and the offsets land outside the mapped frame,
which is what an `alloca`/`_chkstk` stack probe does — the reference still
names real storage, and it renders `&Stack00000008` through the same
unnamed-location leaf (`printc.rs (PrintC::push_spacebase_unnamed_ir)`, whose
address comes from `printc.rs (spacebase_unnamed_address)`, the C++
`TypeSpacebase::getAddress`). What that arm must not do is fall back to the
*functional* render `PTRSUB(ESP, 8)`, kuna's behavior before this leaf existed:
`PTRSUB` is an internal p-code operator and `ESP` a raw machine register, and
emitting either makes the whole function something no C parser accepts
(`tests/stages/ghdec-spacebase-unnamed.xml`, DIV-46).

An unnamed **incoming address** has a narrower, reconstructible case. For
`x86:LE:64:default:gcc` with the ordinary SysV prototype model, an eight-byte,
byte-addressed descending stack based on `RSP`, and a resolved entry-stack
offset of at least eight, C renders the address as
`((char *)__builtin_dwarf_cfa() + (offset - 8))` (omitting a zero addition).
`kuna_callerstack.rs (address)` validates those facts. AMD64's canonical frame
address is entry `RSP + 8`; GCC's [CFA builtin lowering](https://github.com/gcc-mirror/gcc/blob/master/gcc/builtins.cc)
and [AMD64 incoming-frame offset](https://github.com/gcc-mirror/gcc/blob/master/gcc/config/i386/i386.h),
and Clang's [builtin lowering](https://github.com/llvm/llvm-project/blob/main/clang/lib/CodeGen/CGBuiltin.cpp)
provide this compiler extension. The expression names the original caller
area even when recompilation creates a different local frame. It introduces
neither a local object nor a parameter and preserves an explicit `void`
prototype. Functions using this expression receive `__attribute__((noinline))`
in both their definition and exported prototype: inlining would change which
call frame the builtin names. `printc.rs (PrintC::caller_stack_function)` finds
these address uses; direct storage loads/stores do not acquire this attribute.
Named parameters and locals retain their symbol expressions. Return-address
offsets below eight, negative local offsets, other compiler specs, calling
models, architectures, and non-C output retain their existing handling; their
ABI is not inferred from AMD64. Native GCC and Clang O0/O2 checks in
`decompiler/crates/kuna-cli/tests/caller_stack_cli.rs` compare actual entry
addresses and sixteen-byte pipe payloads from adjacent caller storage, using
both single-function and project output and direct same-translation-unit calls.
Typed integer and structure pointer returns retain the emitter's outer pointer
cast and rebuild without pointer-compatibility warnings.

The structure arm has the same failure through a different door. C++
`opPtrsub` reads the pointer type of the *variable* the base belongs to
(`getHighTypeReadFacing`), and the kuna printer reads the base Varnode's own
type, which is the same thing until one member of a merged variable carries a
narrower pointer than the rest. A global assigned a `struct_N *` and also read
back into a loop over `unsigned int *` is such a variable: `ActionSetCasts`
inserted `PTRSUB(dat_263f0, #0)` against the variable's `struct_N *`, and the
member feeding it reads `unsigned int *`, whose pointee is no structure, so the
op fell to the functional render and printed `v4 = PTRSUB(dat_263f0,0);`.
`printc.rs (ptrsub_resolves)` asks whether the member's own type can name a
member at all (a pointer to a structure, union, array or spacebase, or a
relative pointer), and only when it cannot does the arm take the variable's
type instead (`printc.rs (high_pointer_type)`: a mapped symbol's type, else
the merged variable's type representative), which prints
`v4 = &dat_263f0->field_0x0;`. Every output this changes was the functional
render before; on `main` one `tar` O0 function printed it
(`a0->field_0x8 = PTRSUB(dat_9f6a8,0);`).

With `stackviews`, a structure or union member's operation-facing pointer type
can differ from its base variable's C declaration. A detached address snapshot
may be an integer, or a temporary may hold both a node address and the address
of a pointer slot. `decompiler/crates/kuna-decomp/src/p9_emit/kuna_memberbase.rs
(needs_cast)` compares that declaration with the pointer used to select the
field. Differing same-width integer or pointer representations receive an
explicit pointer cast before `->`. The member offset follows the selected
pointee; snapshot declarations and byte arithmetic keep their existing
representations. Matching types, implied expressions, relative pointers and
explicit `nocasts` retain their ordinary rendering.

**Precedence without an AST.** Operators and leaves are not buffered into a
tree; they stream through a reverse-polish stack. `printc.rs (PrintC::push_op)`
pushes an operator's static token — the singleton table `printc.rs (tokens)`
carries each C operator's precedence, associativity, arity stage, spacing, and
its negated complement — and *at push time* decides parenthesization by the
pure predicate `printlanguage.rs (parentheses)`: compare the enclosing token's
precedence/associativity/type against the incoming one, with special stages
for pre/post-surround tokens (calls, subscripts, casts) and the (kuna, DIV-1,
GH-2786) rule that adjacent identical `-`/`+` prefix tokens always
parenthesize so they cannot merge into `--`/`++`.

Two of those tokens are not the ones integer arithmetic uses. `*` and `+` are
associative over the integers, so an operand built by the same token needs no
parentheses on either side and a chain of them flattens to `a * b * c`. IEEE-754
arithmetic is not associative: `a * (b * c)` rounds at different points than
`(a * b) * c` and can differ in the last bit, so flattening a float chain emits C
that computes a different value than the p-code it came from. `CPUI_FLOAT_MULT`
and `CPUI_FLOAT_ADD` therefore push their own tokens, `printc.rs
(tokens::FLOAT_MULTIPLY)` and `printc.rs (tokens::FLOAT_PLUS)`, spelled and
ranked exactly like the integer pair but carrying `left_to_right_only` instead of
`associative`. That flag is the third answer `printlanguage.rs (parentheses)` can
give a same-token operand: `associative` leaves both operands bare, a plain
non-associative token (`-`, `/`) parenthesizes both, and `left_to_right_only`
leaves the first bare and parenthesizes the second. It is the exact rule, because
C already groups `*` and `+` left-to-right: a left operand re-parses into the
tree it came from, and only a right operand needs the parentheses to survive the
round trip. So the two orderings a compiler can emit stay distinguishable in the
output -- `a * b * c` for the left-grouped one and `a * (b * c)` for the
right-grouped one -- where before they printed identically
(`tests/stages/kuna-floatgrouping.xml`). Float subtraction and division already
reached the right answer through the non-associative integer tokens they share.

`printc.rs (PrintC::push_atom)` emits a leaf and then unwinds every operator whose
operand count is now satisfied (`emit_op` prints each operator's text at the
right visit stage — between operands for binary tokens, at open/close for
surrounds). Contextual rendering flows through a modifier word saved and
restored around each descent (`printlanguage.rs (PrintContext)`): e.g. a LOAD
feeding a STORE address prints `*ptr` or hides the dereference
(`print_load_value`/`print_store_value`), a negated condition flips a
comparison token to its complement instead of printing `!`.

**The pretty-printer.** All of the above emits *logical* tokens; line breaks
are chosen by `prettyprint.rs (EmitPrettyPrint)`, an Oppen-style streaming
formatter transcribed verbatim because its breaks are part of the byte-exact
output: tokens queue in a circular buffer (initial capacity 300, grown by 200
with reference fixup) while a scan pass computes each open group's size — held
negative until the group's close commits it — and `advanceleft` flushes tokens
whose size is final. A forced newline carries the `999999` "won't fit"
sentinel as its space cost so it always breaks; an ordinary break token whose
content no longer fits either indents to the group's saved column or, when
breaking would recover fewer than 10 characters, stays on the line;
overflow permanently raises inner indents to guarantee at least half a line of
working space (`prettyprint.rs (EmitPrettyPrint::overflow)`), and inside a
comment every forced break re-emits the comment fill prefix. Defaults: 100
columns (`option maxlinewidth`), indent step 2 (`option indentincrement`),
comment indent 20; brace placement per construct via the four `braceformat`
fields of `printc.rs (PrintCOptions)`: if/loop/switch braces sit on the same
line as their construct, and a function's brace sits directly under its
prototype (kuna DIV-34 — upstream's `skip_line` default leaves a blank line
between the prototype and `{`; `option braceformat function skip` restores
it, exercised by `tests/stages/kuna-cnorm-protogap.xml`).

**Position maps.** Every token can carry a resolved back-reference,
`prettyprint.rs (MarkupRef)`: an op reference (the op's `getTime`, the same id
the function's `<ast>` encoding writes as `<seqnum uniq>`) and a Varnode
reference (`getCreateIndex`, the `<addr ref>` id). On the plain-text path no
reference is even computed — output is byte-identical to a markup-less build —
but under `EmitMarkup` (selected by `printc.rs (PrintC::set_markup)`, the
ghidra-mode front-end) `<variable>` elements carry `varref`/`opref` (declarations add `symref`) and `<op>` elements carry `opref`; plain `<syntax>` elements carry only color/content that resolve against the AST by
construction, which is how the Ghidra client maps a clicked token back to
p-code, and how statement groups map to addresses.

**Token source map** (kuna). A front-end that links the C to the machine code
needs every token of the *plain* text with its place in it, and the plain
emitter keeps no references. `EmitMarkup` therefore optionally records each
token as it encodes it (`decompiler/crates/kuna-decomp/src/p9_emit/prettyprint.rs
(EmitToken)`): its line, its column in UTF-16 code units, its kind (syntax,
variable, value, op, funcname, type, field, comment, label), its colour and
the `opref`/`varref` it carries. The column model is `EmitNoMarkup`'s,
replayed: a line break fires any pending brace first and then moves to the
current indent (or to the explicit indent of `tag_line_indent`), and every
emitted text advances the column by its length, so a token lands exactly where
the plain back-end printed the same characters; blank tokens are dropped and
surrounding spaces trimmed. A `tag_type` records one token for the whole
declarator front (`unsigned long *`) and mutes the per-word split the packed
encoding makes for the Ghidra client. Anything printed in the constant colour
(a `tag_variable` literal or a plain `print`) and case labels are `value`
tokens. Declaration context rides along: tokens inside the return type, the
prototype, and a local declaration are marked, and a comment or label keeps the
space and offset it is attached to. `printc.rs (PrintC::doc_function_tokens)` runs the same
`emit_function_document` sequence with capture on. `option indentincrement`
lives on the emitter leaf, so `printc.rs (PrintC::set_markup)` carries it into
the leaf it swaps in: without that, the markup leaf would indent by the default
2 (shifting every column) and the plain printer restored after it would print
every later function of the batch at 2 as well.
`decompiler/crates/kuna-decomp/src/infra/decompile_drive.rs
(print_c_with_srcmap)` renders the plain text first and the captured markup
second — the text is byte-identical to `print_c_with_provenance` — and the
MSVC cookie-return presentation rewrite reports each line pair it edits so the
tokens follow it (`kuna_srcmap.rs (apply_cookie_rewrites)`: the blanked
assignment loses its tokens and the return line becomes `return`, the literal
carried from the assignment, `;`).
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_srcmap.rs (resolve)` then
places the tokens in the trimmed `code` (lines shift by the number of leading
breaks the trim removed), resolves `opref` to the instruction address (a
comment's or label's own address only when it lies in the function's code
space — a `// stack - 0x10` note names a frame slot, not an instruction), a
call's function name to its callee's entry, and a variable token to its row in
the reported variables (by the varrefs that row's line evidence came from, else
by a unique name, among the parameters for a token in the prototype), and names
the declaration a token sits in (`local`, `param`, `return`, `function`). The
line mappings of both provenance renders are numbered the same way — against
the trimmed text — which matters for Rust output, whose attribute line makes
the render open with two breaks rather than one. `kuna_srcmap.rs (verify)` is the contract: the tokens are
in order and inside their lines, each slice of the code equals its text, and
every code unit between them is a space — so joining a line's tokens with the
gaps as spaces rebuilds that line exactly. A caller ships the tokens only when
the check passes and otherwise reports an empty list with the reason, never a
drifted map. The RPN stack carries each op and Varnode reference as the arena
key's whole 64-bit form (`decompiler/crates/kuna-decomp/src/p9_emit/printlanguage.rs
(IrKey)`), and the comment sorter's op cursor likewise: on a 32-bit target — the
browser build — a `usize` would drop the key's version half and every reference
resolved from it would dangle.

**Literal format.** The remaining P9/`literal-format` knobs all act at the
constant/type-name chokepoints of this walk: `option integerformat`
(hex/dec/best — "best" scores which base makes the constant's digit pattern
most natural, `printlanguage.rs (most_natural_base)`), `option nullprinting`
(the `NULL` token for pointer zeros — kuna DIV-35 flips it default-ON, so a
null pointer renders `NULL` where upstream renders `(type *)0x0`; `option
nullprinting off` restores the casted form, exercised by
`tests/stages/kuna-cnorm-nullprint.xml`), `option inplaceops` (kuna DIV-36
default-ON with the `emitInplaceOp` consumer ported: a standalone statement
`out = out OP y` whose first input is the same HighVariable as the output
renders as the compound assignment `out OP= y` for the ten integer
operators, and a negative signed INT_ADD addend folds to `out -= c`;
when the variable covers only part of its mapped symbol (a 4-byte field of
an 8-byte global), its read form is a cast (`(int)origin`) and not an
lvalue, so the left side renders from the statement's output in the store
form a plain assignment uses (`*(int *)&origin += 1`,
`printc.rs (inplace_target)`); comma contexts — for-loop headers and condition-block side effects — keep
the spelled-out upstream form, so `for (...; i = i + 1)` is unchanged;
`option inplaceops off` restores everything, exercised by
`tests/stages/kuna-cnorm-compoundassign.xml`), and
the (kuna, DIV-6) `realtypes` relabel: residual `TYPE_UNKNOWN` values render
as size-correct real C types (`char`/`unsigned short`/`unsigned
int`/`unsigned long`) at the declarator/cast chokepoints, without touching
the actual data-type lattice — `option realtypes off` restores
`undefined<N>`. The **same** size table applies to a `TYPE_UNKNOWN`
*pointee*, so `undefined8 *` reads `unsigned long *` and `undefined4 *`
reads `unsigned int *`: the relabel is presentation only, and the index and
cast expressions the walk builds elsewhere are still scaled by the original
pointee size, so a declaration that shrank its pointee would contradict its
own body (`void *a3` alongside `a3[1]` meaning byte offset 8 — not
compilable C, and a store cast down to `*(void *)` loses its width
entirely). `void` is therefore only the **fallback** under a pointer, for
the residual sizes with no natural single C type (0, 3, 5, 6, 7, …); as a
scalar those sizes keep `undefined<N>` (DIV-48,
`printc.rs (realtype_unknown_base)`, exercised by
`tests/stages/ghdec-realtypes-pointee.xml`). A genuine `TYPE_VOID` pointee
is not a residual unknown and never enters the relabel, so the opaque
`void *` of `free`/`malloc`/`memcpy` is unaffected. Per-symbol format assertions
(`map convert`, `force datatype`) override the global format at the same
point ([docs/options.md](../options.md)).

Signed integer constants are normalized to their declared byte width before
choosing their sign, magnitude, and numeric base
(`decompiler/crates/kuna-decomp/src/p9_emit/printc.rs (resolve_integer_format)`).
A four-byte `0xfffffffffffffffc` carrier therefore prints as `-4`, just like
`0xfffffffc`; upper carrier bits also cannot turn a positive narrow value
negative. Forced numeric radices retain this width interpretation. Character
overrides, unsigned rendering, and unsized constant handling retain their
existing paths.

Anonymous function types with a stored prototype participate in the C declarator
walk alongside pointers and arrays. The function contributes a parameter suffix,
then the walk continues through its return type. Parameters use recursive abstract
declarators, an empty fixed parameter list spells `(void)`, and a variadic list
retains `...`. Prototype model and ABI recovery are unchanged.
Unknown return bases use only pointer modifiers inside their return type when
deciding the `realtypes` fallback, preserving a scalar return's recorded width.
This applies to locals, parameters, fields, globals, casts and exported type
strings; a known `unsigned int (*)(void)` must not fall back to `undefined1 *`.
Named typedefs and code types without a stored prototype retain their existing
spelling. This only prints the recorded type; it does not infer a callback
signature or change indirect-call ABI recovery.

**Valid C type names** (kuna, DIV-75, `option ctypes`). `realtypes` covers only
residual `TYPE_UNKNOWN`, and the *named* core types beside it are not C at all:
kuna interns them as `uint1`/`int4`/`float8`/`float10`/`code`, a verbatim port of
upstream's no-`<coretypes>` fallback branch, which the real Ghidra application
never takes because its Java side supplies its own names over the wire. That
split is directly observable — one function declares `unsigned int v3;` (relabelled)
next to `int4 v1;` (not) — and it is why the emitted C does not compile.
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_ctypes.rs (core_type_spelling)`
extends the same one chokepoint to every core type: the type's *size* is matched
against the target's own declared widths, in declaration order, first hit wins
(the port of Ghidra's `DataOrganizationImpl.getIntegerCTypeApproximation`).
Declaration order is what makes it per-architecture rather than a guess: under
LP64 both `long` and `long long` are 8 bytes and an 8-byte integer must read
`long`, while under ILP32 and LLP64 `long` is 4 and the same size lands on
`long long`. The widths come from the compiler spec (chapter
[05](05-types.md) §5.1); the same size therefore renders `unsigned long` on
x86-64 System V and `unsigned long long` on i386, from one table.

Three cases resist an exact answer, and each is decided rather than left to fall
out of the table. A 1-byte integer is `signed char`/`unsigned char`, never bare
`char` — its signedness is implementation-defined, and kuna reserves the `char`
core type for text. `code` is Ghidra's pseudo-type for a function body and only
ever reaches the output as `code *`, which becomes `void *`. And floating point
is the one place an approximation is unavoidable: an exact width match wins, but
a width above `double` with no exact match spells `long double`, which is how the
x87 `float10` is reached. No target has a 10-byte `sizeof` — the x86 cspecs
record 10 as the *value* width and annotate the storage in a comment — so that
spelling is an approximation of storage, deliberately the same one the recompile
prelude already makes, since the emitted `.c` and `.h` must not disagree.

Integer widths with no C type at all (3, 5, 6, 7, and 16-byte integers) keep
their `undefined<N>` form. They are **not** widened: `(undefined3)x` is a 24-bit
truncation and `(unsigned int)x` is not, so rounding up would change what the
emitted code means.

The rename is presentation only — the interned core types keep their names,
because a core type's id is `hash_name(name)`, Ghidra-style identifiers are
derived from the first character of the type's name (`float8` is what makes
`fVar1`), and the console's C-type parser resolves base types solely through
`TypeFactory::find_by_name`, which the corpus feeds `int4`/`float8` from 269
script lines. The shipped catalog default is `off`, which is what the XML
parity corpora and an explicit `--mode reliable` run at (42 datatest assertions
pin the Ghidra spellings). The `aggressive` and `fast` presets turn it on, and
`auto` turns it on at every input size, the `reliable` tier from 500 KiB to
2 MiB included (chapter [00](00-overview.md), *Modes*). Valid C is therefore
the rendering every real-binary surface gets, whatever the input size. Before
that, a binary of 500 KiB or more fell back to the interned names, and an
8-byte element cast such as `((int8 *)a0)[4]` read like a byte offset of 4 at
an element offset of 0x20 (GH-1063). Exercised by
`tests/stages/kuna-ctypes.xml` and the per-architecture CLI gate
`ctypes_per_arch`, which also runs `--mode fast` and `auto` at each size tier.

## 9.3 Naming

**(angr) namestyle — the policy.** The master toggle `option namestyle
angr|ghidra` (default `angr` since DIV-5; live flag `name_style_angr` set in
`decompiler/crates/kuna-decomp/src/infra/architecture.rs
(reset_defaults_internal)`) re-skins every *default* (generated) name; user
and recovered names are never touched. The policy helpers live in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_naming.rs` with the pure
address renderers in `decompiler/crates/kuna-decomp/src/p0_knowledge/database.rs
(kuna_global_data_name, kuna_function_name, kuna_label_name, kuna_arg_name)`.
Under the angr scheme: locals and decompiler temporaries are `v1`, `v2`, … —
**sequential per function**, not SSA-subscripted (one name per merged
HighVariable, exactly one counter); parameters with no recovered name are
`a0`, `a1`, … by signature slot; global data reads `dat_<addr>` (lowercase
bare hex), unnamed callees `sub_<addr>`, goto targets `label_<addr>`
(`printc.rs (PrintC::block_label_name)`, from the target block's entry
address so goto and label always agree). Two printed labels can start at
the same address: `ActionReturnSplit` clones a shared return block once per
goto edge, each clone keeping the original's address cover, and a clone
spliced into its predecessor still starts at the return block's address.
When two such copies are both goto targets, each would print
`label_<addr>:`, a duplicate label (a C compile error) that leaves every
goto to either copy ambiguous. Before the body prints,
`decompiler/crates/kuna-decomp/src/p9_emit/printc.rs (PrintC::assign_label_names)`
walks the structured tree in child order over the leaves that print a
label; the first leaf with a given name keeps it and the n-th takes
`label_<addr>_<n>` (`LAB_%08x_<n>` in ghidra mode). A goto resolves its
target's front leaf through the same table, so it names the copy it jumps
to. A function with no shared label prints exactly as before. Under `ghidra` the upstream scheme
returns: `param_N`, type-prefixed `iVar1`/`uVar2`-style locals
(`decompiler/crates/kuna-decomp/src/p6_variables/coreaction_cleanup.rs
(kuna_default_local_name)`), `func_`/`code_` addresses. Both schemes are
recognized as "generated" by `kuna_naming.rs (kuna_is_generated_name)` so
cross-function name recommendation never propagates a default name.

(kuna) **The ghidra-mode third style (Phase 3, DIV-77).** The ghidra-mode
process sets a separate `name_style_ghidra` flag alongside (not instead of)
the angr default; the resolver `Architecture::kuna_name_style` /
`ArchContext::kuna_name_style` gives it precedence at exactly the
ADDRESS-DERIVED fallback sites — an unresolved callee prints `FUN_%08x`
(`decompiler/crates/kuna-decomp/src/p4_calls/fspec.rs (fspec_printed_name)`),
an unnamed global `DAT_%08x` (`printc.rs (kuna_global_data_name)`), a goto
target `LAB_%08x` (`printc.rs (PrintC::block_label_name)`), the renderers in
`decompiler/crates/kuna-decomp/src/p0_knowledge/database.rs
(ghidra_function_name, ghidra_global_data_name, ghidra_label_name)` — because
the Java side's dynamic-name heuristics key on those spellings
(`isDynamicSymbolName`). Local/parameter naming keeps the angr scheme (the
only ported local-naming pass). Never set on the standalone path, so both
existing styles are byte-identical.

**Where names bind vs. where they render.** The *assignment* is a P6 pass —
`decompiler/crates/kuna-decomp/src/p6_variables/coreaction_cleanup.rs
(ActionNameVars)` binds one name per HighVariable (symbol-derived where a
mapped/global symbol exists, e.g. the DIV-24 DWARF data-global names; the
sequential default otherwise) — and P9 only *consumes* the binding: the leaf
push of §9.2 renders every member of a HighVariable through the one bound
name, which is also what keeps a register/global copy-shadow merge reading as
a single variable. Recovered prototype inputs cross that boundary through
`Funcdata::link_proto_params`: an unnamed input is materialized as `aN` exactly
when `name_style_angr` is set, and otherwise as `param_N`, using the same
`kuna_materialized_param_name` helper as the signature and declaration
suppression paths. The test is deliberately the local-style flag rather than
`kuna_name_style`: GUI Ghidra mode sets its address-style override while leaving
`name_style_angr` on, so its parameters remain `aN`. An explicit nonempty
prototype name always wins. The angr scheme's second visible artifact is P9-owned: each
local declaration gains a trailing storage comment — `// rax` (register,
lowercased), `// stack - 0x10` (frame-relative signed offset), `// rdx:rax` (a
join value's register pieces), `// tmp` (an SSA temporary with no machine
home). `decompiler/crates/kuna-decomp/src/p9_emit/kuna_varsources.rs` gathers
every member's machine storage and the storage retained when simplification
removed an equivalent copy. Distinct homes print once, in sorted order, separated
by ` | `: `// eax | ebx`. A register pair holding one split value keeps its
ordered `rdx:rax` spelling. A mapped object's address reference uses its Symbol
storage rather than the constant offset operand. `tmp` is used only when no
machine home survives. The declaration's storage diagnostics do not change
the earlier declaration-collapse decisions. Collapsed declarations combine the
homes of every HighVariable rendered through them. COPY and same-width
MULTIEQUAL inputs contribute unchanged values' homes, including a conditional
move's selected register, without following arithmetic or memory-address inputs.
Such an input that belongs to another variable reports its own frame offset, not
that variable's base: a register copied from the field at -0x80 of a record at
-0x98 says `stack - 0x80` (this also moves 10 of 4,908 functions' comments under
`--mode reliable`, e.g. `stack - 0x208` to `stack - 0x1c0`).
Register copies used only to supply outgoing CALL or CALLIND arguments are
transport locations, so they do not contribute to a local's source comment.
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_calltransport.rs` checks that
the copy has an earlier home and reaches only argument slots whose ABI storage
matches that register. This keeps a saved register's home even when its only
readers forward the value to outgoing arguments. A reload from an existing
stack local can also be transport; the stack remains its source. A register
that first receives a load, arithmetic result, or call result remains a source
even if the value is later passed to a call. Copies also read by local
computation or a store remain homes. Parameters have no separate source comments.
`option namestyle ghidra` emits no storage comments or storage-tracking work.
DIV-5 re-pinned 185 of the 675 upstream datatest assertions
to the angr names; `option namestyle ghidra` reproduces the pre-DIV-5 bytes.

**(kuna) declhightype — the declared type is the merged variable's own.**
Walking HighVariables rather than the symbol table also decides *which type* a
declaration states. Upstream writes `sym->getType()`, and a symbol's type is the
merged HighVariable's — the type of the member Varnode
`HighVariable::getTypeRepresentative` picks as the most specialized, which is
also the type `ActionSetCasts` queried through `getHighTypeReadFacing` when it
decided whether each use in the body needed a cast. Declaration and body
therefore agree by construction. kuna instead reads the type off its
*declaration representative* — the first address-tied member, else member zero —
which is a different Varnode, and for a high whose members disagree the
declaration then states a type no use was ever checked against. The witness is
an obfuscated x86-64 dispatch loop that merges one RAX across the whole
function: a `char *`-returning call feeds `MOVSX EAX,byte ptr [RAX]`, the cast
machinery sees a one-byte pointee and leaves the dereference uncast, and the
declaration says `unsigned long long *` — so the same `*v9` reads eight bytes
past the object and drops the sign extension. The option `declhightype`
(default on) declares the type representative's type, which is the
`sym->getType()` upstream would have written
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_declhightype.rs
(type_representative)`). It is presentation only: no cast, no statement and no
p-code moves. It applies only to a high the symbol table does not describe — a
mapped local keeps the declaration representative's type, because kuna does not
always type-lock the storage a symbol claims and the most specialized member of
a mapped local can be a transient the symbol never described. A whole mapped
local whose Symbol is type-locked (a DWARF or `--assert type` declaration) with
a boolean, integer, float or pointer type as wide as the declaration
representative, and that is not a parameter, declares that Symbol type instead
(`decompiler/crates/kuna-decomp/src/p9_emit/printc.rs
(locked_scalar_local_type)`), whatever this option says: merging can leave the
representative at a weaker type, such as `void *` for a gcc `-O0` DWARF
function-pointer local, which makes the indirect call through it invalid C.
`declared_variable_type` reports the same type, so the storage-transfer casts
agree with the declaration. A local that coalescing left with the Symbol's type
but no Symbol binding keeps that type only when one of its members is
type-locked to exactly that type and none is an input, persistent, global or
`&symbol` reference view; a recovered type with no locked member never imposes
a declaration. The declaration
representative still supplies the array adornment and the
composite mapped-symbol override, all of which outrank this. `option
declhightype off` restores the declaration representative's type.

**(kuna) signedness — an integer local is declared at the signedness its
operations ask for.** The declaration also states a *signedness*, and the type
lattice decides that in a way the body often contradicts. `Datatype::type_order`
ranks `SUB_UINT_PLAIN` (16) ahead of `SUB_INT_PLAIN` (17), so in
`get_local_type`'s "keep the most specific" fold one `uint` vote outranks every
`int` vote on the same Varnode, and no later phase re-decides (§5.1). On
optimized x86-64 those `uint` votes are structural rather than semantic: a
32-bit instruction zero-extends into its 64-bit register, and a strength-reduced
loop bound is masked and shifted — `INT_ZEXT`, `INT_AND`, `INT_RIGHT` and
`INT_XOR` each seed `TYPE_UINT` on both operands. A counter the source declared
`int` is therefore declared `unsigned int`, and `ActionSetCasts` writes the
signedness back at every comparison: `unsigned int v1;` … `if (0 <= (int)v1)` …
`while (v4 < (int)v1)`.

The option `signedness` (`upstream|auto|prefer-signed|prefer-unsigned`, default
`auto`) decides it at the declaration seam instead, from the operations the
body actually applies to the value
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_typeround.rs (plan)`). This is
TRex's *type rounding* (Bosamiya, Woo and Parno, USENIX Security 2025, §3.3.5):
signedness is not propagated, it is chosen once from the accumulated
size-tagged operation set, with a flag for the case nothing observed settles.
For each declared high of plain integer type the pass walks the operations
reachable from its *printed* (explicit) members and folds them into one verdict:
`INT_SLESS`, `INT_SLESSEQUAL`, `INT_SDIV`, `INT_SREM`, `INT_SRIGHT` (operand 0),
`INT_SEXT`, `INT_SCARRY` and `INT_SBORROW` demand signed; `INT_LESS`,
`INT_LESSEQUAL`, `INT_DIV`, `INT_REM`, `INT_RIGHT` (operand 0), `INT_ZEXT` and
`INT_CARRY` demand unsigned; a `CPUI_CAST` to a plain integer of the same width
is a demand for the type it casts to. `INT_LEFT` (operand 0) also pulls unsigned,
and it is the one entry in that list which is a stated **preference rather than a
soundness requirement**: `a << k` shifts the same bits into the same places under
either declaration, so it is not part of what makes a flip meaning-preserving. The rule is kept because a value the body ORs and shifts left
is a bit buffer, which C source spells unsigned, and because a signed `<<` is the
one otherwise-neutral operator `-fsanitize=undefined` reports; it is not kept
because `negative << k` is undefined, an argument that does not separate `<<`
from `+ - *`, whose signed overflow is undefined on the same footing and which
are neutral here. `auto` declares the value signed when every demand is signed and
unsigned when every demand is unsigned, and leaves it alone otherwise;
`prefer-signed` and `prefer-unsigned` additionally settle the no-demand case,
which is TRex's observation that C programmers write `int` when the signedness
does not matter. A *defining* operation votes but cannot veto, because a
definition converts at a fixed width and is bit-identical either way: the
divide-and-shift family (`INT_SDIV`, `INT_SREM`, `INT_SRIGHT` signed;
`INT_DIV`, `INT_REM`, `INT_RIGHT` unsigned) says what kind of number came out
and votes accordingly, while `INT_SEXT`, `INT_ZEXT` and `INT_2COMP` say nothing
at all — an extension describes the operand it widened, not the widened value,
so `int v = *p;` off an `unsigned char *` and `uintmax_t max = (long)(int)n;`
off a `movslq` are both ordinary C. Nothing else changes: no Varnode type, no
inference pass, no cast decision, and no prototype or symbol type — so the
`variables` JSON surface and every recovered signature are byte-identical, and
so is the whole output under `upstream`.

Which arm ships. `auto` is the default: it moves a declaration only when every
signedness-sensitive reader of the value agrees and nothing vetoes it, so the
only text it can change is that declaration and the casts the new declaration
makes into no-ops. That is what the evidence for the flip measures — 0 of 675
datatest assertions, PARITY OK on the stage corpus, and over twelve binaries
from nine projects at `-O0` and `-O2` — eight x86-64 and four 32-bit ARM
firmware images, 15,124 functions — 377 declaration flips and 443 cast tokens
dropped, none added, with no other hunk of any kind. `prefer-signed` is
the more faithful arm and stays opt-in: settling the unobserved values the way C
source does takes agreement with DWARF on 238 unstripped twins from 93.4% to
98.4% overall and from 71.9% to 94.8% at `-O2`, but it moves 7,081 declarations
image-wide, which is more than the datatest corpus can absorb as a default and
more than an unanimity argument covers. `prefer-unsigned` is the opposite
tie-break, kept as that arm's control and not recommended — 4 of its 40
DWARF-judged flips are right. `upstream` restores the declaration type inference
produced, byte for byte, which is what to select when diffing against upstream
Ghidra.

Soundness rests on the demand set covering every C construct whose meaning
depends on an operand's signedness — which is to say, on the *neutral* list being
signedness-independent. Everything the pass lets through is
signedness-independent at a fixed width — `+ - * & | ^ == !=`, unary `~` and
`-`, an assignment, a call argument, a `return`, a stored value, a truncation or
a concatenation — because two's-complement arithmetic and a same-width
conversion produce identical bits either way.

kuna's own cast strategy draws the same line, which corroborates the split
without proving it. The ordered comparisons, `/ %`, `>>` and the two extensions
pass `care_uint_int = true` to `CastStrategyC::cast_standard`
(`decompiler/crates/kuna-decomp/src/p9_emit/coreaction_casts.rs
(get_input_cast)`), and every op on the neutral list above passes `false` or
takes no cast at all. The demand set is a **superset** of that
`care_uint_int = true` set with one op held out: `INT_SCARRY`, `INT_SBORROW`,
`INT_CARRY`, `CPUI_CAST` and `INT_LEFT` all fall through to the dispatch's
default arm, which passes `care_uint_int = false`, and are demanded on anyway;
`FLOAT_INT2FLOAT` is the converse — it passes `care_uint_int = true` whenever the
operand's nonzero mask has its top bit set, and the pass vetoes it outright
rather than demanding on it, which is strictly stronger. Demanding on the carry
intrinsics and the cast anyway is an over-constraint, not a gap — a carry
intrinsic names its own signedness and a same-width cast prints a token that
establishes the type — and only ever declines a flip that might otherwise have
been made; `INT_LEFT` is the stated preference described above.

"At a fixed width" is a precondition of that list, not a turn of phrase, and it
is the third rule. C's integer promotions convert every operand narrower than
`int` to `int` *before* any of those operators runs, and which extension is
performed is read off the declaration, so below the promotion width nothing is
neutral: `(short)-1 == -1` is true while `(unsigned short)0xffff == -1` is a
constant false, and `+ - * & | ^ << == !=` all diverge the same way. The pass
therefore declines any high whose declared type is narrower than the promotion
width, whatever the operations say — and the promotion width that decides this
is **the `int` of the compiler that reads kuna's output, not the target's**.
Emitted C is read and compiled where `int` is 4 bytes however small the target
cspec's `<data_organization><integer_size>` is; that value is 2 on `avr8gcc`,
`avr8egcc`, `TI_MSP430`, `TI_MSP430X`, `CR16`, `PIC24` and `x86-16`, and reading
the guard off it would let a 2-byte local be re-signed on those targets and turn
an emitted `if (v1 != -1)` into a constant-true test. The floor is therefore
`max(4, TypeFactory::get_size_of_int())`
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_typeround.rs
(MIN_PROMOTION_SIZE)`), pinned on x86-64 by `tests/stages/kuna-signedness.xml`
and on a 2-byte-`int` target by `tests/stages/kuna-signedness-int16.xml`. A width change
*between* two integers is an explicit `INT_SEXT`/`INT_ZEXT` in p-code, so a
mixed-width expression is constrained by the extension op rather than slipping
through as neutral.

Two further rules close the gap between "this operation" and "the printed
expression". First, the walk follows *implied* results: `v + 1 < 0` prints as
one expression, so the C type of `v + 1`, and therefore whether the comparison
is signed, follows `v`'s declaration; an operation that keeps carrying the
operand's type extends the walk to its readers, and one whose result is a
declared variable of its own ends it. Some of the *demanding* operations carry
the operand's type as well — `>>` and `<<` print at the shiftee's promoted type
and `/ %` at the usual-arithmetic-conversion type of their operands — so those
record their demand and continue the walk, which is what keeps a second operator
further out (`(v << 3) >> 2`) from disagreeing unseen, while a comparison, a
cast-printing extension and a carry intrinsic stop it because their printed
result establishes a type of its own. Second, anything unclassified vetoes the
variable outright — a `LOAD` or `STORE` address, a `PTRADD`/`PTRSUB` index
(where `base[v]` really does differ between a signed and an unsigned `v`, and no
cast is inserted), any `FLOAT_*` operation, an indirect branch, a type-locked
member, and a `CPUI_CAST` whose target is anything but a plain integer of the
same width (a pointer, a float, a `char`, an enum, a typedef, a different
width). A flip is written only for a high that **owns its declaration line**. The
printer's candidate list is filtered to sole-named entries before any collapse
runs (`retain_sole_named`), because every collapse that follows — the
composite-Symbol retain, `collapse_symbol_decls`, `DeclDedup` and the
`local_name_aliases` group suppression — pairs two candidates rendering the same
name. Without that filter a flip on one high of such a group could move the
collapse's own key, splitting a declaration that used to collapse, or re-sign
the single line a *non*-flipped sibling's uses read through; with it, which
declarations exist is exactly what it was under `upstream`.

When a high does flip, each `CPUI_CAST` on it whose target is the very
type now declared is a no-op token and is dropped, which is the visible half of
the change: `if (0 <= (int)v1)` becomes `if (0 <= v1)`. The drop is authorized
only by the declaration the emitter actually wrote, so a mapped-symbol, array or
collapse override that takes the declared type back also takes the cast back.

**(kuna) castsign — the same rule for frame locals and pointer indexes.**
`signedness` leaves three places alone where the program compares a value only
signed, and those account for a quarter of the unsigned-to-signed casts kuna
printed in the 2026-09-23 cast census: `unsigned long v15; // stack - 0x60` …
`if (0 <= (long)v15)`. First, every high mapped onto a Symbol is skipped, and a
stack local *is* mapped onto its frame Symbol, at offset 0. Second, a
`PTRADD` index and a conversion to a pointer veto the variable. Third, a body
local one of whose members is an input (a slot or register read before any
write) is skipped as if it were a prototype parameter. With the option
`castsign` on, the pass admits all three
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_castsign.rs`,
consulted from `kuna_typeround.rs (plan)`), and the declaration and the casts
it makes no-ops change exactly as they do for a register local, under two
further conditions described below.

A frame local is admitted only when its high covers its Symbol whole: offset 0,
a Symbol type (if any) that is a plain integer of the declaration's width, and
no other high in the function printing the same name
(`kuna_castsign.rs (whole_slot_local)`). The last condition is what keeps an
address-taken local out. `&v15` is a high of its own bound to the same name,
and re-declaring `v15` would change the C type of `&v15` under a pointer that
was typed for the old declaration. A split slot is kept out by the same test.
No high bound to a type-locked Symbol is re-declared, whichever relaxation
admitted it (`kuna_castsign.rs (symbol_type_locked)`). A `--assert type`, a
DWARF local and a type committed from Ghidra each lock the Symbol, and the
member varnodes the evidence walk checks for a lock do not carry it, so the
test reads the Symbol itself: the naming pass's bind, a dynamic Symbol, and
the Symbol containing each address-tied member. A declared `unsigned long`
keeps its declaration and its `(long)` casts even when every reader is signed.
The declaration line is the one the printer writes from that high. The frame
Symbol's type is not changed, so the `variables` JSON surface still reports the
type inference chose for the slot. A `PTRADD` index at pointer width and a
conversion to a pointer of the value's own width are neutral readers
(`kuna_castsign.rs (neutral_reader)`). `p[v]` computes `p + v * size` modulo
the address width under either declaration, and the signed reading is the one
that keeps a negative index inside C's defined behaviour. gcc and clang convert
a same-width integer to a pointer by keeping its bits. A narrower index is
widened by an explicit `INT_SEXT`/`INT_ZEXT` before the `PTRADD`, and that
extension still constrains the variable. The input-member case needs no test
of its own: the printer declares only body locals, and `retain_sole_named`
drops every planned high it does not declare, signature parameters included.

**Arithmetic keeps an admitted variable unsigned**
(`kuna_castsign.rs (can_overflow)`). Re-declaring `v` signed does not only
remove the casts at its comparisons: every `v + k`, `v - k`, `v * k`, `-v` and
`v << k` the body prints then computes in the signed type, where it used to
compute in the unsigned one. Unsigned arithmetic wraps, which is what the
binary does; signed arithmetic is undefined on overflow, and gcc folds on that
assumption even at `-O0`, clang at `-O2`. `0 <= (long)(v1 - 1)` over a
`long v1` is treated as `0 < v1`, which is false at `v1 == LONG_MIN` where the
binary's `v1 - 1` is `LONG_MAX`; `v1 = v1 - 1, 0 <= v1` over a `long v1` exits
at once for the same `v1` under `-O2`, where the binary loops. So a high this option
admits (a frame local, a body local with an input member, or a verdict a
neutral reader decided) is left alone when any of those operators reads it,
directly or through the expression its value is printed into (the walk follows
implied values, as above). The operand position matters only for `<<`, whose
count is not the value shifted. `& | ^ ~`, a comparison, a truncation, an
assignment, a call argument, a store and a `return` cannot overflow and keep
the variable admissible. A same-width conversion from the old declaration's
type into the new one (`v = strtoul(...)` into a `long v`) is defined by gcc
and clang as the same bits.

**A wide literal keeps an admitted variable unsigned**
(`kuna_castsign.rs (wide_literal)`). The printer may spell a constant whose top
bit is set as an unsuffixed decimal: `3000000000` for a 4-byte constant,
`10000000000000000000` for an 8-byte one. In C that literal's type is wider than
the declaration (`long`, and a 128-bit type in gcc), so `v == 3000000000`
converts `v` to it. An `unsigned int v` is zero-extended, which is the 32-bit
comparison the binary makes; an `int v` is sign-extended, and the comparison is
false for every `v`. A `|` or `^` with such a literal, or whose result meets one
(`(v | 0x80000) == 10000000000000000000`), goes wrong the same way, and `&` is
treated alike. So a high this option admits is
left alone when a `==`, `!=`, `&`, `|` or `^` meets it, or the expression its
value is printed into, with a constant whose top bit is set, either as the other
operand or inside the expression the other operand is printed as (through
`+ - * / % & | ^ ~ << >>`). A hex literal of that value has the unsigned type of
the declaration's width and would convert correctly, but whether the printer
chooses hex depends on the constant's display format and on `integerformat`, so
every such constant vetoes. On the castbench corpus that leaves two
declarations unsigned that would otherwise be re-signed, both beside hex
literals: `ls` O2 `(v17 & v25) != 0xffffffffffffffff` (five casts) and `tar` O0
`v12 != 0xffffffffffffffff`.

**A flip must remove a cast** (`kuna_castsign.rs (drops_printed_cast)`). A high
this option admits is re-declared only when one of its declared members is read
by a `CPUI_CAST` to exactly the new declaration's type that prints today. A cast
whose value is only a call argument, the right side of an assignment or a
`return` may already be left out by `castimplied` (§9.1), so it does not count.
Anywhere else in an expression it prints, including under another conversion
(`SEXT816((long)v34)`, `(long)(int)v8`, `p[(int)v16]`): a same-width sign change
never preserves the value, so `castimplied` keeps it there. A flip that removes
nothing would change the declaration for no printed benefit.

A decision any of these relaxations made may only declare the value **signed**.
The census counts 20 signed-to-unsigned casts on locals against 526 the other
way, and IDA's opposite bias costs it 587 casts, so a mirror rule would buy
little and could overshoot. A value some reader needs unsigned keeps its
declaration: an unsigned comparison, a logical shift right, unsigned `/` or `%`,
or a zero-extension. That includes a zero-extension into a 64-bit return or a
varargs slot, where the high bits are read. Two uses were measured as unsigned
evidence and rejected. One is an argument to a type-locked `size_t` parameter:
gnulib's `idx_t` is signed and is passed to `realloc` and `memcpy` everywhere,
and counting such arguments cost 46 casts over the census corpus while getting
`xpalloc`'s `nbytes` wrong. The other is a store through an unsigned pointer,
whose pointee type inference usually took from the stored value itself. A
same-width conversion computes the same bits in both cases, so neither changes
what the C computes. Re-declaring the left side of an assignment would lose a
widening `castimplied` dropped because the spellings matched, so that rule also
accepts a re-signed declaration of the cast's width (§9.1). The option acts on C
output only. Rust has no implicit integer conversions, so `let mut v1: i64;` would
not accept the `u64` that `strlen` returns (`printc.rs (emit_function_document)`
passes it only when the language's `integer_promotion` capability is set, the gate
`castimplied` uses). With the option off the output is byte-identical to
`signedness` alone. Pinned by
`tests/stages/kuna-castsign.xml` (pass 1 off, pass 2 on: a stack value
compared signed and used as `a0[v1]` is declared `int8`; an index the body
decrements, a logically shifted value and an address-taken stack value stay
unsigned in both passes; pass 3 maps the first value's slot `uint8`, and the
locked declaration keeps its casts), by a compiled round trip
(`kuna-cli/tests/decompile_all_cli.rs`,
`a_signed_only_variable_round_trips_through_the_printed_c`: the printed C is
built with gcc and clang at `-O0` and `-O2` and fed `2^63 - 1`, `2^63`,
`2^63 + 1` and the 32-bit edges, and every build must print what the fixture
binary prints; `castsign_eq_x86_64.c` compares values with `3000000000u` and
`10000000000000000000UL`, directly and after a `|`, and keeps them unsigned),
and by `castsign_leaves_a_locked_declaration_alone` in the
same file (a `--assert type` on a stack and a register local, and a DWARF local
declared `unsigned long`, stay unsigned with the option on).

What the rule reads is the compiler's instruction selection, not the source.
Where a compiler proved a `size_t` non-negative and emitted a signed compare on
it, `auto` declares that local signed and the source said unsigned. The walk
`auto` runs for a register local also treats `+ - *` as neutral, so a register
local it re-declares may be the operand of arithmetic the binary wraps: the
emitted C then computes what the binary computes when it is compiled with
`-fwrapv`, and may not without it at the edge of the range (gcc, and clang at
`-O2`, fold `(long)(v1 + 1) <= v1` over a `long v1` to false, where the binary
finds it true for `v1 == LONG_MAX`). Nor does that walk check wide literals: clang
`-O0` code that compares `ntohl(*p)` with `3000000000u` prints
`int v1; // eax` beside `if (v1 != 3000000000)`, false for every `v1`.
`castsign` does not extend either trade to the highs it admits (above). `docs/features/signedness/analysis.md`
carries the measured agreement rate against DWARF on unstripped binaries, which
is the number this option is judged on.

**(kuna) paramrefdecl — an `&parameter` reference is the parameter.** Because
the emitter walks HighVariables rather than the symbol table, it also has to
decide for itself which highs upstream would *not* have declared:
`PrintC::emitScopeVarDecls` is asked only for `no_category` symbols, so a
`function_parameter` symbol appears in the prototype and nowhere else. kuna
answers that by asking whether a `function_parameter` symbol contains the
storage of one of the high's member Varnodes — which is right for every high
that has storage of its own, and blind to a parameter whose address is the only
thing the body ever takes. A `&symbol` reference is carried as the offset
constant of a `PTRSUB(spacebase, off)` (§9.3), bound by
`ActionNameVars::linkSpacebaseSymbol` to the symbol owning the referenced frame
slot; when that slot is an incoming stack parameter the body never reads as a
value, every Varnode of the reference high lives in the constant space, the
storage test finds no parameter, and the high is declared in the body under the
name it took from the parameter symbol it is bound to. The result is a
signature parameter and a body local of the same name and different types in one
scope, which is not compilable C.

With `stackviews` enabled, a formal input and its reused body backing can have
identical stack geometry. A high containing an input and linked to the exact
`function_parameter` symbol remains a prototype parameter even if a container
query would select the body union. The prototype-name guard still applies.
This preserves the incoming value without declaring an uninitialized local
under a suffixed parameter name. A high linked to the backing has a distinct
symbol and keeps its body declaration.

The option `paramrefdecl` (default on since DIV-143) supplies the missing half
of the same predicate, on symbol identity rather than storage: a high whose
bound symbol — the identity `linkSpacebaseSymbol` already recorded, kuna's
`HighVariable::kuna_ref_symbol` for upstream `Varnode::setSymbolReference` — has
category `function_parameter` is that parameter, so no declaration is emitted and
the `&a0` in the body resolves to the prototype's own `a0`
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_paramrefdecl.rs
(references_parameter_symbol)`). It is not a rename: the parameter is not
duplicated under a fresh identifier, the second object simply stops existing. The
skip inherits the storage arm's guard that the high's name is one of the
prototype's parameter names, so a symbol renamed out from under the prototype
keeps its declaration rather than becoming an undeclared variable, and a
reference to a `no_category` local (`&v7`) carries a different category and is
untouched. The same symbol identity answers the `variables` JSON surface, which
collects a parameter's uses by matching Varnodes against the parameter's storage
and so reported an address-taken parameter as unused while the emitted C showed
the reference; the reference is attributed to the parameter only when no
storage-backed or name-backed evidence was found
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_paramrefdecl.rs
(parameter_reference_varrefs)`). `option paramrefdecl off` restores the distinct
body object, but the function-scope uniqueness invariant gives it a suffix
instead of re-declaring the parameter's identifier.

*(kuna perf)* Whether a high is a reference, piece or strict partial whose
declaration belongs to a same-named sibling (the whole symbol, the storage local
a `&symbol` reference points at, the group's owner) is answered from the
function's named highs grouped by name once per declaration walk, each group in
the high bank's own order (`printc.rs (SameNamed)`). Each test walks only its
name's group instead of every high of the function, and finds the same first
sibling it found before. With the other GH-1034 fixes in, serde-hkx's 174 KB
deserializer drops from 238 s to 152 s, nearly all of it in these walks.

**(angr) dedupvardecls — collapsing duplicate declarations.** kuna's
declaration emitter walks HighVariables, not the upstream symbol table (which
declares each Symbol exactly once), so many scalar HighVariables sharing one
stack slot — all bound to the same name by the shared-storage naming — would
each emit a textually identical declaration line (x86_64/cvs `main` declared
one slot 166×). Composite symbols (arrays/structs/unions) are always collapsed
to one declaration per mapped symbol by an unconditional identity check in
`printc.rs (PrintC::emit_local_var_decls)`; the scalar analogue is the option
`dedupvardecls` (default on since DIV-7; row `source_decompiler = "angr"` —
angr's variable recovery yields one variable per storage location, declared
once), which collapses in two steps.

*By symbol.* Several HighVariables whose declaration representatives resolve to
one containing `ScopeLocal` symbol, and that render the same identifier, are one
variable and emit one declaration — the invariant upstream gets for free by
walking the symbol table. The symbol behind a storage location is the
smallest entry containing its base byte — upstream `Funcdata::linkSymbol`'s own
query — ignoring the use-point exactly as the parameter-category query of §9.3
does (`decompiler/crates/kuna-decomp/src/p6_variables/varmap.rs
(ScopeLocal::containing_symbol_for_storage)`), and the survivor is the first in
emission order. When the collapsing highs *agree* about the slot's type, that
recovered type stands, being the sharper information. When they *disagree*, the
survivor declares the symbol's own type — upstream `emitVarDecl` declares
`sym->getType()` — unless the symbol's type is narrower than the widest storage
the group covers, in which case the widest member wins. kuna's `ScopeLocal`
ranges can be narrower than the accesses that reach them, and a declaration
smaller than the object the body writes through would be a new defect rather
than a faithful one.

*By rendered line.* A declaration is then suppressed when its fully rendered
signature — final declarator type and its post-name suffix, name, array
adornment, and (under angr naming) the storage comment — is byte-identical to
one already emitted *for the same object*
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_dedupvardecls.rs
(DeclDedup)`). The object is the local Symbol the naming pass bound the high to,
or, for an `&symbol` reference high whose only storage is the `PTRSUB` offset
constant, the Symbol it points at; a high bound to neither is its own object
(`kuna_dedupvardecls.rs (DeclIdentity::of)`). The references are what this
step still collapses: two `&v30` operands of one stack slot are two highs that
the storage query of the symbol step cannot see, and suffixing one would make
the body take the address of a second object. Identical text alone is not
enough. Two register or temporary highs that took the same name from a
recommendation are two variables, and one declaration for both made the body
write through whichever was assigned last (#762). Keyed on identity, the lines
survive and the uniquifier below suffixes the second.

*By overlap group.* Register aliases can form a `VariableGroup` without any
mapped `ScopeLocal` Symbol: for example, separate AL and AH highs plus the AX
high that covers both. When exactly one declared piece contains every other
piece and all carry the same recovered name, only that whole-value high is
declared. References to the suppressed subpieces resolve through the whole
owner, so the byte writes render as `v4._0_1_` / `v4._1_1_` against one
`undefined2 v4` declaration. An absent or ambiguous whole cover does not trigger
this collapse, and differing user/debug names are never merged. If such grouped
pieces still collide after every semantic collapse, each is instead suffixed and
its access is rendered relative to its own piece-sized declaration (never, for
example, `byte_2._1_1_` against a one-byte object).

After the semantic and rendered-line collapses, declaration identifiers are
made unconditionally unique within the C function scope. The allocator reserves
parameter names, every original local spelling, every snapshotted global-symbol
name, and every rendered direct-callee name; it keeps the first available
spelling and gives any genuinely distinct collision a deterministic `_N`
suffix. Reserving the non-locals prevents a generated `value_1` declaration from
capturing an existing `value_1` global access or direct call. The chosen spelling
is keyed by HighVariable and used by every body reference path as well as its
declaration; existing parameter, user/debug, Ghidra-style, global, and callee
names remain authoritative.

A suffix must reach every high that prints the renamed object, not only the one
that kept the declaration line. So each high the walk declares through another
records that other high as its owner, and before suffixing, every owner chain is
followed to the declaration that finally survived
(`printc.rs (PrintC::settle_local_name_aliases)`); body references then read that
declaration's spelling (`printc.rs (PrintC::emitted_high_name)`). The owners are:
the survivor of every collapse above; for a struct piece (a by-value struct
argument rebuilt from registers has no declaration per field), the root in its
VariableGroup; for a scalar partial view, the high in its VariableGroup that
covers the whole Symbol at full width (`printc.rs (owner_in_group)`); and for an
`&symbol` reference, the storage high bound to the local Symbol it points at
(`printc.rs (reference_owner)`). An owner is never a global's high, and a
reference with no local Symbol, which is a reference to a global, has no owner,
so a global's accesses keep the global's name even when a local of the same
name is suffixed. A piece, a partial view and a reference each point at a high
of another kind (a root, a full-width whole, a storage high), and a collapsed
declaration points at one that survived the same collapse, so a chain never
revisits a high; if one did, its highs would keep their own names rather than
borrow another's. Without the
owners, a local struct named like a global was declared `obj_1` while its field
stores still printed `obj.a = ...` and wrote the global, a stack slot declared
`perf_ret_1` was still read as `(int4)perf_ret`, the global, and after a rename
gave two stack slots one name `&v2` kept printing the other slot's address. An
owner always carries the name of the high that points at it, so nothing changes
unless the owner is suffixed.

The name allocator stores each spelling once, either reserved for a future
declaration or assigned with its next suffix counter. It uses only keyed lookup;
the caller's declaration order, never hash iteration, decides who receives each
name. This replaces separate reserved-name, used-name and suffix-counter maps
without changing the first-free-suffix rule.

Duplicate-name counting borrows the declaration strings and releases those
borrows before suffix assignment mutates names. The allocator consumes borrowed
names directly and owns its reserved keys, without an intermediate string-copy
vector. Rendered-signature deduplication likewise observes only set membership;
caller order determines which declaration is retained.

Partial covers of a mapped scalar are suppressed only when another
HighVariable with the same name actually represents the whole storage: its
first member is non-constant, starts at symbol offset zero, and has the symbol's
full width (`printc.rs (high_name_has_scalar_whole_sibling)`). A constant
`PTRSUB` offset bound to `&local` also carries the symbol's name and full width,
but its declaration is filtered as an address reference; treating that constant
as the whole sibling would suppress every real partial and leave `local` used
without any declaration. When no whole storage high exists, the partials reach
the symbol-keyed collapse above, which retains one declaration for the shared
name.

The symbol step is what makes the collapse total for a *mapped* slot. The line
step alone left one stack slot declared twice under one name with two types
whenever two of its live ranges did not merge and recovered different types
(DIV-52), which is not compilable C and which no rendered-line key can catch.
No collapse can remove the last declaration of a referenced name: the symbol
step requires the identifier to match, the line step requires the whole line and
the object to match, and the overlap step requires a declared unique whole owner. `option
dedupvardecls off` restores the one-line-per-HighVariable behavior for the two
option-controlled collapses; overlap-owner collapsing and collision suffixing
remain active because unique, correctly bound C identifiers are an output
validity invariant rather than a presentation choice.

**(kuna) declorder — the order the declarations print in.** The collapses
and the suffix allocation above walk the locals sorted by name, a plain string
sort under which every two-digit name lands between `v1` and `v2`: a function
with eleven numbered locals declared `v1, v10, v11, v2, ..., v9`. Once the
final spellings are known, and only then, the option `declorder` (P9
`naming-policy`, default `natural`) reorders the surviving declarations
(`decompiler/crates/kuna-decomp/src/p9_emit/kuna_declorder.rs (order_decls)`).
`natural` compares two names character by character, except that where both
have an ASCII digit run at the same position the runs compare by numeric
value: leading zeros dropped, then the shorter run first, then digit by digit,
so no run is too long to compare. Two names whose runs differ only in leading
zeros fall back to plain string order, which keeps the order total and agrees
with name equality (`kuna_declorder.rs (natural_cmp)`). The same eleven locals
then declare `v1, v2, ..., v9, v10, v11`, the order IDA declares its numbered
locals in. Because the reorder runs after the collapses and the suffixes, the
choice of which declaration survives a collapse and which spelling takes a
suffix is the name-sorted one either way; only the order of the declaration
lines changes. The reorder applies to angr-style names, the default
`namestyle`: Ghidra-style names carry hexadecimal offsets (`local_1c`,
`uStack_a8`) that a decimal comparison would scramble, so under
`namestyle ghidra` the declarations keep the string order. `option declorder
name` keeps the string order everywhere.

## 9.4 Strings & comments

**String literals.** A constant pointer whose target type is a character type
triggers the string probe at the leaf push (§9.2): resolve the constant to an
address in the default data space, require the location to be **read-only**
in the global scope (writable data may have changed since load — refuse to
print a literal), then ask the string manager for decoded bytes and emit the
escaped, quoted literal — with an `L` prefix for wide characters and, when the
literal was clipped, the terminator `..." /* TRUNCATED STRING LITERAL */`
(`printc.rs (PrintC::push_ptr_char_constant_ir, PrintC::print_character_constant)`).
On any refusal the constant falls back to the ordinary integer render, so a
wrong guess costs readability, never correctness. The manager itself —
`decompiler/crates/kuna-decomp/src/p9_emit/stringmanage.rs
(StringManagerUnicode)`, one shared instance per Architecture with a
2048-character budget — pulls loadimage bytes 32 at a time until it finds a
character-width-aligned NUL (no terminator within budget, or unreadable
memory ⇒ not a string), validates the whole buffer as UTF-8/UTF-16/UTF-32 by
element width (any invalid codepoint or unpaired surrogate rejects the entire
literal), re-encodes to UTF-8, and caches the result — including negative
results — keyed by address and the complete decode mode (character width plus
opaque-string status), so one interpretation cannot supply the cached result
for another regardless of function-decompilation order. The decode mode is
marshalled with the result; legacy entries without it are not cache hits
(`stringmanage.rs (StringManagerUnicode::get_string_data)`). Rendering escapes per codepoint:
`printlanguage.rs (unicode_needs_escape)` classifies control characters,
separators, bidi markers, surrogates and private-use ranges as escape-worthy,
and `printc.rs (print_unicode)` emits the named C escapes then falls to `print_char_hex_escape`, which emits only `\x` (zero-padded to 2/4/8 hex digits by codepoint magnitude). Internal strings
(not in the loadimage) can be registered under a constant-space hash address
and resolve through the same cache.

When `globalarrayanchor` is enabled, `ActionConstantPtr` records its per-function
pass count for the P3 folding guard (§3.5). Reset activates this count only for
a scheduled action with the option on; functions without that action leave the
guard inactive. The fourth pass releases its hold on unresolved array-base
constants.

The probe's entry condition is a **type**, not a detected string boundary: the
manager reads from whatever address it is handed, so the whole question is
whether the constant arrived carrying a character-pointer type. Type inference
supplies that for a typed callee parameter, and for a constant that hits the
start of a detected literal `ActionConstantPtr` supplies it via the global
spacebase reference. (ida) The remaining case is a pointer into the **interior**
of a read-only character array — how a compiler that merges string constants
shares one literal's tail (`"coreutils"` is stored only as bytes 4.. of
`"GNU coreutils"`; `"%s"` as the tail of `"%s: %s"`). `ActionConstantPtr`
recognizes it — upstream deliberately relaxes its exact-hit requirement for
character arrays — but the reference it builds for an interior hit is a spacebase
`PTRSUB` plus an `INT_ADD` of the residual, and constant folding collapses the
pair straight back to the bare constant, discarding the type; the exact-start
case survives only because its residual is zero. Upstream repairs this later
(`RulePtrsubCharConstant` rewrites the reference into a typed constant); kuna
instead types the constant where the evidence already exists — the covering
symbol is a character-printable array, which is stronger proof than inspecting
the bytes — and leaves the exact-hit path untouched
(`decompiler/crates/kuna-decomp/src/p9_emit/coreaction_render.rs
(ActionConstantPtr)`). Everything after that is the ordinary probe, including its
fallback: if the address turns out not to be read-only, or the bytes do not
decode, the constant prints as an integer exactly as before.

**The zero-character literal.** The probe's accept test is the string manager's
`is_string`, and that answers yes for *any* read-only location whose first
character-width unit is a NUL: `stringmanage.rs
(StringManager::check_characters)` walks only as far as the first terminator, so
for a zero-length string it validates zero characters and can reject nothing.
A pointer into a binary blob that happens to open with a row of zeroes therefore
passes the probe and renders `p = ""` — a token that names no byte of the image,
in place of the address, which was the only thing in the statement a reader
could follow.

Emptiness alone is not the tell, though, and this is where a narrower rule goes
wrong: `setlocale(6,"")` is idiomatic C, and a linker that merges string
constants stores a program's only `""` as the tail NUL of some other literal, so
the empty string is *real* there and the address would be the worse render.
What separates the two is the evidence the emptiness test never looked at — the
bytes *past* the terminator. A genuine `""` is followed by the next literal in
the table (`00 00 00 65 72 72 6f 72 20 69 6e 20 72 65 67 75`, the `""` `nl`
hands `setlocale`); a blob pointer is followed by bytes no C string holds
(`00 00 00 00 00 00 00 00 00 77 df 77 ff fd ff 7f`). **(kuna) emptystrconst**
(default **on**, `decompiler/crates/kuna-decomp/src/p9_emit/kuna_emptystrconst.rs
(declines_literal, reads_as_string_data)`) reads sixteen bytes at the constant
and declines the literal only when the escape walk emitted no characters *and*
those bytes positively contradict string data: skip the terminator run, walk the
next run up to its NUL, and reject if any byte in it is outside printable ASCII
and `\t`/`\n`/`\r`. The constant then falls through to the ordinary casted-hex
print. It is a falsification test on purpose, so everything it cannot judge keeps
the upstream literal — a window of nothing but NULs (padding at the end of a
section), a run that reaches the window's end still spelling text, an address
whose neighbourhood is unreadable, and of course any literal with even one
character of its own (`"\n"`, `"%"`). Only the first run after the terminator is
judged: `du`'s `fts_alloc(sp,"",0)` opens the table `"" "." ".."` and keeps its
quotes even though relocation bytes follow four bytes later. Turning the option
off restores the empty literal in every case. What
this does **not** repair is the reason the blob pointer carried a
character-pointer type in the first place: it shared a merged live range with a
genuine `char *` parameter (§6), and the probe is doing what it is supposed to do
for a `char *` constant once that type is established.

**An indexed table is a literal only when the index stays inside it.** With
`elemptr` on (05-types §5.2), a character-pointer constant that is the base of a
`PTRADD` indexed by a computed value is probed with the index's largest value
(`decompiler/crates/kuna-decomp/src/p5_types/kuna_elemptr.rs
(literal_index_bound)`): a zero-extended byte is at most 255, a mask is at most
its mask, an unsigned remainder is less than its divisor, and anything else is
unbounded. `push_ptr_char_constant_ir` keeps the literal only when that bound is
at most the literal's character count — its NUL is the last byte still inside it
— because the C `"..."[x]` reads the literal, not the image. A table the string
probe accepts as text ends at its first zero byte and the table does not: findutils'
and tar's `get_date` parsers index bison tables (`yycheck`, `yytable`) that printed as `"\x05"[v0]` and a 110-byte
escape string indexed by the parser state, and coreutils `sort` indexes a
256-byte table whose first byte is zero, which printed `""[*v15._0_8_]`. So an
unbounded index declines the literal too. The bound is consulted only for a
constant `elemptr` itself typed (`Funcdata::kuna_elemptr_typed_constant`): a
character array another pass already recovered keeps the spelling it had
(`sort`'s `"CCc"[v21]`, `tar`'s base64 alphabet, `&" %s"[v0]`). A declined
literal falls through to the address, and so to the array name `globalref` gives
it (§9.9). A constant whose character-pointer type comes from `elemptr` alone —
it reaches, through copies and merges, a pointer the rule typed or a callee's
parameter the rule typed and stated, and nothing reads it as a C string — never
prints as a literal (`kuna_elemptr.rs (reaches_element_pointer)`, 05-types
§5.2): the reader indexes the bytes and may take more than a literal ending at
the first zero byte holds. The upstream symbol path (a read-only character-array symbol) does
not consult the bound.

**A character pointer the probe declines is still an address.** When the bytes
at a `char *` constant do not decode as a string — the GB18030 quote glyphs
gnulib's `gettext_quote` returns (`a1 07 65 00`) are the common case — the
constant falls through to the pointer arm's casted-hex print, and with
`globalref` on (§9.9) to `&dat_<addr>` declared `char`.

**Comments.** Comments reach the output through the P0 knowledge plane, never
inline in the IR: analysis passes call `decompiler/crates/kuna-decomp/src/substrate/funcdata.rs
(Funcdata::warning, Funcdata::warning_header)` — buffered per function, then
flushed by the decompile drive into the Architecture-wide comment database
`decompiler/crates/kuna-decomp/src/infra/architecture.rs (CommentDatabase)`
with byte-exact de-duplication (same function, address, and text ⇒ dropped),
so re-decompilation never doubles a warning. At print time
`printc.rs (PrintC::setup_comments)` loads the function's comments into the
sorter `decompiler/crates/kuna-decomp/src/p9_emit/comment.rs (CommentSorter)`,
which bins each comment by the basic block containing its address and orders
it against the block's ops; the body emitters then interleave them — each
statement flushes the comments sorted before it (`printc.rs
(PrintC::emit_comment_group)`), and a construct that folds several blocks onto
one line (an `if` header) pre-flushes its whole subtree so no comment can land
mid-expression (`printc.rs (PrintC::emit_comment_block_tree)`), forcing the
pending `else if` brace when it does. Which categories display is a
`PrintContext` default (`printlanguage.rs
(PrintContext::reset_defaults_internal)`): header + warning-header types
render as `/* ... */` lines above the prototype, user and warning types inside
the body at the 20-column comment indent; a comment is marked emitted after
printing so overlapping windows never repeat it.

## 9.5 Pointer & array notation

**(kuna) arraynotation** — the second GH-558 decision (its registry row
records `ghidra-upstream` because the upstream *issue*, not upstream code,
motivated it; the implementation is kuna-original). A scaled pointer-add
(`PTRADD`) has three renders, decided at `printc.rs (PrintC::op_ptradd_ir)`:
inside a load/store context (the `print_load_value`/`print_store_value`
modifier is set, i.e. the pointer is being dereferenced) it is always the
subscript `base[index]` — that is upstream behavior and not optional; a
*standalone* PTRADD — the address value itself, passed to a call or stored —
is upstream `base + index`, and kuna's `option arraynotation` (default **on**,
DIV-2 lineage; option struct in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_arraynotation.rs
(OptionArrayNotation)`, the flag on `printc.rs (PrintCOptions)`) renders it
`&base[index]` instead, keeping the element-typed reading — implemented as
two ordinary RPN tokens (address-of wrapping a subscript), so the surrounding
expression parenthesizes through the normal §9.2 precedence predicate. The
display-side relatives follow the same philosophy — a
symbol-mapped array access renders `name[index]` with the index in its
natural base, and a spacebase reference to a mapped local renders `&a` /
`&myval.b` through the PTRSUB symbol markup (§9.2's partial-symbol walk).
Flip `off` for consumers that diff against raw pointer arithmetic
([docs/options.md](../options.md)); the toggle is per-render and pure
presentation.

## 9.6 Alternate languages

**(kuna) The output-language plane.** The C++ tree kuna was ported from selected a
back-end through a `PrintLanguageCapability` registry over a three-level hierarchy
(`PrintLanguage` → `PrintC` → `PrintJava : public PrintC`); the port flattened
that into one concrete `PrintC`. kuna re-erects the seam by **parameterizing** the
single emitter rather than growing a second one: `PrintC` carries one `out_lang`
field, and every language-varying site reads a `&'static` policy object through
`printc.rs (PrintC::lang)` instead of naming a `keywords::`/`tokens::` constant.
The RPN driver, the op emitters, `parentheses`, the cast plumbing, the comment
sorter and the markup back-end are shared verbatim — there is no duplicated
emitter, which is what keeps one implementation of "emit an `if`" as languages are
added.

Three artifacts make up the plane, all in
`decompiler/crates/kuna-decomp/src/p9_emit/`:

- **`kuna_lang.rs`** — `OutLang` (the selector), `LangProfile` (the surface
  vocabulary: the keyword and punctuation spellings the emitters use, plus the
  `OpToken`s whose *spelling* varies; the ~40 arithmetic/comparison/shift tokens
  are identical in every language kuna targets and stay in `printc.rs (tokens)`),
  and `LangCaps` — **what the emitter is allowed to produce**. `LangCaps` is what
  lets a language that cannot express a construct never be handed one, instead of
  the operator being asked to flip the kuna rendering defaults that would produce
  it (`truthycond`'s implicit-bool condition, `braceelide`'s braceless body,
  `condfold`'s comma operand, `nullprinting`'s `NULL`). Its load-bearing member is
  `switch_captures_break`: a C `switch` captures a bare `break`, which is why
  `p8_structure/kuna_loopbreak_recovery.rs` legitimately retags a
  goto-to-switch-exit as `f_break_goto` (§8.3); a language whose switch does *not*
  capture `break` must re-resolve that scope or emit a jump to the wrong place.
  A direct case edge marked `f_break_goto` is precisely an empty switch-exit
  arm. `kuna_langrust.rs (PrintC::emit_match_arm_rust)` emits its pattern and
  empty body without a transfer statement. Rust leaves the match naturally;
  a bare `break` would instead leave an enclosing loop or fail to compile when
  there is no loop. Shared case labels retain their common empty arm. Other
  case transfers and breaks emitted inside actual loop bodies retain their
  existing handling. This corrects Rust emission without changing C or Go
  output, the recovered control-flow graph, or the option catalog.
- **`kuna_langtypes.rs`** — `TypeSpeller` and `SpellCtx`. Type *recovery* (P5) is
  language-independent; only the spelling differs, and it lives in the printer for
  the reason `kuna_ctypes.rs` records: `Datatype::hash_name` makes the registered
  name determine the type id, so renaming the interned core types would break the
  Ghidra wire protocol. `SpellCtx` is the former `RealTypeCtx` — `Copy`, already
  threaded through every declarator chokepoint — now also carrying the language, so
  the free-function declarator family reaches its speller with no new parameter.
  `TypeSpeller::declarator` is documented as `<front><name><back>` rather than
  promising a meaningful `back`, because the front/back split is a C-ism: C
  declarators wrap the identifier (`int4 (*a)[1]`) where other languages' types are
  pure prefixes.
- **`p4_calls/kuna_langabi.rs`** — `LangAbi`, the ABI seam. It owns one decision,
  consulted by the Rust prototype emitter: which `extern` a signature declares.
  Rust declares `extern "C"` exactly when the prototype is variadic (rustc admits
  a C-variadic on nothing else) and otherwise nothing, which means the
  unspellable default `extern "Rust"`. Chapter [04](04-calls-and-prototypes.md)
  explains why the axis is thin and what a third language would add.
- **`kuna_langc.rs`** — `CSpeller`, the c-language policy object. It carries the
  declarator algorithm transcribed from `pushTypeStart`/`pushTypeEnd`/
  `buildTypeStack` and the `realtypes`/`ctypes` relabelling (DIV-5/DIV-6), moved
  verbatim out of `printc.rs`, which keeps thin dispatchers.

  C declarator modifiers are consumed outermost-to-base around the identifier.
  A pointer prefixes the declarator; a later array postfix groups the complete
  accumulated declarator before appending its suffix.  Thus a pointer to an
  array is `T (*p)[N]`, an array of pointers is `T *p[N]`, and deeper
  pointer/array alternations preserve the same precedence instead of moving only
  the nearest parenthesis.  Casts, parameters, locals, members, typedefs, and
  exported type strings all share this speller. The internal postfix builder is
  generic enough to obey the same rule for a function suffix, although current
  `Datatype` traversal supplies pointer and array modifiers only.

  Every declaration places both halves around its name, because the front of a
  pointer-to-array declarator (`T (*`) is not a type on its own.
  `TypeSpeller::type_name`, the declaration-position spelling, therefore returns
  the pair too, with an empty back for everything but a C pointer whose
  declarator needs one. A cast or an exported type string is `<front><back>`
  (`T (*)[N]`); a parameter or a struct member is `<front><name><back>`; a local
  is `<front><name>[ [count]]<back>`, so an array of pointers to arrays keeps its
  count inside the group (`T (*v [2])[N]`); and a return type puts its front
  before the function name and its back after the parameter list
  (`T (* f(int x))[N]`). The rendered-line collapse of §9.3 keys on the back as
  well, so two locals differing only in it both survive.

The invariant that makes the seam free: every `LANG_C` field **is** the constant
it replaces, asserted field-by-field — and by pointer identity for the tokens,
since `printlanguage.rs (parentheses)` decides parenthesization with `ptr::eq`.
Reading the C profile therefore produces the identical token, so introducing the
plane is a byte-identical rewrite and `docs/baseline.json` is never re-pinned.

**(kuna) The rust-language back-end.** `option setlanguage rust-language` selects
it (`p0_knowledge/options.rs (OptionSetLanguage)`, the upstream selector, which
now rejects a name no back-end claims rather than silently keeping C). The
recovered function is not re-analysed: the same `Funcdata`, the same types, the
same structured block tree render through a different profile. Three files carry
it: `p9_emit/kuna_langrust.rs` (the profile, the capability record, the three
`OpToken`s whose spelling or precedence differs, and the emitters for the shapes
that are not C's), `p9_emit/kuna_rusttypes.rs` (the speller), and the
`LangForms` matches in `printc.rs` that choose between them.

What differs, and why each is a language fact rather than a preference:

- **Signature** `unsafe fn n(mut a0: T) -> R`. `unsafe` because a decompiled body
  dereferences raw pointers, and an `unsafe fn`'s body carries them with no inner
  block; `mut` on every parameter because a decompiled body assigns to its
  parameter slots and the recovery does not distinguish the ones that do. A unit
  return is omitted rather than spelled `-> ()`.
- **Declarations** `let mut n: T;`, with an array count folded *into* the type
  (`[T; N]`) rather than trailing the identifier.
- **Types** `i8`..`i128` / `u8`..`u128` / `f32` / `f64` / `bool` / `*mut T` /
  `[T; N]` / `()`. A recovered text byte spells `u8`, never `char` — a Rust `char`
  is a 4-byte Unicode scalar with a validity invariant that a decompiled byte does
  not carry. A declared `signed char` (chapter 01) is not the target's text type
  and spells `i8`, so `c as i64` sign-extends; its byte constants print as
  numbers, since `b'a'` is a `u8`. A width Rust cannot name (3/5/6/7, x87's 10) spells `[u8; N]`, which
  is *more* faithful than C's `undefined3`: it names the storage exactly and does
  not claim to be a scalar.
- **Integer widening** remains explicit: Rust has no implicit C integer
  promotions, even when a wider arithmetic operation consumes the result.
  `p9_emit/kuna_rustextend.rs` interprets signed core text storage at its
  signed integer width before `INT_SEXT` widens it. A byte stored as `u8`
  therefore extends through `as i8`, preserving negative byte values without
  changing text declarations, pointer pointees, or return signatures. Narrow
  arithmetic stays inside that interpretation so its original truncation occurs
  before widening. Zero extension retains unsigned interpretation.
- **Recovered composite names** are spelled in *type* position rather than
  flattened to an identifier. A composite carries whatever spelling the debug
  info recorded — `Result<u8, u32>`, `Vec<u8, alloc::alloc::Global>`,
  `(u8, u32)` — and every character in those is legal Rust type syntax, so the
  identifier sanitiser would turn `Result<u8, u32>` into `Result_u8__u32_` and
  discard the one thing the reader wanted. What falls outside the type grammar
  (a DWARF `{closure#0}`, a codegen-unit suffix) still collapses to `_`, and a
  name whose brackets do not balance falls back to the identifier sanitiser
  whole, because a stray `<` would swallow the rest of the declaration.
- **Names** are rendered as Rust *paths*, not flattened into identifiers. `::` is
  legal wherever a name is used — a call, a static — because that position takes a
  path; only a `fn` *definition* needs a bare identifier, so it takes the last
  component and the full path goes in a comment directly above. Flattening `::` to
  `__` everywhere (what a naive identifier sanitiser does) discards the module
  structure for nothing and produces `alloc__vec__Vec__resize` where
  `alloc::vec::Vec::resize` is both valid and what a reader expects.
- **Operator precedence** comes from a declared ladder, not from per-token
  numbers: `LangProfile`'s `PrecLadder` names each tier once, in order, with its
  rank. A language remaps only the tokens whose tier it MOVES — everything else
  keeps the ported C table's number — so the ladder must speak the same numbers
  the table does, and a test asserts that any tier a language leaves in place
  keeps C's rank exactly. Rust moves four: `& ^ |` sit ABOVE the comparisons where
  C puts them below, every comparison shares one non-associative tier where C
  ranks relational above equality, and `as` gets a tier of its own between the
  multiplicative and unary operators. The first of those is why the ladder is
  declared rather than hand-numbered — it changes what `a | b == c` *means*, so
  getting it wrong is a silent wrong answer rather than a syntax error, and
  hand-numbering eleven tokens is precisely how that happened once already.
- **Casts** `x as T`, which inverts the operand order relative to C's `(T)x`;
  every cast site brackets its operand with `push_cast_open`/`push_cast_close`
  instead of emitting the type inline. The `as` token additionally sets
  `OpToken::paren_before_angle`, because `x as i32 < 5` parses `i32 <` as the
  start of generic arguments and precedence alone cannot express that.
- **Loops** `loop { }` for the infinite form, `while c { }` with no parenthesised
  condition, and `loop { body; if !(c) { break; } }` for the bottom-tested one.
  A condition carrying statements — what C renders as a comma expression — becomes
  Rust's block expression `while { stmt; c } { }`. The C `for` header is not
  reached at all: `analyze_for_loops` is gated on `LangCaps::c_for` at the
  `ArchContext` copy, because the reroll physically MOVES the initializer and
  increment and rendering that as a `while` would drop them, while moving them
  back at print time would let a `continue` skip the increment.
- **Multi-way branches** `match v { A | B => { … } _ => {} }`. Arms do not fall
  out, so C's explicit `break;` is dropped; a `match` on an integer must be
  exhaustive, so a `_` arm is synthesised when the recovered switch had no
  `default`; and a wildcard must come last, so the default arm is hoisted (safe,
  because the remaining patterns are disjoint integer literals). Multi-label arms
  are free — `emit_switch_case` already enumerates one `case N:` per jump-table
  index for a shared block, and the same list joins with ` | `. Each pattern is
  the label C prints, signed to the scrutinee's type and masked to its width,
  since rustc rejects a pattern outside that type's range. Note the ordinary
  `case A: case B: body` shape is ONE recovered case with two indices, not a
  fall-through chain.
- **Selection expressions** the `iteregion` recovery renders `dest = if c { A }
  else { B };`. Rust's `if`/`else` is an expression, so this is a *better* form
  than C's `?:`, not a lost one — the passes stay on.
- **Literals** no `U`/`L`/`LL` suffixes (Rust infers the literal type, and naming
  a width here would assert one this site does not know); `b'a'` for a 1-byte
  character constant with a printable spelling and the integer otherwise, since
  Rust has no `'\xff'`; and a string body escaped with Rust's set, which has no
  `\a`/`\b`/`\v`/`\f` and in which a single quote must be BARE — `"PCRE\'s"`
  does not tokenize.
- **Three kuna rendering defaults are suppressed by capability, not by asking an
  operator to flip them**: `truthycond` (DIV-37) would emit `if x` on a `u32`,
  `braceelide` (DIV-38) would emit a braceless body, and `nullprinting` (DIV-35)
  would emit `NULL` (Rust spells it `core::ptr::null_mut()`). `condfold`'s comma
  operand has no Rust form either and is refused the same way.
- **Constructed null expressions** use `printlanguage.rs (TagType)`'s
  `LiteralToken`. `printc.rs (PrintC::emit_atom)` emits that final Rust spelling
  through the same variable-markup path, preserving the operation and varnode
  associations while keeping the parentheses in `core::ptr::null_mut()`.
  Recovered variable names, including enum constants, still pass through the
  identifier speller. The tag preserves this distinction for both constant
  and variable highlighting. C and Go null atoms keep their existing tags.
- **What Rust cannot express** is marked, never silently emitted. The structurer
  manufactures `goto`s as its escape hatch and Rust has no form for one that is
  neither a `break` nor a `continue`; those render as a comment plus a **diverging**
  `panic!("kuna: unstructured goto to <label>")`. Diverging so the document still
  type-checks in any position, loud so a reader cannot mistake it for a
  translation, and greppable because that count over a whole-binary render IS the
  quality number for this back-end — exactly what `gotoreduce`, `taildup`,
  `ifelseflatten` and `crossjumprevert` reduce. A genuine switch fall-through gets
  the same treatment: resolving it needs the next arm's body duplicated, which is
  a block-graph edit and not a printing decision.

The contract is **`syn::parse_file` validity, not `rustc` compilation**, and
`kuna-console/tests/verify_outlang_rust_syntax.rs` enforces exactly that by
parsing the emitted document. Decompiled output calls functions that have no
definition, `CARRY4(a, b)` has no Rust spelling, and `[u8; 3]` does not do
arithmetic; making the output compile is a separate and much larger project.

**The marker is reported, not only emitted** (GH-668). A body whose jump became a
`panic!` is a translation up to that jump and not past it, so a consumer that
reads only the exit code, stderr and the `error` field used to be told a lossy
render was a clean one. Two channels carry the fact now. Every surface that
renders a function names it on stderr in one line — the count, the function, and
the two ways out (`--language c`, which spells the jump as a real `goto`, or a
P8 structuring option that removes it) — and every per-function JSON record
carries `unstructured_gotos`, which is `0` on a C render and on a Rust one with
nothing lost. The **verdict does not move**: exit stays `0` and `error` stays
`null`, because the rest of the body is usable output and a caller that already
treats success as "there is code here" is not wrong.

Both channels count occurrences of `UNSTRUCTURED_GOTO_MARKER` in the *rendered
text*, exported from `p9_emit/kuna_langrust.rs` beside the printer that builds
the marker from it. Counting the text rather than the emitter is what makes one
mechanism serve every surface: `kuna decompile` drives `decomp_dbg` as a
subprocess and would never see an in-engine counter, a `--jobs` worker ships
framed records across a pipe, and the WASM front-end holds only the document —
but all of them hold `code`. The matched text includes the marker's unescaped
`"`, which a Rust string literal in the decompiled program can never contain
(the printer escapes an interior quote), so program data cannot inflate the
count. The switch fall-through marker is a comment with no diverging call and is
deliberately outside this count: it is a different lossy construct, and naming
one number `unstructured_gotos` that meant two things would be worse than
reporting the one.

Two surfaces refuse the language rather than half-honouring it. `kuna-ghidra`
pins its Clang token-markup document to C (`process.rs`), because that document
is consumed by Ghidra's C token model and Rust text in C token slots is a GUI
regression. `kuna decompile-project` errors, because its `.c`/`.h`/`.asm` export
is C-shaped end to end.

**Verified Go pairs (`gopairreturns`).** `p9_emit/kuna_gopairreturns.rs` renders
the pair-result metadata imported by `godwarfsig` when both options are on.
Every consumer verifies the full two-field, 16-byte, eight-aligned integer
layout against its language facet; a name prefix or an ordinary two-field
record is insufficient. `SpellCtx` shares the enabled architecture's type
factory without copying its metadata table. Function declarations and function
pointer types use the same `(int64, uint64)`-style result spelling. Local
storage remains an anonymous struct with named result fields.

A statement call assigns both fields from one invocation. An implied call
passes its two results as the sole arguments of a function literal returning
the struct; the original call evaluates outside that literal's parameter
scope, so generated parameter names cannot capture caller identifiers. Returns
project a stable local's two fields, forward a matching pair call directly,
or use the inverse function literal to evaluate any other joined expression
once. PIECE constructs the struct from its low and high eight-byte operands,
with explicit scalar conversions where required. A verified pair cast of an
implied eight-to-sixteen-byte zero extension constructs the low field and a
zero high field, including a wholly zero pair. A 16-byte left shift by exactly
64 bits instead constructs a zero low field and takes the input's low word.
Go reads that word from validated pair storage or a materialized 16-byte local;
it does not apply an integer shift to a byte array. The selected input is
read once. Other shift amounts, volatile values and unproven storage retain
the ordinary emission path. An opaque 16-byte integer or byte carrier from a
call, load or materialized local may also feed a proven pair. Go passes that
carrier once into a function literal that reads its two words; C uses a
compound union value with the proven pair layout. A call may have an opaque
16-byte return type, or an unlocked unresolved prototype with an existing
16-byte result varnode. The latter retains the recovered result width even
when the provisional prototype still says void. A locked void return or an
already typed pair does not qualify for this conversion.
These adapters avoid an invalid direct conversion between a byte array or
128-bit integer and the pair struct. Existing field extraction
and partial stores retain their ordinary struct semantics. An eight-byte
SUBPIECE at offset zero or eight projects the corresponding validated field,
including from an implied indirect call, and converts signedness at the scalar
field rather than casting the whole struct to an integer. If call-output
extraction instead narrows a field to fewer than eight bytes, the shared
integer field renderer preserves that width, including a narrowed second
result from a callback, without evaluating the call twice. If call-output
trimming has already reduced an amd64 ABIInternal call to one eight-byte
register, an exact RAX/RBX storage match selects the first/second result from
the single-evaluation adapter. C and Rust make the same projection directly
from the ordinary struct-valued call while both import options are enabled.
A callee's two-result type alone does not turn
that narrowed output back into a whole struct. Operation and
variable associations remain attached to the recovered expressions. C and
Rust continue to render the ordinary proven struct; with either import option
off, their previous output is unchanged.

**Go output (`outlang go`).** `p9_emit/kuna_langgo.rs` adds a Go profile and type
speller to the shared RPN and block printer. `outlang c|rust|go` is a cataloged
alias of `setlanguage`; the engine default is C and the CLI automatic policy is
unchanged. Explicit Go selection applies to any input language. Function names
are legal Go identifiers with the original qualified symbol in a comment;
invalid names, keywords, predeclared names and the generated helpers' `math`/`unsafe`
package names use an injective byte-hex escape, including escaping
the escape prefix itself. Locals, parameters and member tokens use the same rule.
Same-package call references omit that package qualifier. For Go source images,
`p9_emit/kuna_gopackage.rs` also resolves the current function's package for
record type spelling: `main.scale` uses `*point` for `main.point`. The context
reaches nested pointers, arrays, local declarations and conversions. Import-path
dots, method receivers and generic function arguments do not alter the package
boundary. Only a simple type identifier with the exact package prefix is
shortened; external and compound type names retain their existing spelling.
This per-document context never renames the interned type and is cleared for
other source or output languages.

Go integer and float names retain the recovered byte width. Unknown or unusual
widths use `[N]byte` storage rather than assert a different integer size. Arrays
use `[N]T`, pointers use `*T`, void/opaque pointers use `unsafe.Pointer`, and a
code pointer with a recovered prototype uses `func(...) T`. Signatures use
`func name(parameter T) R`, with no return type for void, and locals use `var`.
Variadic tails use the blank identifier so they cannot capture a source name.
This is a presentation of the recovered ABI: it does not infer missing Go
multi-results, receivers, strings, slices or interfaces.

`p9_emit/kuna_gobyteview.rs` makes bounded artificial members of byte-array
storage usable under Go output. A final unnamed piece covering the whole array
reads or writes the array value directly. A one-, two-, four- or eight-byte
integer piece uses `*(*T)(unsafe.Add(unsafe.Pointer(&path), offset))`, preserving
the named member/subscript prefix and the exact memory offset. This is an lvalue
for stores as well as a read. Its integer type follows the emitted Go value type,
so its signedness agrees with the surrounding assignment and operand conversions;
the facing IR type must independently qualify for the same kind of view.
The varnode and both value types must have the access
width, and the complete access must fit inside an array of one-byte unsigned or
unknown elements. Anonymous partial types of such arrays use their cached
unsigned or unknown stripped type. Negative or overflowing offsets, unsupported
widths, other containers, volatile or annotation values, address-position
accesses and pending casts keep their existing handling. An unknown scalar
carrying floating-point data also declines the integer view. This changes only
Go spelling; it neither changes the ABI nor infers source tuples. In particular,
an inferred two-word result remains `[16]byte`, with both words preserved.

`p9_emit/kuna_gobyteextract.rs` prints a scalar `SUBPIECE` of a whole named
local byte array as a bounded typed read. The local's actual declaration and
the Go value type must both identify the complete byte array. The source must
be explicit, nonvolatile and addressable; implied expressions, globals,
annotations and constants keep the existing handling. Integer results of one,
two, four or eight bytes use their read-facing type, or the defining type when
there is no reading operation. A result consumed directly by a store instead
uses the rendered destination pointer's integer pointee type; both that type
and the facing result type must qualify. This preserves the store's signedness
even when inference gives the local pointer and the access different types.
Pointer, boolean and floating results decline,
as do unknown results consumed as floating-point storage. A constant low-end
byte offset must fit completely inside the input. For big-endian storage its
memory offset is `input size - result size - low-end offset`; little-endian
storage uses the low-end offset directly. The read takes the address of the
existing local, so an earlier call that produced the array is neither moved
nor duplicated. This is Go output spelling of the recovered register carrier;
it does not infer a source multi-result signature.

Go integer extensions retain their explicit widening conversion before the
consuming expression. C's implicit-promotion rule cannot hide a `SEXT` or
`ZEXT` in Go. A narrow signed interpretation is kept inside the widening cast,
so scaling a signed byte happens at the recovered wider width rather than
overflowing the byte first.
Widening a boolean uses the Go conversion form that evaluates its operand once
and returns integer one or zero; a boolean is never used directly in arithmetic.

The token table puts shifts and bitwise AND with multiplication, OR and XOR
with addition, and all comparisons below those groups. Boolean XOR is `!=`.
Equal-precedence right nesting retains parentheses unless the same associative
operator permits flattening. Operand and assignment conversions use the type
actually emitted for each local after declaration collapse and signedness
selection, rather than an earlier SSA member's type. Integer constant copies
spell the destination-width bit pattern directly, so an unsigned destination
receives `0xffffffffffffffff` rather than the invalid constant conversion
`uint64(-1)`. The same rule follows at most eight implied, same-width integer
COPY/CAST nodes when a constant reaches a return or operand; it never folds
named values, arithmetic or effects. Numeric conversions use
`T(value)`; integer and pointer conversions carry `uintptr` and `unsafe.Pointer`, and pointer indexing
uses `unsafe.Add` with the IR's byte scale. Boolean-to-integer conversions use a
single-evaluation function literal. Float storage transfers use the matching
`math.Float32bits`/`Float64bits` and inverse operations, preserving the distinction
from numeric conversion. Non-finite and negative-zero literals retain their bits.
Rune and string escaping uses Go syntax; invalid rune values stay numeric. A
resolved one-byte C string pointer uses `unsafe.StringData` and includes its
terminating zero. Wide or truncated pointer strings retain their address.
Internal one-byte `DISPLAY_STRING` values use the same data-pointer conversion
and retain their recovered pointer type before any caller conversion. This
also covers length-bounded Go string arguments rewritten by `fatstr`; their
separate length operand is unchanged. A Go string value cannot be converted
directly to `unsafe.Pointer`.

Go has neither ternary nor comma expressions. Recovered if diamonds remain
statements. A short-circuit operand with leading statements evaluates those
inside a `func() bool { ...; return condition }()` operand, so skipped operands
have no effects. While and C-shaped for loops become Go `for` forms. A bottom-
tested loop uses a fresh first-iteration boolean in its for header: the first
condition is skipped, every later condition is tested, including after continue.
Braces and else clauses share the required lines regardless of C brace options;
selecting Go does not mutate those options.

Switch labels sharing a body form one comma-separated case. A case's sole goto
to another case can be rendered by ordering those cases adjacently and replacing
that goto with `fallthrough`; its now-unused label is suppressed. The decision
uses the current block graph, not stale chain metadata after return duplication.
Other gotos remain explicit, including jumps Go's lexical scope rules may reject.
Unknown machine helpers retain their operands. The broad contract is parseable
Go; compilation and execution are checked for the supported scalar, pointer,
conversion and control-flow fixtures. Missing types, low-level helpers and
incomplete ABI recovery still prevent arbitrary output from compiling.

The Java back-end is deliberately not ported:
`decompiler/crates/kuna-decomp/src/p9_emit/printjava.rs (PrintJava)` is a
recorded LOSS whose constructor returns an error — upstream `PrintJava` is a
thin `PrintC` subclass (shared token table and RPN driver, eight overrides for
object references and `instanceof`), and no oracle datatest selects the
`java-language` back-end, so Java remains unregistered; C, Rust and Go are the registered output
languages, with `c-language` the engine default (`printc.rs (CAPABILITY_NAME)`). What *is* live is the Java half of
the cast strategy, `cast.rs (CastStrategyJava)` — Java's pointer-encoded
object references change which extensions and pointer conversions are
representable as casts — kept current alongside `CastStrategyC` so a future
`PrintJava` port is emitter wiring only.

## 9.7 Whole-program document renders (`kuna decompile-project`, `kuna decompile-graph`)

**(kuna) Three additive render surfaces** back the `kuna decompile-project`
project export (the CLI driver is
`decompiler/crates/kuna-cli/src/decompile_project.rs`; usage in
`docs/agents.md`). All three are pure *readers* of finished state — they run
after analysis, insert no ops, flip no options, and change no byte of any
existing render path (the datatest / stages / `decompile-all --json` outputs
are untouched), which is why none carries a `phases.toml` row or a DIV entry.
That still holds under `--stream`, one level down: the streamed export
drives these same renders and changes no byte any of them produces, but the
project folder it assembles from them has a layout of its own — the single
documented exception, described at the end of this section.

After writing the artifacts, a serial project export reports every rejected
assertion on stderr. Ordinary rejections leave the export successful unless
`--assert-strict` requests a nonzero exit. A directive accepted and later refused
by the pipeline always makes the export fail. These checks include declarations
for callees outside the selected bodies and unresolved local directives; accepted
directives keep their final applied outcomes.

**Type definitions — the `docTypeDefinitions` port.** `printc.rs
(PrintC::doc_type_definitions)` is the previously-unported C++
`PrintC::docTypeDefinitions` surface — the console `print C types` command
(`decompiler/crates/kuna-console/src/ifacedecomp.rs (IfcPrintCTypes)`) was a
stub and now wires through it, via the driver
`decompiler/crates/kuna-decomp/src/infra/decompile_drive.rs (print_c_types)`.
It emits a C definition for every user-defined data-type in the factory,
consuming `decompiler/crates/kuna-decomp/src/substrate/dtype.rs
(TypeFactoryImpl::dependent_order)` (chapter [05](05-types.md) §5.1) so every
definition precedes its uses. Core types, unnamed types, and the internal
`Partial*` slices are skipped; what renders is typedefs, structs, unions, and
enums (`printc.rs (render_type_definitions)`; the per-type body renderers —
`compose_type_body`, `compose_enum_body`, `compose_typedef_line` — are pure
functions for unit-testability, and emission is direct string building, since
no emitter markup exists for type definitions). The structures `structsynth`
minted are moved after every other type, in ascending `N`
(`decompiler/crates/kuna-decomp/src/p5_types/kuna_structsynth/ledger.rs
(in_name_order)`), because the tree orders them by the address of a field's type
and the header would otherwise change from run to run (chapter
[05](05-types.md), struct synthesis). Two documented `(kuna)`
divergences from the upstream emission, both in service of "the `.h` always
compiles":

- **Forward-declaration block first.** Upstream prints one anonymous
  `typedef struct {…} name;` per type — a form that cannot express a
  self-referential or mutually recursive pointer field. kuna instead emits a
  `typedef struct <n> <n>;` tag+typedef forward declaration for every
  struct/union up front, then the bodies as plain `struct <n> { … };` in
  dependency order; an incomplete (field-less) struct emits *only* the
  forward declaration, annotated `/* opaque */`.
- **Explicit padding fields.** Struct field-offset gaps and trailing padding
  (the field extents vs `get_size()`) render as `undefined1 _pad<hexoff>[N];`
  members, so `sizeof(struct <n>)` under a recompile matches the decompiler's
  layout. Bitfields render best-effort (`<type> <name> : <bits>;`, padding
  suppressed since their byte coverage overlaps the gap computation); unions
  carry no padding.

A non-C identifier is rewritten by `printc.rs (sanitize_type_name)` (annotated
`/* renamed from "…" */`), and a later duplicate name emits a
`/* duplicate type name skipped */` comment instead of a redefinition — the
first definition wins.

**(kuna) A type name and a function name cannot be the same name.** C keeps
typedefs and functions in one namespace at file scope, and POSIX supplies
several spellings that are both: `stat`, `sigaction`, `group` are each a struct
tag and a function. An image that carries `struct stat` in its debug info and
calls `stat()` therefore produced a header where
`int stat(const char *, stat *);` is `error: 'stat' redeclared as a different
kind of symbol` — and, because the parse does not recover, every declaration
after it fails too. `decompiler/crates/kuna-console/src/project.rs
(build_header)` resolves the clash in favour of the type: a function whose name
is one of the header's typedef names (`project.rs (typedef_names)`) has its
prototype emitted as a comment carrying the full signature, instead of as a
declaration. The type is what every other signature in the file depends on; the
suppressed prototype is one line, and it is still printed. The rule is the
header's alone: the body still spells a call to such a function and a cast to
such a type with the one name they share, so the exported `.c` keeps the clash
the header sheds.

**The prototype — one token stream, two documents.** The prototype segment of
§9.2's document walk was extracted verbatim into `printc.rs
(PrintC::emit_prototype_declaration)` — pure code motion, byte-identical
inside `emit_function_document` — so `printc.rs (PrintC::doc_prototype)` can
drive the IDENTICAL token sequence standalone: the same
`set_output_stream()` → emit → `output_str()` capture harness as
`doc_function_full`, plus a trailing `;`, minus the header warning comments.
The contract this buys the export: the `.h` prototype minus its `;` matches
the `.c` definition line **token-for-token** — there is no second prototype
printer to drift. The exporter does not canonicalize the reserved C entry-point
name: a recovered `void main(void)` remains exactly that in both documents rather
than being rewritten to an unsupported `int` signature. Consumers that only need
to syntax-check the header can macro-remap `main` before inclusion. The public driver is `decompile_drive.rs
(print_c_prototype)` (a function with no recovered proto store renders
`void <name>(void);`).

**The recompile prelude.** `decompile_drive.rs (print_c_recompile_prelude)`
generates the typedef block that makes the other two renders compile: one
standard-C typedef per interned *core* scalar type (`typedef unsigned int
uint4;`, …; 8-byte integers always spell `long long` so the text is
data-model independent; `bool` is covered by `#include <stdbool.h>`;
`char`/`void` are real C and emit nothing), then the fixed Ghidra/kuna
`undefined` family — `undefined`, `undefined1..8` (3/5/6/7 mapped to the next
larger unsigned integer, each carrying a sizeof-divergence note) and
`undefined16`/`undefined32` as byte-array structs. The non-printer half of
the export (section enumeration, one-instruction disassembly, raw image
bytes, named data symbols for the `.asm`/`README.md` artifacts) lives on the
console engine, `decompiler/crates/kuna-console/src/engine.rs
(ConsoleProgram::sections, disassemble_at, read_bytes, global_data_symbols)`,
not in this folder.

**The streamed layout.** `kuna decompile-project --stream` (chapter
[00](00-overview.md)) drives these same renders one result at a time and
adds three pieces of its own, none of which a non-stream export can see.
The linear disassembly walk becomes **resumable**
(`decompiler/crates/kuna-console/src/project_stream.rs (AsmSweep)`): the
same section-by-section walk
`decompiler/crates/kuna-console/src/project.rs (build_asm)` performs,
cut into steps against a code-byte budget, carrying its scratch state —
above all an in-progress `db` run — across the cut, so a chopped budget
shifts which step a byte is written in and not which byte is written.
`header_lines()` plus every step plus the data tail is the non-stream
`.asm` exactly. The **variables section** (`project_stream.rs
(render_variables_section)`) then carries what the labels lost: a
streamed sweep runs to completion long before any function has
variables, and an append-only file cannot go back under a label, so the
per-function `; arg:` / `; stack:` blocks are collected into one address-then-name
ordered `; --- variables ---` section appended after the sweep, ahead of the unchanged
`; --- data ---` tail (`project_stream.rs (render_data_tail)`). The set of comment
lines is exactly the set removed from under the labels. Finally the
README gains a second **layout** and an in-progress render
(`decompiler/crates/kuna-console/src/project.rs (render_readme,
ReadmeLayout, render_readme_streaming)`), the first describing the
streamed `.c`/`.asm` and the two extra files, the second adding a banner
and a status table while the export runs; the `Standard` layout is
byte-identical to what the single renderer emitted before it was split.
A third layout, `Progress`, is only ever rendered while a run is going: a
`--progress` export writes the `Standard` artifacts at the end, so
its running README inventories those, adds the feed form of `index.jsonl` and
`.streaming`, and says the `.c`/`.h`/`.asm` do not exist until the export
completes; the completed export writes the `Standard` README itself.

**The graph document.** `kuna decompile-graph`
(`decompiler/crates/kuna-cli/src/decompile_graph.rs`) is another additive reader
of completed program state: one JSON document holding every discovered function
with its recovered signature, parameters, C body and assembly, plus the call
edges between them. It adds no analysis facts, mutates no IR and changes no
existing C rendering, so it has neither an option row nor a DIV entry. The
field-by-field schema is `docs/cli.md`; what follows is why the document says
what it says.

Every question the document answers is answered by the surface that already owns
it, because two surfaces disagreeing about one program is the failure mode here.
Which entries exist and which of them have bodies is the whole-binary target
policy of §0.2 (`function_entries_canonical` for the rows,
`decompiler/crates/kuna-cli/src/decompile_all.rs (resolve_targets)` — i.e.
`function_entries_executable` — for the bodies), so an address that is callable
but not executable content is a labelled row — `import` for a pointer slot the
program calls through, `data` for a named address that is simply not code —
rather than a body lifted out of a pointer table. Naming such an address with
`--addr` does not buy an exception: the row would then contradict its own `kind`,
and what the run produced would be a plausible-looking function lifted out of a
pointer table. What a function *is* comes from
the shared per-function classifier
(`decompiler/crates/kuna-console/src/classify.rs`), the same one the browser
inventory groups by. Bodies and parameters come from the shared decompile loop
(`decompiler/crates/kuna-console/src/project.rs (decompile_targets)`), which
isolates a failure to one record — and that record's `error` is carried into the
document, so a consumer counting functions is not silently counting a subset.
Assembly comes from the listing walk
(`decompiler/crates/kuna-cli/src/disassemble.rs (function_listing)`), so an
undecodable byte inside a body is a `.byte` row and not the loss of the whole
listing. Edges come from the reference index `kuna xrefs` answers with, through
the same call-graph model `--reachable-from` walks
(`decompiler/crates/kuna-cli/src/callgraph.rs (CallGraph::callees_of)`).

The CLI graph module owns inventory containment, reachability and caller
completeness queries. Its scheduling module,
`decompiler/crates/kuna-cli/src/callgraph/plan.rs`, owns the iterative SCC walk
and recursion policy used by callee-first decompilation. Object-file consumers
share `decompiler/crates/kuna-cli/src/image.rs`: they read the selected Mach-O
slice and reject TE inputs that have no object-file view. These boundaries are
shared by the command drivers without changing edge rules or output ordering.

**Both ends of every edge are rows of the same document.** A reference into the
middle of a body resolves to the body, and one that lands in no discovered
function at all — a `CALL 0x0` off a nulled relocation, a branch into a gap
between entries — is not a call-graph edge and is not emitted, because a
consumer that has to model containment itself to use the edge list has been given
the wrong list. An edge's kind is the `kuna xrefs` kind, so the document and that
command cannot describe one program differently: `call`, `jump` for a tail call or
a branch into a neighbouring entry, and `data` for a function whose address is
materialized. The third is not optional decoration — it is how `main` has a
caller at all in a glibc program, where `_start` hands it to `__libc_start_main`
as a pointer, and dropping it would under-report exactly the indirection an
obfuscated program leans on. A materialized address that does not land on a known
function entry is not an edge (that is a string or a global, not a callee), and
where a caller both calls a function and mentions its address, the one edge
carries the stronger of the two kinds. A computed call whose destination is not a
decode-time constant has no static target and therefore no edge at all; it is
reported as `hasIndirectCalls` on the row that contains the call site — `CALLIND`
only, folded onto its function by the same ordered containment that decides which
function an instruction's references are listed under
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (XrefIndex::has_indirect_calls)`)
— while a forwarding veneer's `jmp [slot]` is an indirect *branch* whose
destination is in fact known, and is reported as `forwardsTo` instead. An
imported API call, `call qword ptr [slot]`, is the case where a `CALLIND` *does*
carry an edge: the slot is a decode-time constant the reference walk reads out of
the instruction (§1.6), so the row is both an edge to the import and
`hasIndirectCalls`. That slot
is only recoverable where the jump names it as a decode-time constant, so an
AArch64 stub that computes it across `adrp`/`ldr`/`br` is a `thunk` row with a
null `forwardsTo`.

**Ordering is total, so two runs of one command are byte-identical.** Function
rows are entry-VMA ordered; each caller's edges follow in first-reference order
with a contiguous zero-based `calleeOrder`, deduplicated on the callee. The key
is `address` and only `address` — a name is not unique in the document, since a
thunk, the pointer slot it forwards through and the callable they stand for are
three rows under one name.

**The document is C.** `codeC` names its language, so this surface refuses any
other rather than half-honouring the request, exactly as the project export does
(and it is excluded from the same auto-language policy, so a rustc-built binary
does not silently produce Rust in a field called `codeC`).

**Absent provenance is `null`, never a placeholder.** `analysisImageBase` is the
PE optional-header ImageBase when present and otherwise the lowest non-empty
loadable segment VMA, keeping it in the same static VMA space as the function and
edge addresses; a relocatable object has no comparable static base and reports
`null` rather than its synthetic loader layout. A field that could never be
filled is not carried: the loader retains no library-module mapping, so the
document has no module-qualified callee rather than a key that is always `null`.

## 9.8 The per-function type-definition preamble (`structdefs`)

The composite definitions §9.7 renders exist only on the whole-program
surface. A single function printed to a terminal gets none of them: a body that
reads `f->_flags` names `FILE` in its signature and nothing says what a `FILE`
is, so the layout the decompiler recovered — the thing the field accesses are
printed *against* — is invisible on the surface most callers actually read.
`option structdefs on` (P9 sub-decision `type-definition-preamble`, default off)
prints it, above the function, the way angr prints its typedefs.

**What the preamble contains** is the definable types that function's own C can
name: composites, enums and typedefs, never core types.
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_structdefs.rs
(referenced_types)` collects the function's semantic type surface — the
prototype's return and parameter types, every Varnode data-type, and every
mapped Symbol type behind a HighVariable — and walks each one's dependency cone
(`kuna_structdefs.rs (visit)`): the typedef base first, then the component
sub-types `substrate/dtype.rs (Datatype::get_depend)` reports — a pointer's
pointee, an array's element, a struct's fields — pushing each definable type
after everything it depends on. The result is definition-before-use over
exactly the referenced subset, which is the order §9.7's
`TypeFactoryImpl::dependent_order` produces over the whole factory, computed
here from the roots instead so a whole-binary run costs the types a function
touches rather than the types the program interned.

**Those roots are chosen to be a superset of what the printer spells.** Every
type name in the emitted C is read off one of them — a local declaration off a
high or its mapped symbol, the signature off the prototype, a cast off the
Varnode type it casts to — so the preamble cannot omit a definition the body
refers to. Collecting from the emitted token stream instead would be exact for
names that print, and would miss the struct behind `p->field_0x8`, whose tag
name the C never prints at all. The cost of the choice is the opposite error: a
type carried by a Varnode that contributes no token can be defined above a
function that never names it.

**One renderer, two surfaces.** `printc.rs
(PrintC::emit_type_definition_preamble)` hands the subset to the same
`printc.rs (render_type_definitions)` §9.7 builds the export's `.h` type block
with, so a preamble line and a header line for one type are the same line: the
forward-declaration block first, then bodies, an incomplete struct printing as
`typedef struct FILE FILE; /* opaque */`, a padding gap as `undefined1
_pad<hexoff>[N];`. It is emitted as whole lines rather than tokens, before
`begin_function`, because a type definition has no `PcodeOp` or `Varnode` for
the markup back-end to bind to. A `kuna decompile-project` export therefore
*suppresses* the preamble in its bodies
(`decompiler/crates/kuna-console/src/project.rs (decompile_pulled)`): those
bodies include a header that already carries every definition, and printing them
again above each body would redefine them. The suppression is keyed on a batch
option that says exactly that — *this caller renders a header that defines these
types* (`DecompileOptions::header_carries_types`, set by the export surfaces and
by a `--jobs` worker serving one, which is the worker the export asks for the
`.h` type block with `--jobs-types`). It is deliberately **not** keyed on
`want_proto`: `kuna decompile-graph` asks for prototypes too, and its document
is per-function C with no header artifact, so it keeps the preamble inside
`codeC` exactly as `decompile-all` keeps it in `code`. The preamble is
documentation rather than a translation unit — a `undefined1` padding member
needs the export's recompile prelude to compile — which is the other half of why
the definitions stay in the header on the surface that is meant to rebuild.

**Two disclosed roughnesses.** A definition whose name is also a function name
prints directly above that function's own definition: `typedef struct stat
stat;` over `int stat(char *a0,stat *a1)` is not a translation unit a compiler
accepts, and the export's `.h` says as much where it drops such a prototype
(§9.7). The preamble does not apply that guard — it is documentation, and
hiding the layout of `stat` from the one function that is about to use it costs
more than the collision does. And the over-inclusion the Varnode-rooted walk
buys (above) is real: a function whose only contact with `FILE` is handing
`stdout` to a callee still gets `FILE` defined above it. On a stripped corpus,
where a libc shell has no members and so pulls nothing else in, that is about one
definition in seven (55 of 367 over stripped `cmp`, `od`, `find`, `tar`); on
their unstripped twins it falls to 50 of 10,912, because a DWARF type the body
does not name is almost always a dependency of one it does.

**The preamble is C, and says so by declining.** The renderer builds the
project export's `.h`, so its output is C whatever the active output language
is: under `--language rust` a `struct X { … };` block carrying Rust-spelled
field types would be neither valid Rust nor readable C. `kuna
decompile-project` refuses a non-C output language outright for exactly that
reason (§9.6, §9.7); the preamble takes the same decision one step smaller —
it declines, and the body is emitted as it would have been. Teaching the
definition renderer the language plane is that plane's work, not this option's.

**The machine-readable half.** `decompile_drive.rs
(extract_type_definitions)` reports the same set as the `types` array of a
`kuna decompile-all --json` function record: one object per type carrying its
name, its definition text (`kuna_structdefs.rs (definition_text)` — the body for
a complete composite, the enum block, the typedef line, or the opaque forward
declaration) and its size, so a consumer reads a recovered layout without
parsing C out of `code`. The key is always present and is empty unless the
option is on: the array and the printed preamble are one decision. The factory
can hold two data-types under one name — a DWARF image carries both the
forward-declared `struct _IO_FILE` and the defined one — which the rendered text
already resolves by printing one forward declaration and one body;
`kuna_structdefs.rs (dedup_by_name)` applies the same rule to the records, since
two entries for `_IO_FILE` reporting size 0 and size 216 is a contradiction a
JSON consumer has no way to resolve.

## 9.9 Constant addresses named as globals (`globalref`)

A pointer-typed constant that no global Symbol covers has exactly one spelling
in the pointer arm of `printc.rs (PrintC::push_vn_explicit_ir)`: the forced-hex
integer behind a typecast, `sub_e4ca((struct_2 *)0x2b080)`. Upstream reaches a
name only through `coreaction_render.rs (ActionConstantPtr)`, which links a
constant to a Symbol that already exists, and a stripped image has none for most
of its data — while kuna prints `dat_2b080` two statements away for the same
address, because *reading* an unnamed global goes through the unnamed-location
leaf (§9.3), which names it. The type campaign made the cast commoner rather
than rarer: once a callee's parameter is recovered as `struct_2 *`, the
constant a caller passes it is typed `struct_2 *` too, so `sub_e4ca(0x2b080)` at
the campaign baseline became `sub_e4ca((struct_2 *)0x2b080)` (572 such casts on
the functions kuna and IDA both emit before the campaign, 1,118 after it). IDA
prints `sub_E4CA(qword_2B080)` and no cast.

`option globalref` (P9 sub-decision `constant-address-global`, default **on**)
prints such a constant as `&dat_<addr>` — the name the unnamed-location leaf
already uses, or `DAT_%08x` under `namestyle ghidra` — and records the global as
an object of the pointed-to type. The expression then has exactly the constant's
pointer type, so the cast is gone because the object is declared at that type,
not because it was suppressed, and its value is the address it replaces
wherever `dat_<addr>` is placed at `<addr>`. The decision is
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_globalref.rs (Plan::decide)`,
consulted at the top of the pointer arm after the string probe (§9.4) and
before the NULL token and the cast; `printc.rs (PrintC::push_global_ref_ir)`
emits the `&` and the name, bound to the constant Varnode for markup.

**Where a global can be.** The object loader classifies its sections once
(`decompiler/crates/kuna-analysis/src/loader/kuna_globalref.rs
(holds_program_objects)`): an allocated section of initialized, read-only or
zero-filled data is a place a program object can live; code is not, a TLS
template is not (its addresses are offsets, not run-time locations), and
neither are the tables the toolchain and the run-time loader own even when
their kind says data — `.got`, `.plt`, `.eh_frame`, `.gcc_except_table`,
`.interp`, `.dynamic`, the PE import/export/exception/relocation directories,
the Mach-O symbol-pointer and unwind sections. The merged ranges reach the
engine as `infra/architecture.rs (Architecture::globalref_ranges)`, installed by
the object bootstrap beside the `litpoolconst` ranges; every path without a
section table leaves them empty, so the rule is inert for the XML datatest
corpus.

**What one function knows.** `kuna_globalref.rs (plan)` walks the function
once when its document starts, and records three facts:

- the constant values the function reads *as numbers* — a non-pointer constant
  read by an ordering compare, a multiply, a divide, a remainder or a shift
  (`kuna_inferfuncentry.rs (reads_as_integer)`, the question `inferfuncentry`
  asks of a constant that lands on a function entry: coreutils `tail`'s
  `BUFSIZ` is `0x2000`, which is that image's `_DT_INIT`);
- every direct access to the default data space — the `dat_<addr>` the body
  reads or writes — by start, width and type;
- for each in-range constant address, the pointed-to types the function reads it
  at: through `void *` only, at one other type (a `void *` use besides it is
  fine), or at two (`Seen`).

**What it refuses.** The constant keeps its cast when the address lies outside
every range (a pointer-typed `0x1`, `0xffffffff` or `-1` is not an address, and
is 21% of the corpus's constant casts); when a global Symbol already covers it
(that is `ActionConstantPtr`'s case, and minting a second name would collide);
when the same function reads the value as a number; when it uses the address at
two different pointed-to types; when it also reads or writes the storage
directly at another start, width or type — `sigemptyset((sigset_t
*)0x2b460)` beside `v2[1] = (void *)dat_2b460;` in `ls` would declare a
`sigset_t` the next statement reads as a pointer, and a direct `int` read beside
an `unsigned int *` use would change what a compare on the direct read means once
the header declares the global; and for a pointer to code. An `undefinedN` direct
read is accepted against an unsigned integer of the same size, since that is the
C type the export's prelude defines it as. A `void *` constant needs one more
thing: the declared object's pointer must convert to `void *` exactly as the
cast did, which C does for an argument, a returned value, a copy or store into
`void *` storage and an equality test against another `void *`, and does not for
a compare against a pointer of another type. An address the function only ever
uses through `void *` is declared at the one type it reads the storage at
directly (`Plan::direct_type_at`), or as the unknown byte.

**The declaration.** `decompile_drive.rs (extract_global_objects)` reads back
off the printer, after `print_c`, every address the function named and every
piece of unnamed program data it read or wrote directly, each with the C
declaration the structure-member declarator builds for it (`printc.rs
(declaration_text)`), its size, and whether it stood for `void`, was a direct
access, or is a record or union. They travel as `FuncResult::globals`, which
the `--jobs` wire carries like the type records, and
`decompiler/crates/kuna-console/src/project.rs (global_declarations)` turns
them into one `extern` line per named address in the `decompile-project`
header, in a block of its own between the type definitions and the
prototypes. The header can hold one declaration per address, and every
function declares the object at the type *it* uses it at, so the choice is
constrained by what the declaration does to the other functions: it is what
every direct `dat_<addr>` read and write compiles against, and a scalar of
another type than theirs would silently change what they compute — a signed
compare turned unsigned, a store truncated — where a pointer of the wrong
type in a body that takes the address is a diagnosed mismatch. So a record or
union some function takes the address of wins, the larger first (a scalar
access of it does not compile at all); otherwise the one type the direct
accesses agree on; otherwise, when the program reads the address directly at
two types, nothing is declared and a comment says why; and with no direct
access, a type is preferred to the unknown byte a `void *` use stands for,
then the larger object, then the declaration more functions make. Every other
type is listed in a comment on the line. Over the 45 exports of the cast
corpus that is 891 declarations, 173 of them with such a comment and 60
addresses left undeclared; `gcc -fsyntax-only` reports 36,471 errors against
36,648 without the option, because direct reads of a now-declared name
compile, and 15,348 warnings against 14,962, the difference being the
incompatible-pointer warnings of those 173 addresses and pre-existing
diagnostics a declared name lets the compiler reach. An array is not a record
for this purpose: it decays to a pointer, so a scalar compare against it
compiles to something else. `project.rs (names_any_type)` reads the
declarations too, so a `struct_N` that only a global names is still redone by
the `structsynth` convergence sweep and kept by the header's type pruning.
A `dat_<addr>` the functions only read and write directly, with no function
taking its address or indexing it, is declared too, by the same rules: the one
type the direct accesses agree on, or nothing and a comment when they disagree.
Without that declaration an otherwise complete exported function using an
ordinary scalar global did not compile. Such a name is left undeclared, with a
comment naming the other global, when its bytes overlap another address the
functions name (an 8-byte store `dat_4020` and a 4-byte read `dat_4024` of its
upper half, as gcc merges adjacent field stores): two declarations would make
one storage two objects, so a store through one would never reach the other.
An address some function takes keeps its declaration either way.

Named global references retain whole mapped declarations through
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_namedglobals.rs`. The C printer
records the actual emitted name only when a mapped data object is referenced,
including field and array accesses. Storage base, extent, and whole symbol type
must agree with the mapping; split or uncertain mappings are not guessed. The
per-function collection resets at each print and excludes substituted literals,
stack objects, and function symbols. Project extraction includes these facts even
when synthetic address naming is disabled. Whole symbol types describe the
object declaration, rather than the scalar type of a partial access.

An integer `INT_ADD` of a constant and a non-pointer offset can still compute a
pointer: a declared pointer member stores it, or a CAST or COPY consumes it at a
pointer type. When types are printed (a project export or `structdefs`), the
pointer is the target's width with byte-sized words, the constant addresses a
complete named data object, and the other operand is an index the binary scaled,
widened or masked (a multiply or left shift by a constant, a sign or zero
extension, an AND with a constant below 0x10000 such as the `index & 0x3c` a
compiler folds `((index >> 2) & 0xf) * 4` into, a sum of those, through CASTs
and COPYs that are not from a pointer),
`printc.rs (op_named_pointer_add_ir)` relocates
the constant through `kuna_namedglobals.rs (object_address)` and keeps the
addition at pointer width, `(float *)((unsigned long long)((unsigned char
*)&arena + 0x40) + index * 4LL)`, so the byte offset is not scaled again and
the recompiled pointer lands inside the generated object rather than at the
original binary's address. A consuming CAST already spells the pointer type,
so the printer adds the pointer cast only when nothing else does. Any other
operand (a parameter, a load, a value cast from a pointer) may itself be an
address, making the constant a byte offset that merely falls inside a global
(`heap + 0x4060` beside a `gbuf` at 0x4040); relocating it would move the
pointer into the global, so it keeps the raw constant. Integer results,
unmapped constants, and other output languages print as before.

A scalar named object is not simply declared at its symbol's type, because the
body reads it at the type the printer gave each varnode, and an image symbol
is usually an undefined type the prelude spells unsigned (`undefined4` is
`unsigned int`): declared so, `if (count <= -1)` becomes an unsigned compare
that is always true, `total >> 2` a logical shift, and `scale * k` integer
arithmetic converted to a double, all without a diagnostic. The printer
therefore records each whole-width read and write, whether it prints the
global's own varnode, a register copy merged into its variable, or the value a
dereferenced `&name` loads or stores. A read whose uses keep its bits under any
integer of its width (a copy, a return, a call argument, a store, a
truncation, a same-width cast, an equality at `int` width or wider or with
zero, wrapping arithmetic whose result is assigned, or an assignment of the
value a dereferenced `&name` loads to a variable of its own) accepts the
symbol's type. The global's own varnode, or a register merged into its
variable, is judged by its uses however it was defined: after `g = *p`, the
reads of `g` print as `g`, so a load defining it says nothing about them.
A read that an ordering, a division, a
remainder, a right shift or an extension reads, directly or through
arithmetic printed inline, needs the signed or unsigned integer of its width,
and a float operation needs the float. A pointer or float varnode names its
own type, and a use outside these makes the read a conflict. A store of an
integer or pointer keeps its bits under any integer declaration, so stored
types count only where a float is involved or nothing reads the object. A
function whose reads all accept any integer declares the symbol's type as a
placeholder that yields to the integer type the other functions agree on;
disagreeing types, or a placeholder against a pointer or float, are reported
as read at two types and left undeclared, the existing rule for `dat_<addr>`.

The header exporter diagnoses one name at multiple addresses and multiple names
sharing one address instead of silently combining or splitting their storage.
Whole named objects also retain the independent-storage overlap guard; overlapping
views require shared storage instead of separate declarations. With `globalref`
on, a native `void *` constant into a complete mapped object is rendered relative
to its base, including interior field addresses. Requesting type definitions
(`structdefs on` or the shared header of a C project export) extends this to
typed object pointers. An explicit cast retains
the requested pointee type, even when a byte array owns the storage. Function
pointers keep their separate rendering. Loader metadata remains numeric: only
addresses in the loader’s program-data ranges can name relocated objects. This
preserves relocation of
the object when the generated C is linked. Split mappings, uncertain extents,
non-byte-addressed spaces, shadowed names and names requiring scope or identifier
rewriting keep the existing rendering.

**An indexed table is an array (`elemptr`).** With `elemptr` on (05-types
§5.2), a constant address that is the base of a `PTRADD` indexed by a computed
value is an array's first element, and `plan` records it (`Plan::indexed`). The
name then prints without the `&` (`printc.rs (PrintC::push_global_ref_ir)` asks
`Plan::is_array`): `dat_4020` already has exactly the constant's pointer type in
C, so `dat_4020[v1]` is the same address and the same element as
`*(unsigned char *)(v1 + 0x4020)`. `extract_global_objects` declares it `T
dat_4020[]`, an array of unknown length, and `global_declarations` prefers that
declaration over a scalar one another function makes when no function reads the
name directly: an indexed body does not compile against a scalar, and a direct
read does not compile against an array, so with both present the address is left
undeclared with a comment, like two direct types. Two functions that index the
address at different elements (`char dat_4020[]` and `unsigned char dat_4020[]`)
leave it undeclared with a comment too: a body reads `dat_4020[i]` at whatever
element the header declares, so either declaration would change what the other
body computes. The batch's agreement pass (05-types §5.2) keeps that from arising
within one process; a sharded `--jobs` worker cannot see the other functions, so
it names no table an array at all (`Funcdata::kuna_elemptr_objects`), nor does
any run of several functions that is not the callee-first batch, and a pool
prints what the serial run with `--option protoorder off` prints. An
array whose storage this function also reads or writes directly keeps its cast
(`DirectAccess`). With `elemptr` on, `plan` also takes an undefined word
(`undefined2 *`) and an unsigned word of the same size read at one address as
one object, named by the unsigned one, the way `same_object` already reads a
direct access (`Seen::merge`): a caller that copies `0x4b000` into a pointer
variable and passes it to a callee whose parameter `elemptr` declared `unsigned
short *` reads the address both ways, and would otherwise lose the name to the
two-type refusal. A global no symbol names that a function reads directly and
`elemptr` typed an element pointer (`dat_5068 = malloc(0x100)`, `dat_5068[i]`)
is declared in the header too, `extern char *dat_5068;`, although no function
takes its address (`GlobalInfo::elem`): its subscripts read the element that
declaration names. A Varnode of that storage at another type, such as its value
before a call, which nothing prints, is not a read of it at that type, because
every walk over the Varnodes holding it agreed on the pointer.

**The value is the binary's.** `decompiler/crates/kuna-cli/tests/decompile_all_cli.rs
(a_constant_address_named_as_a_global_round_trips_through_the_printed_c)`
exports a non-PIE fixture whose data has no symbols both ways, compiles each
witness caller exactly as printed against the export's own header with gcc and
clang, links it with every `dat_<addr>` placed at `<addr>` and the fixture's data
mapped where the binary keeps it, and requires the printed callers to compute
what the binary computes, with the option on and off: a record, two scalars, a
table and its one-past-the-end, a `void *` libc argument, a pointer compare and
a `char *` that is not a string, and four controls that keep the cast.

**Measured.** Over the 45-binary cast corpus (coreutils `fmt`, `ls`, `sort`, `du`,
`cp`, `tail`, `wc`, `grep`, `gzip`, the four diffutils, `tar` and `find`, each at
O0, O2 and O2-noinline) every one of the 1,883 lines the option changes is the
`(T *)0x<addr>` → `&dat_<addr>` substitution and nothing else, removing 1,979
casts; with the option off the output is byte-identical to the build without it.
On the 4,815 functions kuna and IDA both emit, casts fall from 45,126 to 44,001
and no function gains one. Variables and types are untouched, so `type_match`
cannot move (1,609 perfect functions in both arms of the 444-slice sweep).


Declared function-pointer types retain their embedded prototype in C declarators.
The modifier walk includes the function's argument suffix and continues through
its return type. Callbacks therefore emit as `void (*callback)(int4 *)`, including
when passed a frame object that the callback can modify, rather than as a byte
pointer with a call applied to it.

An incoming high variable bound to a function-parameter symbol is declared in
the signature. The local declaration walk uses that recorded identity before
its storage fallback in every mode: a later asserted local in the same register
must not hide the input's category or cause its body references to be renamed
to an uninitialized local.

When `stackviews` is on, a multi-byte LOAD or STORE through a reinterpreted
pointer uses `__builtin_memcpy` and a typed C compound literal. Casting a word
pointer over an integer local does not establish C aliasing: both GCC and clang
can otherwise optimize a later integer read to its old initializer. The copy
preserves the bytes and evaluates the pointer and value once. This fallback is
C-only and bounded to scalar accesses of 2, 4 or 8 bytes. With `stackviews` off,
a function that recovered narrow-parameter backing copies only accesses that
resolve inside that backing; other reinterpreted pointers keep their ordinary
dereference.

Bounded indexed accesses into a recovered backing object also copy their bytes,
including one-byte loads and stores. The byte pointer starts at the whole backing
object, with the original constant displacement and scaled index terms. Indexing
from the address of a struct field would leave that C subobject at the next field,
even when both fields occupy the same physical frame extent. The emitter checks
that the address interval and access width fit the containing symbol, and leaves
unresolved cases unchanged. Ordinary byte accesses keep their existing syntax.

`kuna_stackassign.rs` handles direct scalar assignments into a type-locked frame
layout that declared call uses reinterpret as another object. The declared layout
is retained. Stores copy bytes from a scalar compound literal at the original
displacement instead of assigning a pointer to a struct or imposing the declared
field's numeric type on a later incarnation. COPY and same-width CAST retain the
source representation; computed stores use the opcode's result type, including
floating arithmetic and numeric conversions. A recovered standalone byte-array
local that receives a same-width floating representation uses a byte-copy store
from the scalar expression, including any preceding numeric conversion. One-byte
SUBPIECE reads defined by that floating transfer use byte subscripts at the target's memory offset,
rather than passing an array to an integer helper. Opaque vector lanes retain
their separate option-controlled rendering.
A scalar write into a declared
byte-array member takes this byte-copy path even when the call's record layout
agrees with the local layout: the member has no scalar C assignment type, and
copying a float must retain its representation instead of casting it to an array.
An explicit register or unique definition bound to a local frame Symbol follows
that Symbol's unique stack mapping and member displacement for a byte-array
member store whose value would otherwise render through a byte-array CAST.
Other register or unique definitions, including stores into scalar members,
retain their existing rendering. Ambiguous storage mappings and bindings
outside the local scope do not qualify. Implied same-width CASTs to the byte-array view are peeled before selecting the
scalar representation; numeric conversion opcodes remain part of the expression.
A byte-array member receiving an implied nonvolatile memory read retains the
source pointer and read context, even through same-width COPY/CAST wrappers or
when the LOAD itself defines the mapped member.
Numeric conversions and computed expressions remain scalar transfers. For
byte-addressed source storage with matching endianness, `__builtin_memmove`
retains the original load-before-store behavior when addresses may overlap.
Integer bit patterns are printed as
unsigned constants, while named pointer constants retain their address provenance.
Equal-width signed, unsigned and unknown integer views remain compatible and
keep ordinary scalar assignments; the fallback targets incompatible layouts or
representations rather than changes of integer signedness. Conditional and
short-circuit boolean assignment recovery retains explicit branch statements
when an arm requires this storage-copy path or a changed-byte transfer. A
ternary or boolean assignment would otherwise bypass byte-store emission and
assign to an artificial partial field of the declared layout.

`kuna_stackbytes.rs` follows byte provenance through COPY, same-width CAST,
PIECE, SUBPIECE, zero extension and byte-aligned logical shifts. With
`stackviews on`, a write that preserves bytes of the same physical backing
copies only its changed contiguous ranges. Each range uses a byte-array
compound literal, so a three-byte write never invents a scalar or struct
field and never reads untouched upper bytes. The preserved source must be
bound to the same backing symbol; an incoming formal at the same stack
address is a separate value. Full-width integer bits assigned to an aggregate
view use the same byte path. Unsupported expressions retain ordinary emission;
the provenance walk is bounded to eight-byte values and 32 levels.

The byte walk carries source storage identity, projected offset, and original
read operation separately from a merged HighVariable. A projected global read
therefore renders from its physical data-space address instead of using the
merged stackview name. Mutable LOADs and implicit global reads can be moved to a
store only within the same block and across no write, call, STORE, INDIRECT or
CALLOTHER effect; readonly non-volatile sources do not need that timing proof.
Volatile reads and pointer values or pointer-origin constants stay on typed
emission paths. Any other source printed by name must be a declared variable
(a named local or a linked symbol), never bare register storage. The pointer
test reads a def-facing type only for a written Varnode; an input or constant
is classified by its own type. A complete scalar range uses one typed compound-literal
evaluation for `__builtin_memcpy`; partial ranges use byte literals only when
their source reads are safe to reproduce at the store.

Explicit zero-offset PTRSUB field selections keep their union write-edge
resolution through cast fixup. Their output token is the selected member's
pointer type, rather than an unresolved parent or generic byte pointer. Logical
frame-object assertions use this path to keep a named incarnation visible at
each call. Scalar accesses through the synthetic backing continue through an
equal-sized one-field struct to the scalar member, so a pointer write uses
`backing.handle.value`, not an aggregate assignment.

Synthetic `stack_views_` unions and `stack_slice_` wrappers preserve exact extents
and displacements. When their byte layout differs from natural C alignment, the
printer adds a packed/aligned attribute matching the recovered storage; an
interior eight-byte view at offset four must not move to offset eight, nor grow a
twelve-byte backing object to sixteen. Ordinary declared composites are unchanged.

Read and definition type queries in C emission use Funcdata's facing accessors,
including numeric conversions, extensions, truncations and constant spelling.
The Varnode-only accessors cannot resolve union edges. Numeric int-to-float
conversion targets the float member, never the shared backing union. Storage
bitcasts also prefer that selected member over a whole-object declaration type.

**Preserved scalar prefixes (`partialconcat`).** A partial-register update can
leave `PIECE(SUBPIECE(source, low_size), low)` in the finished expression graph.
For a two-, four-, or eight-byte integer with a one-, two-, or four-byte
replacement, P9 renders this as
`(unsigned_result_type)source & high_mask | (unsigned_result_type)low & low_mask`
when the upper extraction is implied and covers exactly the original scalar's
unchanged prefix. P9 also accepts the equivalent zero-offset truncation of a
right shift by the number of replaced bits, which cast insertion can introduce.
The implementation is
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_partialconcat.rs` and the
`PrintC::op_partial_concat_ir` renderer in `printc.rs`. Both masks matter: the
upper one removes replaced bits, and the lower one truncates arithmetic that C
promotes before evaluating. Casts to the unsigned result width keep the operation
on bit patterns, including when an operand has a signed type. The IR, signatures,
and evaluation of the lower expression are unchanged. Named upper values,
noninteger types, enums, widths above eight bytes and concatenations of unrelated
halves keep their existing rendering. The option defaults on for C output; off
restores the upstream CONCAT helper, and other output languages keep their own
rendering.

For scalar CAST storage transfers through a global array symbol, such as an
asserted byte array, the printed member access determines the scalar
representation. An exact scalar array piece retains its type. Any other piece
takes the type partial access prints it with (`kuna_partialaccess.rs`): the
value's own scalar type of that width, such as a float stored in half of a
`double` element, else the width-matched unknown scalar for a four- or
eight-byte access crossing byte elements or covering the whole array. Floating
transfers to and from that storage reinterpret bits rather than numerically
converting the value or attempting an array cast. This lookup uses the exact
global container and offset. When the type this lookup or the merged variable
declares for a transfer's input is unknown or a partial aggregate, as for a
value merged into a byte-array backing, it does not say whether the bits are a
pointer or a float; a pointer or float read-facing type of the input decides
instead (`kuna_bitcast.rs (storage_transfer)`). A pointer stored through
`*(void **)&storage[8]` and moved into a `double` therefore passes through the
unsigned word of its width and is reinterpreted, rather than printing the
invalid `(double)` conversion of a pointer. A `FLOAT_FLOAT2FLOAT` that writes such storage
directly keeps its numeric precision conversion, cast to the float of its output
width rather than to the unknown type of the storage, because partial access
prints that destination as a float.

Project C results retain declarations of named direct-call targets whose input
and output prototypes are both locked. The declarations use the ordinary C
declarator builder, including nested pointer types and variadic parameters.
Call-only type dependencies join the referenced type roots. Headers deduplicate
these declarations after type definitions and keep typedef collisions diagnostic.
A target that is itself one of the exported functions keeps only its own
prototype, so a whole-binary export declares each function once. Two differing
declarations of one target become a comment rather than conflicting externs.
A target whose return type is an array or function type is not declared,
because C cannot spell it (a 16-byte integer the type system holds as
`char[16]`). Unknown or partially inferred targets do not acquire invented
signatures.
The declarations survive worker serialization and streamed body removal, and
remain roots when pruning synthesized types. Capture is implemented in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_callprototypes.rs`.

With a live `callwide` verdict, a proved eight-byte result also needs a
declaration when its producer was not selected for export. The declaration
uses the actual call operands and finalized four-byte argument storage under
the same model, including calls whose recovered prototype store is empty. It
neither recovers nor regroups inputs. Canonical unknown eight-byte results use
the C speller's existing unsigned representation; ignored results obtain only
their proved width and physical pair. Unsupported storage, types or arity
withhold that function's C with an export error. Private typed contracts survive
workers and streamed body removal. A selected producer's exact definition may
resolve signed versus unsigned four-byte input words, preserving their ABI
bits; its output representation and arity must agree. External-only conflicts
remain errors. Streams may retain conflicting records, in order and within
fixed bounds, only for an exact producer in the complete preknown selection,
then validate against its actual definition. An absent or incompatible
definition fails the export. A conflicting definition or type-name collision
cannot silently remove a required wide declaration. Ordinary locked-declaration
conflicts retain the diagnostic behavior above. Capture remains after temporary
C rendering and before publication. The proof and bounded contract checks belong to
`decompiler/crates/kuna-decomp/src/p4_calls/kuna_callwide.rs`.

Format-specific call arities are not declarations of the callee. When a call
has format-derived arguments, project declarations restore its parked formal
variadic signature. Call-only type roots are gathered only for project headers;
ordinary per-function type inventories retain their original scope.

Automatically admitted `localstackviews` backings use the same physical-version,
byte-projection and mutable-read timing checks as explicit `stackviews`.
Native write preservation is established before mapping; emission does not
resurrect hidden arithmetic or mark reconstructed COPYs as physical stores.
A surviving native persistent publication supplies its exact locked pointer
contract to the existing typed-member address binding, so a shared union address
is published as the declared pointee address at the original operation.

Project C exports use the exact global-scope function symbol's display name
for a successful definition and its header prototype when both spellings are
plain C identifiers (`decompiler/crates/kuna-console/src/kuna_projectfunctionnames.rs`).
This aligns definitions with calls when debug information names a function
differently from its linker symbol. Analysis, selector aliases, and standalone
output retain their existing names. The original display is restored after
rendering. Namespaced and nonidentifier spellings are not guessed. A separate
optional emitted C name travels through worker records and survives stream
compaction, so the header checks every successful prototype record, including
streamed bodies whose text was released. Multiple entries claiming one C name
(duplicate static functions from separate translation units, or a PLT stub
beside the definition it reaches), or a function conflicting with a data or
typedef declaration, are listed in address-only header comments. They are not
fatal: the export still writes every artifact and keeps its exit status, and a
typedef collision keeps the commented-out prototype so the header itself still
parses. Source selection names and alias metadata retain their existing meaning.

Project C emission reserves global function names before rendering local symbols.
A colliding parameter or local receives a unique local spelling; parameter storage,
types, and lock flags are preserved, and the prototype and body use the same name.
This prevents a source-level parameter name from shadowing a function's emitted
linkage identifier. The change is local to the rendered function.

A statement LOAD rendered through a byte-copy helper copies directly into the
printed destination member’s scalar type when its width matches the access.
The helper must preserve the representation instead of numerically converting
an integer temporary into a float member (`printc.rs (op_load_ir)`).
An `iteregion` assignment diamond whose arm is such a LOAD, with the destination
member and the helper's type disagreeing on float-ness, keeps its `if`/`else`
form so each arm stays a statement LOAD copying into the member's type
(`printc.rs (converts_storage_load)`); a `?:` arm would convert numerically.
A STORE helper likewise initializes its compound literal with the rendered
source member’s same-width scalar type (`printc.rs (op_store_ir)`), preserving
its bytes when propagated IR types disagree.

A same-width integer representation assigned to a declared pointer member needs
an explicit pointer cast in C. CAST statements are checked using the type their
result expression prints, rather than the input type, so a pointer-to-integer
cast cannot leave an integer expression assigned to a pointer field, and a
pointer-typed CAST assigned to an integer variable receives the integer cast
(`len = (long)(char *)&len[1];`) instead of a bare pointer. When the
variable's Symbol is a structure, array or union, that whole Symbol supplies the
member type, since the declaration representative covers only the field. A
scalar local or global keeps the type its declaration prints, which can differ
from its Symbol's scalar type (`kuna_pointerstorecast.rs (target)`).

### Rust signed primitive operations

Rust represents core signed text storage with unsigned integer types so recovered
bytes remain ordinary storage. Recovered unsigned primitives can also feed signed machine operations when
prototype constraints keep their storage unsigned. At signed less-than, less-or-equal, and arithmetic
right-shift operations, `kuna_rustsigned.rs` reinterprets that storage through the
signed integer of the same width before applying the operator; the IR opcode
defines signed interpretation even when the recovered input type is unsigned. Comparisons retain
their boolean result; a shift converts its result back to the declared storage
type when necessary. This preserves negative ordering and sign-bit propagation
without changing declarations or shift counts. Unsigned constants retain an
inner cast to their storage width so Rust does not infer an overflowing signed
literal before reinterpreting its bits. Each operand is emitted once.
An in-place assignment is expanded when its unsigned storage cannot itself
perform the required signed operation.

The plan requires core integer inputs with exact matching operation widths,
and activates when a numeric operand has unsigned or signed text storage, or a
signed shift must restore unsigned result storage even when its input already
prints with the correct signed type. Non-core aliases,
pointers, floats, unsupported widths and unrelated operators retain their existing
emission. Shift outputs must be core integer storage of the same width. Explicit
cast suppression still suppresses these conversions. Unsigned comparisons and
logical shifts, and output languages other than Rust, are unchanged.

### Rust machine-operation names

A functional `CALLOTHER` names the architecture's machine operation. When Rust
output encounters a strict or reserved keyword such as x86 `in`, AVR `break`, or
MIPS `yield`, `kuna_rustuserop.rs` supplies the raw-identifier prefix `r#`. This
preserves the operation's identifier and arguments while preventing Rust from
parsing it as a control-flow construct or rejecting it as a keyword. Ordinary
names and other output languages keep their spelling. The keyword set includes
edition-specific reserved words; weak keywords remain ordinary identifiers.
Rust forbids raw spellings of `_`, `crate`, `self`, `Self`, and `super`, so those
are excluded. This correction applies only to functional machine-operation
calls, not to unrelated type, variable, namespace, or symbol naming.

### Literal Rust print macros

`rustfmtliteral` (default on) uses
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_rustfmtliteral.rs` to render
literal-only `std::io::stdio::_print` and `_eprint` calls as Rust print macros.
It changes only Rust output and requires the detected Rust language, an
unambiguous stable 1.93.0 or 1.93.1 compiler version, and a 64-bit little-endian data space.
The loader obtains the version from ELF `.comment` records through
`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/kuna_rustversion.rs`.
Absent, malformed, prerelease or conflicting Rust records provide no version;
a forced source-language option cannot manufacture version evidence.

A resolved sink may store its name as a qualified string or as a leaf name plus
namespace. A leaf `_print`/`_eprint` qualifies only at the exact symbol entry and
with the complete `std::io::stdio` scope. Missing, extra or unrelated namespaces
keep the runtime call, including when resolution follows a relocated GOT slot.

The call must have exactly two constant machine-word arguments and no result.
In this compiler layout the second word's low bit distinguishes a literal from
a formatting template: odd means `(byte_length << 1) | 1`. The first word must
be nonnull, and every byte of the bounded (at most 4096-byte) string must be
readonly, nonvolatile, mapped and valid UTF-8. An empty string needs no read.
Even tags, nonconstant arguments and mismatched sink names keep the runtime call.
This checks the IR and loader bytes; it does not rewrite output text.

A final LF selects `println!` or `eprintln!` and removes exactly that one byte
from the argument. All other bytes, including a preceding CR, are retained.
Rust string escaping protects controls, quotes and backslashes; doubled braces
preserve literal formatting semantics. No arguments or side effects are dropped.
The option does not recover placeholder templates, `format!`, `write!` or panic
macros. Turning it off restores both encoded runtime arguments.

### Primitive Rust print arguments

`rustfmtargs` (default on) uses
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_rustfmtargs.rs` for the placeholder
representation at the same verified Rust 1.93.0/1.93.1 stdout/stderr sinks.
It requires Rust output, a 64-bit little-endian data space, exactly two runtime
arguments, no return value and a nonnull constant template pointer. Sink identity
may be a fully qualified call name or the exact function symbol with its
`std::io::stdio` namespace chain; an unqualified spelling alone is insufficient. Every consumed
template byte is mapped, readonly and nonvolatile. A bounded decoder accepts UTF-8
literal pieces and default placeholders, including explicit argument indices.
It limits input to 4096 bytes, 128 pieces and 16 referenced arguments. Missing
terminators, unsupported formatting flags and gaps in the referenced indices
preserve the runtime call.

The second word must identify a naturally aligned local stack descriptor array.
Only pre-call inputs of stack INDIRECT effects associated with this exact call
provide descriptor cells. Overlapping, missing or duplicate cells reject the
whole candidate. Formatter pointers must resolve through bounded pure operations
to an unambiguous primitive integer Display identity retained from full object
symbols, before trait qualifiers are removed for display names. A normalized
`fmt` name cannot distinguish Display, Debug or exponent formatting and is never
used as evidence. Conflicting symbol aliases also disqualify a callback.

Each value pointer must resolve through pure operations to an aligned local stack
address. The macro borrows a dereference cast to the formatter's integer type,
preserving width and signedness without substituting a later memory version.
Literal escaping doubles braces and retains all controls; exactly one final LF
selects an `ln` macro. Explicit indices preserve repeated-argument order. All
original setup statements and IR remain intact, and C output is unchanged.
Generic reference formatters, `format!`, `write!` and specialized sinks remain
explicit. Other integer traits and width/precision require `rustfmtflags`.

### Static Rust integer format specifications

`rustfmtflags` (default on) extends `rustfmtargs` through
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_rustfmtflags.rs`. The same version,
language, memory, stack descriptor and exact sink requirements apply. Full object
symbols establish both integer width/signedness and Display, Debug, LowerHex,
UpperHex, Octal, Binary, LowerExp or UpperExp trait identity. Only exact standard
library paths for 8-, 16-, 32- and 64-bit integers qualify. Pointer-sized integer
aliases may share their corresponding 64-bit formatter; different types or traits
and unknown aliases invalidate the address. Generic formatter types are not inferred. The loader indexes only candidate formatter addresses, then checks every symbol against those candidates; unknown aliases before or after a recognized name still invalidate the address.

The bounded template decoder accepts static flags, width and precision before an
optional explicit argument index. Dynamic count headers are refused before reading
their fields. Width and precision values must agree with their enable bits: the
runtime copies encoded values without enabling them. Enabled fields omitted from
the template have value zero. Width zero without zero-padding is refused because
the corresponding source spelling would turn on zero-padding. Invalid Unicode
fill, brace fill, a reserved high bit, conflicting signs or debug-hex modes, and
non-space fill without explicit alignment also preserve the runtime call.

Rendering retains alignment, fill, sign, alternate form, zero-padding, width and
precision, followed by the verified trait suffix. Debug hexadecimal flags require
a Debug callback. Fill characters are escaped for the surrounding Rust string;
literal braces and repeated argument indices retain their existing treatment.
Turning the option off restores default-only Display recovery. Disabling
`rustfmtargs` disables this extension too. Floating-point, pointer and generic
formatters, dynamic counts, `format!`, `write!` and specialized sinks remain
explicit. No IR, descriptor setup or C output changes.

### Rust format String initialization

`rustfmtresult` (default on), in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_rustfmtresult.rs`, recognizes only
`alloc::fmt::format::format_inner` at the existing direct-call rendering hook.
The name must be fully qualified or resolve to the exact entry with the complete
`alloc::fmt::format` namespace. The call has a hidden destination, template and
argument-array input, and no output varnode. It reuses `rustfmtargs` version,
language, endian, readonly-template, same-call descriptor and integer formatter
proofs; disabling `rustfmtargs` also disables this result consumer. Static format
specifications independently require `rustfmtflags`.

The destination is a word-sized integer/unknown or pointer value that resolves
through bounded pure copies/casts to a non-spacebase entry input. Constants,
computed pointers, local destinations and incompatible types are refused. A
local output buffer may still be split across several primitive declarations;
it is not rendered as a String write until its complete allocation is recovered. An
entry value is interpreted as an output pointer according to the verified sink's
ABI; its dynamic address is not guessed from a type name.

The renderer uses `std::ptr::write(destination as *mut std::string::String,
format!(...))`, with a raw-pointer bridge for pointer/reference expressions.
This initializes the caller's storage without dropping its previous contents,
as the original hidden-result call does. Format literals retain terminal LF;
there is no println-style newline removal. Descriptor setup, surrounding IR,
existing returns and function signatures remain intact. The option does not
recover generic wrappers, indirect calls, call-return values, unsupported
formatters or other layouts, and it does not change C output.

### Rust panic messages

`rustfmtpanic` (default on), in
`decompiler/crates/kuna-decomp/src/p9_emit/kuna_rustfmtpanic.rs`, renders verified
`core::panicking::panic_fmt` calls as `panic!`. The source language must be Rust,
the output must be Rust, and the compiler record must identify stable Rust 1.93.0
or 1.93.1 on a little-endian 64-bit data space. A direct call must have exactly
three runtime arguments and no output. The name is either fully qualified or
resolves to the exact function entry in the complete `core::panicking` scope.
The call prototype must be non-returning, or its basic block must end in the
artificial no-return halt attached to the same machine instruction. This accepts
the existing flow proof when its fact is stored separately from the call prototype.

The third argument is the hidden `track_caller` location. A bounded pure
constant-expression walk must recover a nonnull address, and all 24 bytes of the
location record must be mapped and nonvolatile. Its contents are not interpreted:
normal PIE images place this record in relocation-backed data, and its original
file and line are not part of the recovered message. Dynamic caller locations
remain explicit. The macro displays a source-level panic; recompiling it naturally
uses the recovered source's location rather than the original binary's file and
line. No original-location or backtrace equivalence is claimed.

The first two arguments use the existing verified `fmt::Arguments` layout.
Literal-only messages share the bounded readonly UTF-8 byte reader with
`rustfmtliteral`, but do not depend on that option. Braces are doubled and controls
are escaped; every terminal newline is retained. Primitive integer messages reuse
`rustfmtargs`' same-call descriptor cells, aligned local value pointers and exact
formatter identities. Static format specifications additionally require
`rustfmtflags`. Disabling either prerequisite retains calls requiring it; literal
panics still qualify when both are off. Unsupported callbacks, templates, versions,
call shapes or location records retain the runtime call.

The change is confined to rendering the call expression. All descriptor setup,
IR, declarations, existing returns and no-return control flow remain intact.
It does not recover generic arguments, other panic entry points, indirect calls
or earlier formatting layouts, and it does not change C or Go output.

## Verified Rust piece-array printing

`kuna_rustfmtpieces` extends source printing to the pre-template
`fmt::Arguments` representation. The default-on `rustfmtpieces` option accepts
x86-64 little-endian ELF executables from stable Rust 1.89.0 and 1.90.0 and
nightly 1.89.0 `bf64d66bd` dated 2025-05-21. Compiler comments must identify one
unambiguous supported build; other nightly commits, missing metadata and mixed
versions do not qualify. The stable-version fact used by the 1.93 template
readers retains its existing meaning.

An exact `_print` or `_eprint` identity, including exact namespace resolution,
must have one runtime argument and no result. Its argument must point to an
aligned stack descriptor. The call's non-creation INDIRECT effects must supply
five distinct complete words: piece pointer/count, argument pointer/count, and
a null optional-format pointer. The inactive optional-format length is not
read. Missing, overlapping, dynamic or ambiguous cells prevent recovery.
There may be at most sixteen arguments, and the piece count must equal that
count or exceed it by one. Every table span and string span must be mapped,
immutable and nonvolatile; all strings must be UTF-8 and total at most 4096
bytes. Null pointers and overflowed spans are rejected.

The loader records the supported image's RELRO extent for this renderer only.
The upper bound is rounded down to a complete 4096-byte page, while the lower
bound remains inside the declared segment. This supplies immutable-range
proof for adjacent length words in relocation-backed piece arrays. It does
not change global readonly properties or general constant propagation.
Explicit volatile markings override both this fact and existing readonly
properties. A relocated pointer alone is insufficient evidence for the
surrounding table.

Literal recovery also requires `rustfmtliteral`. Nonempty argument arrays also
require `rustfmtargs`, exact full primitive Display callback identities, and
the shared aligned stack-pointer proof for each 8/16/32/64-bit signed or
unsigned input. Formatting specifications, generic callbacks and non-Display
traits remain explicit. The pieces are interleaved with default placeholders
and escaped through the shared renderer; precisely one final newline selects
`println!` or `eprintln!`. Empty arrays, empty separating pieces, braces,
Unicode and control characters preserve their output bytes.

The pass replaces only the print call's presentation. All setup assignments,
IR, function prototypes, returns and surrounding statements remain. Existing
descriptor type gaps can still prevent complete primitive functions from
compiling; primitive macro execution does not imply whole-function
recompilability. C and Go output, newer layouts and other formatting sinks are
unchanged. Disabling `rustfmtpieces` restores the runtime-call presentation.

String callback discovery likewise indexes only the forwarding and pad candidates, then rejects every conflicting or unknown alias before reading callback bytes.

`rustfmtstr` extends template-layout formatting to a proven string Display
argument. In x86-64 ELF images, complete object-symbol identities must identify
both a generic reference Display callback and `core::fmt::Formatter::pad`.
The callback must have the exact 18-byte body that loads the first two words of
its argument as string data and length, preserves the formatter argument, and
tail-jumps directly to that pad function. Conflicting aliases, another target,
extra operations and other instruction sequences do not establish this fact.
The generic name itself never supplies a concrete type.

Recovery is restricted to stable Rust 1.93.0/1.93.1 and requires both live,
eight-byte, aligned stack words at the existing formatting call. It constructs
`std::str::from_utf8_unchecked(std::slice::from_raw_parts(data, length))` from
those values. Valid UTF-8 storage follows the original `pad(&str)` call contract;
no string contents are guessed from neighboring memory. Existing literal,
argument, static-format, result-destination and panic-location checks still
apply. Every setup statement, IR operation, prototype and return remains.
Disabling the option preserves runtime calls containing these string arguments;
unknown wrappers and derived Debug callbacks remain explicit. C and Go emission
is unchanged.

`rustfmtwrite` is off by default: the declared speed study did not clear the
small-C wall-time confidence bound, despite median deltas below 0.2 percent.
When enabled, it recovers formatting into an existing `String` only for the verified
Rust 1.93.0/1.93.1 x86-64 little-endian ELF layout. The direct call must resolve
exactly to `core::fmt::write`, with four runtime arguments and a one-byte result.
The writer must derive from a function input through copies or casts. Its vtable
must be aligned and contain six complete immutable, nonvolatile words: String
drop identity, size 24, alignment 8, String's `fmt::Write::write_str` and
`write_char`, and `core::fmt::Write::write_fmt`. Every method requires its full
object-symbol identity; conflicting aliases invalidate that address. The loader
provides a private RELRO extent with its upper boundary rounded down to a full
4096-byte page, without changing global memory properties. Volatile annotations
always override the private immutable-range evidence.

The existing literal or compact-template checks establish all formatting bytes
and arguments. One terminal newline selects `writeln!`; otherwise the renderer
uses `write!`. The writer is cast to the proven String type and borrowed mutably.
A local expression block imports `std::fmt::Write` for this call. The macro's
`is_err()` preserves the original `fmt::Result` zero/success and one/error byte,
with a cast matching the recovered signed or unsigned byte type; boolean results
need no cast. Other result sizes or types remain explicit. Descriptor stores,
result uses, branches, prototypes and IR remain unchanged. Custom writers,
unsupported callbacks and IO-error result layouts do not qualify. Disabling the
option retains the runtime call, and C/Go output is unchanged.


`rustfmtio` is off in every preset: the declared speed study did not clear the
Go-control CPU and wall-time confidence bounds, despite median deltas below
1.3 percent. When enabled, it recovers Stdout `write!` and `writeln!` expressions only for exact
stable Rust 1.93.1 x86-64 little-endian linked ELF implementations. The loader
proves the full `&Stdout` write_fmt body and all four formatting-adapter callback
bodies. All nonrelative bytes, internal branches, external target roles and
symbol aliases must agree. In particular, generic adapter callback names alone
do not establish the writer: write_str and write_char must call the exact
StdoutLock write_all identity. The forwarded write_fmt must use the same adapter
table and core formatting function. The complete table, panic text and location,
code and unwind stubs must be immutable and nonvolatile. Resolved whole-word
relocations are applied before comparison; unresolved, overlapping or partial
relocations in protected spans invalidate recovery. Import slots must have one
exact unresolved binding with the expected identity and zero addend. Private
RELRO evidence uses the same page boundary rule as String writes. The emitter
rechecks every protected byte against its current loader image.

The two verified method bodies distinguish a reference-cell receiver from an
optimizer-promoted inner pointer, even when both have the same method name.
Recovery borrows the original `&Stdout` cell or reconstructs a temporary Stdout
handle from that same inner pointer. It evaluates the original receiver once
and never substitutes a newly acquired stdout handle. The original direct call
must have three runtime arguments and an eight-byte integer result. Existing
literal, primitive, string and flag proofs establish the formatting inputs.

A scoped `std::io::Write` import enables the macro. Matching its Result preserves
zero for success; an error is consumed into its pointer representation, then
converted through usize to the original signed or unsigned integer type. This
preserves the owned error payload for surrounding result handling, without
dropping it or reducing it to a Boolean. Descriptor setup, branches, prototypes
and IR remain. Other writers, producer versions, dynamic formats, callback
profiles and result layouts stay explicit. Disabling the option restores the
runtime call, and C/Go emission is unchanged.

An empty literal stays a runtime call. In the buffered broken-pipe regression,
the Rust 1.93.1 producer reports an error for that call, while a recovered empty
macro built with Rust 1.90.0 reports success. Rebuilding the original empty-call
source shows the same compiler-version difference: original and macro agree
within 1.90.0, 1.93.1 and 1.99.1. This is a standard-library-version boundary,
not evidence that a same-version macro changes the result. Recovery refuses it
because the supported older execution compiler does not preserve the producer's
behavior. Six other recovered forms match across all three execution compilers;
no broader compiler-version equivalence is inferred.
