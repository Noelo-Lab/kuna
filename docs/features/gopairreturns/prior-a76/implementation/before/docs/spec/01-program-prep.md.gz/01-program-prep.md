# 01 — Program preparation (kuna-analysis)

```yaml
Anchors:
  - decompiler/crates/kuna-analysis/src
  - decompiler/crates/kuna-decomp/src/p1_partition
```

Everything in this chapter runs **before any function is decompiled**. The
`kuna-analysis` crate is kuna's port of the layer Ghidra keeps *outside* its C++
decompiler — the Java loader, the analyzer tier, and the Listing — rebuilt against
kuna's own symbol/type tables. Untagged prose in this chapter therefore describes a
port of a **Ghidra Java analyzer or loader** (named per pass), not of the C++
decompiler; `(angr)`, `(ida)`, and `(kuna)` mark the other lineages, matching each
pass's row in `decompiler/crates/kuna-decomp/phases.toml`. Every analyzer named
below **is** a settable option under its own name (`--option <id> on|off`) —
except `funcdisc_recursive`, which rides the `funcstart_patterns` flag;
defaults, symptoms, and flip guidance live in the generated catalog,
[`docs/options.md`](../options.md), and are not repeated here.

## 1.1 The tier contract

A program-prep analysis is an implementation of
`decompiler/crates/kuna-analysis/src/pass.rs (AnalysisPass)`: it declares the phase
it feeds (P0/P1, a few feeding back to P2), a stable `id()` that doubles as its
option name, and one method `run(&AnalysisCtx) -> AnalysisOutput`. The contract has
three load-bearing properties:

- **Pure and read-only.** A pass sees only the parsed object (`object::File`), the
  raw image bytes, the opened load image, the resolved `Architecture`, the image's
  own on-disk path, and (for Listing consumers, §1.6) the built Listing. It mutates
  nothing. The path is the one input that is not the image's *content*: it is what
  lets a pass reach a companion file the image only names — a `.pdb` sidecar today,
  a `.dSYM` bundle or a `.gnu_debuglink` target tomorrow. It is derived once, at the
  context build, from the load image's own filename
  (`decompiler/crates/kuna-analysis/src/passes.rs (image_on_disk_path)`) and is
  absent unless that filename resolves to an existing file, so a synthesized or
  in-memory image cannot make a pass probe the working directory.
- **Additive and total.** A pass only ever contributes *more* knowledge — names,
  types, entries, flags — and never fails: a malformed section, an unknown magic, or
  an out-of-range offset yields an *empty* output, never an error or panic.
- **Facts, not effects.** The output is a flat struct of typed fact lists
  (`pass.rs (AnalysisOutput)`): function/data symbols, sized data globals, discovered
  entries plus an optional name overlay, no-return functions, no-fall-through call
  sites, read-only ranges, string literals, library prototypes, processor-context
  paints, tracked register values, call-fixup tags, DWARF stack locals, source-line
  comments, and FID renames. Merging two outputs is concatenation; deduplication is
  the committer's job.

The passes never touch the pipeline live, and the pipeline never calls an analyzer:
the two meet exactly once, at a commit seam. `decompiler/crates/kuna-console/src/engine.rs
(bootstrap_from_object)` runs every registered pass at `load file`
(`decompiler/crates/kuna-analysis/src/passes.rs (run_default_analyses_per_pass)`) and
**stashes** each load-time pass's output keyed by its id. The commit happens later,
at `read symbols` (`engine.rs (commit_pending_analysis)`) — after the CLI's
`option` lines have been applied — so a disabled load-time pass's already-computed
facts are simply dropped at the gate (`engine.rs (analysis_pass_enabled)`; an id
with no registered gate fails *open*, so a new pass runs by default). Deferred
work is dispatched after those options are known: a disabled Listing consumer, AIF
gap walk, or operand-reference scan is not invoked at all, and its commit gate
remains as a defensive check. This is semantically load-bearing
for AIF: speculative SLEIGH decoding can paint processor context, so `aif off`
means no speculative decode, not merely discarding its discovered-entry facts.
The stash is drained on commit, so a second `read symbols` cannot double-commit.

Stash-at-load is the default, but it only pays when computing the facts is cheap
relative to the chance of using them. A pass whose sweep is expensive and whose gate
is normally off is *deferred* instead — kept out of `passes_for` and run from the
commit point by `passes.rs (run_deferred_entry_passes)`, where the gate is already
in effect. `funcstart_patterns` (§1.5) is the one entry pass in that category: its
whole-image pattern sweep is a fixed load-time cost on every subcommand and is
discarded on every default run. Deferring an entry pass is output-neutral because
the commit's entry arm is idempotent by address and resolves each name from the
fully merged `entry_names`, so merge position never changes what installs; the
deferred run rebuilds the object view exactly as the load-time run does,
`relocrebase` (§1.2) included, so a relocatable object still yields entries in the
loaded image's address space. It is dispatched *before* the deferred Listing build,
whose walk takes the committed entry set as extra roots.

`engine.rs (commit_analysis_output)` then installs the merged facts into the engine
once, each arm idempotent against the loader's own funcsym stream: a function fact
no-ops where `find_function` already resolves (a real `.symtab` name always beats a
discovered one), and it is listed beside any same-named function at another address,
as the funcsym stream lists one, because every overload and template instance of a
qualified name is a function of its own (`engine.rs (register_overload)`); sized data globals and string symbols skip occupied addresses (the plain label arm does not), no-return facts resolve by
**address** first (`find_function_across_scopes` — stable across demangling, which
renames the funcsym before install) with a name fallback for imports, and rename
facts (FID, ObjC, PDB) pass a **label gate** (`engine.rs (is_generic_placeholder_name)`)
that only ever overwrites an engine `sub_*`/`func_*`/`FUN_*`/`LAB_*` placeholder. Two fact
kinds are not installed globally: DWARF stack locals are parked per function and
re-seeded into each freshly-rebuilt `Funcdata`'s `ScopeLocal` at decompile time (the
`map addr`/`seed_mapped_symbols` path), and the `error(nonzero,…)` call-site list is
stashed on the `Architecture` for the per-function flow override (§1.7).

The entry arm is where a single-function run pays for the whole inventory: a
`createFunctionIfMissing` per discovered entry costs about a kilobyte, so an image
whose `.eh_frame` enumerates every function (377,429 on a 51 MB Android `.so`)
spends some 315 MB of a run that reads one of them. `lazyfuncs` (default **off**)
splits the commit: the names install exactly as above, but the entry starts are
parked on the `Architecture`
(`decompiler/crates/kuna-decomp/src/infra/architecture.rs (set_lazy_entry_starts)`)
and no `Function` is created. An entry some other fact of the same commit attaches
to is not parked — a committed name (`_INIT_<i>`, the entry oracle's `main`), a
no-return verdict, a FID rename, an address-keyed prototype (library, `elfmain`,
DWARF, demangled), locals, comments, tracked registers or a format site
(`decompiler/crates/kuna-console/src/kuna_lazyfuncs.rs (fact_entries)`) — because
each of those lands on the `Function` itself and would otherwise be dropped; the
string and data arms also treat a parked start as occupied, as they would its
`Function`. Flow still reads such an entry as a function rather
than code to follow into — `decompiler/crates/kuna-decomp/src/substrate
(ArchFlowEnv)` consults the parked set once the symbol table declines — so a
`BRANCH` into a lazy entry stays a tail call. The raw walk `bejoin evidence` makes
of a function and its callees stops at a parked entry for the same reason
(`decompiler/crates/kuna-decomp/src/p4_calls/kuna_bejoin/evidence.rs (destination)`):
its verdict is cached once per image, before any `Function` is materialized, so a
walk that ran on into a tail-called entry would swap a big-endian pair's halves in
every later read. Materialization then happens on read,
at two depths: the console gives the *selection* its `Function`
(`decompiler/crates/kuna-console/src/engine.rs (ensure_function_symbol)`), and after
a drive `decompiler/crates/kuna-console/src/kuna_lazyfuncs.rs (materialize_callees)`
gives every parked entry the p-code read one — transfer targets plus code addresses
taken as *values*, a Thumb pointer's odd value naming its even start — while
`decompiler/crates/kuna-console/src/decompile_step.rs (decompile_one_prefollowed)`
drives again while that makes progress. The value case is load-bearing:
`decompiler/crates/kuna-decomp/src/p9_emit/coreaction_render.rs (ActionConstantPtr)`
types a constant as a code pointer, and the printer names it, only through a global
Symbol, so a merely-stored function address would lose both. Only parked entries
are materialized — never a constant that merely looks like an address, nor a
p-code-relative `BRANCH` offset — so the lazy symbol table is always a subset of the
eager one. The saving is a property of one function's run: a whole-binary surface
materializes what it walks.

Two timing consequences shape the tier. First, anything that must influence the
**loader itself** runs before any `option` line exists, so load-time gates are
bridged across the process by environment variables the CLI exports:
`KUNA_RELOC_OBJECTS` (`relocobjects`), `KUNA_I386_PIE_PLT` (`i386_pie_plt`),
`KUNA_RELOCREBASE` (`relocrebase`), `KUNA_DYNRELOCS` (`dynrelocs`),
`KUNA_MSVCFPCONST` (`msvcfpconst`), `KUNA_PDATACHAINED` (`pdatachained`),
`KUNA_REXTHUNK` (`rexthunk`), `KUNA_PEORDINAL` (`peordinal`),
`KUNA_MACHO_ARM64E` (`macho-arm64e`),
`KUNA_MACHO_SLICE` (`--slice`), `KUNA_ARM_ISA` (`--isa`). For those,
the option rows exist for discoverability while the live gate is the env var. The
external-artifact paths `kuna_fid_db` and `kuna_pdb_path` are different: they only
*locate* the artifact, and only as one tier among others (`pdb` also searches
beside the image, §1.4) — the `fid`/`pdb` passes stay flag-gated at the deferred
commit (`decompiler/crates/kuna-console/src/engine.rs (analysis_pass_enabled)`). Second,
anything that must **decode instructions** cannot run at load at all — the engine's
loadimage is attached to the SLEIGH translator only *after* the load-time pass list
runs — so the Listing build, its consumers, and `operand_refs` are deferred to the
commit point too (§1.6).

The XML `<binaryimage>` datatest path never constructs an `ObjectLoadImage` and never
stashes an output, so the entire tier is structurally inert on the 675-assertion
parity oracle; only real binaries feel it.

(kuna) The load image is two halves, and only one of them is single-threaded.
The bytes — the vma-sorted segment list and the containing-segment-else-
closest-greater walk over it — are `SegmentBytes`, held behind an `Arc` and
published through `LoadImage::shared_bytes`
(`decompiler/crates/kuna-sleigh/src/loadimage.rs (ImageBytes)`); the reader is
the 512-byte window and the `Rc<AddrSpace>` an incoming address is checked
against, which is per-reader because space identity is pointer identity. A
second reader over the same bytes is `SharedBytesImage`, and both it and
`ObjectLoadImage` serve reads through the one `windowed_load_fill`, so there is
no second copy of the read semantics to drift. Every site that writes the bytes
— the dynamic-relocation patch at construction, an `--assert bytes` overlay,
`adjustVma` — runs at load time and requires sole ownership of the `Arc`; an
overlay requested after publication fails closed.

## 1.2 Load image

`decompiler/crates/kuna-analysis/src/loadimage_object.rs (ObjectLoadImage)` is the
real-binary `LoadImage` backend — the substitution for upstream's GPL-licensed
BFD loader (`LoadImageBfd`), rebuilt on the permissive `object` crate with the C++
interface semantics preserved exactly: the same 512-byte read buffer, the same
containing-segment-else-closest-greater walk with gap zero-fill, and the same
"initial address unmapped → `DataUnavailError`" contract in `loadFill`. Two
deliberate corrections inside that contract. The first: the buffer's
`bufoffset` is claimed at the top of a fill, *before* a byte is read, and a failed fill **releases it
again** (upstream throws with it still claimed). Left claimed, the buffer's own
fast path answers every later request within 512 bytes of the failed address out
of a buffer that was never filled — stale bytes, reported as a successful read.
Nothing upstream reads twice near a failure, which is why it never surfaced
there; a caller that probes addresses in order (the extern-slot
classification of §0.2) walks straight into it.

(kuna, GH-510) The second: **a read longer than the buffer is served straight
into the caller's slice**, bypassing the buffer entirely
(`decompiler/crates/kuna-sleigh/src/kuna_sharedbytes.rs (windowed_load_fill)`,
over `decompiler/crates/kuna-analysis/src/loadimage_object.rs (fill_span)`).
Upstream stages every read through the 512-byte window and copies the answer
back out of it with `memcpy(ptr,buffer,size)`, which for a longer request reads
past the end of the buffer — a silent heap over-read kept out of reach only by
upstream's own callers, none of which ask for more than sixteen bytes. kuna's do
ask for more: the `.asm` data tail of a project export reads each named global
at its declared datatype size, and the same copy spelled as a Rust slice panics
instead of over-reading, so any image carrying a string or typed global of 512
bytes or more — `/bin/ls` among them — aborted the whole `decompile-project` run
before its output directory was created. A span that
long could never be answered out of a 512-byte window anyway, so serving it
directly caches nothing that would have been cached, and the window a
neighbouring short read is being answered from is left as it was. Nothing else
about the read changes — the same segment walk, the same zero-fill past the last
segment it crosses, the same unmapped-start `DataUnavailError` — and a request
of 512 bytes or fewer still follows exactly the path it always did.

The mapping unit is the ELF **`PT_LOAD` segment** (what the OS actually maps), not the BFD
section list. Where upstream returns a BFD target string for the Java side to
re-map, kuna resolves the SLEIGH language id directly off the object header
(machine + endianness + class → e.g. `x86:LE:64:default:gcc`).

(kuna) **A Go image composes the `:golang` compiler field instead**
(`decompiler/crates/kuna-analysis/src/loadimage_object.rs (language_id_for)`,
option `goabi auto|off`, default auto, carried as the `KUNA_GOABI` loadtime
environment gate — the `sourcelang` pattern, because the id is composed inside
`load file`). Go's register ABI is not the platform C ABI: under the `gcc`
model a Go function's RAX/RBX/… arguments are scratch, so its parameters are
invisible, a second return value is dead-coded away and the statements feeding
it are deleted (`func pair(a,b int) (int,int)` rendered
`long pair(void){ return v1 + v2; }`). The vendored golang cspecs
(`abi-internal` default, `abi0`, the write-barrier/duff helper models) exist
for x86-64, x86-32 and AArch64, so the override fires only on those three
little-endian architectures when the effective source language is Go (the
`KUNA_SOURCELANG` force included); everywhere else the composed id is
byte-identical to before, and `elf_language_ids` enumerates the golang ids so
the resolves-in-the-DB gate proves them vendored. Measured on a stripped
go1.22 hello-world (1,544 functions): functions with recovered parameters
544 → 992, functions reading a never-assigned register local 853 → 501, zero
failures either way. Per-symbol `abi0` binding is deliberately absent: the
go1.22 pclntab carries no `.abi0` names and the canonical entry inventory
collapses the unstripped symtab aliases, so no `.abi0` spelling reaches the
engine — alias-aware symbol plumbing has to come first.

(kuna) **With the golang cspec active, the goroutine register becomes the
named, typed global `g`** (option `goreg on|off`, default on, carried as the
`KUNA_GOREG` loadtime environment gate;
`decompiler/crates/kuna-decomp/src/p1_partition/kuna_goreg.rs`, installed by
the architecture build right after the cspec `<global>` decode —
`decompiler/crates/kuna-decomp/src/infra/architecture.rs (kuna_install_goreg)`).
The register ABI pins the current goroutine in a register — `R14` on amd64,
`x28` on arm64, the values the vendored golang `register.info` files state —
which the cspec lists as `unaffected` and no `<pentry>` names, so every access
rendered as a phantom local (`v3; // r14`) fed by unexplained arithmetic. The
install mirrors a cspec `<global><register/>` (the register's storage joins
the global scope; the vendored spec itself stays pristine) and maps a type-
and name-locked `g` symbol typed `runtime.g *` over it. `runtime.g`,
`runtime.gobuf`, `runtime.m` and `runtime.gsignalStack` are synthesized shells
carrying exactly the fields whose offsets the runtime source states for the
register-ABI era, and the layouts are **versioned off the image's own
toolchain**: the build-info blob's version string
(`decompiler/crates/kuna-analysis/src/loader/gobuildinfo.rs
(go_toolchain_version)`) travels as the `KUNA_GOVERSION` loadtime variable —
set by the object bootstrap before the sleigh build, because the shells are
interned inside the cspec decode, upstream of every per-image fact write —
and selects the release's layout
(`decompiler/crates/kuna-decomp/src/p1_partition/kuna_goreg.rs (GoLayout)`):
go1.23 inserted `g.syscallbp`, go1.25 dropped `gobuf.ret`, and with both
perturbations the liblink-stable anchors (`stackguard0` 0x10, `_panic` 0x20,
`m` 0x30, `stktopsp`..`goid` 0x80..0x98) land identically while
`syscallsp`/`syscallpc` and everything inside `runtime.m` after `morebuf`
shift with the gobuf width. The `runtime.m` shell is verified field-for-field
against go1.22.10 and go1.25.3 through `profilehz` (linux/amd64 `sigset`; a
PE Go binary's empty `sigset` would shift the tail from `tls` on — the shell
is a reading aid and `goreg off` removes it); `g.m` carries the completed
`runtime.m *`, so `g->m->curg` chains render named end to end, while `m`'s
own goroutine pointers stay `void *` (a pointer taken to a still-incomplete
composite would survive the factory's clone-and-re-key completion pointing at
the stale type). An access past a modeled prefix renders as an offset off the
shell — still anchored. An image with no parsable build-info version takes
the go1.22 baseline. A golang target with no pinned register (x86-32 reaches
`g` through TLS) is untouched. Measured on the stripped
go1.22 hello-world: functions declaring a phantom `// r14` local 267 → 23,
functions reading named `g->` fields 7 → 297, the preemption-request store
rendering `g->stackguard0 = 0xfffffffffffffade` exactly as the runtime source
spells it; with the `runtime.m` shell, functions indexing raw bytes off
`g->m` fall 166 → 42 and ~77 render named `curg`/`locks` reads — and on a
go1.25 build the versioned layouts keep those same names at that release's
shifted offsets (53 `curg` readers, `syscallbp` rendering where it exists).

The loader's symbol
stream — defined FUNC symbols plus the resolved import stubs of §1.3 — is
`@VERSION`-stripped, demangled (§1.4) and **character-sanitized** before each
name is installed as a `FunctionSymbol`, and the loader's read-only section ranges are applied to the
symbol-table property map eagerly at bootstrap (loader markup, not a gated pass):
they are what lets the printer prove a constant points into read-only memory and
render a string literal.

(kuna) **The loader's tables, the notes and `.interp` are not read-only program data**
(`decompiler/crates/kuna-analysis/src/loader/format/elf.rs (is_loader_table)`).
BFD sets the read-only bit on any allocated, non-writable section, which is as
true of `.interp`, the `SHT_NOTE` sections, `.dynsym`, `.dynstr`, `.gnu.hash`,
`.rela.*` and the version tables as it is of `.rodata`. Nothing in the program
reads those, but the read-only range is the *only* thing
`PrintC::pushPtrCharConstant` asks before it replaces a constant with the
characters at that address, so a number whose value happens to land in one came
out as a string. A PIE that calls `puts((char *)0x4a3)`, `puts((char *)0x320)`
and `puts((char *)0x3a0)` printed `puts("uts")`, the tail of the dynamic string
table's own `"puts"` entry, `puts("d-linux-x86-64.so.2")`, the middle of the
loader path in `.interp` at `0x318`, and `puts("\x03")`, a byte of the
`.note.ABI-tag` kernel version
(`decompiler/crates/kuna-analysis/tests/fixtures/loadertablestring_x86_64`). In
real builds `bash`'s `rl_do_lowercase_version` returned `"_ungets"` for
`0x1869f` and coreutils `ls` compared a pointer against `"loc"` for `0x12c7`.
Those sections therefore do not carry the read-only bit: `SectionKind::Metadata`
(the `SHT_SYMTAB`/`SHT_DYNSYM`/`SHT_STRTAB`/`SHT_RELA`/`SHT_REL`/`SHT_RELR`/
`SHT_HASH`/`SHT_DYNAMIC` family), `SectionKind::Note`, the GNU dynamic-info types
`SHT_GNU_HASH` and `SHT_GNU_verdef`/`verneed`/`versym`, which `object` reports
as `SectionKind::Elf(sh_type)`, and the section named `.interp`, which is plain
`SHT_PROGBITS` and differs from `.rodata` only in its name. The same
classification gates `operand_refs`: a scalar operand that lands in one of these
sections is not a data reference, for the reason its `.got`/`.plt` exclusion
already exists.

(kuna) **An unusable section table is dropped, not fatal**
(`decompiler/crates/kuna-analysis/src/loader/elf_shdr.rs
(tolerate_unusable_section_table)`). An ELF's section table is link-time metadata;
what the loader obeys — the entry point and the `PT_LOAD` map — lives in the ELF
header and the program headers, which is why `readelf -l` still prints a full
segment map for an image whose `e_shoff` is garbage. `object` nevertheless
validates the section table eagerly inside `File::parse`, so a single out-of-range
`e_shoff`, a wrong `e_shentsize`, or an `e_shstrndx` naming no section rejected the
whole image and every kuna surface exited 1 with "not in recognized object file
format". Packers, `sstrip` and CTF authors all produce that shape deliberately. The
image bytes are therefore normalized once, at the same canonical read point as the
Mach-O fat-slice peel, by clearing `e_shoff`/`e_shnum`/`e_shstrndx` — the encoding
of "this ELF has no section table" — so the loader and every analysis pass below
see the same recovered view. The test is pure header arithmetic and runs before any
parse, so an image whose table is usable is passed on byte for byte; the rewrite is
kept only if the rewritten copy actually parses, so corruption elsewhere still
reports `object`'s own error rather than a misleading one about the section table.
What was dropped, and what survived it, is reported on stderr. The CLI surfaces
that parse the image themselves rather than through the loader (`strings`, `crypto`,
`xrefs`, `decompile-graph`, the call graph) read it through the same normalization
(`elf_shdr (read_image)`), so a recovered image is recovered everywhere.

(kuna) **A PE DOS header whose `e_magic` is not `MZ` is repaired, not fatal**
(`decompiler/crates/kuna-analysis/src/loader/pe_dosmagic.rs
(tolerate_corrupt_dos_magic)`). The DOS header's only load-bearing fields are
`e_magic` and `e_lfanew`, the file offset of the NT headers; every header the loader
reads — the `PE\0\0` signature, the COFF and optional headers, the section table —
lives behind that pointer. `object` identifies the format from the leading bytes
alone, so an image whose first byte was overwritten (a CTF image ships `0x15 'Z'`,
`e_magic` `0x5a15`) was "Unknown file magic" on every surface although `e_lfanew`
still led to an intact PE. When the file is no format `object` recognizes and
`e_lfanew` points at `PE\0\0` clear of the magic itself, `MZ` is written over
`e_magic` in the loaded copy, at the same canonical read point and before the
data-directory clamp below, which reads the headers behind it; the file on disk is
never modified. Any other file, including every image that already parses, is passed
on byte for byte with no parse performed, and the format sniff that routes `load
file` to the object loader admits the same images. Like the clamp, the repair is kept
even when the copy still does not parse: the signature settles which format the
file is, so the caller reports what is actually unreadable in it. The repair is
reported once on stderr and, with the other two header repairs, recorded on the
loaded program (`ConsoleProgram::load_notes`), which `functions --summary --json`
publishes as its `warnings` array.

(kuna) **A PE data-directory count larger than its own header is clamped, not
fatal** (`decompiler/crates/kuna-analysis/src/loader/pe_datadirs.rs
(tolerate_oversized_data_directories)`). A PE's optional header ends with an array
of `IMAGE_DATA_DIRECTORY` entries whose length is declared separately, by
`NumberOfRvaAndSizes`, and the two can disagree: `SizeOfOptionalHeader` bounds how
many entries are physically there. Windows trusts the bound and reads
`min(declared, what fits)`; `object` slices exactly the declared count inside
`ImageNtHeaders::parse`, so one oversized `u32` rejected the whole image with
"Invalid PE number of RVA and sizes" before a byte of code was mapped — the shape
a packer produces by overwriting the field (a reported Invius-packed image
declared 1531532893 in a 224-byte optional header holding the 16 real
directories). The count is therefore clamped to what the header holds at the same
canonical read point as the section-table repair, so the imports are read from the
real table rather than fabricated, and a count that already fits is passed on byte
for byte with no parse performed. Unlike the section-table repair, the clamp is
kept even when the rewritten copy still does not parse: a count larger than its own
header is wrong however the rest of the file reads, so keeping it lets the caller
report whatever is actually unreadable instead of a header count that was never
the whole story.

(kuna) **A PE's header page is mapped, read-only**
(`decompiler/crates/kuna-analysis/src/loader/pe_headers.rs (header_region)`).
Windows maps a PE in two parts: `SizeOfHeaders` file bytes are copied to
`ImageBase` as `PAGE_READONLY`, and only then is each section copied to
`ImageBase + VirtualAddress`. `object`'s neutral view enumerates the sections
alone, so everything below the first section's RVA — the MZ stub, the PE
signature, the COFF and optional headers, the section table — was mapped nowhere,
and an address there answered "is not mapped in this input" on every surface,
including `decompile --define-function`. A compiler puts no code in the header, but
a hand-built or packed image may: a reported keygenme declares
`AddressOfEntryPoint` `0x154`, the byte immediately after its own two-entry section
table, so its declared entry was unreachable. The region is therefore published to
the segment and section walks as one more mapping unit, `DATA | READONLY`. It is
read-only, not executable, both because that is what Windows does and because it
keeps the executable-region scans of §1.6 out of the MZ/PE bytes of every PE — so
function *discovery* invents nothing in a header. Its extent is `SizeOfHeaders`
clamped twice, to the file length and to the first section's RVA, so a malformed
value — the same field a packer overwrites two paragraphs above — can never shadow
real content; a clamp to zero publishes nothing. No other format defines one
(`ObjectFormat::header_region` defaults to `None`), because an ELF's `PT_LOAD`
headers already describe whatever of the header is in the mapping.

(kuna) **The one thing that makes a header page code is the image saying so**
(`decompiler/crates/kuna-analysis/src/loader/pe_headers.rs
(declared_entry_in_header)`). Mapping the page was not enough to *decompile* the
keygenme above: the header page is no section, so the executable-section filter of
§1.6 rejected the entry as implausible code, and both of that image's sections
carry characteristics `0xc00000e0` — `CNT_CODE|INITIALIZED|UNINITIALIZED|READ|
WRITE` with `MEM_EXECUTE` clear — so there was no executable section for any other
candidate to land in either. Its whole inventory was the two Import Address Table
slots, and once those were correctly withheld from the batch set (§1.9)
`decompile-all` answered `count: 0` on an image `decompile --addr 0x400154`
renders in full. Where `AddressOfEntryPoint` points into the header page the
region is therefore published `CODE | READONLY` instead of `DATA | READONLY`, and
that one address is exempt from the executable-section filter. Nothing is guessed:
the image names the address the OS jumps to, and no section flag ever spoke for
bytes that are in no section. Three things keep it that narrow. An
`AddressOfEntryPoint` of `0` is the "no entry point" encoding, which `object`
reports as `ImageBase` — inside the page — so it is rejected rather than declaring
the `MZ` signature to be a function. Only the entry is exempt, never a `.pdata`,
TLS or export candidate. And an entry inside a section the image flags
non-executable is **not** exempt: there the flag is a statement about those bytes,
and kuna answers it by naming the cause and the `--define-function` that overrides
it (§1.9), rather than overriding it silently.

(kuna) **A segment's zero-filled tail is mapped, not a hole**
(`decompiler/crates/kuna-analysis/src/loadimage_object.rs (Segment::mapped_size)`).
Every format states a segment's RAM footprint separately from the bytes the file
supplies for it — ELF `p_memsz` over `p_filesz`, PE `VirtualSize` over
`SizeOfRawData`, Mach-O `vmsize` over `filesize` — and the excess is the
zero-initialized data the loader is expected to materialize: `.bss`, and the tail
of any `.data` whose trailing zeros the linker declined to write out. kuna copied
only the file extent into each segment, so an address in that tail matched no
segment, `loadFill` hit the "initial address unmapped" contract, and the surfaces
above it reported an address the image plainly maps as covered by no loaded
segment — a reported keygenme keeps its globals at RVA `0x8740`, inside a `.data`
of `VirtualSize` `0x7a8` over `SizeOfRawData` `0x200`, and reading them was
refused with the advice to unpack an image that was never packed. Each segment
therefore records its RAM footprint alongside its bytes, and the
containing-segment walk answers over the footprint; the part of the read past the
file extent falls into the zero-fill `copy_segment` was already doing for the
straddling case. A data segment with no file bytes at all — a `SizeOfRawData` `0`
section, an ELF `.bss` of its own — is kept for the same reason instead of being
dropped as empty. The footprint is trimmed at the next segment's vma so a declared
size can never shadow real content, and the trim only ever shortens the *tail*:
segments an image stacks at one address (a COFF `.obj` read through the linked
path described later in this section) map exactly what they mapped before.

The tail is recorded only for a segment the image marks as **data**. An
executable uninitialized region is a packer's staging area — `UPX0` is
`VirtualSize` `0x9000` over `SizeOfRawData` `0`, executable — and its file-time
contents are not its run-time contents, so materializing zeroes there does not
recover the code, it feeds 36 KB of `add [eax],al` to the flow walk of §1.6 in
place of the honest `DataUnavail` that stops it. Measured on the in-repo UPX PE:
without the carve-out, the packed entry stops reporting `Unable to load 512
bytes` and decompiles to 16,883 lines in 19.6 s, where the answer that helps is
`kuna unpack`. The consequence is that an image whose only load segment is `RWX`
does not get its `.bss` read either; that is the conservative direction, and the
address still resolves through the section walk, which has always described the
whole footprint.

(kuna, GH-1426) **Where declared segments overlap, the first in address order
serves.** An image can declare an address more than once: two `PT_LOAD`s over
one page from different file offsets, a Mach-O segment or PE section whose
extent runs into another's. The load image neither merges them nor rejects the
image. Its segment list is sorted by start address with a stable sort, so
segments that start together keep the order the image's table lists them in;
the tail trim above ends each zero-filled tail where the next segment starts;
and the containing-segment walk takes the first segment whose mapped extent
holds the address
(`decompiler/crates/kuna-analysis/src/loadimage_object.rs (SegmentBytes::find_section)`,
upstream `LoadImageBfd::findSection`'s first match). So a lower-starting
segment's file bytes shadow a higher-starting one's, the first-listed of two
segments at one address shadows the second, and any segment's file bytes shadow
another's zero fill. That is a static rule, not a runtime one: Linux maps
`PT_LOAD`s in program-header order with `MAP_FIXED`, so the *last* one wins page
by page, and Ghidra imports the later one into default memory and the earlier
as an overlay. kuna's bytes, and so its decompilation, follow this rule; `kuna
read --json` lists every other segment that declares a listed address in its
`provenance` ranges' `overlaps`
(`decompiler/crates/kuna-cli/src/disassemble/provenance.rs`), so the choice is
visible rather than silent.

**Character sanitizing** (`symbolnamechars`, `off|safe|ident`, default `safe`;
`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_symbolnamechars.rs`) is the
last step of that name reduction, and it is the only one that treats the name as
*bytes*. A symbol name is unvalidated binary data, and it is printed verbatim
into the `// Function:` header comment, the `.h` prototype, the definition, every
call site and the `.asm` label. Three shapes therefore restructure the C document
rather than merely look odd — a `*/` closes the header comment early and turns
the rest of the line into code, a raw `0x0a` splits each of those five renderings
across two lines, and a `//` comments out the remainder of the line it lands on —
and a fourth breaks identity rather than syntax: the name is decoded with
`String::from_utf8_lossy`, so two symbols differing only in an invalid byte
become the same `String` and the export carries two definitions and two
prototypes with one name.

`safe` (the default) rewrites exactly that structural set and nothing else: an
ASCII control byte (`0x00`–`0x1F`, `0x7F`), a `"`/`'`/`\`, a `*` or `/` that
forms `*/`, `/*` or `//` with its neighbor (both characters of the pair), and
every byte of an invalid UTF-8 sequence. Each becomes its `_x<hh>` hex escape
rather than a single `_`, because a single `_` is not injective — `a"b`, `a'b`
and `a\nb` would all collapse to `a_b`, reproducing the redefinition defect with
a different trigger — and the escape costs nothing legible, since `safe` fires on
no name a real toolchain emits. A lone `*` or `/` is left alone (it is not a
comment delimiter), as are `.`, `$`, `@`, `-`, `+`, `<`, `>`, `(`, `)`, `;`, `{`,
`}` and all valid multi-byte UTF-8; `::` survives intact, because §0.4's scope
splitter reads it. `ident` additionally reduces each `::` component to
`[A-Za-z0-9_]` through the same routine the Itanium RTTI recovery uses for a
class name (`kuna_symbolnamechars (sanitize_ident_chain)`, called unconditionally
by `kuna_itaniumrtti (sanitize_class_name)`), which is what a reader who intends
to *compile* the export wants; it is not the default because the most common
name in the wild that is not valid C is gcc's clone suffix
(`err_fatal.constprop.0`, `main.part.1`, `add_fdes.cold`), which appears on most
`-O2` binaries and which `safe` is a measured no-op on. `off` restores the
verbatim bytes for someone auditing what a binary literally claims.

The sanitizer runs at the **mint** — after the demangler, so it sees the reduced
name rather than the `_ZN…` envelope, and before the scope splitter, so it never
contends with `symbolnamerepair` over the same empty component — and it covers
the second channel a name arrives through as well: an analysis pass's recovered
name (a DWARF `DW_AT_name`, a Go `pclntab` entry, a PDB public symbol) is
sanitized in `kuna-analysis`'s pass driver
(`decompiler/crates/kuna-analysis/src/pass.rs (AnalysisOutput::sanitize_names)`)
before the commit boundary of §1.4 sees it. Like the other gates consumed inside
`load file` it is carried by a process environment variable. Print-time
sanitizing would be the wrong seam: §0.4 explains that the string in the symbol
table is the key `kuna decompile <name>` and `load function` are passed, so a
name only the printer fixed would be one the tool could no longer be asked for.

The **data** half of those same two symbol tables is read alongside the function
half (`loadimage_object.rs (data_symbols)`): every defined, named `STT_OBJECT`
entry with a non-zero `st_size`, deduplicated by address, `.symtab` before
`.dynsym`. Zero-size entries are dropped because the linker's section-boundary
markers (`__bss_start`, `_edata`, `_end`) are exactly the sizeless ones, and a
sizeless symbol would plant a name on the first byte of whatever object follows
it. Each surviving entry becomes a named `undefined<size>` global — the same
shape §1.4's DWARF data globals use, and for the same reason: a size-1 entry does
not contain a 4- or 8-byte access, so the printer's covering-symbol query would
miss and fall back to `dat_<addr>`. The behavior matches IDA Pro and Ghidra,
which both name data objects from the symbol table independently of any debug
info, and it is what makes `fprintf(stderr, ...)` read as an error path instead
of `fprintf(dat_61a0, ...)` on a stripped binary (GH-184). Per the standing
options contract it is gated by **`datasyms`** (`--option datasyms on|off`,
default ON, DIV-26/DIV-76): the stream is collected at `load file` but committed
at `read symbols`, after the option lines are applied, so the gate is the plain
`Architecture` flag the commit consults — no env bridge is needed on either CLI
path. Off drops the stream at the commit and restores the raw `dat_<addr>`
rendering exactly.

A PE image has no sized data symbols, but its export directory names data too:
`msvcrt.dll` exports `_iob`, `_environ` and `__argc`, and a COM DLL exports its
`IID_*` constants. Each named export whose address lies outside every code
section is kept as a **lookup name only** (`pe_iat.rs (data_exports)`), so
`xrefs --to _iob` and `disassemble` resolve it, under the same `datasyms` gate.
It never becomes a global: an export carries no extent, and a one-byte symbol
would not cover a wider access, so mapping it would trade `dat_<addr>` for
extra casts and raw addresses. A declaration (`--assert data ...`, DWARF) that
supplies the real extent names the storage in emitted C.

A Mach-O image takes the same rule (`macho_stubs.rs (data_exports)`). Its
"exports" are the external defined `nlist` entries, and every one of them used to
enter the function stream: a `__DATA,__data` global, an Objective-C class object
in `__objc_data`, Swift type metadata in `__TEXT,__const`, an `N_ABS` value. Each
then listed in `kuna functions` and decompiled by name to an
`UndefinedInstructionException` body. Now only an export inside a section the
loader classifies as code enters it; the rest are lookup names, under both their
symbol-table spelling (`_audit_global`) and the C spelling (`audit_global`), and
a decompile by either name answers that it names data, where, and that `kuna
read` shows its bytes. One more symbol is excluded the same way: an `N_SECT`
symbol's kind comes from its section's name, and the Mach header symbol
(`__mh_execute_header`) is numbered into `__text` while addressed at the image
base, outside it. A Mach-O symbol is a function entry only when its address lies
inside a code section.

Mach-O data symbols then join the `datasyms` stream themselves
(`macho_stubs.rs (data_symbols)`): every named `N_SECT` symbol inside a non-code
section, local ones included, plus the header symbol, demangled as the function
stream's names are. An `nlist` records no size, so each extends to the next
symbol of its section or the section's end, the way `lldb` sizes Mach-O symbols,
**capped at 8 bytes** (`MAX_DATA_EXTENT`, one 64-bit scalar or pointer). The
extent is what lets the covering-symbol query find the name at the access width,
so `counter += 1` and `return audit_global` read by name, and every pointer to
the object renders `&name` (`MetaClass(&gMetaClass)`,
`&original_NSManagedObject_init`). The cap exists because the gap is a guess: a
release image is stripped of its local symbols (`-x`), so the gap after an
exported object often holds unnamed data (Swift's lazy metadata caches follow
`__dyld_private`), and Go's region markers (`runtime.rodata`, `go:string.*`)
label hundreds of kilobytes; uncapped, every access there would render as an
offset into the wrong name. Inside the cap the guess can still cover alignment
padding, so an access narrower than the extent renders as a partial access of
the named object (`(short)half`, `*(char *)&flag = 1`).

The `nlist` is not where a Mach-O image keeps its exports, only where `object`'s
`exports()` looks for them (the `LC_DYSYMTAB` external-defined range). `dyld` binds
against the **export trie** (`LC_DYLD_EXPORTS_TRIE`, or the `export_off` range of
`LC_DYLD_INFO`), and the two disagree on a stripped image: `strip -N` removes every
`nlist` entry and keeps the trie, and a Swift framework can ship 17 external `nlist`
entries beside a trie of 219 names. `macho_trie.rs (exports)` walks the trie and
`macho_stubs.rs (named_exports)` appends, in address order, each trie name the `nlist`
does not already hold at that address. The trie's names take the `nlist` exports'
rule: one in a code section is a function entry, spelled as the symbol table spells
its names (`_audit_exported_function`), so a stripped image lists what its
unstripped original lists and the C spelling resolves the same way (at an entry
another name already holds, it is a lookup alias of that entry); any other is a
lookup name and, inside a non-code section, a `datasyms` entry sized like an `nlist`
symbol. A re-export names another image's symbol and is skipped, a
stub-and-resolver export names its stub, a thread-local export its descriptor, and
an absolute export is a value, never an entry or a global. On 32-bit ARM the trie
marks a Thumb function with the low address bit, which the `nlist` does not
carry, so an odd address whose even neighbour lies in a code section names that
even entry; an odd address in data keeps its bit, since an exported byte may sit
there. A trie name in code is
also a discovery seed: an `LC_UNIXTHREAD` executable with no `LC_FUNCTION_STARTS`
exports its crt `start`, which is how its entry is found at all. An exported
`_main` is a real symbol at the `LC_MAIN` entry, so `machomain` (§1.5) stands down
for it as it does on an unstripped image.

The trie is untrusted input, so its walk is bounded by its own size, never by what
it claims. Each node is entered at most once (a cycle or a shared child ends there);
a ULEB128 wider than 64 bits or an offset past the end drops the node; an empty edge
label drops the edge and a name over 64 KiB the node's remaining edges; the bytes
read are capped at four per trie byte and the names kept at sixteen per trie byte
(real tries hold about three). `resolve_imports` runs about twenty times per load,
so the export list is kept for the last two images, keyed by the bytes it is read
from: the load commands, the `nlist` array, the string table and the trie.

A **declared extent is never trusted to be representable.** `st_size` is a 64-bit
field of the image that no header check validates, while the type factory sizes
types in a 32-bit `int4`, so the commit clamps the declared size into `1 ..=
int4::MAX` **before** narrowing it — the same shape §1.4's DWARF globals use, even
though those arrive already bounded. Clamping after the narrowing inspects the
wrong number and lets two whole classes of size through: one whose low 32 bits are
zero becomes a size-0 type, which the symbol table rejects, and one whose low 32
bits have the sign bit set becomes a negative size. Neither cost only the symbol.
`engine.rs (commit_analysis_output)` applies its arms in place and propagates the
first error, so a rejected symbol abandoned every later arm — prototypes, context
paints, tracked registers, call-fixups, DWARF locals and line comments — and the
pending stash is taken by then, so a second `read symbols` cannot retry; a
negative size was worse still, indexing the type factory's fixed-size caches out
of bounds. `decompiler/crates/kuna-decomp/src/substrate/dtype.rs` therefore also
refuses a negative size at both cache lookups, as an ordinary error rather than an
invariant, because sizes reach them from image bytes. The clamp is saturating, not
narrowing: a hostile extent stays hostile — a symbol claiming ~2 GiB still covers,
and so shadows, every unnamed address above it, exactly as a legal `st_size` of
`0x7fffffff` already does — but it is now a symbol with a wrong extent rather than
a load that fails or a process that stops.

Precedence is what makes this safe to add underneath the existing sources. The
loader's data symbols commit **last** (`engine.rs (commit_analysis_output)`),
after the DWARF globals and after the detected string literals, and each is
skipped where a function or a covering data symbol already sits. So a
DWARF-described global keeps its DWARF-recovered extent and a detected string
keeps its `char[N]` typelock; the loader arm only fills addresses neither source
reaches. That residue is the interesting one: a copy-relocated libc extern
(`optind`, `stdin`, `stdout`, `optarg`) has a real `.bss` address and a `.dynsym`
entry but no DIE in the program's own `.debug_info`, so nothing else could name
it. Relocatable objects are excluded — `reloc_object` rebases only the function half
of the symbol table, so a `.o` keeps its previous behavior.

With `symbolnamechars ident`, imported data basenames become collision-safe C
identifiers before being mapped into the engine symbol table
(`decompiler/crates/kuna-console/src/kuna_dataidentifiers.rs`). Readable stems
survive (`tempfile.3` becomes `tempfile_3`); a numeric suffix is added only for
an actual collision, and an address-based name is used only when no stem
remains. C keywords and leading digits receive identifier-safe adjustments.
Valid accented names remain intact. The default `safe` mode keeps ordinary
binary spellings unchanged. Data-name folding is deferred until installed and
pending names can be reserved together, so `counter.3.1` cannot capture an
existing `counter_3_1`. Original data spellings remain lookup aliases for
`kuna xrefs --to` and `kuna read`, without adding duplicate mapped objects.

Format dispatch is by magic (`engine.rs (is_object_binary)`): ELF, thin or fat
Mach-O, PE (`MZ`, validated downstream by the typed PE parser), and bare COFF
objects recognized by a whitelisted leading `IMAGE_FILE_MACHINE_*` u16 — anything
else routes to the XML front-end (§1.8). Per-format knowledge is funneled through
one trait, `decompiler/crates/kuna-analysis/src/loader/format/mod.rs (ObjectFormat)`:
the compiler-model id (ELF → `gcc`/`default`, PE → `windows`, with a resolve-time
fallback retry to the arch default when the preferred model has no vendored spec),
the section-flag translation, import resolution (§1.3), and extra constant ranges
(the MIPS GOT). Two format specifics live above the trait:

- **Relocatable objects** (angr, `relocobjects`, default-on) — a pre-link object
  does not say where its bytes live, and each format fails that differently. An
  ELF `.o` has no program headers, so the faithful loader maps zero bytes and
  every lift fails. A COFF `.obj` does present segments, but stacks every section
  at VMA 0: the faithful loader maps whichever sorts first and every symbol
  collapses onto address 0, so with MSVC function-level linking (`/Gy`, one COMDAT
  `.text` per function — the default for real builds) all but one function
  disappear. `decompiler/crates/kuna-analysis/src/loader/reloc_object.rs (RelocLayout)`
  reproduces angr CLE's relocatable backend for both: lay each memory-resident,
  non-empty section out above `0x400000` (`RELOC_BASE`, matching CLE so addresses
  line up with angr's), apply the relocations, rebase defined symbols, and bind
  each undefined extern to a synthetic call target in an extern area above the
  sections so calls render by name. COMMON symbols instead reserve their
  full size (ELF `st_size`, COFF symbol value), using the ELF alignment carried
  by `st_value` or a 16-byte synthetic alignment for COFF, in a separate synthetic
  area after the maximum undefined-symbol slot extent. Their addresses are
  reused for repeated references, remain disjoint from extern slots, and do not
  move ordinary undefined targets. The analyzer’s rebased view retains the COMMON
  extent as a separate loaded-address range. The project loader includes this
  extent in its program-object ranges, so generated headers declare referenced
  COMMON globals; unresolved external slots remain excluded. Invalid alignment, address overflow or an
  allocation beyond the object's address width leaves the relocation unresolved,
  rather than assigning overlapping storage. This loader correctness repair in
  `decompiler/crates/kuna-analysis/src/loader/kuna_commonalloc.rs (CommonAllocator)`
  needs no inference option; it retains the existing treatment of unbacked
  synthetic storage. An adjacent SPARC `sethi`/`jmpl` pair
  carrying `HI22`/`LO10` relocations to the same symbol with zero addends also
  identifies that symbol as code, even when the ELF marks it `STT_NOTYPE`.
  The jump must use the register written by `sethi` and discard the link or
  write `%o7`; an ordinary address materialization or data load does not qualify.
  This lets existing tail-call recovery resolve a named external destination
  and preserve its delay-slot arguments. The relocation encoder handles generic
  absolute, relative, PLT-relative, and image-offset fields at 8/16/32/64 bits in
  the object's byte order, plus the instruction fields and ABI formulas for ARM
  `CALL`/`JUMP24`/Thumb branches/`REL32`/`PREL31`, AArch64 branch/page/low-12
  forms, PowerPC `REL24`/`PLTREL24`/`LOCAL24PC`/`ADDR24` calls (32- and 64-bit;
  a `-fPIC` object's `PLTREL24` addend locates the caller's `.got2` for the
  linker's call stub and is not added to the target), the 14-bit conditional
  branches, the absolute (`ADDR16*`, including the 64-bit `DS`, `HIGHER` and
  `HIGHEST` forms), PC-relative (`REL16*`) and TOC-relative halves, and the
  `REL32`/`REL64`/`UADDR*` data words, and 32-bit SPARC `WDISP30`/`WPLT30`/
  `HI22`/`LO10`/`PC22`/`PC10`/`DISP32` forms. A PowerPC64 ELFv1 object names each
  function by its `.opd` descriptor: the function symbol is registered at the
  code the descriptor's `R_PPC64_ADDR64` points at, a branch relocated against a
  descriptor's symbol, or against `.opd` plus a descriptor's offset (a call to a
  `static` function), reaches that code, and the descriptors (with their TOC)
  are the loader's ELFv1 descriptors, as a linked image's are. The TOC base is
  `.toc + 0x8000`; an object with no `.toc` (medium-model code that reaches its
  data through `@toc@ha`/`@toc@l` halves) still has the one the linker's `.got`
  would give it, 256-aligned after the other sections, plus `0x8000`. An
  undefined `.TOC.` resolves to that base.
  MIPS relocations go through
  `decompiler/crates/kuna-analysis/src/loader/kuna_mipsreloc.rs (Gp)`. An o32
  object (REL) keeps each addend in the field it patches, so a `HI16`, or a
  `GOT16` against a local symbol, takes the low half of its addend from the next
  `LO16` against the same target, as the GNU linker pairs them; an N32/N64 object
  (RELA) states its addends and chains up to three operations in one entry
  (`%hi(%neg(%gp_rel(f)))` is `GPREL16`, `SUB`, `HI16`), each result the next
  one's addend. Neither `$gp` nor a GOT exists before link, so the layout makes
  what the linker would: a GOT after the object's other sections, with one entry
  per symbol and addend a `CALL16`/`GOT16`/`GOT_DISP`/`CALL_HI16`-style
  relocation names and one per 64 KiB page a local `GOT16` or a `GOT_PAGE`
  reaches (sized from the relocations before any is applied), then the
  small-data sections (`.sdata`, `.sbss`, `.lit4`, `.lit8`, `.srdata`), and `_gp`
  `0x7ff0` past the GOT's start. `_gp_disp` resolves to `_gp` less the place
  (the PIC prologue adds `$t9`, the function's entry) and an undefined `_gp` or
  `__gnu_local_gp` to `_gp`. The GOT's entries hold what the relocations put in
  them and nothing writes them, so the loader reports its range foldable
  (`dynreloc_const`, beside the MSVC FP constants), and
  `lw $t9, %call16(f)($gp); jalr $t9` decompiles to a call of `f` wherever `$t9`
  is seeded with the entry. `R_MIPS_JALR`, a hint naming the function a `jalr`
  calls, is not applied; microMIPS, MIPS16, R6 PC-relative and TLS relocations
  are reported unsupported. An entry that cannot be encoded is left
  untouched and classified by reason (unsupported, unresolved target, missing
  TOC, section bounds, required veneer, alignment, range, or invalid encoding).
  The loader reports exact failure totals in at most eight groups with three
  samples per group, once per public load, so machine-readable output remains
  valid and stderr stays bounded. The
  result feeds back into `ObjectLoadImage` as the same segments/sections/funcsyms
  triple the linked path produces. The loader also retains the original section
  index, section name, section-relative offset, symbol binding, and
  defined/undefined provenance beside each synthetic VMA. Front-ends expose that
  coordinate as `.section+0xOFFSET` or `SECTION_INDEX:0xOFFSET`; a bare numeric
  selector first means a mapped synthetic VMA, then falls back to a raw function
  offset only when exactly one definition matches. Name and raw-offset collisions
  report every candidate instead of taking symbol-table order, and only a symbol
  marked undefined is classified as external. Linked ELF inputs retain the
  symbol-table definition addresses separately from resolved import-stub
  addresses, using ELFv1 code entries rather than descriptor addresses and
  folding the ARM Thumb state bit. These addresses follow loader VMA shifts.
  A name matching one executable definition and only import stubs selects the
  definition in both selector resolution and canonical name lookup; both entries
  remain in the inventory. Multiple executable definitions or unclassified
  executable competitors remain ambiguous, and explicit address selection
  remains literal. A load of any format, linked or relocatable, still reports
  one name per address (the first in symbol-table, import-stub, `.dynsym`
  order, the one the symbol table installs for call sites: on Mach-O the first
  `nlist` entry, locals ahead of externals as the linker writes them, on a PE
  the first COFF function symbol; a PowerPC64 ELFv1 image keeps every name, as
  before), but no longer discards the other distinct names there: they
  become lookup-only aliases
  (`decompiler/crates/kuna-analysis/src/loadimage_object.rs (ObjectLoadImage::func_symbol_aliases)`,
  raw addresses with any Thumb bit), which the console appends to the
  canonical entry at the normalized address. So a local veneer name, a
  `.localalias` or a strong symbol ahead of its weak alias no longer hides the
  name after it, and an exported name that also labels a PLT stub selects the
  definition by the rule above instead of the stub. An alias never becomes the
  reported name, so `kuna functions` and whole-binary output keep the name
  its callers print. Nor does it outbid a function's own name: when that rule
  does not settle a name, the candidates it reaches only through a loader alias
  are dropped before the remaining tie-breaks, so a static `shared` still wins
  over another function's same-address alias `shared` and a name that selected
  one function keeps selecting it. An alias whose address no entry holds yet
  (discovery has not named it) is still a candidate there, so a lookup sees the
  same candidates with or without discovery. Mach-O and PE kept only the first
  name until GH #1357, so a second `nlist` label at one entry (`_audit_export_b`
  beside `_audit_export_a`, two local labels, a function `ld64` folded into an
  identical one) or a MinGW pair (`_fpreset`/`fpreset`) did not select its own
  function. A Mach-O export is also reported in its C spelling (`audit_export_a`)
  by the export stream; at an entry the symbol table named, that is the same name
  again, and lookup already retries a Mach-O name with its `_`, so it is not kept
  as an alias (two exports at an entry only the export stream names, as in a
  kext's `__TEXT_EXEC`, are two names and both are kept). That retry narrows
  its candidates by the decorated spelling, so `audit_shared` selects the
  function named `_audit_shared` over another one's `_audit_shared` alias, as
  `_audit_shared` itself does. Loaders that publish no section
  records, including the XML corpus loader, prove a numeric VMA by probing one
  byte from the load image instead. Which sections are memory-resident
  is the one question that stays per-format — ELF's `SHF_ALLOC` bit and COFF's
  `Characteristics` content bits minus the link-time-only sections (`.drectve`,
  `LNK_REMOVE`, the discardable `.debug$S`/`.debug$T`) — and it is asked through
  `ObjectFormat::is_alloc_section`, alongside `ObjectFormat::relocatable_layout`,
  which decides whether a given file needs this path at all.
  A REL-style relocation table (COFF, 32-bit ELF) stores its addend in the field
  being patched rather than in the entry, so the in-place value is read back and
  added; a RELA entry carries the whole addend and reads back zero.
  ARM function symbols additionally retain the ABI state bit while branch
  relocations are applied. `R_ARM_CALL` and `R_ARM_THM_CALL` convert `BL` to
  `BLX` (or back) when a typed target crosses the ARM/Thumb boundary. A
  cross-state jump cannot make that transition in place, so it is left
  untouched and reported as requiring a linker veneer instead of being encoded
  as a branch in the wrong instruction set. Untyped and undefined targets do
  not infer state from their synthetic slot address. AArch64 branch, page, and
  low-12 relocations preserve the instruction's opcode/register fields, while
  PowerPC64 `REL24` and TOC-family relocations preserve big-endian instruction
  layout and DS-form low bits. SPARC `WDISP30` and `WPLT30` rewrite the 30-bit
  word displacement of a `call`, computing `S + A - P` modulo 2³² so a call
  can cross the signed-address boundary or wrap around address zero;
  `HI22` writes bits 31..10 of `S + A` into a
  `sethi` and `LO10` the low ten bits into a format-3 immediate, leaving the
  upper `simm13` bits as the GNU linker does; `PC22`/`PC10` are the same two
  fields over `S + A - P`, and `DISP32` is the 32-bit PC-relative data word.
  The split forms truncate rather than range-check, and reject a REL-style
  implicit addend, which cannot be reassembled from one half. SPARC64 (V9)
  instruction relocations, and GOT/TLS forms that need linker-built tables,
  remain unsupported.

  An undefined symbol reached through any branch or call instruction field —
  not only a call-spelled one — is bound to a named extern slot. A tail call is
  spelled as a plain jump relocation (`R_ARM_JUMP24`, `R_AARCH64_JUMP26`, a
  PowerPC64 `REL24` with its link bit clear), and the branch is patched to point
  at the synthetic slot either way; leaving that slot unnamed makes the *calling*
  function undecompilable, because the flow walk follows the branch into memory
  the layout never backed. The call/jump distinction itself is kept where it is
  load-bearing — the ARM `BL`/`BLX` interworking rewrite — and is not what
  decides whether an extern is named.

  Laying the object out synthetically splits the address space in two, and every
  pass in this chapter reads the *other* half: each one re-parses the file through
  its own `object::File`, which reports the **pre-link, section-relative**
  addresses the linker has not yet assigned. Mixing the two in one inventory is
  what produced a phantom `sub_<section-offset>` beside every real function, a
  single DWARF function at address 0, and string literals that never attached to
  the loaded image at all. `relocrebase` (kuna, default-on) closes that by
  rebasing the analyzer tier's **input** rather than each output fact — necessarily
  so, because a fact is a bare address by the time it reaches `AnalysisOutput`, and
  in a relocatable object every section sits at address 0, which makes `.text`+0x20
  and `.rodata`+0x20 the same number. Worse, the fields that matter are not offsets
  at all until their relocation is applied: an unrelocated `.eh_frame`
  `initial_location` reads back as its own section offset, and an unrelocated
  `DW_AT_low_pc` reads 0 for every subprogram (as does every `DW_FORM_strp`, so the
  whole object's DWARF collapses onto one function named after whatever string sits
  at `.debug_str`+0).
  `decompiler/crates/kuna-analysis/src/loader/kuna_relocrebase.rs (rebased_view)`
  therefore re-presents the object to the tier: each laid-out section carries the
  loader's own relocated bytes and its load VMA (ELF `sh_addr`, COFF
  `VirtualAddress`); each section the layout skipped — every `.debug_*` table — has
  its relocations applied here, resolving a target in a laid-out section to that
  section's load VMA and a debug-to-debug target to its own section-relative offset,
  which is what a single-object link leaves in place; and each ELF symbol defined in
  a laid-out section has its `st_value` shifted by **its own section's** delta,
  since the layout is non-contiguous and there is no single global offset (a COFF
  symbol needs no shift — it is reported as `VirtualAddress + value`, so the section
  write already moved it). Each patched field is written in the object's own byte
  order (ELF `EI_DATA`), the implicit addends of a REL table read in it, so a
  big-endian object (PowerPC, MIPS, SPARC, ARM big-endian) is rebased as a
  little-endian one is; it used to keep the pre-link view, so `kuna functions`
  listed each of its functions twice (`0x0 scale` beside `0x400000 scale`) and a
  MIPS PIC function's `$t9` was seeded at its section offset rather than its
  entry, so its `addu gp,gp,t9` never resolved and every call and global through
  the GOT stayed a load from an unknown `t9`. Over 959 relocatable objects the 441
  whose output changes are all big-endian: the `t9` variables left in MIPS PIC
  functions drop from 3,352 to 25, string literals printed rise from 6,766 to
  18,169, and no function is added or lost. Every pass then produces an
  already-rebased fact with no source change of its own.
  A field with no relocation still yields an address in no laid-out section, so
  `kuna_relocrebase (retain_in_image)` **drops** exactly those rather than letting a
  pre-link address through — that is the phantom class. The single exception is a
  no-return fact, which the commit resolves by name when its address does not
  resolve (an undefined `exit` in a `.o` has never had one); it is kept with its
  address zeroed. The Listing/xref tier takes the other answer and declines outright
  for a synthetically laid-out object (§1.6): it exists to find functions an image
  has no symbol for, and a pre-link object always carries the symbol table the
  linker is about to consume.

  Binding an undefined symbol to a synthetic slot resolves the *reference* and
  loses the *value*, and for one class of symbol the value was never elsewhere to
  begin with: MSVC never encodes a floating-point literal into the instruction
  stream — x87 and SSE both load one from memory — so the compiler emits each
  literal as a COMDAT whose **name spells it**. `__real@8@3ffec90fdaa22168c000`
  is π/4. COMDAT folding then keeps the definition in exactly one translation
  unit, so in every other object that symbol is undefined: no section, no bytes,
  a slot with nothing behind it, and an expression written entirely in opaque
  addresses (`(… * dat_402020 + dat_402040) * dat_400ae0`). `msvcfpconst` (kuna,
  default-on, env-bridged,
  `decompiler/crates/kuna-analysis/src/loader/kuna_msvcfpconst.rs (plan)`) reads
  the value back out of the name. Three spellings are accepted:
  `__real@<size>@<20 hex>`, an x87 80-bit extended datum (a 16-bit
  sign/exponent field then a 64-bit mantissa carrying its **explicit** integer
  bit) plus the storage width the program loads it at — `4` for `float`, `8` for
  `double`; and the two bare-bits forms `__real@<16 hex>` (IEEE double) and
  `__real@<8 hex>` (IEEE float, which is what MSVC has emitted for a `float`
  literal since VS2005 — the 20-hex form is the VC6-era one). The decode is
  exact rather than approximate: the source constant was a `float` or a `double`
  before the assembler widened it, so at most 53 of the mantissa's 64 bits are
  set and the `f64` image is lossless. Every x87 encoding class with no faithful
  `f64` image is **refused** rather than approximated — an Inf/NaN exponent, a
  denormal or pseudo-denormal (whose true scale is one binade away from the
  normalized formula), an unnormal, and any value outside `f64` or, at `@4@`,
  outside `float` — as is every other mangling, `__xmm@`/`__ymm@` included: a
  wrong 16-byte datum is worse than an honest `dat_<addr>`.

  As with `dynrelocs` below, decoding is only half of it. The undefined half
  gets the decoded bytes materialised as a segment at its extern slot, which is
  what makes the address readable at all; but the *defined* half needs nothing
  materialised and still renders `dat_<addr>`, because folding a read-only global
  is gated program-wide by `option readonly` (default off). Both halves are
  therefore reported as `ObjectLoadImage::dynreloc_const_ranges` — the same
  narrow "constant by construction, not by policy" exception list `dynrelocs`
  fills on the linked path, carried to `Architecture::dynreloc_const` and folded
  by `ActionVarnodeProps` with global propagation still off (§3.4). Listing only
  one half would be worse than listing neither: one operand of an expression
  would come out a literal and the operand beside it stay opaque. A defined
  COMDAT's mapped bytes are cross-checked against its own name before its range
  is admitted, which is also what keeps the relocatable-object fidelity hazard
  away from this path — a read-only section in a `.o` holds *pre*-relocation
  bytes, but a `__real@` COMDAT carries no relocation, and a disagreement between
  the bytes and the name drops the range with a warning rather than folding it.
- **Mach-O fat/arm64e** — a universal binary is peeled to one slice's bytes
  before anything else parses it, because `object::File::parse` has no fat arm
  and rejects the whole file with "Unsupported file format"
  (`decompiler/crates/kuna-analysis/src/loader/macho_fat.rs (select_fat_slice)`;
  preference `--slice`/`--target`, else x86-64 → arm64 → first), so the loader,
  every pass, and the deferred-Listing stash all see the same thin slice. The
  peel is one policy with two readers: the engine dispatch, and the canonical
  image read every surface that parses the file for itself goes through
  (`macho_fat (peel_fat_image)` from `elf_shdr (read_image)`, the same point the
  ELF and PE header repairs above are applied). Reading the file directly instead
  is what made `strings`, `xrefs` and the `functions --summary`/`--reachable-from`
  call graph exit 1 on a universal image whose `functions` inventory loaded fine,
  and what made `--slice` inert on those surfaces — it steers both readers, so a
  slice named on the command line selects the same image the inventory reports.
  An
  arm64e slice selects the Apple-Silicon pointer-auth SLEIGH spec instead of
  generic v8A only under the `macho-arm64e` env gate
  (`decompiler/crates/kuna-analysis/src/loader/format/macho.rs (MACHO_ARM64E_ENV)`).
  Modern Mach-O pointer slots are chained-fixup entries, not pointers;
  `decompiler/crates/kuna-analysis/src/loader/format/macho/chained.rs (ChainedFixups)`
  parses `LC_DYLD_CHAINED_FIXUPS` into a VMA→resolved-pointer overlay for every
  user-space pointer format (`DYLD_CHAINED_PTR_64`, `_64_OFFSET`, `_32`, and the
  arm64e formats 1, 7 (a kext), 9 and 12, authenticated rebases with their PAC context
  stripped) plus the import each bind names, read through the chained imports
  table. A bind resolves to no pointer, so a consumer misses and falls back rather
  than reading a wrong address. The loader writes the resolved values into the
  image it maps (`dynrelocs`, §1.3). The header is the image's own bytes, so the
  walk is bounded by the file rather than by its counts: a `seg_count` stops at
  the end of the blob, every address computation wraps instead of overflowing, a
  chain stops at a file word the walk already decoded, and the walk reads at most
  one page start per 2-byte entry of the blob (`chained.rs (Walk)`). An honest
  image decodes each slot once and reads each page start once, so neither bound
  changes what it yields; a hostile one with 65535 tiny pages all starting inside
  one long chain would otherwise walk it once per page, and thousands of segments
  sharing one 65535-entry start table would read it once per segment. Only the
  import records a bind uses are read, and their names, which an honest pool
  holds once each, are read from at most the pool's own length in total
  (`chained.rs (read_imports)`): a table whose names all run on to the pool's end
  would otherwise copy the pool once per import.

An explicit target changes only language selection: the parsed container still
owns section mapping, image base, symbols, and imports. Container header class is
independent of decoder instruction width, so ELF32 can be decoded with a 16-bit
x86 language. An endian disagreement is reported on stderr rather than refused:
`--target` is the flag that overrides what the container declares, and a
byte-swapped decode of a mislabeled image is a legitimate use of it. Empty targets
and the `default` sentinel select the detected architecture and retain the
compiler-model fallback; the loader and console normalize these requests
identically.
This separation lets a recognized container remain loadable when `object` reports
its architecture as unknown. In particular, PE/COFF machines `0x01c0`
(`IMAGE_FILE_MACHINE_ARM`) and `0x01c2` (`IMAGE_FILE_MACHINE_THUMB`) are both
treated as little-endian ARM32 for language selection; what each says about the
decode mode is the shared ARM mode table's answer (§ the TE paragraph below), a
whole-image Thumb paint for `THUMB` on a PE and the entry-bit walk for `ARM`.
Their sections and PE image base still come from the container parser.

Bare THUMB COFF objects use the typed COFF reader before architecture selection:
the generic `object` magic dispatcher omits machine `0x01c2`. The shared
`loadimage_object::parse_object` entry point preserves the original machine,
sections, and symbols, and is also used when analysis or a CLI inspection
command reopens the image. It retains the typed reader's header and section
validation; it does not rewrite the machine bytes to another architecture.

(kuna) **MS-DOS `MZ` executables load as relocated real-mode images.**
`decompiler/crates/kuna-analysis/src/loadimage_mz.rs (MzImage)` claims a file
with an `MZ` (or `ZM`) header that is not the stub of a newer format: a `PE\0\0`
signature at `e_lfanew`, an `NE`/`LE`/`LX` one there past the old header, or an
image the `object` crate opens as PE keeps the object path. Bytes 0x3c..0x40 are
read as `e_lfanew` for the `NE`/`LE`/`LX` test only when the header reaches past
them and the relocation table does not cover them (deark's rule); otherwise they
are code or a relocation entry, and a stray `LE` they happen to point at does not
turn a DOS program away. The load module is
the file from the header's paragraph count to the size its page fields declare
(an overlay past that is not mapped), and it is placed at segment 0x1000, linear
0x10000, as DOS would place it at some free paragraph: each relocation-table
entry adds 0x1000 to the word it names, and one that names a word outside the
module is skipped and reported. The entry is `(0x1000 + CS) * 16 + IP`, with the
segment add wrapping as the CPU's does, so PKLITE's `FFF0:0100` lands on the
first module byte; an entry outside the module is refused. The dispatcher
(`decompiler/crates/kuna-console/src/engine.rs (bootstrap_from_mz_bytes)`) hands
the relocated bytes to the raw-image path as one in-memory `CODE` mapping, with
the `x86:LE:16:Real Mode:default` language unless the caller names another and
the entry as its seed, so `rawdiscover` widens the inventory from it and the
entry is reported as the image's, together with the relocated words the call
sweep reads (`mzsweep`, below). It then states the code segments the image
names to the 16-bit x86 decoder
(`decompiler/crates/kuna-analysis/src/loader/kuna_realmodecs.rs (paint)`): the
entry's CS from its `CS:IP`, and, for every relocation whose word is the segment
of a far `CALL`/`JMP ptr16:16` (`9a`/`ea`, offset, segment) with a target in the
module, that segment at the target (`MzImage::code_segments`). The target must
also lie below the next segment the image names (every relocated word, and the
entry's CS): a far branch lands in its own segment, while a `9a`/`ea` byte that
is the tail of another instruction (`b8 9a 10 ba ..` is `mov ax, 0x109a; mov
dx, seg x`) implies a target past that segment, in code another CS runs, and
stating that CS there would wrap its near branches in the wrong segment. A
segment holds from its point up to the next one, so a near branch in the
entry's segment wraps IP inside that segment instead of taking the linear sum,
and the raw-image call sweep, which runs before the descent, already decodes a
far-called segment with its own CS. The header's
minimum allocation is not mapped: a flow into uninitialized memory is a flow
into nothing, not into zeros that decode as `ADD [BX+SI],AL`. A PKLITE or LZEXE
stub is named on load, since its code is a decompressor in front of a packed
body (issue #1288); the note sends a PKLITE file to `kuna unpack`. Surfaces that
need an `object::File` refuse an `MZ` input with a capability error, as they do
a TE.

(kuna) **UEFI TE images take a bounded container path of their own.**
`decompiler/crates/kuna-analysis/src/loadimage_te.rs (TeLoadImage)` parses a
file the format probe claims. That probe reads more than the `VZ` signature —
two ASCII letters an unrelated file can open with — and also requires an EFI
subsystem and a `StrippedSize` leaving room for the header it counts, so a
non-container keeps the headerless-image guidance instead of being routed into
the TE parser or refused as a TE; the machine word is deliberately not part of
the claim, so a TE for a machine kuna has no binding for is told so by name. One
dispatcher (`decompiler/crates/kuna-console/src/engine.rs (bootstrap_from_image_with_isa)`)
routes every front-end's file load to the TE or the object loader, and the
section table is classified by the same `SectionKind` rule and flag rule the PE
loader applies to the same characteristics. The TE header remains authoritative for
the machine, image base, entry point, data directories, and section table; an
explicit target can select only a width- and data-endianness-compatible SLEIGH
language. Each section's file offset subtracts the stripped-header bias while
its loaded address retains the original image-base-relative VMA. File offset zero
is retained at `ImageBase + StrippedSize - 40`, and the read-only mapping
continues up to the adjusted `BaseOfCode`, so it covers the TE header, the
section table, and the alignment slack behind them. That region has two extents
and they coincide only when the image was linked with SectionAlignment equal to
FileAlignment: the file BACKS it up to the first section's adjusted raw offset,
while it is MAPPED up to the adjusted `BaseOfCode`, with the difference reading
as zero. Deriving the file length from the RVA delta instead refuses an
ordinary 0x200-file-aligned image outright. The file-backed part must lie
inside the file, and a section's adjusted raw range must begin at or after the
section table describing it — the TE analog of a PE section starting at or
after `SizeOfHeaders`; truncated or overlapping input is rejected rather than
completed with synthetic bytes.
`VirtualSize` bounds each section's mapped extent when nonzero, file-alignment
padding beyond that extent is not exposed, and a virtual tail beyond the
initialized bytes reads as zero — a firmware module is loaded into a zeroed
buffer, so unlike the object loader's packer-staging refusal that tail is
faithful. It is still not *evidence*: the literal-pool constant ranges are built
from the file-backed extents only, so a read landing in a tail the image carries
no copy of is never folded to a constant. The parser rejects arithmetic overflow,
overlapping or out-of-file ranges, directories outside mapped sections, and
entries outside file-backed code before allocating section contents. Byte
assertions atomically replace a complete span within one mapped header or
section and may materialize a zero-filled virtual tail; unmapped,
cross-boundary, and wrong-address-space writes are rejected. The entry is named
at the analysis commit, after options such as `namestyle` are applied.

Language selection reuses the object loader's `compose_language_id` over the PE
machine word, so a TE and a PE carrying the same machine select the same SLEIGH
variant; only the compiler model follows the UEFI bindings (C/cdecl for IA-32,
the UEFI x64 convention with the arch-default fallback for x64, AAPCS for
AArch32, AAPCS64/LP64 for AArch64), and an explicit compatible target remains
authoritative. The ARM decode-mode policy is one table in
`decompiler/crates/kuna-analysis/src/loadimage_object.rs (pe_arm_mode_policy)`,
read by both PE-family loaders: `ARMNT` declares a wholly Thumb image on every
container and is painted as such; `ARM` may interwork on every container; and
machine `0x1c2` is read as its container family names it — `THUMB` on a PE,
painted wholly Thumb, and `ARMTHUMB_MIXED` on a TE, interworking — a decision
made once there rather than in each loader. Where the policy leaves the mode to
the entry bit, on a TE or a PE alike, an odd entry arms the `entrythumbflow` pass
(`decompiler/crates/kuna-analysis/src/listing/kuna_entrythumbflow.rs (entry_thumb_flow)`,
default on), run at the deferred analysis commit after image-scoped overlays so
it follows the effective instruction stream: it seeds `TMode=1` over each
executable range as one region write, decodes the flow reachable from the
normalized entry through fall-through, direct branches, and direct
mode-preserving `BL` calls (an interworking `BLX` target keeps the mode its
encoding selects), restores every run of values the range already held rather
than the one at its start, and publishes exactly the decoded instruction ranges
as bounded `TMode=1` paints under its own gated pass id — written to the
context database at once as well as stashed, because the deferred Listing
consumers decode the same bytes before the stash is committed. Decoding inside
the walk masks only the `TMode` bits out of the language's context writes
(`set_context_write_mask`): a Thumb `blx` runs `globalset(TMode=0)` at its target,
which would flatten every Thumb address above that target for the rest of the
walk, and the seed already answers the mode question for the whole range.
Other context writes still propagate, including the IT condition at the next
instruction, so guarded branches and returns retain their fall-through. The
previous write mask is restored when the walk finishes, even at its budget. The
walk covers file-backed executable bytes plus successfully applied byte
overlays clipped to executable mappings. Adjacent and overlapping spans merge
before decoding, so an instruction can cross their boundary, while unwritten
gaps and tails remain excluded: zero-filled bytes can decode as Thumb no-ops.
Only enabled analysis passes supply no-return seeds to the entry walk and the
later Listing consumers. An unconditional direct call to one of those callees
has no fall-through; an IT-guarded call, including `BLX`, retains the successor
reached when its condition is false.
The walk is bounded at 4096 instructions; reaching the bound publishes the ranges
walked so far, reports the truncation once on stderr, and leaves the unreached
code at the language default, so the load never fails on the size of the image.
The pending entry is consumed before the walk runs, so a failure cannot re-arm
it, and a walk that publishes nothing leaves the context partition as it found
it. A wholly Thumb image can opt into the explicit `--isa thumb` range paint
instead.

PE entry discovery and Listing seeds normalize the low bit according to the
selected decoder before deduplication and naming. A 32-bit ARM decoder clears
the Thumb bit; a non-ARM override preserves an odd address even when the header
machine is ARM, THUMB, or ARMNT. The header-page entry exemption and the loader's
reported image entry use the same selected-decoder convention. Container-only
discovery, which has no selected language, retains the automatic machine policy.

The parsed entry and named sections are retained as format-neutral program
metadata (`decompiler/crates/kuna-console/src/engine.rs (ProgramImageMetadata)`),
populated by the object loader as well, so the project README no longer
re-parses the input and reports the entry through the inventory on every path.
A TE image has no `object::File`, so the Listing discovery tier cannot run over
it: the deferred consumers are skipped and the load says so once on stderr —
unconditionally, because it is a property of the container rather than of a
run's options — and the object-view consumers (`strings`, `crypto`, `xrefs`, `decompile-graph`,
and the graph-backed `functions`/`decompile-all` filters) report one capability
error from the shared image read rather than the object crate's parse failure.

(kuna) **Static unpacking.** A packed image is the one input on which the whole
tier is honestly useless: it maps a loader stub and a compressed blob, so every
address the original program used is absent until something recovers it.
`decompiler/crates/kuna-analysis/src/upx` reimplements the recovery in-process --
the UCL NRV2B/NRV2D/NRV2E decoders (`nrv.rs`), the LZMA1 decoder (`lzma.rs`), UPX's
branch-target filters (`filter.rs`), and one reconstruction walk per target family. `kuna unpack` is the
only caller; nothing on the load path unpacks implicitly, because the recovered
file is an artifact an analyst reads and names, not a hidden rewrite of their input.

The two families share nothing but the codecs, because the packed layouts do not
resemble each other. An ELF (`upx/elf.rs`) carries its `PackHeader` in the tail and
its payload as one block stream per original `PT_LOAD` plus the gaps between them.
A PE (`upx/pe.rs`) carries the `PackHeader` in the header padding immediately before
the compressed data -- outside the tail window entirely -- and holds the whole image
in a single block, followed by a trailer that the packer's own loader consumes at
run time and the unpacker replays instead: the original PE header and section table,
then one record per rebuild -- where the stripped import list starts, where the
relocation stream starts, and the icon count the resource rebuild restores -- then a
pointer back to that header. `win32/pe` (PE32) and `win64/pe` (PE32+, amd64) are the
same walk; they differ only in word size: eight-byte import thunks whose ordinal
flag is bit 63 instead of four-byte ones with bit 31, and `DIR64` relocations
instead of `HIGHLOW`. The optional-header magic sets the word size, and both the
packed header and the recovered one must have the size the PackHeader's target
format names; a PE32+ whose PackHeader claims `win32/pe`, or the reverse, is refused
as unsupported before anything is rebuilt. A PE header that does not parse is
reported as what it is; the tail scan that serves every other target can still find
such a file's PackHeader, but a PE PackHeader has no overlay field, so it is never decoded
as though it had one -- that misreading is what used to answer a valid `win64/pe`
file with "PackHeader declares an overlay outside the file".

UPX filters only the code, and every rewritten branch target carries the code's
distance from the image's first section as a bias, so the unfilter takes that bias
rather than refusing a code base that does not start the image. `win64/pe` uses the
`ctok` filter (`0x49`) alone; `win32/pe` adds the plain calltricks `0x11`-`0x16` a
`--brute` pack can choose.

The import descriptors, thunk arrays and hint/name entries UPX strips out of the
image come back from the trailer's compact list. The DLL *names* are not in the
trailer at all; they stay in the packed loader's own import table, which the trailer
addresses by offset. That table is found by agreement with the trailer rather than
through the packed image's import data directory, because retargeting the directory
at a decoy is the first thing a repacker does to a UPX image, and the witness in
`tests/fixtures/upx_packed_pe_i386.exe` is exactly that. Where the original's import
names were one contiguous run, the trailer says where it started and they are
written back there in order; where they were scattered -- every MinGW image -- UPX
leaves each descriptor's name address and each thunk's hint/name address in place
and only the strings go back where those already point. A `KERNEL32` import by
ordinal is recorded as the offset of the packer's own loader thunk for it, and the
ordinal is read out of that thunk rather than out of the offset.

The agreement is over the *set* of DLL names, not a position-by-position walk. The
loader table holds one descriptor per distinct DLL, while the original image may
import a single DLL across several descriptors -- a 32-bit MSVC witness names seven
DLLs from thirteen, `KERNEL32.DLL` four times -- so the two lists differ in length
whenever a binary does that, and a positional comparison can never agree on one. It
did not merely lose the table: it reported the image as corrupt. The table also
carries the stub's own `KERNEL32.DLL` descriptor even when the original imports
nothing from that DLL, so one such descriptor is allowed beyond the set.

Base relocations are rebuilt the way `upx -d` rebuilds them. UPX strips an EXE's
relocations when it may, marking the packed header `RELOCS_STRIPPED`, and its own
unpacker then zeroes the recovered header's relocation directory; `kuna unpack` does
the same. The relocations UPX keeps -- every DLL's, and every ASLR image's, which on
win64 is nearly all of them -- were rebased to zero, byte-swapped in place and
recorded as a delta-coded position stream; the rebuild decodes the stream, restores
each pointer, and lays the positions out as a fresh `.reloc` table (one block per
page, padded to four bytes), with the 16-bit `LOW`/`HIGH` lists a PE32 may append.
Entries of a kind UPX does not keep -- anything but `DIR64` in a PE32+ -- were
dropped when it packed, so they are not in the result either. An export directory
UPX moved out of the image -- a DLL's always, an EXE's with `--compress-exports=0`
-- is rebuilt at its original address in the compact layout UPX's `Export::build`
writes, forwarder strings included. A TLS directory needs no step: UPX's own
`rebuildTls` is empty. The resource directory comes back with every leaf UPX moved
repointed, unless UPX could not clear the original's (its pieces were not
contiguous), in which case the original's is still in the image and stays. What
comes back is the packed copy whole, names included: UPX's packer lays the directory
out afresh with every name string behind the directories and data entries, and
clears only the original's directories and data entries, so the original's names are
still in the image at offsets the packed copy's entries do not point at.

Which trailer records exist is read from the trailer's length rather than predicted
from the data directories. The packer writes a record only when it had something to
put in it, while UPX's own unpacker predicts each one from the original's
directories, and the two disagree on an image whose import directory names no DLL or
whose relocations are all of a kind UPX drops -- `upx -d` then reads the next record
as this one and fails. The three records are 8, 5 and 2 bytes and no two sets of them
sum alike, so the length names exactly one set, and a length no set reaches is
refused as a PE feature this tier does not rebuild. The resource record is the one
the length cannot leave out: the packer writes it exactly when it gives the packed
header a resource directory, which it does only for an original with one, so a
trailer without it for an image whose two headers both have a resource directory is
refused as damaged rather than unpacked with its resources left unrebuilt.

The rebuilt header matches what `upx -d` writes in two ways and keeps the original's
in two. The bound-import directory is zeroed -- its table lived in header slack the
packed file's own headers took over -- and so is the checksum, which covers bytes
the rebuilds re-laid out. The import-address-table directory and `SizeOfHeaders`
keep the original's values, which `upx -d` zeroes and recomputes, and each rebuilt
import descriptor's `OriginalFirstThunk` names its `FirstThunk` array rather than
the zero `upx -d` leaves; with those set aside the file is byte-identical to
`upx -d`'s. Data past the packed file's last section is the original's overlay -- a
signature, a MinGW image's COFF symbol table -- and is appended again at the
original's offset. With nothing dropped from the image, the original's length says
how long that overlay was, and the packed file's tail can carry more than it on
either side. UPX 3.9x writes its stub's relocation block twice; the second copy
spills past the last section's declared end, and the spill and its zero padding to
the file alignment sit in front of the overlay, where `upx -d` copies them too. Bytes
appended to the packed file afterwards -- a signature, a payload -- sit behind it. So
the overlay is read from past a front of exactly the spill's shape, and only for its
own length; neither shifts it. The reconstructed file must
be exactly the original's length, or short of it only by what UPX itself drops: the
trailing `.reloc` section of an image packed without relocations (its directory is
gone too), or debug data that started the overlay (the debug directory stays).

Every size and offset these rebuilds follow comes from the file, so each walk is
bounded by the bytes the file holds. The loader-table scan reads only section
bytes present in the file -- a section past the end of the file maps nothing, and
one at the top of the address space does not wrap -- and reads at most two
descriptors per four bytes of the file, about twice what an honest image needs; a
trailer naming more than 256 distinct DLLs is refused as unsupported, since UPX can
pack more. A resource tree that reaches one directory or data entry twice is refused: UPX's packer writes
the directory out afresh with every node once, even for an original whose linker
shared a subtree, so only an edited file has one, and following it lets a small tree
fan out into an exponential walk. The leaves it moves may not add up to more than
the packed file. An export rebuild is sized as its strings are read, and refused once
it outgrows the image -- every name pointer may name the same long string. The output
file is laid out, and refused if it would be longer than the declared original,
before anything is allocated for it.

What is not rebuilt is named. The `win64/arm64` and `wince/arm` targets exit with
their names; so does PackHeader version 14, UPX's exact-layout PE mode, whose trailer
stores the original headers and the gaps between sections verbatim instead, and so
do versions before 12, older than any layout UPX's own unpacker still reads.

(kuna) **NEOLite.** A second packer, recognized before UPX is asked and on evidence
of its own, so nothing about the UPX arm -- including what it answers for a file that
is not packed at all -- depends on this. `decompiler/crates/kuna-analysis/src/neolite.rs`
takes an image with a `.NEOpack` section that **owns the entry point**; the section
name alone is a string anyone can write into a header, and it is the entry landing
inside the stub that says the stub runs first.

The layout is the opposite of UPX's, and it is why this is recoverable statically at
all. NEOLite compresses each original section in place and appends only its two
loader sections, leaving the original section table untouched -- so every virtual
address and virtual size in the packed file still describes the original image, and
"where does this decompress to" is a question the file already answers. What the
stub computes at run time is then only what the file also still holds: the original
entry point is the operand of its `push OEP; ret` hand-over, and the original import
directory is inside the `.rdata` that was just decompressed.

The codec is an LZX derivative rather than anything UPX carries. A block transmits
757 Huffman code lengths -- 721 main, 28 length, 8 aligned -- through a 19-symbol
code-length tree, DEFLATE-style with the run codes 16/17/18, each length delta-coded
modulo 16 against the previous block's so consecutive blocks pay only for what moved.
The main alphabet merges match length and position slot the way LZX does
(`256 + slot * 8 + len_slot`) over LZX's 58 position slots and its three repeated
offsets, and only the eighth length slot escapes to the length tree, which indexes
DEFLATE's length base/extra tables. Distances come out raw or, when the block's
aligned tree is not the uniform three-bit one that means "verbatim", as high bits
plus a three-bit aligned symbol. Symbol 720 ends a block and introduces the next
one's trees.

Completeness of a code table is the whole validity test a section's bytes get, and it
carries real weight: a packer routinely leaves resources uncompressed, and the only
thing separating those bytes from a stream is that their first block header does not
build a complete canonical code. A section that fails it is carried through exactly
as it stands rather than decoded into nonsense. The rebuild then restores three
things beyond the bytes -- the entry point, the import data directory, and
`CNT_CODE | MEM_EXECUTE | MEM_READ` on the section the recovered entry lands in,
because the packer rewrites every section to plain read-write data and a `.text` that
does not claim to be code is a section the executable-section filter skips. No other
section's flags are touched: the narrow claim is the one the entry point itself
warrants. Only PE32 x86 is rebuilt; any other optional-header magic is declined by
name, which is why the parse reads the entry point and section table before it looks
at the magic at all.

Refusing beats guessing, in both arms. The output is a file a reader will
disassemble and believe, and a subtly wrong one is more expensive than none: an
unreversed filter leaves every call target wrong while every size still adds up. So
each arm proves its own reconstruction rather than assuming it -- both of the
packer's Adler-32s, a total that equals the original file size the header declares
to the byte, and every rebuilt directory confined to the section the recovered
header says owns it. The PE arm adds one guard the ELF arm does not need: which
trailer steps run depends on which data directories the original image had, so an
unimplemented one would silently desynchronize every later read. The walk therefore
tallies the trailer bytes it consumed against the trailer's real length and refuses
a mismatch, on top of naming base relocations, TLS, bound and delay-loaded imports
up front. Everything unimplemented -- the CL1B, DEFLATE, ZSTD and BZIP2 methods, the
64-bit and ARM PE targets, the `ctojr`/PowerPC/RISC-V filters -- is a named refusal
and writes no file.

Two codecs sit behind that walk, chosen per block by the `b_info` method id. The UCL
decoders cover methods 2-10; method 14 is LZMA, which is what `upx --lzma` and
`upx --best` write and therefore what most recently packed binaries carry. UPX does
not wrap LZMA in a container: a block is a raw LZMA1 stream with no properties/size
preamble and no end-of-stream marker, prefixed by two UPX bytes that spell the coder
parameters -- `pb` in the low three bits of the first, `lc` and `lp` in the low and
high nibbles of the second. The uncompressed length comes from the block header, so
the decoder runs to a known size rather than to a marker, and a stream that stops
short is an error and not a partial block. The one place it relaxes the NRV arm's
contract is input consumption: an LZMA range coder holds lookahead bytes it never
uses, so trailing slack is a property of a valid stream, and the packer's Adler-32
over the decoded bytes is what proves the block instead.

(kuna) **Decoding without the metadata.** Discovery can fail on an image whose payload
is intact: a repacker that strips the `PackHeader`, a private packer that borrows only
the codec, a blob a reader located by hand. `no UPX PackHeader found` is then a correct
answer and a dead end, and the missing input -- where the stream is -- is something the
reader already has. `kuna unpack --raw-lzma START:END` supplies it: discovery is skipped
entirely and that range is decoded as one raw LZMA1 stream. Endpoints are virtual
addresses, resolved through the object's own section table (the table the address was
read out of) and clamped to the bytes the file stores for that section, since a
section's virtual size routinely runs past its raw data and the excess is zero fill, not
stream; `--raw-offsets` reads them as file offsets, which is also the only reading
available for an image no object parser recognises.

The consequence that shapes the decoder is that **no `b_info` exists to declare the
uncompressed length**. `lzma::decompress_exhaustive` therefore runs the same decoder to
the end of the *input* instead of to a length: the recovered size is a result, capped by
the caller rather than predicted, and running out of input is this mode's ordinary
ending rather than the `Truncated` refusal a declared length earns. A corrupt stream
still fails, because a bad distance or an unreachable model index is a different fact
from a short one. By default the range's first two bytes are the UPX parameter prefix;
`--lzma-props` names `pb`/`lp`/`lc` for a stream that carries none, and the prefix is
synthesized so one decoder path serves both.

What this arm produces is a payload, not a program: no imports, no relocations, no
rebuilt header, and none of the reconstruction proofs the walk applies -- there is no
declared size, no `UPX!` marker and no Adler-32 to check it against. That is why it is
an explicit override and not a fallback the `PackHeader` search reaches on its own. The
refusal path is unchanged and deliberately so: an image that genuinely is not packed
still exits `1` naming that, because an `unpack` that exited `0` on everything would
trade a right answer for a reachable one.

(kuna) **PKLITE.** The DOS packer, recognized after NEOLite and before UPX by its
decompressor stub at the DOS entry point, so a file without one reaches the UPX arm
exactly as before. A Windows or OS/2 program (`e_lfanew` naming a `PE`, `NE`, `LE`
or `LX` header) is never PKLITE's, even when its DOS stub is a PKLITE file: the
program is the new-style executable, which PKLITE does not pack.
`decompiler/crates/kuna-analysis/src/pklite` is a port of deark's
`pklite` module (MIT; the notice is in the module header and `NOTICE`): `stub.rs`
reads the parameters out of the stub, `decode.rs` is the decoder, and `mod.rs`
rebuilds the file. A packed EXE enters at `FFF0:0100` -- the start of its code --
and its load module is the stub, the compressed program, a compressed relocation
table and an 8-byte footer holding the original `SS`, `SP`, `CS`, `IP`; the 1990
betas put the data before the decoder instead. Without extra compression (`-e`) the
stub's header also keeps a copy of the original MZ header.

Nothing trustworthy *declares* the parameters. The version word at `0x1C` is
routinely wrong, so the compression mode and the data's position are read from the
stub's machine code, walked component by component against known byte patterns:
the intro (whose `MOV DX` immediate keys the descrambler some versions run over the
rest of the stub, an XOR or ADD chain undone in place before anything else is
read), the copier (whose `MOV SI` immediate locates the decompressor), and the
decompressor (whose immediate is the compressed data's paragraph, and whose
literal-copy loop, length table and register setup say whether extra compression,
large compression or the v1.20 code tables are in use, plus any XOR key on match
offsets). Every component that matches no pattern is a named refusal.

The codec is LZ77 over an 8 KiB window with fixed Huffman codes for the match
length and the distance's high five bits. Control bits come from 16-bit words read
least-significant first, and the next word is fetched the moment the last bit of
the current one is consumed, ahead of the data byte that follows; extra compression
XORs each literal with the number of control bits left at that moment. One length
code escapes to a byte that is a longer length, the stop code, a no-op, or an
uncompressed area, whose eight-byte `PKLITE` signature and length byte are restored
in the output while the history gets zeros (two registered PKZIP 2.04 builds put
stale memory there instead, matched by content). The relocation table is the short
form (count byte, segment, offsets) normally and the long form (count word per
`0x0FFF`-paragraph segment) under extra compression, byte-swapped when the stub's
descrambler is the ADD kind.

The rebuild uses the kept header copy only when its registers agree with the footer
and its relocation count with the table; otherwise it writes a 28-byte header with
the code 16-byte aligned, the footer's registers, `MAXALLOC` from the packed file
and `MINALLOC` estimated from the stub's own free-memory check, as deark does.
The kept copy runs up to the original relocation table, and PKLITE does not record
the bytes between that table and the code, so those are zero. An overlay is carried over when
the decompressed module ends exactly where the recovered header says. The format
has no checksum, so the proofs are structural: the stream must end on its stop
code, the relocation table must end where an 8-byte footer still fits before the end
of the load module, and a match may not reach before the output or behind an
uncompressed area. A file whose stub stores a `PK` signature into the PSP is
unpacked with a warning that the program checks for it at run time. A PKLITE COM
file is decompressed whole. As with UPX, nothing on the load path unpacks
implicitly; the runtime hint names the stub (`PKLITE packed: run 'kuna unpack'`).

## 1.3 Loader markup

Import naming exists because a CALL into a linkage stub carries no symbol: without
it `FlowInfo`'s call query finds nothing and every library call prints
`sub_<addr>(...)`. Each format reconstructs the stub→name map from its own linkage
structures, and all of them emit the same `ImportSym` currency into the loader's
funcsym stream:

- **ELF** (`decompiler/crates/kuna-analysis/src/loader/elf_plt.rs
  (resolve_plt_imports)`, the `ElfDefaultGotPltMarkup` analog): build
  `got_slot → name` from the dynamic relocations, then decode each `.plt*` stub's
  indirect jump per architecture (x86-64/x32, i386, AArch64, ARM, RISC-V, SPARC)
  and match the *decoded* GOT target against the map — self-correcting, since PLT0
  and IRELATIVE/IFUNC stubs jump to non-symbol-bearing slots and fall out
  automatically. `.plt.sec`/`.plt.got` outrank `.plt` so the CET call target wins.
  `option ifuncfpret` (default off, x86-64) adds a second pass that DOES name those
  IRELATIVE IFUNC stubs — `ifunc_<resolver>`, keyed off the `R_X86_64_IRELATIVE`
  resolver-address map — so a tail `jmp` to a glibc math/mem/str dispatcher's stub
  is recovered as a `tailcalljump` to a discovered function instead of flowing into
  the stub and rendering `(*dat_...)(...)`; the FP-return-type recovery it unblocks
  is a Ghidra-divergent follow-up (`docs/features/ifuncfpret/proposal.md`).
  Two ABIs need special handling: PowerPC (ELFv2 `.plt` is a NOBITS data table, not
  decodable code; PPC32 uses its own secure-PLT stub shape), and **MIPS**, which
  has no PLT and no jump-slot relocations at all — its resolver walks the
  `.MIPS.stubs`/GOT layout from the dynamic table (`DT_MIPS_LOCAL_GOTNO`/
  `DT_MIPS_GOTSYM`) and marks the external GOT slots constant, so with
  read-only propagation the `lw $t9, off($gp); jalr $t9` sequence folds to the
  named import (the bootstrap turns `readonlypropagate` on for MIPS only).
  Only a slot that holds its import's stub address is marked. An import with no
  lazy stub (its address is taken, or the reference is weak) has a slot holding
  0, which the dynamic linker overwrites with the import's address at load
  time; folding that 0 printed `(*NULL)(a0)` for the call and folded a weak
  `if (hook) hook();` guard away, so such a slot stays variable and reads like
  an x86-64 `-fno-plt` GOT call, `(*dat_<slot>)(a0)`. The slots of what the
  image itself defines are covered under `dynrelocs` below.
  PPC32 linked images use
  `decompiler/crates/kuna-analysis/src/loader/kuna_ppc32_imports.rs (resolve)`:
  a zero-addend `R_PPC_JMP_SLOT` names its call target directly inside an
  allocated, writable, executable NOBITS `.plt`, after the reserved 72-byte
  header. Secure-PLT entries are pointer slots instead: complete `r11` load,
  `mtctr r11`, `bctr` stubs in executable sections are named only when their
  decoded address matches such a relocation in the non-executable `.plt`.
  Absolute stubs encode the address directly. For PIC stubs, the loader instead
  exposes validated relocation-slot metadata through
  `decompiler/crates/kuna-analysis/src/loader/kuna_ppc32_imports.rs (pic_slots)`.
  Duplicate relocations, nonzero addends, data-symbol relocations and slots
  outside the allocated writable non-executable `.plt` are rejected. This
  metadata neither names executable stubs nor adds global no-return contracts.
  The `ppc32picimports on` mode consumes it during P2 flow, in the
  selected caller's register context. Metadata is available after loading even
  when the option is off, so `on`/`off` changes require no reload for an image
  loaded without `abi`. Entering or leaving `abi` requires reloading the image
  because its loader identities persist for that image. The default is `off`.
  `DT_PPC_GOT`, GOT headers and `.got2` locate tables, not the value of r30.
  Both ELF byte orders are supported. BSS-PLT and absolute-stub naming remains
  independent of this option. This does not add a sectionless PPC32 resolver.
  The `ppc32picimports abi` mode additionally resolves short and long PIC stubs through
  `decompiler/crates/kuna-analysis/src/loader/kuna_ppc32picimports.rs (resolve)`.
  A PIC stub loads its target from `r30` plus a displacement, so its import is
  whatever `r30` its callers hold. The stub is named only when every transfer
  into it is reached by the proof and all of them select the same `JMP_SLOT`.
  The proof walks the image once from every entry: exported and local symbols,
  call targets, relocated code pointers, the ELF entry, `DT_INIT`/`DT_FINI` and
  `.eh_frame` function starts. A local symbol or FDE start that only other
  functions branch to (a `.cold` part) is not an entry; their walks continue
  into it. Each walk starts from symbolic registers: the caller's values of
  the nonvolatile registers, the entry stack pointer and return address. It
  tracks constants, stack offsets, the stack words that hold a saved
  nonvolatile register, the return address or a back chain, and loads from
  words whose runtime value the image fixes (code, read-only data and
  relocated GOT entries). `bcl 20,31` reads the program counter; it is not a
  call. Counted conditional branches decrement CTR on both successors, and
  indirect LR/CTR targets discard their low two bits. Joins keep equal values
  only. A stack word below `r1` holds nothing
  the walk knows: a signal frame or a callee's frame can overwrite it at any
  time, and a callee also writes its return address to `4(r1)`. `stwcx.` may
  store nothing and `stwbrx` stores reversed bytes, so neither saves a
  register. Scalar stores invalidate every saved word overlapping their actual
  effective-address range, including unaligned reversed and indexed floating-point
  stores. Only vector stores apply their instruction-defined alignment mask.
  The return address stays in registers and the frame's save
  words: a walk that stores it anywhere else, moves it to a special register
  other than LR and CTR, or calls through it forgets everything (below).
  A call to an import, or through a register, continues at the next
  instruction with `r1`, `r2` and `r13`-`r31` kept, as the SysV calling
  convention guarantees. A call to local code uses that function's summary:
  the nonvolatile registers every return restores, and whether it returns at
  all. Summaries come from the callee's own walk. They start from the
  strongest claim and weaken until no caller's view changes. This greatest
  fixed point is sound for recursion by induction on the depth of a call that
  returns. A callee whose walk forgets everything may return anywhere in the
  code that called it, so each caller's walk forgets everything as well. A
  straight-line helper ending in `blr`, such as libgcc's
  `_savegpr_N`/`_restgpr_N`, runs in the caller's state instead, unless it
  reads LR. The helper recognizer, normal walk and unresolved-edge walk share
  opcode-19 classification: only CR operations and `isync` are known fallthrough
  forms. TAR transfers and other unmodeled forms refuse a straight-line helper
  and flood the affected walk instead of applying skipped register writes or
  restores. A linked TAR branch is also a potential exception call site.
  A tail branch into another function returns through LR: to the
  walk's caller for the entry return address, and to a known address of the
  same code for a constant LR. Any other LR, such as the return address a
  call left behind, makes the branch an unresolved jump. A branch or table
  jump to an entry strictly inside its own function (a label whose address a
  computed goto takes) continues the walk there instead. The walk does not continue past a call to an import that its own
  proven slot names on the base ELF no-return list (`abort`, `exit`, `err`,
  `__stack_chk_fail`, `__cxa_throw`, `_Unwind_Resume`, `std::__throw_*` and the
  like) — the list `on` mode and the `noreturn_known` marking of the named stub
  also use, so the three agree on every import. It also stops after a call that is the last instruction of its FDE
  range or sized symbol (a stub that call would run into if it returned is
  never named), after `sc` with `r0` = 1 or 234 (`exit`,
  `exit_group`), and after an unconditional trap.
  Each landing pad in an LSDA call-site table is entered from the calls in
  its range, with their nonvolatile registers. A jump table is followed when
  the target is the table base plus a table word (PIC) or a table word itself.
  The index is shifted by two. An unsigned `cmplwi` the branch has passed, or
  the shift's mask, bounds it, and every bounded entry inside the jump's
  function is a target. An unbounded table is read until its first target
  outside the function. An entry outside the function is no case label, but
  a stub it runs into is never named. A target inside the dispatch sequence itself is never
  a case label. Any other indirect jump might reach any instruction of its
  function, including the GOT-pointer setup, so that walk forgets everything.
  It then floods what it reaches: a stub entered from there gets no evidence,
  and its summary keeps nothing. The failure stays scoped to what that
  function's walk reaches.
  A load resolves imports about twenty times; it holds its image buffer in an
  `ImportProofScope` (`decompiler/crates/kuna-analysis/src/loader/kuna_ppc32picimports.rs`)
  so those resolutions share one proof. The scope borrows the immutable buffer,
  so its address identifies the image while the load runs; nothing is copied or
  retained once the load ends. The console carries the proof with the stashed
  bytes to the deferred analyses at `read symbols`. An image resolved outside a
  scope is proved on each request, so another image can never reuse its
  identities, whatever its length or hash.
  The soundness argument rests on the toolchain and ABI, stated as
  assumptions. (1) Stub provenance: the linker writes a PIC stub's address
  only into branch fields (`R_PPC_REL24`, `R_PPC_PLTREL24`, `R_PPC_LOCAL24PC`).
  No relocation yields it for data or address arithmetic, and the stub has no
  symbol an input object could name. So no code pointer (a return address,
  function pointer, jump-table or landing-pad target) holds a stub address.
  The one exception, a call immediately before a stub, is a fallthrough site.
  An uncertified transfer elsewhere therefore cannot enter a stub; that is
  why one failing caller withdraws only the stubs its own walk reaches. The
  proof checks the observable part. A stub is never named when a data word,
  relocation, symbol (other than a local label at its start), the image entry,
  `DT_INIT`/`DT_FINI`, a landing pad or a branch points into it or into its
  padding. The same holds when a computed constant equal to its address is
  stored or passed, or when an unresolved jump's function contains it.
  Dynamic relocations in code reject the image. (2) Calling convention:
  imports and functions called through registers restore `r1`, `r2` and
  `r13`-`r31`. Local code is not trusted; its summary is proven. (3) A
  function's switch tables and computed gotos target its own code: its FDE
  range or sized symbol, else the code between neighbouring entries and stubs.
  (4) Exceptions are raised by calls, as in C and C++ without
  `-fnon-call-exceptions`. The unwinder enters a landing pad with the throwing
  call's nonvolatile registers. (5) Only a frame's own function writes its
  register save words, at fixed offsets from `r1` or its frame pointer. A
  pointer from elsewhere, or one the walk cannot compute, addresses a program
  object, so a callee given a local's address cannot overwrite the saved `r30`
  or LR. Only the dynamic linker writes GOT words, with their relocated
  values. No code rewrites a saved context (a `jmp_buf` or a signal's
  `ucontext`), and no function keeps a return address it received in a
  register other than LR for other code to jump to.
  (6) Compiled code does not run past the end of its FDE range or sized
  symbol, and the listed no-return functions do not return. (7) A function's
  address is taken through a relocated data word or a symbol, so the seeded
  entries are the only ones. Under these assumptions every runtime path to a
  stub starts at a seeded entry and follows modeled edges. The walk's state
  over-approximates every runtime state, so a constant `r30` at every
  transfer into a stub is the runtime `r30`. A stub's name is the slot its
  callers really load: code that moves `r30` between the linker's base and a
  call (as hand-written assembly can) is named after the slot it reaches, not
  after the linker's label. `DT_PPC_GOT`, a valid GOT header and a retained
  `_GLOBAL_OFFSET_TABLE_` symbol locate the GOT but never establish `r30`;
  GNU ld can discard an empty `.got2` while callers still use its per-object
  base. Duplicate relocation slots, nonzero addends, data symbols and
  incomplete stubs provide no import identity. A `.gcc_except_table` without a
  readable `.eh_frame` rejects the image, and an FDE whose LSDA cannot be read
  makes its function's walk forget everything. The walk is bounded by 64 visits
  and table reads per code word; an image that exhausts it gets no PIC names. Both byte orders
  are supported. Off keeps PIC stubs unresolved; BSS-PLT and absolute stubs
  are unaffected. In the console, set the option before `load file`; CLI
  options are bridged before either loader runs. The `abi` mode is opt-in because
  the proof walks every function:
  about 0.3-0.4 s for libstdc++ or libc, which makes listing a PPC32 PIC
  image's functions 1.1-1.8x slower and a single-function decompile up to 3x.
  The default path and other formats pay nothing, and the proof runs once per
  image content. Resolved PPC32 import names take
  precedence over local stub labels, which remain aliases. Existing library
  prototypes, no-return facts and name-based xrefs therefore see the same
  imported identity, including when a terminal call has no mapped fall-through
  bytes. This does not add a sectionless PPC32 resolver.
  Every input named so far is keyed on the section table — `object` builds its
  dynamic-relocation iterator by scanning it for `SHT_REL`/`SHT_RELA`, reads
  `.dynsym` as a section, and the stub scan finds `.plt*` by name — so an ELF
  whose section table is absent or unusable gets its bytes and none of its import
  markup, and every library call prints `(*dat_<slot>)(...)`. None of that
  information is actually section-bound.
  `decompiler/crates/kuna-analysis/src/loader/elf_dynseg.rs (dynamic_imports)`
  reads it out of `PT_DYNAMIC` instead — `DT_SYMTAB`/`DT_STRTAB`/`DT_SYMENT` for
  the names, `DT_JMPREL` (with `DT_PLTREL`/`DT_PLTRELSZ`) and `DT_RELA`/`DT_REL`
  for the slots they attach to, `DT_PLTGOT` as the i386 GOT anchor
  `_GLOBAL_OFFSET_TABLE_` otherwise supplies — translating each virtual address
  through the `PT_LOAD` map, which is how the run-time loader finds the same
  tables. It runs only when the section-driven resolution produced **nothing at
  all**, so it adds names to an image that had none and can never move a name on
  an image whose sections are intact. The PLT is deliberately not reconstructed
  as a range: with no section name left there is no honest bound for it, and a
  guessed sub-range of an executable segment names stubs off by an entry.
  Each executable `PT_LOAD` window is handed whole to the same per-architecture
  decoders, and the decoded-GOT-target match above decides which instructions in
  it were stubs — the relocation slots are the bound. PowerPC and MIPS are
  excluded: neither resolves through a `.plt` code section at all, and both need a
  section-derived anchor this path cannot supply.
- **Linked-image dynamic relocations** (kuna, `dynrelocs`, default-on,
  env-bridged): the loader maps the `PT_LOAD` bytes the *linker* wrote, which is
  not the image a process runs. Every slot filled by a dynamic relocation —
  `R_*_RELATIVE`, `R_*_GLOB_DAT`, `R_*_JUMP_SLOT` — is left at zero for the
  run-time loader to complete, and in a PIE (which is the default link mode of
  every current toolchain) that is the whole `.got` plus every relocated function
  pointer in `.data.rel.ro`. A call through such a slot therefore reads a null
  target and can never resolve, which is the `(*dat_<addr>)(...)` rendering of a
  callee that is a *named function in the very same image*. Zero is not an
  ambiguity to be judged; it is a byte the run-time image never holds.
  `decompiler/crates/kuna-analysis/src/loader/kuna_dynrelocs.rs (resolve)` walks
  `.rela.dyn`/`.rel.dyn`/`.rela.plt` and computes the value the dynamic loader
  would store: for `RELATIVE` the image's load bias plus the addend (kuna maps a
  linked image at the vaddrs it declares, so the bias is zero and the value is the
  addend); for `GLOB_DAT`/`JUMP_SLOT` the symbol's address, **and only when that
  symbol is defined in this same image**. An undefined one is an import — its
  value lives in another object, there is nothing to write, and the PLT/import
  naming above already covers the call — so it is skipped and that path is
  untouched, lazy-binding stub contents included. A `REL` table (32-bit ELF)
  carries no addend field, so the in-place word is read back as the addend, the
  same in-place convention `relocobjects` uses. Architectures are named by their
  relocation triple: x86-64, AArch64, i386 and ARM; a machine with no entry
  produces nothing rather than guessing at a number that means something else
  there.

  Applying the relocation is only half of it. `.got` is `SHF_WRITE`, so nothing
  downstream would trust a value read out of it, and the constant fold of
  read-only storage is gated program-wide by `option readonly`
  (`readonlypropagate`, default off — turning it on would fold every `.rodata`
  read in the program, a far larger change than this one). The narrow warrant is
  `PT_GNU_RELRO`: the linker's own statement that the segment is `mprotect`ed
  read-only once startup relocation finishes. So the written slots that RELRO
  covers are reported twice — through `getReadonly` (which paints
  `Varnode::readonly` as for any read-only section) and separately as
  `ObjectLoadImage::dynreloc_const_ranges`, carried to
  `Architecture::dynreloc_const` and into every per-function handle, where
  `ActionVarnodeProps` folds a read-only varnode inside one of those ranges even
  with global propagation off (§3.4). The halves are useless apart: relocating
  without the constancy leaves the load unfolded, and declaring constancy without
  relocating would fold the call target to zero. Slots outside RELRO — a
  `RELATIVE` pointer in ordinary `.data` — are still filled in, because that IS
  the value at process start, but are never declared constant, because the
  program may legitimately overwrite them.

  A MIPS dynamic image relocates its primary GOT with no relocation records at
  all (glibc's `elf_machine_got_rel`), so the walk above never reaches it. Its
  first `DT_MIPS_LOCAL_GOTNO` entries are local: page or full link-time
  addresses, to which the run-time loader adds the load bias. Entry 0 (the lazy
  resolver) and entry 1 when its top bit is set (the GNU module pointer) are
  written at run time. The global entries that follow map one to one onto
  `.dynsym` from `DT_MIPS_GOTSYM` to `DT_MIPS_SYMTABNO`, and for a symbol the
  image defines the run-time loader stores the address its lookup binds the
  name to, which the linker already wrote as the symbol's value. At kuna's zero
  bias each of those slots holds its run-time value, and only the run-time
  loader ever writes one, so
  `decompiler/crates/kuna-analysis/src/loader/kuna_mipsgot.rs (const_ranges)`
  reports every local entry after the reserved ones, and every defined symbol's
  global entry whose contents are that symbol's value, as constant beside the
  import-stub slots above (`ElfFormat::const_ranges`; MIPS folds read-only
  loads). `lw $25,%call16(add64)($gp); jalr $25` to a function of the same image
  becomes a call to `add64`, a `%got` page load plus `%lo` names the static or
  global it addresses, and a PIC jump table's base folds, so its switch is
  recovered. A `jr $25` tail call through such a slot is a one-destination
  table, which `tailcalljump` (§2.2) takes as a call or copies in. A
  default-visibility definition in a shared object can be interposed by another
  object's definition of the same name; the fold names the symbol the access
  binds by and gives it the body this image carries, the choice this pass makes
  for a `GLOB_DAT` slot of a defined symbol. Undefined, common, absolute, TLS
  and `STT_GNU_IFUNC` symbols are skipped, as is a multi-GOT image's secondary
  GOT, which `R_MIPS_REL32` records relocate. Every slot is read from the
  allocated section that holds `DT_PLTGOT`, so a count that claims more entries
  than that section holds stops at its end. `dynrelocs off` leaves every such
  slot variable.

  This is a different path from `relocobjects`/`relocrebase` above, which own the
  *pre-link* `ET_REL` object; a relocatable object's relocations are applied by
  the layout pass and this walk does not run for it.

  A Mach-O image's dynamic relocations are its `LC_DYLD_CHAINED_FIXUPS` chains,
  and there the on-disk word is worse than zero: it is not a value at all. Each
  pointer slot holds a packed chain entry, the target in its low bits and the
  hop to the next slot of the page in its high bits, and in Apple `ld64`'s
  `DYLD_CHAINED_PTR_64_OFFSET` layout the target is an offset from the image
  base. GH #1333's slot for a pointer to `audit_target` at `0x100000410` reads
  `10 04 00 00 00 00 00 00`, and a slot that is not the last on its chain carries
  `next` bits above the target (`0x0010000100000440` for a pointer to
  `0x100000440`). `kuna_dynrelocs.rs (macho_chained)` takes the chains from
  `chained.rs (resolve_chained_fixups)` and writes each rebase's resolved target
  and a zero for each bind, the word every other format's loader leaves in an
  import slot. A bind names an import, whose address is in another image, so
  nothing better is knowable. No Mach-O slot is reported constant: the read-only
  `__DATA_CONST` segment is the RELRO analog, but no Mach-O section is read-only
  to the engine today, so there is nothing for the warrant to narrow. A classic
  image (`LC_DYLD_INFO` rebase and bind opcodes) needs no write: its rebased words
  are already the unslid pointers, and its bound slots are already zero or a
  stub-helper address. `dynrelocs off` leaves the chain words as the linker wrote
  them.

  A Mach-O image's dynamic relocations are its `LC_DYLD_CHAINED_FIXUPS` chains,
  and there the on-disk word is worse than zero: it is not a value at all. Each
  pointer slot holds a packed chain entry, the target in its low bits and the
  hop to the next slot of the page in its high bits, and in Apple `ld64`'s
  `DYLD_CHAINED_PTR_64_OFFSET` layout the target is an offset from the image
  base. GH #1333's slot for a pointer to `audit_target` at `0x100000410` reads
  `10 04 00 00 00 00 00 00`, and a slot that is not the last on its chain carries
  `next` bits above the target (`0x0010000100000440` for a pointer to
  `0x100000440`). `kuna_dynrelocs.rs (macho_chained)` takes the chains from
  `chained.rs (resolve_chained_fixups)` and writes each rebase's resolved target
  and a zero for each bind, the word every other format's loader leaves in an
  import slot. A bind names an import, whose address is in another image, so
  nothing better is knowable. No Mach-O slot is reported constant: the read-only
  `__DATA_CONST` segment is the RELRO analog, but no Mach-O section is read-only
  to the engine today, so there is nothing for the warrant to narrow. A classic
  image (`LC_DYLD_INFO` rebase and bind opcodes) needs no write: its rebased words
  are already the unslid pointers, and its bound slots are already zero or a
  stub-helper address. `dynrelocs off` leaves the chain words as the linker wrote
  them.
- **Data-held pointers** (kuna,
  `decompiler/crates/kuna-analysis/src/loader/kuna_dataptrs.rs (data_pointers)`):
  the read-only twin of the two writers above, for `kuna xrefs`. A word in data
  that holds `&audit_target` is a reference no instruction makes, so the
  instruction walk never reports it, and calling it a call edge would be wrong.
  But a rebased image lists every such word, because its loader must fix each
  one up: a chained-fixup Mach-O threads them on its chains (the rebase carries
  its target), a classic Mach-O lists them in its `LC_DYLD_INFO` rebase opcodes
  (interpreted here; the slot already holds the unslid target), a
  position-independent ELF carries a dynamic relocation for each, and a PE lists
  them in `.reloc`. The ELF list is read here, not through `dynrelocs` (whose
  writes are an option of the loaded image): a `RELATIVE` word holds `B + A`, and
  an absolute word, `GLOB_DAT` or `JUMP_SLOT` against a symbol the image defines
  holds `S + A`. The absolute kind is how a shared object stores its own exported
  functions, which are preemptible (`R_X86_64_64 audit_target` for the first entry
  of a callback table). The list keeps
  each word whose target is in an allocated section, and says which metadata it
  came from. An image that lists none (a non-PIE ELF, whose own pointers carry no
  relocation, a PE without base relocations, a relocatable object) reports
  coverage `none`: its pointers are plain words no metadata tells from integers,
  and guessing would make an empty answer mean two things. A bound slot is not
  listed, since it holds an address of another image. `kuna xrefs` reports these
  as separate `pointer` rows with that coverage, never merged into the
  instruction rows or the call graph (`docs/cli.md`). On x86 an instruction can
  embed an absolute address, so a 32-bit PE's `.reloc` also lists every
  `push offset f` and `jmp [slot]` operand in `.text`; a word that lies inside a
  decoded instruction referencing the same address (the instruction's bytes, as
  its own decode measures them, cover the word) is that instruction's row and is
  left out (`xrefs.rs (data_rows)`). A word just past the instruction, such as a
  pointer table placed in `.text` after a `mov eax, offset f`, stays a pointer,
  and so does one inside an instruction the walk never decoded or whose reference
  it did not record, so dropping a row never leaves the word unanswered.
- **Fixup sites** (kuna, GH #1379,
  `decompiler/crates/kuna-analysis/src/loader/kuna_dynrelocs.rs (fixup_sites)`):
  the slots whose loaded bytes the two writers above may have rewritten, for a
  reader of the load image that must say which of its bytes are the file's. It
  lists every slot of the metadata `resolve` walks, the ones it leaves alone
  included: each chained-fixup rebase (with its target) and bind (with the
  import it names and its addend), and each dynamic relocation of a linked ELF.
  It also lists the packed `SHT_RELR` relocations `resolve` does not read
  (`relr_sites`, on any machine): each is a rebase whose target is the word its
  slot already holds, so there is nothing to write. A `RELATIVE` relocation is a
  rebase whose target is `B + A`; a `GLOB_DAT` or `JUMP_SLOT` one is a bind,
  valued `S + A` where the image defines the symbol and unvalued for an import;
  any other kind (`COPY`, `IRELATIVE`, an absolute word, TLS, and every
  relocation of a machine without the triple) is listed unvalued, because the
  loader rewrites the slot and kuna does not. Both callers share one
  per-relocation classifier (`ElfTable::classify`), and `resolve` writes exactly
  the valued rebases and binds, as before. The list is read whatever the
  `dynrelocs` gate says, so a reader compares the loaded bytes with the file's
  to learn what was applied. Any other image lists none, under coverage `none`.
- **In-code literal pools** (kuna, `litpoolconst`, default-on, DIV-136,
  `decompiler/crates/kuna-decomp/src/p1_partition/kuna_litpoolconst.rs`): the
  third user of the same "constant by construction, not by policy" exception, and
  the one that needs no loader pass at all — only the section table the loader
  already reports.

  An ARM immediate too wide for the instruction encoding is not in the
  instruction: the compiler parks it in a **literal pool** in `.text` and loads it
  PC-relatively, so the value a function returns can be a word a few bytes past
  its own last instruction. `getReadonly` already covers that word — `.text` is
  `SHF_ALLOC` without `SHF_WRITE`, so every varnode reading it carries
  `Varnode::readonly` — but folding it is gated by the program-wide `option
  readonly`, which is off. The default C therefore said `v3 = dat_8458;` where
  `kuna disassemble` printed `0x8458 39050000 .word 0x00000539` in the same
  listing: the number the program returns was nowhere in the output, and reading
  it meant inspecting the pool by hand.

  `code_const_ranges` takes the `(vma, size, flags)` section snapshot and keeps
  the rows that are allocated, executable, non-writable and file-backed
  (`CODE|READONLY`, neither `UNALLOC` nor `NOLOAD`), falling back to the `PF_X`
  load segments when no section qualifies — the sectionless-ELF case. The merged
  ranges are carried on `Architecture::litpool_const`, and `ActionVarnodeProps`
  folds a read-only varnode that lies **entirely** inside one even with global
  propagation off (§3.4). Entirely, not merely starting there: a word straddling
  the end of `.text` is half instruction stream and half something else, and
  neither half is evidence about the other.

  The warrant is the mapping itself. Executable non-writable memory is mapped
  `r-x`, so a store to it faults and the image's copy of those bytes *is* the
  run-time value — the same standard `PT_GNU_RELRO` supplies for the slots above.
  What it deliberately does not cover is a non-writable *data* section —
  `.rodata`, `.data.rel.ro` — which stays behind `option readonly` unless the
  image maps it executable as well, as a firmware image with one RX region does.
  The warrant is the permission, not the section name. That is the direction that
  matters on a corpus of packers and protectors: a data section's flags are least
  trustworthy exactly where an image rewrites its own data, and a program that
  patches itself has to make the page writable first. An image whose
  loader reports neither sections nor segments — the XML `<binaryimage>` corpus,
  the raw-bytes loader — contributes no ranges, so the option is structurally
  inert for the datatest oracle and the whole feature is a no-op there.

  One property outranks the mapping warrant: an **external reference** is a slot
  the loader resolves, not a constant stored by the program. A PE is allowed to
  place its Import Address Table inside the same RX section as its code and import
  directory. Such a slot contains a hint/name RVA in the file, but the Windows
  loader overwrites it with the imported function address before execution.
  `ActionVarnodeProps` therefore never fills an `externref` Varnode from image
  bytes, under either `litpoolconst` or program-wide `readonly`; subtracting PE
  ranges here would wrongly couple this general invariant to one loader and would
  make `peimportcall off` lose its raw behavior.
- **i386-PIE stubs** (angr, `i386_pie_plt`, default-on, env-bridged): a PIE i386
  PLT entry is GOT-relative (`jmp *disp(%ebx)`, bytes `FF A3 <disp32>`), so naming
  it needs the GOT base `%ebx` holds at run time; `elf_plt.rs (i386_got_base)`
  derives it once and threads it into the i386 decoder. Off (or non-PIC), only the
  absolute `FF 25` form decodes, as upstream. Without this a 32-bit PIE's `exit`
  stays `sub_<addr>` and is never marked no-return — the spurious
  `do {} while(true)` symptom.
- **PE IAT** (`decompiler/crates/kuna-analysis/src/loader/pe_iat.rs`, the
  `PeLoader.processImports` analog): PE exports enter the function-symbol
  stream only when their addresses lie in sections classified as code by the
  loader. A data export keeps only a lookup name (§1.2), so an explicit array
  or other object declaration can claim its address.
  The import path walks each import descriptor's INT (names) and
  IAT (slots) in lockstep — the i-th name belongs to the slot at
  `image_base + first_thunk_rva + i*ptr` — naming the slot (the GOT analog, folded
  through the read-only `.idata` page) and additionally decoding the MinGW `FF 25`
  thunk veneers so a direct `call thunk` also resolves. An import-by-ordinal has
  no name in the INT. (kuna) `peordinal` (default-on, env-bridged,
  `decompiler/crates/kuna-analysis/src/loader/kuna_peordinal.rs (ordinal_name)`)
  names it from a built-in export table when the DLL is `OLEAUT32`, `WS2_32`,
  `WSOCK32` or `MSVBVM60`, whose ordinals are fixed by their `.def` files and which
  toolchains routinely import by ordinal (`OLEAUT32` #2 is `SysAllocString`, #6
  `SysFreeString`; `WS2_32` #23 is `socket`, #115 `WSAStartup`). Each table is the
  consensus of independent export listings: an ordinal is admitted only when every
  listing that has it agrees on the name. `WS2_32` is limited to the WinSock 1.1
  ordinals (1-23, 51-57, 101-116, 151, 500), the only ones stable across Windows
  releases, and `WSOCK32` has its own table because it swaps `inet_addr`,
  `inet_ntoa` and `ioctlsocket` relative to `WS2_32`. Any other ordinal, and every
  ordinal of any other DLL, synthesizes `<DLL>_Ordinal_<n>`, which is also what
  `option peordinal off` restores. The resolved name is the import's name
  everywhere downstream (slot and thunk symbols, `kuna functions`, `kuna xrefs`),
  so `win32sigs` seeds its prototype when its table carries one.
  (kuna) `rexthunk` (default-on, env-bridged,
  `decompiler/crates/kuna-analysis/src/loader/kuna_rexthunk.rs (is_rex_tail)`)
  keeps that thunk decode off compiler-emitted tail jumps. The decode is a byte
  scan for `FF 25 <disp32>` whose target is an IAT slot, and every PE linker
  (link.exe, lld-link, GNU ld) emits its import thunk bare, starting at the `FF`.
  MSVC, GCC and clang instead put a REX.W prefix on an indirect tail jump through
  `__imp_X` (`48 FF 25`), the epilogue form the Windows x64 unwinder recognises.
  The scan's match is then one byte into that instruction, and the slot still
  resolves, since a RIP-relative displacement counts from the end of the
  instruction both readings share. Each such tail jump therefore became an
  import-named function one byte into an instruction (35 in each of the MSVC `/Od`
  and `/O2` images of GH-468), and the function ending in that jump reported a
  size cut short at the phantom.
  On x86-64 a match whose preceding byte is `40`-`4F` is a REX tail and is
  dropped, unless one of two things makes the byte before a real thunk harmless.
  If the six bytes before the match are themselves an `FF 25` through an IAT slot,
  the byte is that neighbour's displacement high byte, as in a contiguous link.exe
  thunk table; both ends of a displacement lie in one image, so that byte can be
  `40`-`4F` only in an image spanning more than 1 GiB, and the look-back handles
  that layout directly. Otherwise the match is kept when the image references its
  `FF` byte
  (`decompiler/crates/kuna-analysis/src/loader/kuna_rexthunk.rs (referenced)`): a
  direct `call`, `jmp` or `jcc` rel32 or a RIP-relative `lea` in an executable
  section, the address as an eight-byte little-endian value anywhere in a section
  other than discardable data such as `.reloc` or MinGW's `.debug_*` (a relocated
  pointer, a function table, a `mov reg, imm64`, a pointer that `litpoolconst`
  folds), a `.pdata` `BeginAddress`, or an export. A real thunk can
  directly follow a function ending in `jmp qword ptr [rax+0x48]` (`48 FF 60 48`),
  and through any of those references it keeps its import name, so a call that
  reaches it keeps the name and the import's no-return fact. A thunk reached only
  in another way (a short branch, a 32-bit absolute or image-relative value, a
  computed address) loses its import name; a short jump into one still renders the
  import through the slot, as a plain call instead of a tail call. Short branches
  are not counted as references because a random `EB` or `7x` byte within 128
  bytes of a REX tail lands on it about once in 200 tails, which kept 13 of the
  corpus's tails below, and COFF has no 8-bit branch relocation, so no linker thunk
  is a short-branch target. A branch into a real REX tail at its `FF` would
  execute the bare jump, so the name is right there too. The evidence scans run
  once per image: `format::resolve_imports` is called about twenty times per load,
  so the result is remembered under a hash of the scanned bytes, the section
  addresses and the candidates, and a later call only rehashes.
  The prefix byte is not named in the tail's place: a function whose whole body is
  the tail jump is a compiler-emitted wrapper with a symbol of its own
  (`my_lconv_init` in `pe_imports.exe`, the CRT's `__acrt_FlsFree`), reached by an
  ordinary `call` and found by the call-target walk, and its body still renders the
  import through the slot. The 32-bit arm is unchanged, because there `40`-`4F` are
  the one-byte `inc`/`dec` instructions and say nothing about where the `FF 25`
  starts, and non-x86 images never run the scan. Across 944 x86-64 PEs (the RE
  dataset, Wine's MinGW-built DLLs, the other vendored fixtures, the GH-468
  testbed) the option removes 2,589 entries, every one at a REX `FF 25` byte, and
  adds or renames none. None of the 37,366 bare thunk matches in those images
  follows a `40`-`4F` byte, and no REX tail there is referenced in any of the ways
  above. Whole-binary decompiles of the affected images change no function's C;
  only the phantoms and the enclosing functions' sizes differ.
  `option rexthunk off` restores the previous inventory exactly.
- **Mach-O stubs** (`decompiler/crates/kuna-analysis/src/loader/macho_stubs.rs`,
  the `MachoProgramBuilder.processIndirectSymbols` analog): the `LC_DYSYMTAB`
  indirect-symbol table indexed by each `__stubs`/symbol-pointer section's
  `reserved1`, entry address `sec.addr + i*stride`. Calls target the stub
  *directly*, so naming the entry is sufficient and arch-independent;
  `__la_symbol_ptr`/`__got` slots are named too for `-fno-plt`-style indirect
  calls. `INDIRECT_SYMBOL_LOCAL`/`ABS` entries are skipped; the C-ABI leading `_`
  is stripped. The image's own exports (its external `nlist` entries and its
  export trie) join the stream only when they lie in a code section (§1.2,
  `data_exports`).

The import currency deliberately includes both executable linkage stubs and
pointer slots in data sections: the latter must be function symbols so indirect
calls resolve to a name and library prototype. They are not function bodies.
The complete canonical inventory retains both, while automatic whole-binary
decompilation selects only entries contained by a loader `CODE` section
(`decompiler/crates/kuna-console/src/engine.rs
(ConsoleProgram::function_entries_executable)`). Explicit decompiling selection
uses the same body distinction: a lone IAT slot is refused with its import name
and address, while a name shared by a stub and slot selects the sole body-bearing
stub. Generic lookup still resolves the slot for call binding and inventory
consumers. Loaders without section metadata keep the complete inventory.

(kuna) "In a data section" is the usual place for a slot and not a property of
one, so the section flags cannot carry that filter alone. A PE is free to put its
Import Address Table wherever it likes, and a packed image routinely puts it in
the one section it has: a round-9 crypter's first section is `0xe0000060`
(`CODE|EXECUTE|READ|WRITE`) and contains the whole import directory, so every
slot passed the `CODE` test and 50 of its 56 inventory entries decompiled to a
body dereferencing an uninitialized pointer — the pointer word read as
instructions, truncated by `funcboundflow` at the next slot. What tells a
pointer word from a function entry is not where it lives but who put the name
there, and the loader knows: each format reports the slot addresses it resolved
names at (`ObjectFormat::import_slots`, PE Import Address Table entries and typed
Mach-O lazy/non-lazy symbol-pointer entries) beside the names themselves, and the engine carries them
as `[lo, hi)` ranges (`ObjectLoadImage::import_slot_ranges` →
`ConsoleProgram::is_import_slot`). An entry inside one is excluded from the
batch set whatever the section says. Nothing else moves: the canonical
inventory, `kuna functions`, generic symbol resolution and the call naming the
slot exists for are unchanged. Decompiling `--addr`/`--functions` selection
refuses a slot before decode — on the crypter the batch goes
from 56 entries to its 6 real ones while the surviving body still renders
`ExitProcess(0)`. A caller-declared entry (`--define-function`) outranks this
test as it outranks the section-flag one, so an analyst who asserts a function
at an address the import directory claims still gets a body; that is also the
recourse if an image's import directory is a lie.

Each canonical entry also carries a byte **extent**, so the inventory answers
"how big" as well as "what is here" and a caller can order a binary's functions
by weight without decompiling any of them. kuna's model of a function is its
entry — the Listing is keyed by entry VMA and nothing in it records a body — so
the extent is reconstructed as the address-contiguous clip from the entry to
whichever comes first: the next canonical entry, or the end of the CODE section
containing the entry (`decompiler/crates/kuna-console/src/funcextent.rs`). This
is the same reconstruction the FID extent generator
(`decompiler/crates/kuna-analysis/src/analyzers/fid/extent.rs`) and the
discovered-no-return pass already apply where they need a body from an
entry-keyed model, and it reuses the entry list and the loader section table
rather than decoding anything, so the metadata-only `functions` surface stays
metadata-only.

The number is an upper bound, not the exact body: the clip runs to the neighbour,
so inter-function alignment padding is counted in, and against ELF `st_size` over
the symbolized fixture corpus it is never short. An entry in no CODE section — a
pointer slot, an undefined external — has no body to measure and reports zero,
the same value a synthesized entry carries when there is no program to measure
against. The loss is that the clip is address-contiguous rather than
flow-reachable: an outlined cold half living past the next entry is attributed to
its neighbour. Every whole-binary surface reports this one number under the one
name, including the decompiling ones; their alternative, the recovered
`Funcdata::get_size()`, is the *requested* flow bound rather than a measurement,
and a whole-binary run always requests an unbounded extent.

(kuna) The zero has that meaning only while a section table exists. An image that
publishes none — a sectionless ELF, or one whose section headers are corrupt
enough that the loader continues from the program headers — has no CODE section
anywhere, so every entry fell to the same answer and the whole binary reported
zero; size-based triage then discarded all of it, `--min-size 1` reporting a count
of none out of a total of twelve with no error to distinguish that from a binary
that really holds nothing. When the section table yields no CODE span at all, the
clip runs against the **executable load segments** instead, which the loader now
reports beside the sections
(`decompiler/crates/kuna-analysis/src/loadimage_object.rs (ObjectLoadImage::get_segments)`,
reaching the console as `ConsoleProgram::segments`); a segment's CODE bit is its
execute permission, so the same filter reads both. The container is coarser, and
the last entry of a segment therefore runs to the end of it rather than to the end
of a `.text`, but that is the same kind of answer the field already gives: an
upper bound clipped at the next entry. The fallback is whole-table, never
per-entry. An entry that misses the CODE spans an image *does* publish is the
pointer slot the zero exists for, and choosing a segment for it would hand a body
to exactly those. The analyzer tier already degrades this way for entry point
discovery, which is where the shape comes from.

Naming a pointer slot is not by itself enough to bind a call *through* it. An ELF
PLT stub and a Mach-O `__stubs` entry are code, so the call is direct and the name
resolves at flow time. A PE Import Address Table slot and a Mach-O symbol-pointer
slot are data, so `call [slot]` lifts to a `CALLIND` whose target is the contents
of a global. The only pass that resolves such a target is `ActionDeindirect`, and
its external-reference arm requires the target Varnode to carry
`Varnode::externref` — a flag Ghidra sets from an `ExternRefSymbol`
(`Scope::addExternalRef`) that kuna's port never carried. Without it a Windows API
call stays `(*dat_4112c4)(0)` and a direct Mach-O `__got` call to `objc_msgSend`
stays `(*dat_100004038)(...)`: no name, prototype, or no-return flow effect.
`decompiler/crates/kuna-analysis/src/loader/kuna_peimportcall.rs (PeImportCallPass)`
(`peimportcall`, PE/COFF/Mach-O, default-on per DIV-57 and extended by DIV-171)
closes that with the
property map rather than a second symbol: `ObjectFormat::import_slots` reports one
exact pointer-width range per PE import-descriptor entry or Mach-O
`S_LAZY_SYMBOL_POINTERS`/`S_NON_LAZY_SYMBOL_POINTERS` indirect-symbol entry, and
the commit ORs `Varnode::externref` over each, the same
`Database::setPropertyRange` the loader's read-only section ranges use. The Mach-O
walk validates the typed section and indirect-symbol entry together, excluding
stub/export addresses, LOCAL/ABS entries, other pointer-section types, and
ordinary Objective-C data such as `__objc_msgrefs`.
`Scope::queryProperties` folds the property map into every global Varnode covering
the range, so the slot read now carries `persist|externref` and `ActionDeindirect`
resolves it against the `FunctionSymbol` the IAT walk already registered at that
same slot VA — kuna's `Architecture::query_function` keys on the Varnode's own
address, where upstream indirects through `ExternRefSymbol::refaddr`, so no extra
symbol is needed. The flow half rides the same gate: `query_function` also carries
the resolved callee's no-return flag onto the prototype it hands `ActionDeindirect`
(the snapshot in
`decompiler/crates/kuna-decomp/src/p0_knowledge/database.rs (Database::build_global_query)`
dropped it, where upstream returns the callee's live `Funcdata`), which is what makes
the deindirect schedule the restart whose re-flow plants the artificial halt. The
extra upstream Win32 no-return-name list remains on the PE/COFF arm only. Off, PE
and Mach-O import-slot calls render byte for byte as before; other formats are
unaffected either way.
The `externref` mark also protects the slot until that resolution: P3 read-only
folding cannot replace it with an on-disk thunk/name RVA, even if a hostile or
single-section PE mapped the IAT executable and non-writable.

Two arch-marker passes paint **decode context** rather than names, because a wrong
decode mode is unrecoverable downstream. `decompiler/crates/kuna-analysis/src/loader/arm_markers.rs
(ArmMarkerPass)` (`arm_markers`) ports ARM's `ARM_ElfExtension`/`ArmSymbolAnalyzer`:
`$t`/`$a` mapping symbols and the STT_FUNC odd-address convention become `TMode`
paints, applied to the engine's `ContextDatabase` at commit, before any decode.
(kuna) Those are point paints: each fills up to the next address where the mode was
set, and so does the `TMode=1` a `blx` commits for its target. In an image with
function symbols but no mapping symbols nothing set the mode again at an A32
function placed after a Thumb one, so the Thumb mode reached it. The `armfuncmode`
pass (`decompiler/crates/kuna-analysis/src/loader/kuna_armfuncmode.rs (arm_func_mode_paints)`,
default on) sets `TMode=0` over each defined function symbol whose value is even, the
AAELF32 mark of an A32 function, when it lies in an executable section of a linked
ARM ELF after an odd function symbol, and sets `TMode=1` again where its extent ends.
The extent is the symbol's size cut at the next function symbol and at the end of the
section: an exported Thumb function whose symbol the linker moved onto its A32
interworking stub keeps the function's size, and must paint only the stub. The extent
then grows over every direct A32 `b`/`bl` target it reaches before the next function
symbol, up to the first return, unconditional branch, call to a function the
no-return list names (the image's own definition or its PLT stub), or literal-pool word
on that target's linear run, and over what that run branches to in turn: an A32 branch
target is A32 by its encoding, so an unsymbolized A32 static helper an A32 export calls
keeps A32. A run that reaches the next function symbol or the section end without such
a stop says nothing about where its code ends and adds nothing, and words a PC-relative
`ldr` in the scanned code loads are data, never read as branches. That data test is a
known limit: a pool word reached through `adr` + `ldr`, `vldr` or `ldrd` is still read
as a possible `b`, and a Thumb-2 `pop.w {..., pc}` at an address 2 mod 4 reads as an A32
`pop {..., pc}` stop, so a run over such bytes can still grow over a following
unsymbolized Thumb routine. Past the
extent the Thumb mode the symbol paint gave resumes, so a stripped library's
unsymbolized Thumb routines after an A32 one keep their mode. A symbol of size 0
states no extent and is skipped, and an image whose function symbols are all even
keeps the language default it already had, together with whatever modes its calls
commit. The pass paints nothing for an image with `$a`/`$t` mapping symbols, a
relocatable object, an image whose build attributes rule out A32 (M profile or
`Tag_ARM_ISA_use` 0), a Cortex-M image with a vector table, or an address that also
carries an odd function symbol. Its paints are committed under its own gate and fed
to the Listing's context painter as well, and the Listing keeps the A32 extents: the
AIF gap walk rejects a Thumb walk (a 2-aligned candidate, or one whose first
instruction is 2 bytes) whose flow leaves the gap for a decoded instruction inside one
of them, since a Thumb branch cannot reach A32 code without an exchange. Without that
check a Thumb walk over the zero padding before an A32 routine was accepted once its
branches landed on the A32 instruction starts the extent now yields; an explicit `--isa` states the whole
image's mode and turns the pass off, and so does the option, which restores the leak.
`decompiler/crates/kuna-analysis/src/loader/mips_markers.rs` carries the MIPS pair:
`MipsIsaModePass` (`mips_isa`) paints `ISA_MODE` at MIPS16e/microMIPS entries
(LSB-set or `st_other` STO-marked), and `MipsMarkerPass` (`mips_gp`) is a register
**value** seed, not a context bit — `t9 = func_entry` per function (the PIC
`jalr t9` convention, Ghidra's `MipsAddressAnalyzer`), committed as a tracked-range
so the S3 constant-base action emits `COPY #entry -> t9` at the entry block and the
prologue's `addu gp,gp,t9` folds to a real `$gp`. Both are doubly guarded: the pass
gates on its architecture, and the commit swallows an unregistered-variable /
unknown-register error, so a paint on the wrong language is a faithful no-op.

(kuna) **A PowerPC64 ELFv1 function symbol names a descriptor, not code**
(`decompiler/crates/kuna-analysis/src/loader/elfv1.rs (Descriptors::read)`, the
`.opd` half of Ghidra's `PowerPC64_ElfExtension`). Under ABI v1 a function symbol
and the image entry both point at a 24-byte `.opd` record — code address, TOC base,
environment — so selecting a function by name used to decode the record as
instructions. For a linked (`ET_EXEC`/`ET_DYN`) PowerPC64 ELF whose `e_flags` ABI
field is 0 or 1 and whose `.opd` is file-backed, the image entry and every
8-aligned function symbol defined in `.opd` are read as descriptors. A descriptor
is used only when its code word is 4-aligned and lands on file-backed bytes of an
`SHF_ALLOC|SHF_EXECINSTR` section; the loader's symbol stream and image entry then
carry that code address, and every name at it is kept as an alias, so `answer`,
a `.answer` code symbol and a second descriptor for the same code select one
function. A descriptor word covered by a dynamic relocation takes the relocation's
value instead of the section bytes: an 8-byte RELA `R_PPC64_RELATIVE` resolves to
its addend (a linked image is mapped at zero bias), and any other type, a partial
overlap, or a second write to the word leaves it unresolved. An unresolved or
implausible code word leaves the symbol at its descriptor address, as before, and
ELFv2, 32-bit PowerPC, relocatable objects and every other machine read no
descriptors at all. Explicit numeric selections (`--addr`) stay literal. The TOC
word is the function's `r2` on entry, so the bootstrap records it per code entry as
a loader register seed (§0.5's per-function snapshot) that the S3 constant-base
action emits as `COPY #toc -> r2`, and a TOC-relative load resolves to the global
it names. A code entry whose descriptors disagree about the TOC, or where any of
them has an unresolved TOC word, gets no seed.

ELFv1 import markup recognizes complete descriptor-call stubs that save the
caller's TOC at SP+40, load the entry and TOC, and transfer through CTR.
A stub is named only when its decoded displacement and a validated function TOC
identify the same `R_PPC64_JMP_SLOT` import for every possible TOC. Only explicit
zero-addend relocations qualify: a nonzero addend selects the descriptor at
symbol address plus addend, whose identity cannot be inferred from the symbol's
name. Implicit addends are also unresolved here. Conflicting names and possible
TOCs without a matching import relocation are declined: an
unmatched TOC can select a returning local descriptor instead. Import matching
scans every 8-aligned word in `.opd` for a resolved, plausible code entry, so
symbol-less descriptors still contribute possible TOCs after stripping. It reads
the following TOC word without requiring an environment word; an unavailable
TOC is ambiguous. Unresolved potential code words also decline all these names
because they cannot exclude a descriptor. This conservative scan supplies only
import ambiguity, while symbol normalization and register seeding use the
validated image-entry and symbol-derived descriptors described above. Possible
TOCs include aliases that disagree and cannot seed their shared code entry.
This resolver declines all descriptor-stub names if any validated descriptor's
TOC remains unresolved: without a caller-specific TOC, the unknown value could
select a different import and invalidate a no-return fact.
Both full environment-word and GNU lazy-resolution forms are supported. A lazy
stub's zero-TOC branch must reach the matching import's resolver entry: its
relocation index, branch to the common glink code, and the common code's load of
`DT_PLTGOT` are validated against `DT_PPC64_GLINK` and `DT_JMPREL`. Returning
fallbacks, entries for another slot, and unknown resolver code or metadata are
declined. Currently only the two-instruction resolver entries with indices below
32768 qualify. The full environment-word form needs no lazy resolver.
The existing known-no-return pass consumes these names, so a guard failure
import no longer introduces false fall-through or consumes the normal return.
ELFv2 decoding and ordinary returning imports retain their existing behavior.

The file front-ends also accept `--isa auto|arm|thumb`. An explicit ARM/Thumb
choice paints `TMode` across mapped CODE sections before decoding. If an ELF has
no section headers, it uses executable `PT_LOAD` memory extents, including their
zero-filled tails; non-executable segments and gaps remain unpainted. `auto` uses
the marker facts above, Cortex-M evidence, and Thumb-specific PE/COFF machine
values only when the resolved SLEIGH decoder is ARM32. Inferred container hints
therefore preserve an explicit non-ARM decoder selection; explicit `arm` or
`thumb` still fails for a non-ARM decoder. Explicit input state is retained on
the architecture so later Listing
and xref painters cannot replace it with ELF markers or Cortex-M metadata.
The analysis commit applies input paints after all other passes' context facts.
Before painting, the console checks whether the loaded ARM language exposes `TMode`.
Fixed-A32 languages without that variable accept explicit `arm` without any paint;
`thumb` fails with an unsupported-mode diagnostic even if there are no code ranges.
The generic PE ARM machine (`0x01c0`) is deliberately not a whole-image hint in
either direction, because such an image may mix ARM and Thumb; the THUMB
(`0x01c2`) and ARMNT (`0x01c4`) machines are Thumb-only by definition, so those
two do paint the image, with no flag and no option, where an unflagged run
previously decoded their bytes as A32. Without mode evidence, decoding uses the
selected language's default context. `--isa` is refused rather than dropped where
it could not reach a decode: `strings --no-xrefs` walks no references, so pairing
the two is a usage error.

## 1.4 Metadata analyzers

The always-on core, in pass order (`passes.rs (passes_for)`):

- **Strings** (`strings`, the `StringsAnalyzer` port,
  `decompiler/crates/kuna-analysis/src/analyzers/strings/mod.rs`): scan allocated,
  initialized sections for runs of printable ASCII (plus CR/LF/TAB) ended by a NUL,
  minimum visible length **4**; each hit commits a *typelocked* `char[len+1]` data
  symbol (`s_<addr>`) — the typelock is what carries the array type through type
  propagation, and the printer renders the literal, not the name. LOSS: Ghidra
  additionally scores candidates with a trigram model (`StringModel.sng`, not
  vendored), so kuna over-accepts random printable NUL-terminated runs; real
  literals are unaffected. Kuna uses four rather than Ghidra's default five so
  command and mode literals such as `quit`, `show`, `bind`, `fork`, and `dup2`
  do not remain raw addresses in stripped binaries. (kuna) A run that starts on
  a pointer slot is an entry of a pointer table, not text, and is not planted
  (`decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_ptrslot.rs (PointerSlots)`).
  An image rebased at load time lists every pointer it holds, so on a
  position-independent ELF (its dynamic relocations) or a PE with base
  relocations the slot is exactly a relocated, pointer-aligned address. A non-PIE
  ELF or a PE without base relocations lists none, and there the slot is a
  pointer-aligned address whose pointer-sized value, read in the image's byte
  order, lies inside an allocated section. On an i386 image linked at
  `0x21414140` a function-pointer table reads `@AA!KAA!VAA!` up to its NULL
  entry, and planting it made the printer index and pass that literal where the
  code uses the table. Without relocations a genuine string can be refused only
  when its first pointer-sized bytes, NUL and padding included, spell an address
  of the image; it then prints as that address. A relocatable object has no
  image addresses yet, so nothing is refused there.
- **Rust `&str` records** (`fatstrrecords`, kuna, rustc-detected images only,
  `decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_strrecords.rs
  (StrRecordPass)`, committed under the `fatstr` option's mode gate): Rust
  literals carry their length in the fat pointer, not a terminator, and rustc
  packs them back to back — so the NUL scan above GLUES adjacent Rust literals
  into one wrong row. The static `(ptr, len)` records that state every
  literal's length (a PIE's `R_*_RELATIVE` slots in `.data.rel.ro` with the
  length in the unrelocated companion word; absolute word pairs in read-only
  data on a non-PIE) are re-read as length-BOUNDED facts — exact extents, no
  terminator — and the commit plants them BEFORE the NUL stream, so the
  occupied-address guard retires the glued row and the symbol at each literal
  spans exactly the literal. Guards: target in read-only data, `1..=4096`
  bytes, valid UTF-8 at least 90% printable-or-whitespace, and the direct
  (relocation-less) arm additionally keeps the NUL scan's minimum of four.
  The engine half of the option is chapter [05](05-types.md)'s `RuleFatStr`.
- **Wide strings** (`widestrings`, the `StringsAnalyzer` `allCharWidths` arm,
  `decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_widestrings.rs
  (scan_wide_strings)`): the same matcher over 2-byte little-endian code units —
  the same printable-ASCII recognizer applied to each unit's low byte, the same
  require-NUL-end rule, the same minimum length of 5, over the same section set,
  reading units on even addresses only. Each hit commits a typelocked
  `wchar2[len/2]` instead of a `char[N]`, and the character type's size 2 is what
  makes the printer emit the `L` prefix and read the bytes two at a time. Without
  it a UTF-16LE literal is read at 1-byte width as a ONE-CHARACTER string — the
  NUL behind the first unit closes the run — so a wide Windows-API argument
  rendered as its own first character (`LoadLibraryW("n")` where the image says
  `L"ntdll.dll"`). The two widths cannot claim the same run: a wide unit demands a
  zero high byte, so five consecutive 1-byte-charset bytes never occur inside a
  wide run. They are ordered anyway, and the order is the fix rather than a
  detail — the wide facts commit FIRST, because `operand_refs` puts facts into the
  same stream whose run test accepts a *single* visible character, and at a wide
  literal that test reads the first unit plus its high-byte NUL as a complete
  `char[2]`. Whichever fact is planted first wins the commit's occupied guard, so
  the width that read the whole literal has to go first. (`operand_refs` now also
  declines a run that opens an array of 2-byte character codes nothing points
  into, described with that pass below, so the order decides only the shorter
  runs it still reads.) Scope: UTF-16**LE** whose
  units are all in the 1-byte charset (the Windows-API case); a big-endian or
  non-Latin wide literal is not recovered. Default **on**; `off` leaves the markup
  exactly the 1-byte pass's.
- **4-byte wide strings** (`widestrings32`,
  `decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_widestrings32.rs
  (wide_string32_facts)`): the same matcher over 4-byte code units, the width of
  a `wchar_t` literal on ELF and Mach-O targets and of a `char32_t` one. Read at
  1 or 2 bytes `L"hellow"` (`68 00 00 00 65 00 00 00 ..`) is a one-character
  string, so nothing marks it up and a call that hands it to the image's own
  function printed its address (`lenw(&dat_2004)`), or before `operand_refs`
  learned to decline it, its first character (`lenw((int *)"h")`). Units are read
  in the image's byte order on 4-aligned addresses of read-only data (allocated,
  not writable, not executable, not one of the loader's tables); each holds a
  value of the 1-byte charset and a zero unit closes the run. Each planted run
  commits a typelocked `wchar4[len/4]`, ahead of the 2- and 1-byte facts for the
  same reason the 2-byte width goes before the 1-byte one, and the existing
  printer path renders `L"hellow"`. Unlike the narrower widths, the bytes alone
  do not plant: an `int` table of character codes is byte for byte a wide
  literal (`{72, 101, 108, 108, 111, 0}` is `L"Hello"`, a table of the weeks in
  each year reads `L"4544.."`), `int` tables are common, and a table that runs
  on past its zero (`{97, 98, 99, 100, 101, 0, 7, 8}`, a switch lookup table of
  character codes with a zero case, `h e l p z 0 q`) would print as a literal
  that code reading the table reads past. A run is planted only when no sized
  data object of the symbol tables overlaps it -- a declared array keeps
  printing as its name, whatever its element type; an assembler-local `.L`
  label of exactly the run's extent, which a relocatable object keeps for its
  own literals, does not count, while one such as `.Lswitch.table.f` does --
  and either it lies in a mergeable string section of 4-byte entries (a
  relocatable object's `.rodata.str4.4`, where every NUL-terminated run is a
  literal), or all of these hold. It has at least five units, at least three
  of them distinct. Something points at its start: an operand target of the
  `operand_refs` scan, a pointer-aligned slot of a data section, or a dynamic
  relocation; a symbol table alone backs nothing, since a linked image keeps no
  symbol for clang's switch tables. What follows its terminator
  (`kuna_widestrings32.rs (follower)`) is the next literal or object, not the
  table's next element: the section's end, or the first nonzero unit after at
  most 64 bytes of zeros, fewer than that unit's address alignment asks for,
  that either code indexes or a symbol starts at, with a unit that is no
  character (at or above U+110000) or a string there, or that an operand, a
  data slot or an entry of a table of relative offsets (clang's `reltable`)
  points at, with a string there. A string is a zero-terminated run of
  characters (printable ASCII, tab, CR, LF, or U+00A0 and above outside the
  surrogates) with at least one printable ASCII unit, or a narrow string of
  four characters or more; fewer are the bytes of a wide unit or of a pointer
  such as `0x402039` (`"9 @"`). In an image a literal is followed by the next
  literal or object, while a table goes on with its next element, a code or a
  field that opens no string even where the code names it (`sum(&tbl[6], 2)`,
  the count, a negative delta or a string pointer after a struct's
  `int codes[6]`); a literal followed by a jump table the decode does not see
  indexed (gnulib's `vasnprintf` loads the base of the one after `L"(NULL)"`
  far from its jump in some builds) is refused with them. And no code adds a
  computed index to any
  address from its start to its terminator. The index test follows the
  same linear decode
  (`decompiler/crates/kuna-analysis/src/analyzers/operand_refs/mod.rs
  (TableUses)`): an address an instruction puts in a register stays held for
  the next 31 instructions, across calls and conditional branches (both fall
  through with the register intact), until a jump, a return or an overwrite (a
  tail call's argument is not the next function's table), and an add of a value
  that is not a constant to it, or of a register to an address constant in one
  instruction (`lea rcx,t` then `mov eax,[rcx+rax*4]`, `lea rdi,[rax+t]`), marks
  it a table; the run that holds it is refused, a literal indexed in place
  (`L"0123456789abcdef"[c]`) included, since the printer's index bound does not
  cover a literal another pass planted. A literal laid out right after another
  object's last printable unit (clang's switch table ending in `'q'` before
  `L"hellow"`) is the tail of a longer run nothing points at; an operand target
  at one of its units starts the run there instead, under the same tests. An
  entry of a table of relative offsets at an operand target backs a run's
  start the way a pointer slot does. An ARM
  literal pool slot backs nothing, since the scan cannot see code index the
  address it loads, and an address built in two instructions (AArch64
  `adrp`/`add`, MIPS `lui`/`addiu`) is no operand target, so a linked image of
  those targets plants only what a data slot holds (a pointer table's entries);
  their relocatable objects plant from `.rodata.str4.4`. A relocatable object is
  read through the laid-out view the loader builds, never its raw sections,
  which all sit at address 0. What remains are the anonymous tables of a
  stripped image whose bytes are those of literals: one that ends at its zero
  prints as the literal its elements spell, the same values; the rows of a 2-D
  table of codes, or adjacent code tables, each ending in a zero, and a code
  table followed by a string (a struct's `char name[8]` after its
  `int codes[6]`, or `{.., 101, 0, 233, 120, 0}`) print as one literal each,
  so code reading across them reads past a literal; and a
  fixed-size code table whose codes are followed by zero padding up to its size
  (`static const int t[8] = {97, 98, 99, 100, 101}`, common C) prints as the
  shorter literal, so code reading past its first zero reads zeros in the
  binary and past the literal in the printed C, other values. A
  run that a tail-merged suffix shares (`L"bind"` inside `L"xbind"`) is planted
  whole from its first unit, and the printer reads the suffix's literal at its
  own address (`lenw(L"bind")`), except where the element-pointer rule refuses
  literals for the callee's parameter, which then prints the address
  (`lenw((wchar_t *)0x2024)`). PE and COFF images, whose `wchar_t` is 2 bytes,
  are not scanned. The scan reads the facts at the deferred `operand_refs`
  commit, where that pass's operand targets and table uses are known; with
  `operand_refs` off,
  `decompiler/crates/kuna-analysis/src/passes.rs (run_wide_strings32)` runs the
  same decode for them without planting that pass's own facts. Scope: units in
  the 1-byte charset; a non-Latin literal is not recovered. Default **off**,
  carried by the aggressive preset; `off` drops the `wchar4` facts at the commit.
(kuna) The **reporting** face of those two passes is a separate, read-only query
(`decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_stringinv.rs
(inventory)`, behind `kuna strings`), and it runs the same matcher over the same
address set — but not under the same ending rule. `requireNullEnd` is a property
of what the pass *plants*: only a NUL-ended run describes a `char[N]`. Asked as a
question about the image it loses whole regions, because a length-prefixed name
table — `\x0cout.js\x06std\x12_0x8ec6b3`, where each identifier is preceded by
its own length and followed by the next one's, the shape a bundled JavaScript or
bytecode payload carries — contains no NUL at all. On the reported 977 KB Node
bundle that made `kuna strings --section .rodata --filter '_0x|out.js'` answer
zero for a region `strings -a` reads 635 names out of. So the matcher takes a
termination policy (`strings/mod.rs (scan_runs)`), the query defaults to the
relaxed one, and every reported row carries which ending it had — a run closed by
an ordinary byte, or by the end of its region, occupies exactly its visible bytes
and is not a C string. The markup passes are unaffected: they ask for
`Termination::Nul` and commit exactly the facts they always did, so no emitted C
moves. `kuna strings --termination nul` is that same view as a report.

For a relocatable object, the inventory applies the load-time option bridge before
scanning and uses the existing `relocrebase` view. Section bytes, string addresses
and the xref walk therefore share the loader's synthetic address space. The scan
keeps only regions wholly contained in that view's mapped ranges, excluding
discarded linker/debug sections. This also applies with `--no-xrefs`: skipping
reference attribution does not change a literal's address. Explicitly disabling
`relocrebase` retains the raw pre-link inventory; linked images keep their usual
addresses and query schema.

The same query takes a second reading of the **1-byte** width, for the same
reason and with the same confinement to the report
(`decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_utf8strings.rs
(scan_utf8_runs)`). The recognizer is `AsciiCharSetRecognizer`, so every byte
`>= 0x80` closes a run, and a literal whose first characters are multi-byte is
reported starting at the byte AFTER its last sequence — on the filing image the
prompt `＿φ( °-°)/ so what was the magical keycombination? ` at `0x2000` came back
as its ASCII tail at `0x200c`. What makes that more than a cosmetic truncation is
the address: `0x200c` is not an address anything in the image refers to, so the
row also arrived with `xrefs_count 0` and no owning function while
`kuna xrefs --to 0x2000` already answered one. The reference machinery had the
literal's true start all along; only the reported address was wrong, so one
change closes both halves. `scan_utf8_runs` is the same matcher with a
well-formed UTF-8 sequence admitted as one character when its scalar is not a
control — the same charset for single bytes, the same termination policy, the
same minimum, counted in characters rather than bytes. It is a *superset* of the
ASCII reading, not a rival: a continuation byte is never in the 1-byte charset,
so no accepted sequence can swallow a byte the ASCII matcher would have taken,
and an ill-formed sequence advances one byte and lets the scan continue — every
ASCII run is therefore a subrange of some UTF-8 run. Hence the query runs one
1-byte scan or the other rather than both (`--encoding utf8` and `--encoding
all`), and labels each row by what its bytes hold, so a row with no multi-byte
sequence is reported as `ascii` under either and a pure-ASCII image reads
identically. Overlong encodings, surrogates, lead bytes past `U+10FFFF` and
control scalars are declined, which is what stops a stray byte pair inside code
from joining two neighbouring runs. The markup passes are untouched: they still
scan at the ASCII and 2-byte widths only, so no `char[N]` fact and no emitted C
moves.

- **Library prototypes** (`libproto`, the `ApplyDataArchiveAnalyzer` analog,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/mod.rs (LibProtoPass)`):
  Ghidra ships parsed C headers as `.gdt` archives; kuna substitutes a built-in
  table of common libc signatures (`puts(char*)`, `printf(char*,...)`, …), parked
  on matching callees so `ActionDefaultParams` types the caller's argument
  constants — this typing, plus the read-only markup, is what turns `puts(0x400915)`
  into `puts("Username: ")`. LOSS: the built-in table is not a header archive, so
  it covers only the names it lists; every other libc callee leaves its caller's
  argument an inferred integer. The compatible name-keyed prototype stream is
  retained for ordinary symbols. For an imported table name the pass additionally
  emits the same signature at every concrete address the format resolver reports.
  This is required on PE, where the IAT slot and its `FF 25` veneer are separate
  `FunctionSymbol`s with the same name and a direct call reads the veneer's
  prototype by entry address.
  ELF relocatable objects also contribute the loader's proven external code targets,
  including undefined `STT_NOTYPE` symbols reached by call relocations. Their
  synthetic target addresses receive the same signature as ordinary imports;
  data-only relocations and undefined symbols without code relocation evidence
  or a function symbol kind do not qualify. A same-spelled
  definition still suppresses ambiguous name-only parking. The `libcsigs` and
  `libctypes` passes use this same import evidence.
  The extension adds no option of its own: it is more evidence for the same
  passes, so `libproto`, `libcsigs` and `libctypes` off together decompile a
  relocatable object exactly as before. Code imports
  the loader cannot establish, including untyped x86 `PC32` direct calls and
  `GOTPCRELX` indirect calls, remain outside this additional evidence stream.
  LOSS: typing one callee can move an untyped neighbour's argument inference
  (stale i386 `-O0` outgoing stack slots, the AArch64 `x8` result register), and
  in an i386 PIC object, whose `GOTOFF` addresses the loader leaves unresolved,
  a `char *` parameter renders such a garbage address as a string literal.
- **(kuna) libgcc DI-mode contracts** (`libgccsigs`, off by default,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libgcc.rs (LibgccSigsPass)`):
  seeds the reserved compiler-runtime name `__divdi3` on SPARC32 big-endian ELF
  under `sparc:BE:32:default:default`. Its DI-mode contract is a signed
  eight-byte quotient of two signed eight-byte operands, independent of the
  target's four-byte C `long`. The normal compiler model assigns the argument
  and return register pairs. Thus a caller storing only `%o1` stores the low
  word of the computed quotient instead of reading an unassigned local. Other
  names and targets retain their existing inference. Existing import-address
  and name-ambiguity rules apply, and DWARF or explicit prototype assertions
  retain precedence over the built-in signature. The pass's facts are computed
  at load and committed only when the option is on. It ships off because the
  locked eight-byte result still costs a caller that returns arithmetic on the
  quotient: §4's whole-pair proof keeps both return words only when each is a
  bare slice of the call result or a literal and nothing else reads the
  quotient, so `return a / b + 1;`,
  `return -(a / b);` and `return f ? a / b : c;` keep only the high word or
  return nothing, where the off output returns every word.
- **(kuna) Measured libc signatures** (`libcsigs`,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libcsigs.rs (LibcSigsPass)`):
  the second, larger half of the same table, closing most of the LOSS above. Which
  names it carries was *measured*, not guessed — a PLT call-site histogram over the
  frozen decbench C corpus plus a per-callee ranking of the cases where a rival
  decompiler recovers a perfect parameter typing and kuna does not; a name is in
  the table when it clears 100 corpus call sites or 3 such cases. A second,
  widened pass over the same corpus admits every remaining name on the same terms
  with a broader question asked of it: not "which callee would move the metric"
  but "which callee does this corpus actually import", so a name is admitted when
  it is an **undefined** `FUNC` symbol in at least three of the corpus's
  dynamically linked binaries, kuna does not already carry it, and its platform
  declaration reduces *whole* to the width-stable vocabulary. That admits the
  `*at` family (`renameat`, `mkdirat`, `fchownat`, `faccessat`, `utimensat`,
  `linkat`, `symlinkat`, `readlinkat`), the SELinux surface coreutils links
  against (`getfilecon`, `freecon`, `setfscreatecon`), the account, xattr, socket
  and pthread names, and the `_chk` and LFS spellings the fortified headers
  redirect to. It admits no name the rule does not reach: `strtoll`, `strtoull`,
  `strtoimax`, `strtoumax` and `llabs` are the widest-imported names still
  missing, all rejected for returning a type — `long long`, `intmax_t` — whose
  width is not fixed by the data model. With `float` and `double` in the
  vocabulary (4- and 8-byte IEEE on every target the tables apply to) the same
  rule admits `strtod`, `strtof`, `sqrt`, `pow`, `ceil`, `log2` and `modf`, and
  still rejects `strtold` (`long double` has no fixed width). `strtod_l` is
  added by hand: its `locale_t` is glibc's `struct __locale_struct *`, a typedef
  the reduction does not see through, and without it gnulib's `c_strtod`, a tail
  call to `strtod_l`, returned an integer beside `xstrtod`'s `strtod`, which then
  converted it by value. A float-returning name fewer than three corpus binaries import
  (`nanf`, `sqrtf`, `fabsf`) stays out, and its import stub is recovered from what
  its callers read instead (chapter 04). These rows are seeded only on x86 and AArch64
  (`decompiler/crates/kuna-decomp/src/p4_calls/kuna_typedcallabi.rs (returns_doubles_whole)`),
  whose return recovery reads a `double` whole (`xmm0`, `ST0`, `d0`), and on a
  hard-float ARM image once `armfloatreturn` applies (chapter 04). Otherwise ARM
  gets none of them. Its default model lists only `s0`..`s7` among the outputs, so on
  a hard-float image a function returning what it computed from `strtod` was
  recovered as `unsigned int`, the low half of `d0`, where it had been `void`.
  A soft-float or `-mfloat-abi=softfp` image hands a `double` around in
  `r0:r1`, and its callers hold that as a 64-bit integer: the rows made such a
  function `double`, which those callers then converted by value, where it had
  returned the right `unsigned long long`. Because `armfloatreturn` is set after
  the load, an ARM image holds these rows back
  (`decompiler/crates/kuna-analysis/src/pass.rs (arm_float_prototypes)`) with a
  second, ARM-only table of the C99 `<math.h>` functions and glibc's `sincos`
  (`kuna_libcsigs.rs (LIBM_VFP)`: `double log(double)`, `float sinf(float)`,
  `long lrint(double)`, `double ldexp(double,int)`, ...; each row checked against
  `gcc -aux-info` over glibc's `<math.h>`, `double *` slots as `void *` as in
  `modf`), and the first decompile parks them only when the option applies to
  the image. An operator-declared name
  (`seed_declared_libc_prototype`) is refused on ARM the same way. The signatures
  themselves are reduced from the platform's own C declarations (`gcc -aux-info`
  over the standard headers, GCC's builtin types for the FORTIFY `_chk` entry
  points, the `<stdio.h>` `__REDIRECT` for the `__isoc99_*` aliases), never written
  from memory, and any declaration with a slot whose width is not stable across
  ILP32/LP64 — `off_t`, `time_t`, `long long`, a `char` parameter — is **rejected
  rather than approximated**, because a wrong prototype is worse than a missing one:
  it asserts a false type where the inferred integer was merely uninformative.
  Two consequences follow from that same principle. A global by-name signature
  is applied only to a name the image **imports** and does not itself define — a
  PLT/IAT import named `error` is the platform's
  `error(int, int, const char *, …)`, but a *defined* `error` is the program's own
  function that happens to share the spelling (zlib's `minigzip` declares
  `void error(const char *)`). The base table continues to
  match imported-only and defined-only names, but uses the same collision guard.
  And the FORTIFY entry points are
  modeled as the distinct functions they are, not as aliases: `__printf_chk` takes
  a leading `int flag` before the format string, `__fprintf_chk` a `FILE *` and a
  flag, so treating either as its plain namesake would shift every argument of the
  most frequent call in the corpus. Unambiguous imports keep the historical by-name
  prototype. Independently, every provenance-confirmed import receives an
  address-keyed copy at each resolver address. Thus an IAT slot and veneer remain
  typed even when a same-spelled export suppresses the global key; the export
  itself remains untouched. Two complex-valued rows, `cexpf` and `cexp`, are
  seeded with the DWARF pass's complex pair types (below), and only where that
  layout applies to the value's width, so a call passes and returns the value
  in the target's own registers or hidden buffer.
- **(kuna) Library parameter and result names** (for `libcnames`,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libcnames.rs (library_names)`):
  every prototype the three libc tables above build carries the library's own
  names for its parameters and, where the result has one, for its return value,
  in `PrototypePieces::kuna_library_names`. They travel with exactly the
  prototypes the tables park, so the imports-only rule and the order in which
  DWARF replaces a table prototype apply to them unchanged, and they are kept
  out of `innames`: the callee's signature prints as before and no parameter
  becomes name-locked. Only the naming pass reads them, under `option libcnames`
  (chapter 06). The parameter names are the glibc 2.35 header declarations with
  the leading underscores stripped (`read (int __fd, void *__buf, size_t
  __nbytes)` gives `fd, buf, nbytes`), read from the plain headers first and the
  FORTIFY ones for the entry points only those declare; a slot the header leaves
  unnamed stays empty. `__isoc99_X`, the GCC FORTIFY builtins `__X_chk` and
  `__X_2` have no declaration of their own and take `X`'s names for the slots
  they share with it. A return name is given only where the result is one kind
  of thing whatever the arguments (`fd` for `open`/`socket`/`dup`/`mkstemp`, `n`
  for `read`/`write`/`fread`, `len` for `strlen`, `p` for an allocation or a
  pointer into a string, `fp` for an opened stream, `pid`, `dirp`, `entry`, `c`
  for a read character); `fcntl` and `ioctl`, whose result depends on the
  command, have none. 567 entries: 554 name parameters, 91 name the result.
- **(kuna) Named libc aggregate types** (`libctypes`, values `off|opaque|glibc`,
  default opaque,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libctypes.rs (LibcTypesPass)`,
  layouts in
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libctypes/glibc.rs`):
  the two tables above share one type vocabulary, and that vocabulary is
  width-stable by construction, so every aggregate pointer in them is spelled
  `void *`. `fopen` returns one, `fclose` takes one, `stat` fills one,
  `getopt_long` reads one. That is honest about the width and silent about the
  pointee — and the pointee is the one thing the table actually knows, because
  `int fclose(FILE *)` is a declaration, not an inference. Turned to `opaque`,
  this pass restates the same signatures with their aggregate slots named:
  `FILE`, `DIR`, `dirent`, `stat`, `passwd`, `group`, `tm`, `option`,
  `timespec`, `timeval`, `sigaction`, `sigset_t`, `mbstate_t`, `termios`,
  `sockaddr`, `pthread_mutex_t`. It also carries the stdio names neither shipped
  table has — `__uflow`, `fgetc`, `rewind`, `freopen`, `popen`, `pclose`,
  `getdelim`, `flockfile`, `funlockfile` — for the same reason: on a `-O2`
  coreutils reader loop the inlined `getc` refill path calls `__uflow` and
  nothing else in the body says what the stream argument is, so that one
  declaration is the whole evidence for the enclosing function's first parameter.

  A second round of names was added after the first was measured against the
  ground truth of the benchmark corpus, by asking which pointer-to-named-struct
  variables the debug twins actually hold and which libc slot each one could be
  reached from. That adds seven aggregates — `obstack`, `spwd`, `utmpx`, `utmp`,
  `re_pattern_buffer` (the struct tag `regex_t` is a typedef of),
  `lconv` and `statfs` — and sixty-six further slots: the rest of the stream
  surface (`fseeko`, `ftello`, `fread_unlocked`, `fputc_unlocked`,
  `feof_unlocked`, `fgets_unlocked`, `setbuf`, `vfprintf`, `__getdelim`), the
  record-at-a-time and reentrant halves of the three account databases
  (`getpwent`, `fgetpwent`, `putpwent`, `getpwnam_r`, … and their `group` and
  `spwd` twins), more `tm`, `timespec` and `termios` slots, the regex entry
  points and the obstack entry points. Every one of them is new to both shipped
  tables, so `libctypes off` is still the shipped behaviour exactly — and,
  unlike a retarget, each also supplies an ARITY where there was none.

  Two kinds of slot are left out because naming them makes the caller's frame
  worse. `utimensat`, `futimens`, `utimes` and `futimesat` take a two-element
  array; the vocabulary can only name one element, and a one-element pointee
  shrinks the caller's frame object to it, so the second element's stores
  detach into locals of their own (and in gzip's `lutimens` the neighbouring
  `struct stat` splits, leaving its tail read from locals nothing writes). And no
  further `sigset_t` slot is added: `sigdelset`, `sigismember`, `sigsuspend`,
  `pthread_sigmask`, `sigwait` and `sigfillset` are handed `&sa.sa_mask` of a
  `struct sigaction` local as readily as a standalone set, and a `sigset_t` at
  offset 8 splits the 152-byte object at 136, so the `sa_flags` store lands
  outside what `sigaction()` is handed. The shipped `sigemptyset`, `sigaddset`
  and `sigprocmask` slots already do this; fixing it belongs to frame merging,
  not to more slots.

  Nine decisions shape the pass.

  *The retarget is enumerated slot by slot, never applied in bulk.* The last
  `void *` of `vasprintf`, `vsnprintf`, `__vasprintf_chk`, `__vfprintf_chk`,
  `__vsnprintf_chk`, `verr` and `vwarn` is a `va_list`, not a stream; a blanket
  `void * -> FILE *` would assert a false type at every one of those call sites,
  which is exactly the wrongness the `libcsigs` rejection rule exists to avoid.
  Each named table entry restates a shipped one with the same arity and the same
  variadic slot, so no argument can shift.

  *Each named type is a shell carrying its real width, never width 0.* A
  zero-width pointee is not opaque, it is broken: the pointer-arithmetic seam has
  no size-0 early out and `RulePtrsubUndo`'s no-field arm short-circuits when the
  pointee size is zero, so the `PTRSUB` survives to the printer and renders in
  FUNCTIONAL form — a literal `PTRSUB(p,0x28)` inside the C, on exactly the
  `stdout + 0x28` and `f + 8` accesses this table exists to type. The widths are
  the platform ABI's own (`FILE` 216, `stat` 144, `dirent` 280, `sigaction` 152,
  `sigset_t` 128, `option` 32, `tm` 56, `passwd` 48, …, and 1 for `DIR`, whose
  layout the platform publishes nowhere). With a real width, an in-range access
  renders `f->field_0x8` and an out-of-range one falls back to the cast form.

  The width carries a second load, and it is the one worth stating precisely.
  Every slot these tables name is a POINTER — no libc declaration restated here
  passes or returns an aggregate by value — but that is a property of the table,
  not of the emitted C. Ordinary type propagation still carries a named type
  into a by-value position, and does: `timespec sub_10210(void) { timespec v1;
  clock_gettime(0,&v1); return v1; }` on `-O2` coreutils `ls`, from the
  `timespec *` slot of `clock_gettime` alone. That rendering is correct — a
  16-byte `timespec` is returned in a register pair — and it is correct because
  the shell is SIZED. A width-0 shell in the same slot is exactly the
  hidden-return-buffer case: an aggregate return the ABI classifier cannot size
  grows a phantom first parameter and shifts every real one. Across the corpus
  swept for this option, three copies of that same `gettime` wrapper are the
  only by-value named returns at all, nothing wider than a register pair reaches
  a return slot, and no `rethidden` appears in either arm — but the table does
  not forbid the wider case; the width is what would answer it correctly.

  *The widths are glibc's x86-64 ones, so nothing is named on another ABI.* A
  width is a claim about the caller's frame too, not only about offsets inside
  the shell. A named pointer handed the address of a frame object gives that
  object the aggregate's width, so the object grows to the declared width
  wherever frame recovery had seen less of it. On x86-64 against glibc the growth
  is right, and it does happen: `char v1 [12]` becomes `termios v1` when the
  program touched only twelve bytes of the 60-byte struct `tcgetattr` fills. On
  another ABI the same growth runs past the real object and folds the caller's
  neighbouring locals into it. An i386 `struct timespec` is 8 bytes; handed to
  `clock_getres` as a 16-byte one, it swallowed the two `int` locals above it
  (`v1._12_4_ = a0 + 2`), and an `int k[12]` beside an i386 obstack became a
  field of an 88-byte one. So the pass runs only where the widths are the ABI's:
  an ELF for x86-64 that is not dynamically linked against another C library —
  no `.dynstr` at all (a relocatable object, a static link), or one naming glibc
  (`decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_libctypes/glibc.rs
  (target_takes_the_widths)`). i386, ARM, AArch64 (whose `stat` is 128 bytes and
  `pthread_mutex_t` 48), MIPS, PE and Mach-O get no named slot, no stream symbol
  and no shell — the shipped `void *` tables, byte for byte what `libctypes off`
  gives. `formatstring static` reads the same decision
  (`effective_libctypes_layout`), and the declared-name path below is handed it as
  a fact about the image. Scaling the table per architecture would need a
  measured width for every row on every ABI, and is not attempted.
  `tests/stages/kuna-libctypes.xml` pass 14 is the i386 witness.

  Growth is also why a named vote is held to what the caller does with the
  pointer. A libc aggregate is often the first member of a larger object, whose
  address is then the one the call reads; the vote is declined for a call whose
  argument the caller reads past the aggregate's end (chapter 05, `kuna_libcfit`).

  *The shells stay incomplete, and the names are bare.* `type_incomplete` stays
  set on the sized shell so the project exporter declares it
  `typedef struct FILE FILE; /* opaque */` rather than as a struct with a width
  and no members. The names are the bare DWARF spelling (`stat`, not
  `struct stat`) because that is what the printer spells for a named base and
  what that same `typedef` makes valid C. What that buys in the header it spends
  in the body: the exported `.c` declares objects of a type its own `.h` calls
  incomplete, so `cc -fsyntax-only` over an exported `ls.c` gains 58 errors with
  the option on (911 to 969) — 51 of them `invalid use of incomplete typedef`,
  `storage size … isn't known` and `return type is an incomplete type`, the rest
  the type-name/function-name clash of §9.7 arriving in the body, which
  `build_header`'s fix does not reach. The exported body has never compiled; the
  header does, in both arms, and it is the header that carries the declarations
  the rest of the export depends on.

  *An image with debug info already has the real thing, and gets it.* DWARF
  interns `stat`, `passwd`, `tm` and `option` under the identical bare spelling,
  with their true layouts, so this table has nothing to add there and must not
  get in the way. It runs AFTER the DWARF importer and adopts whatever
  aggregate of the declared width is already held under the name — or under the
  spelling the platform's own headers use for it, which for `FILE` is
  `struct _IO_FILE`. Width and metatype are the whole test: a struct of the
  declared width is adopted complete or not. That is what lets the importer
  finish populating one underneath the pointers already built against it, and it
  is what keeps the table idempotent — the second slot of a signature meets the
  shell the first slot minted and has to take it, not decline it. A name held by
  anything else — a different width, a non-struct, or the width-0 type a bare
  forward declaration interns as — declines the signature: this table never
  completes, re-keys or alters a definition it did not establish. A declined
  name is not a withdrawn prototype; the width-stable signature stands, so the
  arity survives even where the pointee does not.

  The order is not a preference, it is the correctness condition. A pointee is
  captured as a reference when the signature is built, and completing a struct
  re-keys it into a NEW object (`TypeFactory::setFields` mutates in place in the
  C++; the Rust factory clones). A shell minted first and completed by DWARF
  afterwards is completed for everyone EXCEPT the pointers already built against
  it, so `st->st_mode` would silently degrade to `*(int *)&st->field_0x18` on
  exactly the `-g` binaries that have the answer. Running second closes that
  window. For the same reason the named tables match IMPORTED names only, where
  the shipped `LibProtoPass` also matches a name the image defines: a defined
  `fopen` is that image's own function and its DWARF prototype outranks a table
  entry.

  *One table is the exception, and it is what makes obstack reachable at all.*
  The five `_obstack_*` entry points are matched against a name the image
  DEFINES as well as one it imports. The reason the general rule exists —
  that a plain spelling in an image's own symbol table is that image's function
  — cannot apply to them: `_obstack_*` is the implementation-reserved half of
  `obstack.h`, written only by glibc or by the gnulib copy of the same file, and
  both publish the same `struct obstack`. The reason it is worth an exception is
  that most images reach obstack that way and no other: gnulib links its copy in
  and the linker exports the symbols from the program, so a stripped `grep`,
  `tar` or `coreutils` binary carries `_obstack_newchunk` in its dynamic symbol
  table and nothing else in the image says what its first argument addresses.
  Measured over the corpus's debug twins, `obstack` is the widest aggregate in
  ground truth after `FILE` — 431 pointer variables, 371 of them inside a
  function that calls one of those five directly. `_obstack_allocated_p` is left
  out for want of any installed declaration at all, exactly as `__underflow` was.

  *The obstack size slots follow the channel, because the two publishers
  disagree about them.* gnulib's copy defines its size type as `size_t`; the
  installed glibc header declares plain `int`. Which one holds is not a property
  of the corpus — the same results tree contains both, with fifteen slices (the
  five `dpkg` programs at each optimization level) importing
  `_obstack_begin`/`_obstack_newchunk` from glibc while everything else links
  gnulib's copy in — so it is decided per image by which channel the name
  arrived on. A DEFINED name takes the `size_t` table, an imported one the `int`
  table; the aggregate slot is the same in both. Getting that backwards is not
  cosmetic even though both pass the value in a register: the caller of an
  imported `_obstack_newchunk` would have its own `int` parameter widened and
  two casts inserted to reach a `size_t` argument that the callee does not have.
  An operator's `--define-function` is answered from the DEFINED table, since a
  directive names a body in this image.

  *The gate is read at load time, inside the pass.* The named shells are interned
  into the type factory while the signatures are built, which happens during
  `load file` — upstream of every `option` command and, in `decompile-all`,
  upstream of the runtime option pass. An architecture flag read inside the pass
  would therefore see the constructor default whatever the operator asked for, so
  the gate is a process environment variable that the console's `option` arm and
  both CLI surfaces set before the load, the same bridge `dwarfstructs` and
  `typedepth` use. With the gate off the pass returns immediately: not one shell
  is interned and the output is the shipped tables, byte for byte. The same gate
  answers the operator's declared-name lookup (`declaredlibcproto`), so
  `--define-function 0x…=fopen` agrees with what the pass parks on an imported
  `fopen`.

  *`glibc` fills in the layouts the platform publishes.* A sized, fieldless
  shell keeps the arithmetic seam honest and says nothing about what is at an
  offset: the refill body of an inlined `getc` reads `f->field_0x8`, and the
  value it loads is `unsigned char *` only because the cast that used to be
  there said so. The third value installs the real x86-64 members of the nine
  aggregates whose layout glibc publishes in an installed header and an
  application is meant to read — `FILE`, `stat`, `timespec`, `timeval`, `tm`,
  `passwd`, `group`, `option`, `dirent` — so the same access is
  `f->_IO_read_ptr`, a `stat` buffer reads `st->st_size`, and the loaded value
  takes the FIELD's type. That last part is what carries: `st_size` is a signed
  `long`, so a wrapper that returns `-1` on failure stops printing its sentinel
  as `0xffffffffffffffff`. `DIR`, `sigaction`, `sigset_t`, `mbstate_t`,
  `termios`, `sockaddr` and `pthread_mutex_t` stay opaque under `glibc` too:
  glibc publishes no layout for `DIR` at all, and the rest are reserved words no
  caller reads by name.

  A field name is a claim about what is at an offset, so `glibc` makes it only
  where the claim is checkable. The pass installs a layout only when the image is
  an ELF for x86-64 whose dynamic string table names glibc — the `libc.so.6`
  soname, or a `GLIBC_2.x` symbol version, which is where `.gnu.version_r`'s
  version names live. musl, another libc, another architecture and a statically
  linked image all fall back to the `opaque` shells, and for a static image that
  costs nothing, because these tables are matched against IMPORTED names only and
  a static image has no named aggregate to lay out. Where the platform's own
  debug info already describes the aggregate, the adoption rule above still
  decides: a held definition of the declared width is taken whole and no
  published layout is installed over it.

  Three constraints shape the tables themselves. No row names a member glibc
  reserves for itself — `stat::__pad0`, `stat::__glibc_reserved`,
  `_IO_FILE::__pad5`, `_IO_FILE::_unused2` — so those offsets stay holes and
  print in the neutral offset form. The width they take up is measured with
  everything else, but a member no program may read has no truthful use that
  carries information: every honest occurrence of such a name is a whole-struct
  copy spilling padding, and the occurrences that carry meaning are all wrong,
  because a named pointee landing inside a larger struct gives that struct's own
  members the reserved names. Measured over sixteen binaries the rows fired 28
  times — nineteen padding copies, eight mis-names of diffutils'
  `file_data::desc` and `::name`, and one address computation the name made
  harder to read — so the hole is the honest form in every case. No field is
  spelled as a pointer to the aggregate being filled — `_IO_FILE::_chain` and `_IO_FILE::_freeres_list`
  are `void *` here — because completing a struct re-keys it into a new object,
  so a self-pointer taken while the shell is being filled would strand the
  program on two stream types; nothing reads `_chain`, and the alternative is a
  split type. And nesting is one level deep: `stat` holds three `timespec`s by
  value and `timespec` holds no aggregate, which is what makes the recursive mint
  terminate by construction rather than by a depth counter, and what keeps
  `dependent_order`'s definition-before-use walk finite. All three are
  unit-tested properties of the tables, not conventions.

  Every offset, width and alignment in those tables was measured against the
  installed headers with `offsetof`/`sizeof`/`_Alignof`, not restated from
  memory; the program and its output are recorded in
  `docs/features/libctypes/glibc.md`.

  A name the operator declares by hand (`--define-function 0x…=fopen`) arrives
  long after load, with the image out of reach, so it cannot re-run that target
  gate — and it does not re-derive one either. The gate's own answer is carried
  forward as a fact about the image (`AnalysisOutput::libctypes_glibc`, kept by
  the console across the load), and the declared-name path is simply told: the
  gate accepted this target, or it did not. Nothing about the program stands in
  for that. The member names the kernel ABI fixes are shared by every libc and
  every architecture — `st_dev` is at offset 0 of a 32-bit MIPS `stat` and a musl
  `stat` alike — so a program that looks glibc-shaped from the inside is not
  evidence that its `FILE` is 216 bytes with `_fileno` at `0x70`. An image the
  gate refused gets the opaque shell for a declared name too, whatever it holds
  and whatever the run asked for. The width gate travels the same way
  (`AnalysisOutput::libctypes_refused`): on an image it refused, a declared
  `fopen` gets the width-stable `void *` signature, as an imported one does.

  The default is `opaque`. No datatest loads a file, so the 675 assertions
  cannot see this tier either way; the stage corpus can, and
  `tests/stages/kuna-libctypes.xml` pins the row in both arms. The evidence for
  the default is therefore the corpus type-recovery sweep: over the decbench
  slices at `-O0`, `-O2` and `-O2 -fno-inline`, naming these pointees moves 70
  functions to a perfect type score and one to a worse one — a `hash_do_for_each`
  callback whose own declaration spells the payload `void *` while its body only
  ever hands it to `fwrite_unlocked`. The whole-binary `decompile-all` sweep that
  accompanies it moves no call target at all (the call-target multiset is
  identical in every function), but it does move numeric literals, and in three
  PLT thunks a control-flow edge: a constant offset into a named aggregate is
  absorbed into the field name it selects, so `*(long *)&a0[4]` becomes
  `a0->field_0x10`, and a thunk that inherits a typed return value grows the
  `return` it had no value to carry before. The functional `PTRSUB(` form the
  sizing rule exists to prevent stays absent in both arms. `--option libctypes
  off` restores the shipped `void *` tables byte for byte, which is the ablation
  to reach for when a pointee name is in question; the cost the default carries
  is in `decompile-project`, whose exported `.c` reads fields out of a shell its
  `.h` declares incomplete (the `.h` is unaffected). `glibc` is measured the same
  way against `opaque`, and its own sweep is in `docs/features/libctypes/glibc.md`:
  across twenty-six whole binaries it turns 792 `field_0x<hex>` accesses into 28
  and 2,946 piece reads into 2,429, and moves the stack declaration count by 10
  in 14,487. Four things that sweep is NOT evidence for are recorded there with
  their counterexamples. The functional `PTRSUB(` form is **not** absent under
  `glibc`: giving `FILE` a member at offset 0 makes a `PTRSUB(p,0)` matching where
  the fieldless shell let `RulePtrsubUndo` remove it, and the printer falls back
  to the functional spelling rather than `&p->_flags` — two sites in one libselinux
  function. That fallback is not new; it is what the engine already does for a
  DWARF-complete struct, and `glibc` only reaches it on a stripped image. A sized
  pointee makes an index respell an offset, and where the named aggregate is only
  one member of a larger struct the respelling is a confident mis-name — six of
  the ten indexed member accesses in the corpus, e2fsprogs `init_resource_track`
  giving `brk_start` the name `tv_sec`. A frame slot can grow and swallow its
  neighbours, and not only when an aggregate is involved: openssh `ssh-keygen`
  `do_gen_krl` merges two `char *` locals and an 8-byte slot into one `char[24]`
  read through `._0_8_`/`._8_8_`/`._16_8_`, and shadow `useradd` `main` loses a
  recovered 144-byte `stat` stack symbol into a `char[128]` on the `variables[]`
  surface the type metric scores, and scores identically in both arms — so a flat
  sweep means nothing regressed *that the metric scores*, which is not the same
  claim. And a load spanning two fields is now decomposed into piece writes on a
  scalar local (`v._0_4_ = st->st_mode; v._4_4_ = st->st_uid;` for an 8-byte read
  at `stat+0x18`) — 51 sites, against 517 piece reads the value removes.

  *The stream slots are typed as storage, not as a prototype slot.* Everything
  above types a stream where a CALL says what it is, which leaves the streams
  themselves untyped storage: `stdin`, `stdout` and `stderr` are named from the
  symbol table (the loader data stream below) and carry an `undefined<size>`
  word, so a function that hands `stdout` to one of the image's own helpers
  learns nothing about it and the two renderings of one global disagree inside a
  single binary. Under any enabled value this pass also emits a typed DATA
  symbol for each stream slot (`AnalysisOutput::typed_data`, committed with
  `typelock|namelock` between the string literals and the loader's own data
  symbols, so a DWARF global or a detected literal still wins the address and the
  loader's untyped naming of the same slot stands down). It answers to
  `datasyms` as well: that option's contract is that `off` restores the raw
  `dat_<addr>` rendering for every global the DWARF pass does not name, and a
  stream slot's name is a `.dynstr` string like any other, so naming a data
  object stays that option's call and `libctypes` only decides what the named
  object IS. There is no half of this to keep — the type rides on the symbol.

  Which slot, and what it holds, is read off the DYNAMIC RELOCATION that binds
  the stream — that relocation is also the evidence that the name is the C
  library's and not a global the program happens to spell `stdout`, so a name the
  image defines itself is never reached: the `COPY` arm is reached only through a
  copy relocation, which is by construction a claim about a definition in another
  image, and the `GLOB_DAT` arm requires the symbol to be undefined. The same
  rule reaches one step further out for the one name this pass MINTS rather than
  reads — `stdout_ptr` is kuna's coinage, so the `GLOB_DAT` arm declines when
  either of the image's symbol tables already spells it, and an image carrying
  its own `stdout_ptr` global keeps the untyped `*dat_<addr>` rendering rather
  than printing two addresses under one identifier. `.symtab` counts as much as
  `.dynsym` there: a `static long stdout_ptr` reaches only the former, and that
  is the table the loader's data symbols are named from. The two shapes hold
  different things. A
  `COPY` relocation names a `.bss` word of pointer width that the run-time loader
  fills with libc's own `FILE *stdout`: the slot's type is `FILE *` and its name
  is the stream's. A `GLOB_DAT` relocation on an UNDEFINED symbol names a GOT
  word holding the stream's ADDRESS: its type is `FILE **` and its name is
  `stdout_ptr`, because the address is not the stream and calling it one would
  make the emitted `*stdout_ptr` read as an indirection the program does not
  perform. A `GLOB_DAT` whose symbol is DEFINED — the same image's own copy slot,
  in a mixed executable — is not a stream fact at all; the relocation fill and
  the RELRO constant-fold already render it. Linked ELF only, and only where the
  width gate above passes: the slots mint the same `FILE` at the same width, and
  `structdefs` reports that width, so an i386 image gets no stream symbol. A
  spelling that occurs more than once in `.dynsym` is declined outright.

  The `FILE` the slots point at is the one `named_aggregate` hands the rest of
  the table, so `opaque` gives `stdout->field_0x28` and `glibc`
  `stdout->_IO_write_ptr`, and an image whose own debug info holds a different
  `FILE` contributes no stream symbol rather than a contradictory one. What this
  changes in emitted C is bounded and was measured: over twelve whole binaries,
  45 lines move and every one of them is a GOT slot gaining its name (38, of
  which 31 also drop the `(FILE *)` cast the untyped slot needed), a declaration
  taking `FILE *`/`FILE **` (5), a cast appearing on a genuine `FILE *` global
  (1) or a return type becoming `FILE *` (1). Eight of the twelve are
  byte-identical end to end, because on those the type already arrived by
  inference from a typed stdio call in the same function — the reach this step
  extends is the function that makes no such call, and the shared object, whose
  stream never had a name at all. The cost is local merging: a slot that takes
  `FILE *`/`FILE **` stops merging with the unrelated values a scalar local had
  absorbed, which adds a declaration and renumbers the locals after it, so a
  single retyped slot can account for most of a function's changed lines
  (libedit's `rl_initialize`: one new declaration, 57 changed lines, 15 of them
  once the numbering is normalised away).
- **(kuna) Win32 API signatures** (`win32sigs`,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/kuna_win32sigs.rs (Win32SigsPass)`):
  the Windows half of the same `.gdt` stand-in, which the tree did not carry at all.
  A PE's `LoadLibraryExW` / `CreateFileW` / `WriteFile` therefore reached
  `ActionDefaultParams` with an empty prototype and its arguments had to come from
  the call site alone; where that recovery loses — the ordinary case for an image
  that fills its outgoing slots well before the call — the call renders
  `LoadLibraryExW()` and the argument stores survive as mapped stack locals, along
  with the return-address push the CALL itself makes. Which names the table carries
  was measured the same way the libc one was: an import histogram over the PE images
  of the RE arena corpus, admitting a name at five or more images, plus the
  resource/loader family below that bar because it is the family the defect was
  reported against, plus the OLE Automation `BSTR`/`VARIANT`/`SAFEARRAY` calls and the
  WinSock-only exports (`WSACleanup`, `WSAGetLastError`, `closesocket`, ...), which
  are nearly always imported by ordinal and reach this table through `peordinal`'s
  names. The BSD socket spellings are not added here; the libc tables carry only
  some of them (`socket`, `recv`, `send`, `select`), and `SafeArrayCreate`,
  `VariantChangeType` and `WSAStartup` are absent because each takes a by-value
  `VARTYPE`/`USHORT`/`WORD`. The reduction rule is the one above, with the
  Windows spellings named — handles and `LPVOID` are `void *`, `DWORD`/`UINT`/`LCID` are unsigned
  4-byte, `BOOL`/`LONG` signed 4-byte, `SIZE_T` pointer-width, `LPCSTR` a `char *`,
  `LPCWSTR` a `wchar_t *` at the compiler spec's `wchar_size`, `LPDWORD` an
  `unsigned int *` — and a declaration with a slot that has no honest spelling is
  rejected, which is why `SetFilePointerEx` and the `RtlVirtualUnwind` family are
  absent. Two things are specific to Windows. The **arity** is load-bearing beyond
  typing: the x86 PE default prototype model is `__stdcall` with an unknown
  `extrapop`, so a locked N-parameter prototype also states that the callee pops
  `4 + 4N` bytes, which is why the table admits only callee-cleans `WINAPI` exports
  and no `__cdecl` CRT spelling. Like the libc passes, the prototypes are parked by
  **entry address**: a PE import is registered as two `FunctionSymbol`s — the size-0 IAT
  slot the engine constant-folds through and the `FF 25` thunk veneer a direct
  `call` targets — the global by-name query answers with the slot, and
  `ActionDefaultParams` asks about whichever one the call resolved to, so a by-name
  park is a silent no-op on exactly the calls that need it. The pass emits one
  address-keyed prototype per genuine import the resolver reports, which lands on
  both. PE/COFF only; a same-named definition/export is never retyped because this
  pass emits no global by-name prototype.

  The libc tables meet the same `__stdcall` default on an i386 PE and need the
  opposite answer: every export of a Microsoft C runtime DLL is `__cdecl`, so the
  caller removes the arguments. Left under the default model, a locked
  `memset(void *,int,size_t)` read as a callee that pops 12 bytes, and in a frame
  whose caller pops nothing (the GCC/Clang fixed frame, where the caller writes
  arguments with `mov [esp+k]`) every later stack slot in the function moved by
  12: a local one call filled through a pointer was read back from another slot.
  `LibProtoPass` therefore also reports the names the image imports from a C
  runtime DLL (`decompiler/crates/kuna-analysis/src/loader/pe_iat.rs
  (c_runtime_import_names)`: `msvcrt`/`msvcr*`, `ucrtbase`, the
  `api-ms-win-crt-*` forwarders, `vcruntime*`, `crtdll`), and the commit boundary
  (`decompiler/crates/kuna-console/src/engine.rs (commit_analysis_output)`)
  declares the prototypes parked under those names with the spec's `__cdecl`
  model, whose stated `extrapop` of 4 leaves nothing for `calleeprotostack`
  (chapter 04) to resolve. The DLL is the evidence, not the name: the BSD socket
  spellings the libc tables carry are `__stdcall` WinSock exports and keep the
  default. Only where the default model's `extrapop` is unknown and the spec
  registers a `__cdecl` model of its own, so x86-64 and every ELF are untouched.
- **(kuna) Declared names** (`declaredlibcproto`,
  `decompiler/crates/kuna-analysis/src/analyzers/protos/mod.rs (declared_libc_prototype)`,
  consulted from `decompiler/crates/kuna-console/src/engine.rs (ConsoleProgram::declare_function)`):
  both passes above match a name the **image** carries — its FUNC symbols, its
  imports — which is exactly the evidence a stripped, statically linked target does
  not have. There the name exists only because an operator supplied it
  (`--define-function 0x8048968=ptrace`, `--assert 'function 0x8048968 ptrace'`,
  console `function bounds … as ptrace`), and a name that buys no prototype buys
  almost nothing: the callee's arity has to come from somewhere, and a varargs
  wrapper cannot yield it to any amount of body analysis, so the call sites keep
  rendering `ptrace()` with the pushed argument slots stranded as raw stores on the
  lines above. So a declared name is looked up in both tables at declaration time
  and the matching signature parked on the **declared entry address** — the key
  `ActionDefaultParams` reads a callee prototype back by, and the only key that
  survives two symbols sharing a spelling. The imports-only restriction the measured
  table carries is deliberately lifted here: it exists so a *coincidental* spelling
  cannot retype a function the image defines itself, which is a judgement about
  evidence, and the evidence is different once a human or an agent has identified
  the entry outright. The lookup runs after the declaration is registered and before
  any assertion is applied, so an explicit `--assert prototype` on the same function
  still wins. The base table carries `ptrace` for this reason: glibc *declares* it
  `long ptrace(enum __ptrace_request, …)` and fetches the rest with `va_arg`, so the
  four fixed slots — glibc's own, and the call form `ptrace(2)` documents — can only
  come from a table.
- **DWARF** (`dwarf`, the `DWARFAnalyzer` port,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/mod.rs (DwarfPass)`), the
  parser wholesale-substituted by `gimli` (the same dependency-substitution loss as
  BFD → `object`). Three recoveries: (1) names — each defined `DW_TAG_subprogram`
  emits a function symbol, each top-level `DW_TAG_variable` with a `DW_OP_addr`
  location a data symbol; (2) typed signatures — return + formal-parameter DIEs
  mapped to kuna `Datatype`s (structs as named opaques, with a cycle guard on the
  DIE walk — see `typedepth` below), registered *after* libproto so real source
  signatures win,
  and read back at *two* points: by a caller's `ActionDefaultParams` for the call
  site, and by the drive as the function's own locked prototype (04 §4.2 —
  `int main(int argc, char **argv)`, not `undefined16 main(uint4, void*)`).
  A compilation unit with no type references and no formal or variadic parameter
  records supplies names and ranges only. Its functions do not acquire locked
  prototypes: rustc minimal debug information omits this signature evidence, and
  treating the omission as `void f(void)` would erase arguments and return values.
  The same guard covers both the direct and declaration-derived prototype paths
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfsignatures.rs`).
  Units with signature evidence retain their typed imports, including genuinely
  parameterless functions. Names from such minimal units retain their namespace
  qualification, so Rust `core::fmt::write` does not become a global `write`
  alias that could inherit the C import's incompatible signature.
  The opt-in `godwarfsig` arm
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_godwarfsig.rs`)
  recovers complete scalar/pointer contracts from Go compiler units on
  little-endian amd64 under `abi-internal`. It requires the producer's `regabi`
  marker and `DW_AT_variable_parameter` to distinguish every input from every
  result. Unit-relative and absolute type/origin references share a bounded
  cross-unit graph. Concrete one-hop abstract origins must account for every
  inherited formal exactly once and in order; additional concrete formals may
  only be results. Malformed references, missing roles, closures, trampolines,
  ABI0 wrappers, unsupported composites by value and unsupported multiple results are
  refused as a whole, retaining existing inference.

  Go compilation units never supply prototypes through the generic C or C++
  DWARF importer (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_goformals.rs`).
  Go encodes results as formal-parameter children, so those importers would
  otherwise install extra inputs and a void return for uncompressed units.
  This exclusion follows each unit's `DW_AT_language`, independently of target
  architecture and option settings. Names and other metadata remain available;
  only the Go-specific importer may install a source signature. Unsupported
  Go contracts therefore retain inference in compressed and uncompressed files.

  Accepted inputs occupy the verified Go integer or float register sequence;
  an explicit empty location is permitted for an optimized-away input. A
  nonempty location must identify its expected entry register. Go DWARF 5 may
  give a RET-only input a zero-length entry range. That case requires exactly
  one raw range, a base equal to function entry, offsets `[0,0)`, and a single
  register expression matching the input's ABI slot. The function must declare
  a one-byte extent and the image must contain `RET` (`0xc3`) there. Additional
  ranges, a wrong register/base, longer bodies and result-range substitutions
  are refused. General DWARF location-list handling is unchanged. The existing
  calling-convention model must assign every recovered slot to that same
  register with its exact width and no hidden parameter. Stack arguments and
  float arguments beyond the model's eight-register bank are therefore refused.
  A result uses RAX or XMM0. Scalar aliases are checked against width and Go
  kind; pointers retain grounded scalar pointees, unsafe.Pointer, or named flat
  records with nonoverlapping scalar/pointer fields. Cycles, unresolved fields,
  bitfields and invalid extents are refused. Materialized pointees and fields
  must still match the validated graph; a generic void-pointer fallback cannot
  silently satisfy a typed contract.

  `gopairreturns` extends this importer only when `godwarfsig` is also on;
  both remain off by default. Exactly two signed or unsigned 64-bit integer
  results may follow the scalar inputs. Result allocation restarts independently
  at RAX and RBX. Explicit result locations must name those registers in source
  order; unavailable locations still require the compiler and complete type
  contract. Repeated concrete function entries are ambiguous and cannot receive
  a pair contract. Narrow, floating, mixed, aggregate and three-result contracts
  remain unsupported. Assignment first uses a temporary ordinary 16-byte struct;
  its zero-flag join must contain RBX then RAX, each eight bytes in the exact
  architectural register space. Input assignments retain their existing checks.
  Only after this proof is the struct interned with fields `result0` and
  `result1` at offsets zero and eight and a `GoPairResults` language facet.
  The facet stores signedness, never interned type references. Existing names
  require matching metadata and complete layout; unrelated names or stale
  metadata cannot be overwritten. No metatype or pcode output count changes.

  Native Go zlib debug sections are retained compressed at load time. Their
  combined stored/declared extents are bounded to 64 MiB and are inflated only
  when `godwarfsig` is enabled. Each stream must end exactly, pass its checksum
  and produce precisely its declared size. Ordinary non-Go DWARF decompression
  behavior is unchanged. Uncompressed Go units reuse the ordinary snapshots;
  neither path interns new types while the option is off. Enabled contracts
  bind by entry address before function analysis and reach both definitions and
  callers. Later explicit user prototype assertions retain precedence. Source
  aliases, aggregate register decomposition and high-level receiver syntax are
  separate from this import contract.
  An externally visible defined DWARF function's exact `DW_AT_linkage_name` also binds its prototype
  to matching ELF PLT entry addresses
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarflinkage.rs`). The linker spelling is taken from the
  definition or its one-hop `DW_AT_specification` declaration. When no explicit
  linker spelling is present, a source name is accepted only if a defined, global
  ELF function symbol has that exact name and the definition's exact entry address.
  This covers ordinary C declarations without guessing a mangling scheme or
  following abstract-origin clones. Address binding avoids
  ambiguity between an exported implementation and its same-named PLT stub.
  C++ declaration-derived aliases remain in the `cppproto` fact stream, and
  explicit prototype assertions retain their later precedence. Declaration-only
  DIEs and other binary formats do not acquire these aliases. `DW_AT_external`
  must be true on the definition or its specification; a local definition cannot
  retype an unrelated import with the same linker name. A name the file defines as
  an `STT_GNU_IFUNC` symbol is never bound: the DWARF definition behind it is the
  resolver (`void *(void)`), not the implementation its PLT entry dispatches to.
  Separately,
  a formal parameter of a Fortran compilation unit whose location is exactly
  `DW_OP_fbreg` followed by `DW_OP_deref`
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfbyref.rs`)
  receives a pointer to its described value type. GNU Fortran passes every
  non-`VALUE` dummy argument by reference but describes it by its value type
  plus a frame slot that holds the address; taking that value type as the ABI
  argument instead selected floating registers for a `real` dummy and
  disconnected the incoming address, so `output = sample + bias` printed as
  three unrelated pointer locals. Plain frame slots, including Fortran `VALUE`
  arguments, keep their value types. Other source languages are not inferred
  from this pattern (a C++ class passed by invisible reference carries the same
  location form), nor are composite expressions. Optimized arguments also receive pointer
  types when their location is exactly `DW_OP_breg<n> 0` in an incoming integer
  argument register for the image ABI. Location lists must contain one unambiguous
  expression covering the subprogram entry. Register values, stack/frame-pointer
  locations, nonzero offsets and stack-value expressions retain their value types.
  The register rule skips only values the ABI itself may pass by value through a
  hidden address in that register: none on x86-64 System V or 32-bit Arm, sizes
  other than 1, 2, 4 and 8 bytes on Win64, and values wider than two argument
  registers on AArch64 and RISC-V. Every other value type, including derived
  types, arrays, complex and extended floating types, becomes a pointer; leaving
  one of them a value would hand its register to the next reference argument
  and misname every argument after it. Both
  the name-bound and the address-bound prototype import paths apply the rule;
  a `DW_TAG_enumeration_type` becomes a real enum type — name, declared width,
  signedness, and the `DW_TAG_enumerator` value→name map (05 §5.1), which is what
  turns `quotearg_style(4, …)` into
  `quotearg_style(shell_escape_always_quoting_style, …)`; the enum is looked up
  before it is built, because the same declaration recurs in every compilation
  unit that includes its header. The sign is the enum's `DW_AT_encoding`, which
  gcc emits, else the encoding of the integer its `DW_AT_type` names, which is
  all clang emits (clang's signed enums used to read as unsigned). An enum that
  is not built (anonymous or memberless) falls back to a plain integer: `int` at
  32 bits or wider, as it always was, and below 32 bits an integer of the enum's
  own sign, since that sign decides how a calling convention extends the value
  (04 §4.4, `narrowext`); an enum whose DWARF states no sign (strict DWARF 2) is
  unsigned, named or not, which is what the RISC-V spec's zero extension
  assumed. Base types
  map by encoding; `DW_ATE_UTF` (`char8_t`, `char16_t`, `char32_t`, unsigned in
  C++), the Fortran character encodings and `DW_ATE_unsigned_fixed` are unsigned
  integers, where they used to fall through to a signed one. The two character
  encodings map by name as well (`char_datatype`): `unsigned char` (and so
  `uint8_t`) and `signed char` become character types of that sign
  (`TypeFactory::get_type_char_signed`, Ghidra's `uchar`/`schar`), which print
  as characters and still collapse to `builtin_memset`/`builtin_memcpy`, but
  extend, compare and convert by their own sign. Plain `char`, and any other
  name, keeps the core `char` type whatever its encoding, since its sign is
  the target's (AArch64 and Arm state it `DW_ATE_unsigned_char`) and a string
  stays a `char *`. Both used to read
  as `char`, so a clang `int fwd(char *b, const char *f, unsigned char c)
  { return sprintf(b, f, c); }` printed `sprintf(b,f,c)` with `char c`, which
  compiles to a sign extension (202 prints as -54). A `DW_ATE_complex_float`
  base type
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfcomplex.rs`)
  becomes a structure of two floating fields, `real` and `imag`, each half
  the value's size, aligned to that half (`kuna_complex_float`,
  `kuna_complex_double`), on the compiler specifications whose ABI passes and
  returns the complex value exactly like that pair structure: ELF SysV AMD64
  and PE x64 Windows for complex float and double, PE i386 for complex float
  only (double-complex recovery there additionally requires correct stack
  argument alignment). It used to fall through to the integer mapping, so
  `float complex f(float complex z) { return cexpf(z); }` printed
  `long f(long z)` with the call's argument and result lost. A complete
  layout of that name is reused across units; a same-named type with any
  other layout (a user's) is left untouched and the next free numbered name
  is taken. Other targets, and `long double` complex everywhere, keep their
  previous mapping. An array's length is the product of the lengths of all its
  `DW_TAG_subrange_type` children, so a multidimensional `int a[3][4]` (or
  gfortran's `grid(-2:0,5:11)`) becomes one flat array of every element (12, 21)
  rather than of its first dimension only, which under-sized the storage of
  multidimensional locals, globals and members. Each subrange's length
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfbounds.rs`) is
  an explicit `DW_AT_count` if present, otherwise `upper - lower + 1` over signed bounds,
  where an omitted lower bound takes the compilation unit's `DW_AT_language`
  default (one for Fortran and Ada, zero for C, C++ and an unknown language).
  A bound given as a reference or an expression is not a constant, and a count
  that does not fit 64 bits is rejected rather than wrapped; such a dimension
  contributes nothing to the product (a flexible `int rows[][4]` is one row), an
  array with no known dimension is one element, and a product that overflows 64
  bits or exceeds `int4` leaves the array untyped. The
  zero origin used to be assumed everywhere, so gfortran's `real :: a(3)` read
  as `float a[4]` and `a(-8:-4)` as `float a[1]`;
  (3) stack locals — direct `DW_OP_fbreg` children become typelock|namelock stack
  symbols at `call_frame_cfa + fbreg`, re-seeded per decompile (§1.1). A frame
  location may include `DW_OP_plus_uconst` displacements, as emitted for interior
  equivalence views. Each unsigned LEB128 operand is decoded and added without
  signed overflow; truncated operands and dereference, piece, register, or value
  expressions remain outside this fixed-local path. Nested lexical-block locals
  and composite locations are a documented loss. (ida) The
  data-global fix (DIV-24): a global used to be mapped with a size-1 type, so any
  multi-byte access queried `queryContainer(addr, 4)` past it and rendered
  `dat_<addr>`; the pass now resolves `DW_AT_type` to a byte size
  (`pass.rs (DataObjectFact)`) and the commit maps an `undefined<size>` entry —
  namelocked but *not* typelocked, so inference still recovers the real type —
  matching how IDA Pro and Ghidra name symbol-table globals (`max_width`, not
  `dat_<addr>`). Declaration-only DIEs are skipped so DWARF never fights libproto
  over imports. `dwarf_lines`
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/lines.rs (DwarfLinesPass)`)
  is the separate `.debug_line` pass: each row becomes a `file:line` instruction
  comment in the commentdb; default-off because it changes the output.
- **DWARF C++ prototypes** (`cppproto`, default-on,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_cppproto.rs`) is the
  C++ arm of that same pass. Keying every recovery off a subprogram DIE's own
  `DW_AT_name` is right for C and wrong for C++, where the compiler splits a
  definition from its declaration: an out-of-line member or namespace definition
  carries only `DW_AT_specification`, and a concrete out-of-line instance of an
  inlined function only `DW_AT_abstract_origin`. Neither has a name of its own, so
  the whole DIE — name, signature and stack locals — used to be dropped, and on a
  `-g` C++ binary that is most of the program. This arm fuses the definition with
  the declaration it points at (a **single hop**: what a definition points at is
  always a declaration, never another indirection — the reduction of Ghidra's
  `DIEAggregate`), takes the name, return type and parameter names from whichever
  DIE carries them, and builds the source name by walking the DIE's
  namespace/class ancestry (`DWARFName`), so the installed symbol carries
  `Account::deposit` rather than the bare `deposit` the declaration DIE holds. Three type-mapper corrections ride
  along: `DW_TAG_class_type` maps like a structure and a C++ reference like a
  pointer (both are what Ghidra's importer does, and without the first every
  `Foo *this` degraded to `void *`); the transparent qualifier hops
  (`typedef`/`const`/`volatile`/`restrict`) are collapsed before the type switch
  runs, because a `const` member function's `this` is `const Account *const` —
  four DIEs deep, and under the pre-`typedepth` budget one hop too many; and a
  parameter whose type the switch still cannot
  map degrades to an `undefined<n>` of that DIE's own width instead of discarding
  the entire signature, so one exotic member type costs one parameter's type
  rather than the function's whole prototype. Finally the recovered prototype is
  parked by **entry address** rather than by name. Address is the key the read
  side already uses, and the only one that survives C++: kuna files the demangled
  template name `maxof<int>` as `maxof`, and a qualified name lives in a nested
  scope that a global by-name query cannot reach — so both the drive's own-prototype
  lookup (04 §4.2) and the callee-prototype snapshot resolve across every scope,
  not just the global one. The producing pass runs at `load file`, upstream of the
  `option` commands, so its C++ facts are stashed apart from the always-on ones and
  the gate is applied where they are committed; with `cppproto off` the DWARF
  recovery is the name-only walk, byte for byte. (Struct/class **fields** are the
  sibling `dwarfstructs` increment below; before it, a class stayed a named opaque
  and `this->balance` printed as an offset.)
  At the enabled commit boundary,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_cppnames.rs`
  also reconciles a qualified
  function fact with the generic DWARF fact at the same entry address. A unique
  qualified name replaces only its exact bare leaf in the incoming function
  stream. This prevents a redundant global `target` from shadowing
  `left::target` during address lookup, including Rust crate/module paths.
  Definitions, direct calls and whole-function values then share the same
  namespace fact; P9's C function-address qualification preserves the target when
  a function returns its address instead of calling it.
  Every component must be a plain ASCII C++ identifier and must not be a C++
  keyword, using the same spelling check as P9 function-address qualification.
  This retains the generic alias for Rust raw-identifier modules such as `union`,
  template/reference type scopes, and anonymous or malformed scope paths rather
  than replacing printable C definitions with invalid qualified spellings.
  Conflicting qualified facts, different names or addresses, and data symbols
  remain intact. Existing symbols in the database,
  including explicit global aliases and unmangled exports, are never removed.
  With `cppproto off`, the generic stream is unchanged. Address-keyed prototype
  application still follows generic prototype application.
- **Aggregate layout** (`dwarfstructs`, default-on,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfstructs.rs`) is
  what turns a recovered aggregate from a *name* into a *type*. The mapper used to
  resolve every `DW_TAG_structure_type`/`union_type`/`class_type` to
  `get_type_struct(name)` — a named, empty, **zero-size** shell — and never read
  `DW_AT_byte_size` or walked a single `DW_TAG_member`. That is enough for
  `struct foo *p` to render, and the shortfall was filed as a fields gap; it is
  worse than that, because a zero width is not a conservative answer. The
  x86-64 parameter-storage model reads the size, so a struct passed **by value**
  had no width to classify and its slot degraded to the raw register it arrives
  in (`int take_struct(unsigned long,int)` for `take_struct(P8,int)`), and an
  8-byte struct **return** — a register return on this ABI — was classified as a
  hidden-return-buffer call: a *phantom* `rethidden` parameter appeared in front of
  the real ones and the body then did arithmetic on it. This arm reads
  `DW_AT_byte_size`, walks the `DW_TAG_member` children, places each at its
  `DW_AT_data_member_location` **verbatim**, and recurses each member's
  `DW_AT_type` through the same DIE switch; bitfields come off `DW_AT_bit_size`
  with either the DWARF 4/5 `DW_AT_data_bit_offset` or the DWARF 2/3
  `byte_size` + `bit_offset` spelling, each placed in the smallest byte span that
  covers it — the geometry the compiler's own access agrees with, and the one the
  printer's `.`-versus-`->` test reads. A "bitfield" occupying whole aligned bytes
  of a natural width is not one and goes in as a plain field of that width, which
  is exact on a little-endian target and keeps a known
  `BitFieldPullTransform` divergence (three bitfields sharing one extraction
  chain) out of reach. Offsets are installed through a raw
  field-setting entry point rather than the C packing rules, because the layout is
  the compiler's own answer for the target ABI and re-deriving it would silently
  disagree with the bytes the decompiler reads.

  Two hazards come with populating fields, and both are handled in the naming.
  The type factory interns by `(name, hash(name))` and refuses a second, different
  definition of a name it already holds; while every aggregate was a sizeless
  shell that was invisible, because two shells compare equal. It goes live the
  moment fields exist — and it is not exotic: `rustc -g` names every enum payload
  struct **bare** (`Some`, `Ok`, `Err`), and a five-function Rust witness carries
  four distinct `Some` DIEs of sizes 16, 24, 16 and 12. Aggregates are therefore
  interned under their **parent-qualified** name (the namespace/class ancestry walk
  the C++ arm already had) and, when that name is still held by an aggregate of a
  different size, under a size-suffixed variant; a name held by a non-aggregate is
  stepped over the same way. The second hazard is self-reference: a
  `struct node { struct node *next; }` reaches its own DIE while its fields are
  being built, so the shell is interned **before** the members are walked and the
  inner resolution finds it by name, with the walk guard refusing a re-entrant
  population. LOSS: because an interned type is immutable in kuna, completing one
  mints a new handle, so the pointer the inner frame captured still refers to the
  pre-completion shell — the name renders but the chain is one level shorter.
  `DW_TAG_variant_part`/`DW_TAG_variant`/`DW_AT_discr`, the Rust tagged-enum
  encoding, are not read by this arm; the sibling `dwarfvariants` increment below
  reads them, and with it off a Rust enum recovers its width and no fields. Same
  load-time shape as `typedepth` below: the layout is installed inside
  `load file`, so the live gate is the process env var
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_dwarfstructs.rs`) that the
  CLI exports before the load, and `dwarfstructs off` is the name-only mapping byte
  for byte.
- **Discriminated unions** (`dwarfvariants`, default-on,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_dwarfvariants.rs`) is
  the arm for the aggregates the member walk above cannot see at all. A Rust
  tagged enum carries **no `DW_TAG_member` of its own**: its layout hangs off a
  `DW_TAG_variant_part`, whose `DW_AT_discr` points at the artificial member that
  IS the discriminant, and whose `DW_TAG_variant` children each carry a
  `DW_AT_discr_value` plus one `DW_TAG_member` naming the variant (`Ok`, `Err`,
  `Some`, `None`) and referring to its payload struct. So `dwarfstructs` alone
  gave a Rust enum its `DW_AT_byte_size` and zero fields — and a field-less
  aggregate is still an aggregate the ABI classifier acts on, so an 8-byte
  `fn(u32) -> Result<u32,u32>` came out with the same phantom `rethidden`
  parameter described above and a 16-byte one wrote its variants as
  `*(uint *)&r->field_0x4`.

  Reading it from DWARF rather than from codegen is the point. The two questions
  a decompiler cannot answer from shape are *is this a discriminated union* and
  *which variant is which*: two return paths storing different constants at
  offset 0 is equally a `#[repr(C)] struct {kind, val}`, a `(u64,u64)` tuple, a
  bitmask pair, or a `&'static str` fat pointer whose "discriminant" would be a
  `.rodata` address. `DW_AT_discr` and `DW_AT_discr_value` are the compiler
  stating both answers, so no name installed here is an inference — though a name
  DWARF states is still only installed where the union model can select it
  unambiguously, which is the second limitation at the end of this bullet.

  The recovered type is a struct of the discriminant plus a **union** of one
  payload struct per variant. A union's members all sit at offset 0, which is
  exactly a variant overlay, so this uses the existing type model rather than
  adding a `type_metatype` (that enum is matched at ~1,700 sites in this
  workspace — `grep -ro 'type_metatype::' --include=*.rs decompiler/crates | wc -l`
  reports 1678 — mostly non-exhaustively, so a new variant would compile clean and
  behave wrong;
  `sub_metatype` is a contiguous propagation sort key; and `metatype2string`
  writes a fixed vocabulary onto the Ghidra wire). The overlay
  begins at the lowest offset any variant places a field at, and each facet's
  fields are **re-based** to it: DWARF gives a variant's payload struct the width
  of the whole enum with its members at their absolute offsets
  (`Result<u32,u32>::Ok` is 8 bytes with `__0` at 4), which describes an overlay
  at offset 0 and cannot be placed beside a `tag` field at the same offset.
  Every name minted — the facets and the overlay union — is derived from the
  enum's own parent-qualified name and goes through the same collision policy
  `dwarfstructs` established, because rustc names payload structs bare and the
  collision is not hypothetical: the committed `dwarfvariants_x86_64` fixture
  alone carries **3 structure DIEs named `Some` at two different widths** (8 and
  16), and a std-linked `rustc 1.90 -C debuginfo=2` witness with 152 variant parts
  carries 61 named `Some` across 8 byte sizes (0/8/12/16/24/32/48/64), 61 `None`,
  and 31 each `Ok`/`Err` across 7. A suppressed facet, whose name is derived from
  its offset rather than from the variant, can collide inside a single enum
  (`Tree::field_0x8` for both `Leaf` and `Node`); identical layouts then share one
  interned struct and differing ones are given a numeric suffix, because the ABI
  classifier common-refines the union's members.

  Two shapes get specific treatment. A **fieldless** variant (`None`, `Nil`, a
  unit variant) overlays nothing and gets **no union member**: an empty struct of
  the overlay's width is indistinguishable to the union-field scorer from the
  facet that does carry the payload, and it wins the tie by declaration order.
  Ablating the exclusion, a std-linked `rustc -g` witness writes an `Option<i64>`
  payload as `v13.payload.None = ...` and reads drop glue as
  `(*a0).dropfn.drop.None` — 2 functions of 612, measured, which is what fixed it
  this way. The variant is not lost — its name and its discriminant value
  are on the side table, which is where a `match` renderer reads them, and there
  is no payload for a field path to reach. A **niche-encoded** enum, where a
  `DW_TAG_variant` carries no `DW_AT_discr_value` at all (it is the default
  variant: every value the others did not claim) and the discriminant's bytes
  overlap the payload, has no byte range that is only the tag — so the recovered
  type is the **overlay alone**: the union, at the variants' own DWARF offsets,
  under the enum's own name, with no enclosing struct, because a `tag` field would
  have to sit at an offset a variant already owns. The geometry still reaches the
  side table, marked as a niche.

  The geometry — the discriminant's offset and width, each variant's name,
  discriminant value and absolute field offsets, and whether the encoding is a
  niche — is recorded in a side table on the `TypeFactory`
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_dwarfvariants.rs`). It is
  the `kuna_wire_symbols` arrangement: nothing in the analysis reads it, no
  `Datatype` points at it, and it is not encoded onto the wire, so filling it
  cannot perturb emitted C. It exists so a later pass can render `match` /
  `if let` / `Ok(v)` from the compiler's own answer.

  Every guard REFUSES rather than guesses, and every refusal ends at the same
  answer the `dwarfstructs` path above gives — a named aggregate with the enum's
  byte size and no fields — but by two different routes. Refused BEFORE anything
  is interned, so the DIE simply falls through: no `DW_AT_discr`; a variant with
  anything other than exactly one named member; two variants with no
  `DW_AT_discr_value`, or with the same one, or with the same name; a payload
  struct carrying its own `DW_TAG_variant_part` (a nested variant part, which the
  single-level overlay cannot describe — rustc 1.90 emitted none across the 75
  variant parts in the two witnesses measured for this change); no variant with
  any field at all (a C-like enum, which rustc emits as a
  `DW_TAG_enumeration_type` instead); a discriminant whose type is not
  integer-shaped, zero-width, or wider than the enum; a zero-width or absent
  `DW_AT_byte_size`; and a `DW_AT_declaration` DIE.

  Refused AFTER the shell is interned — it has to exist before the members are
  walked so a recursive payload has something to point at — the answer cannot be
  "leave it to `dwarfstructs`", because a zero-size incomplete type is already
  sitting in the factory under the enum's own name, and downstream that degrades
  to `void`. Those refusals instead SEAL that shell at the enum's
  `DW_AT_byte_size` with no fields, which is byte for byte the `dwarfstructs`
  answer: a member that would extend past the enum; every facet's fields being
  unbuildable, which would leave a zero-member union describing nothing; and the
  overlay union's name being unmintable or any of the three completions being
  refused by the factory. Same load-time env-var gate as `dwarfstructs`, and
  gated on `dwarfstructs` itself as well — this arm extends that one, so
  `dwarfstructs off` stays exactly the pre-DIV-86 name-only mapping its own row
  promises.

- **Discriminant-value naming** (`variantnames`, default-on,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_variantnames.rs`;
  `docs/multilang.md`, the first `VariantLayout` consumer) closes the loop the
  side table above left open at its cheapest point. The variant-part importer
  installs the `tag` member with the plain integer type DWARF declares for it,
  so every test or store of the discriminant renders a bare constant —
  `(*e).tag == 1`, `rethidden->tag = 0` — when the compiler stated what those
  values MEAN. With the gate on, the importer instead gives the tag member a
  synthesized enum, `<enum>::Discriminant`, of the tag's own width
  (`TYPE_ENUM_UINT` plus a namemap of exactly the variant part's
  `(DW_AT_discr_value, variant name)` pairs, masked to the tag's width the way
  `build_enum` masks a C enumerator), and the stock enum-constant rendering
  prints `(*e).tag == Err` / `rethidden->tag = A` with no new emission
  machinery. A bit-TESTED tag takes the stock flag-enum arithmetic form —
  `(l->tag & Nil) == Cons` where `off` prints `!(l->tag & 1)` — which carries
  the vocabulary at some cost in plainness; that form is the existing C-enum
  behavior, not a new renderer, and `off` restores the integers. Stand-downs,
  each deliberate: a NICHE layout has no tag field, so nothing is retyped (an
  `Option<&T>` null test keeps its rendering — selecting the facet a niche
  value implies is the `match` renderer's job on the same side table); a tag
  DWARF already declares as an enum keeps the compiler's own type; the DEFAULT
  variant has no single value and so gets no member; and a foreign type
  already owning the synthesized name is never fought (the re-imported
  compilation unit reuses it on an exact shape match, the `build_enum` rule).
  Gated like its parents (`KUNA_VARIANTNAMES`, load-time env bridge), and
  suppressed wholesale by `dwarfvariants off` — no layout, no tag member,
  nothing to retype. The sibling `dwarfvariants` witnesses pin this arm OFF so
  each file measures its own option; `tests/stages/kuna-variantnames.xml` and
  the kuna-console `verify_variantnames` gate own the naming assertions
  (store, read, declaration type, and the niche no-op) over the committed
  `dwarfvariants_x86_64` fixture.

  **The limitation is the channel.** This needs full debug info
  (`-C debuginfo=2`, cargo `debug = true`). Where a binary's DWARF carries no type
  DIEs the arm is not degraded, it is inert: it recovers nothing and attempts no
  fallback, because the only available fallback is the shape inference above. A C
  program has no variant part at all, so the arm never fires on one.

  **The second limitation is the union model, and it decides what may be named.**
  Representing a variant overlay as a union means a member selects itself by
  OFFSET; the discriminant is never consulted. For a tagged enum that is not a
  corner case but the definition of the encoding: every payload variant begins
  immediately after the tag, so `Ok` and `Err` are at the same offset, always, and
  the facet the union-field scorer picks is not evidence of anything. Measured, on
  a `Result<u64,u64>` witness the label was not merely uncertain but consistently
  false — `Ok` was printed on both arms of the producing `if`/`else` and on the
  consumer's `Err(e) => e + 100`, and `Err` appeared nowhere in the binary.

  So a variant name is installed **only where it is forced**, and the rule is
  applied per byte range rather than per variant:

  - a facet keeps its `DW_TAG_variant` name only when no other variant claims a
    byte it claims. `Option<T>` has exactly one payload-carrying variant, so
    `Some` survives; `Result<T,E>` has two over one range, so both are spelled
    `field_0x<offset>` — the same offset rendering `dwarfvariants off` produces,
    which is what a reader gets when the answer is unknown. Both the union member
    and the facet's own interned type name are suppressed, because a cast in the
    emitted C prints the type name and suppressing only one of the two would still
    leak the variant. Two suppressed facets that describe the same bytes share one
    interned struct; two that differ get distinct ones, because the ABI classifier
    common-refines the union's members and merging two shapes would change how the
    enum is passed.
  - a field inside a facet keeps its DWARF name only when every other variant
    either claims none of its bytes or names exactly that range the same way.
    rustc names tuple payloads `__0`/`__1`, so `Result`'s two `__0`s agree and the
    name claims nothing about which variant is live; `enum Multi { P{a,b}, Q(u64) }`
    keeps `P.a` (nothing else claims [4,8)) and spells the word at 8 by offset,
    because `P.b` and `Q.__0` disagree there.

  The rule is deliberately conservative at facet granularity: an access WIDTH can
  sometimes single out a variant that the byte range alone cannot (an 8-byte store
  at offset 8 of `Multi` can only be `Q`), but a union member name is fixed when
  the type is built, not per access, so those labels go too. What is given up is
  the label, never the layout — offsets, widths, member types and the enum's own
  size are exactly what DWARF states either way, and every variant's source name
  and `DW_AT_discr_value` remain on the side table. Picking the facet from the tag
  needs a dominating-guard analysis; that is what the side table is recorded for,
  and it is not attempted here.
- **Function-pointer types** (`calltargettype`, off in the catalog, on in the
  `aggressive` preset) keep what a `DW_TAG_subroutine_type` says. The mapper used
  to give up on the tag, so a pointer to one became a pointer to `void`: a
  parameter, a record field or a local declared `int (*f)(int, long)` came out
  `void *`, and every call through it was a call of a `void *` that no C compiler
  accepts. With the option on, a prototyped subroutine type maps to a code type
  whose prototype is its `DW_AT_type` (none is `void`) and its
  `DW_TAG_formal_parameter` types, a trailing `DW_TAG_unspecified_parameters`
  making it variadic, through `TypeFactory::get_type_code_proto`
  (`decompiler/crates/kuna-analysis/src/analyzers/dwarf/mod.rs
  (build_subroutine)`), and a pointer to it is a function pointer:
  `unsigned long (*hasher)(void *,unsigned long);`. A type without
  `DW_AT_prototyped` (`int (*)()` in C, and every C++ one, which never carries
  it) states no parameters, a `...` with nothing before it has no C spelling,
  and a parameter type the switch cannot build leaves nothing to state, so each
  keeps the `void` pointee. The mapping happens inside `load file`, before any
  option is applied, so the gate is the `KUNA_CALLTARGETTYPE` environment
  variable (chapter 00) the CLI exports ahead of the load from the run's options,
  the mode's preset included, and leaves off when the output language is Rust;
  the browser front-end does not export it.
  Chapter 05 covers what the option does to the calls.
- **Full-depth DWARF types** (`typedepth`, default-on,
  `decompiler/crates/kuna-analysis/src/analyzers/dwarf/kuna_typedepth.rs`) is the
  type mapper's recursion guard, and it exists because the DIE walk can be handed a
  chain that closes on itself — a `DW_TAG_pointer_type` whose `DW_AT_type` is its
  own offset, a `typedef`/`const` pair pointing at each other — which nothing in
  the format forbids and a truncated or forged `.debug_info` supplies. Upstream
  (`DWARFDataTypeImporter.trackRecursion`) guards it with a **per-DIE-offset
  re-entry counter**: a DIE may be re-entered twice and the third entry is refused,
  which fires only on a cycle because an acyclic chain visits each offset once.
  kuna's port had reduced that to a flat three-hop budget counted over *every*
  link, transparent qualifiers included — which conflates "the same DIE again" with
  "a deep but finite chain". Four DIEs is ordinary C: `const char *const *`,
  `const size_t *`, `char *const []`, `char ***`. All of them ran out of budget and
  fell back to `void`, so a `-g` binary's stack locals, its globals (a truncated
  element type sizes the global at one byte, and the extent is what the container
  query needs — §1.4) and its deeper pointer parameters rendered `void *` while the
  debug info named a concrete type. This restores upstream's counter, with a second
  absolute nesting bound as a native-stack backstop that a Java port does not need;
  termination no longer rests on a cap that also has to be small. Two consequences
  ride along: the qualifier collapse the C++ arm introduced now runs for the C
  callers too — that is what carries an anonymous aggregate's typedef name onto it
  (a local `mbstate_t`, not the shared `anon_struct` every unnamed struct fuses
  into) — and when the borrowed name is one the type factory already holds under
  another kind (kuna registers a core type called `code`, which zlib's
  `inftrees.h` really does typedef an anonymous struct to), the aggregate falls
  back to the anonymous name rather than failing to build and letting the pointer
  arm degrade it to `void *`. Like the other DWARF gates the mapping happens at
  `load file`, upstream of the `option` commands — but unlike `cppproto` this one
  changes how a single fact set is *built* rather than selecting between two, so
  the live gate is the process env var
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_typedepth.rs`) that the
  CLI exports before the load, the same bridge `relocobjects` and `i386_pie_plt`
  use. With `typedepth off` the mapper is the pre-fix budget, byte for byte.
- **Demangling** (`decompiler/crates/kuna-analysis/src/analyzers/demangle/mod.rs
  (demangle_name)`, the `GnuDemanglerAnalyzer` analog) is not a registered pass but
  a loader hook: applied to every funcsym name after `@VERSION` stripping, before
  install. Upstream shells out to libiberty; kuna substitutes the `cpp_demangle`
  (Itanium), `rustc_demangle`, and `msvc_demangler` (`?…` names) crates. A `?…`
  name `msvc_demangler` rejects goes to `undname`, a port of LLVM's
  MicrosoftDemangle, which reads the newer encodings MSVC emits (a deduced `auto`
  return, `operator<=>`, `noexcept` function types, address and member-pointer
  template arguments, vtordisp thunks); its spelling of a compiler-generated
  member is brought to `msvc_demangler`'s (`dtor` is `destructor`) so a member
  reads the same whichever crate demangled it.

  **(kuna, docs/multilang.md) Swift names demangle through a ported, bounded
  name-only subset** (`decompiler/crates/kuna-analysis/src/analyzers/demangle/kuna_swift.rs
  (demangle_swift_name)`), because no crate exists at the maturity of the three
  above: the Vector35 `swift-demangler` builds the real C++ demangler through
  cmake (a native-toolchain dependency this workspace does not carry, floor
  rustc above this repo's), and the pure-Rust alternatives are unvetted 0.x
  crates — for symbol RENAMING a wrong answer is strictly worse than none. The
  subset parses context chains (`module.Type.member`, `V`/`C`/`O` nominal
  kinds, the stdlib `s` contraction), functions with argument labels rendered
  Swift-style (`Swift.print(_:separator:terminator:)`), property accessors
  (`.getter`/`.setter`), `init`/`deinit`, and the common global markers
  (`type metadata`, nominal descriptor, metadata accessor, full metadata,
  metaclass, value witness table) as dotted suffixes; everything else —
  punycode identifiers, witnesses/thunks, specializations, generic machinery —
  **passes through unchanged** (parse-or-passthrough: the label-less function
  arm additionally refuses any signature carrying digits, since a digit there
  could open an un-labeled custom parameter type whose path components are
  indistinguishable from labels). The arm is shape-gated on
  `sourcelang::is_swift_mangled` — prefixes no other scheme owns — and
  option-gated by `swiftdemangle` (default on) through the `KUNA_SWIFTDEMANGLE`
  loadtime env bridge, the `rexthunk` pattern, because names are demangled
  inside `load file` upstream of every option line. The test corpus is
  hand-derived from the mangling grammar (each case cites its production), so
  no third-party fixture text is vendored; the end-to-end gate synthesizes an
  ELF whose symbol table carries the mangled names, since no Swift toolchain
  exists on this host or CI — a real-swiftc fixture is the Swift pack's own
  follow-up.

  **(kuna, DIV-83) Which crate is asked first is decided by a marker, not by
  which one answers.** Rust's *legacy* scheme reuses the Itanium `_ZN…E`
  envelope, escaping the characters an Itanium identifier cannot hold (`$LT$`
  for `<`, `$C$` for `,`, `$u20$` for a space, `..` for `::`). A C++ demangler
  therefore does not decline such a symbol — it sees a well-formed nested-name
  whose components happen to contain dollar signs, and returns the escapes
  verbatim. Asking Itanium first did not fall through to Rust; it produced a
  wrong answer confidently, and every Rust binary rendered its own call graph as
  escape soup (`core::ptr::drop_in_place$LT$…$GT$` where `nm -C` gives
  `core::ptr::drop_in_place<…>`). `sourcelang::is_rust_mangled` identifies both
  Rust schemes exactly — a `_R` prefix, or the legacy `17h<16 hex>E` hash tail —
  so a symbol carrying either goes to `rustc_demangle` first. A C symbol carries
  neither, so the arm is unreachable for one.

  The v0 arm requires the **leading underscore**, and that requirement is
  load-bearing rather than cosmetic. A prefix test written as
  `strip_prefix('_').unwrap_or(name)` keeps the *original* name when there is no
  underscore to strip, which quietly reduces "begins with `_R`" to "begins with
  `R`" -- and since one matching symbol is enough to classify the whole image,
  any C program importing OpenSSL's `RAND_bytes` or `RSA_new` was reported as
  `Compiler::Rustc`. That misclassification is invisible to both parity corpora,
  whose fixtures are `<bytechunk>` images with no symbol table at all, and it
  reaches the reader through the `--language auto` policy of DIV-80: an ordinary
  C binary rendered as `unsafe fn`.

  A Rust demangling is a *type expression*, not a path: it carries generic
  arguments (`drop_in_place<Vec<u8>>`) and trait qualifiers
  (`<aes::Aes256 as crypto_common::KeyInit>::new`). `normalize_rust_name`
  resolves both, and they cannot be resolved the same way — a generic list
  carries no path and is dropped, but a qualifier carries **two** paths and
  dropping it would leave a leading `::`, an empty scope component the symbol
  table rejects outright. `<X as Y>` keeps the type `X` (so the method stays
  attached to the type that defines it), `<impl X as Y>` keeps the trait `Y`,
  and `<impl Trait for Type>` keeps `Type`. Angle brackets nest, so this is a
  depth-tracking scan iterated to a fixed point rather than a pattern match.

  The hard contract is **name-only** reduction: kuna's scope splitter nests on every `::`,
  so signature tails and template argument groups must be stripped or they become
  junk scopes. **Operator names are exempt from that stripping**: `operator[]`,
  `operator()`, `operator<<`, `operator->` and their siblings are spelled with the
  very characters the reduction removes, so a bracket run directly after an
  operator head is copied verbatim and only the parameter list that follows it is
  dropped. Without the exemption every bracket-spelled overload of a class
  collapsed onto one indistinguishable `Class::operator` — 65 distinct functions
  in `libstdc++` shared the name `std::operator`, which is now split into its real
  `std::operator<<` (33) and `std::operator>>` (32). A `<` followed by an
  identifier character is left to the generic path, where it opens a template
  argument list rather than spelling the operator. **Anonymous namespaces are the
  second exemption**, and the one whose absence was fatal rather than merely lossy:
  Itanium renders `_GLOBAL__N_…` as the parenthesized `(anonymous namespace)` and
  MSVC as the backtick-quoted `` `anonymous namespace' ``, so the reduction used to
  delete the Itanium spelling whole and leave an **empty** component —
  `leveldb::(anonymous namespace)::HandleDumpCommand` reduced to
  `leveldb::::HandleDumpCommand`. The scope splitter rejects an empty component
  (§0.4), and because the symbol table is installed inside `load file` that
  rejection aborts the entire architecture build, so a binary carrying one such
  symbol produced no output from any command. An anonymous namespace is the
  ordinary way C++ gives a definition internal linkage, which put a large share of
  real unstripped C++ binaries — a MinGW malware DLL with 1184 such libstdc++
  symbols, and `libleveldb` — outside what kuna could load at all. Both spellings
  now become the identifier `anonymous_namespace`, matching what
  `decompiler/crates/kuna-analysis/src/analyzers/rtti/kuna_itaniumrtti.rs
  (sanitize_class_name)` already gives the same construct, so one toolchain's
  anonymous namespace is spelled like another's and the component survives as a
  real scope. Two translation units that each define `helper` in an anonymous
  namespace still collide on one name — the Itanium mangling is identical for both,
  so no demangler can separate them — and their distinct addresses are what every
  resolver keys on. `demangle_raw` keeps the faithful c++filt text it is asked for,
  unrewritten.
- **Demangled C++ signatures** (`cppsig`, `off|proven|inferred`, default `proven`;
  `decompiler/crates/kuna-analysis/src/analyzers/demangle/kuna_cppsig.rs`, the
  `DemangledFunction.applyTo` / "Apply Function Signatures" analog) is the
  *signature* half of demangling, and the first consumer of the full c++filt form
  the module has always been able to produce. Where the DWARF arm above needs
  debug info, this one needs only the mangled symbol — which is what a **stripped**
  C++ shared library still exports through `.dynsym` — so the two are
  complementary, and where both reach a function the DWARF prototype (ground truth)
  is applied last and wins over the demangled one (a declaration).
  The declaration is parsed out of the demangled *string*, as upstream's
  `GnuDemanglerParser` does: the last depth-0 parenthesis group is the parameter
  list, the last depth-0 token before it is the qualified name, and a trailing
  `const`/`volatile`/`&`/`&&` is the cv/ref qualifier. Each declared parameter maps
  to a pointer of any depth, a primitive (at its LP64/ILP32 width and with the
  sign C++ gives it, so `char16_t` is `unsigned short`), or — as a POINTEE only —
  a named opaque structure carrying the bare innermost class name (upstream's
  placeholder structure). An aggregate passed **by value**, an array, a function pointer, a
  pointer-to-member or an overloaded operator refuses the whole signature: the
  mangling carries no layout, and a wrong width shifts every following parameter.
  The **return type is deliberately not applied**. Itanium encodes one only for a
  template function, so upstream returns null and keeps whatever the analysis
  recovered; kuna expresses that as a prototype with no `outtype`, which the drive
  reads as "lock the INPUT half only" and leaves return recovery running (04 §4.2).
  What makes this a three-valued option rather than a flag is the **implicit object
  parameter**: Itanium mangles a static member function exactly like a non-static
  one and like a namespaced free function, and inventing a `this` that is not there
  shifts every parameter rather than merely losing precision. `proven` therefore
  applies only the shapes the mangling *entails* — a constructor, a destructor, a
  cv-/ref-qualified member (all three take `this`), an unqualified global name, and
  the MSVC forms, which state the access specifier, `static`, and the calling
  convention outright. `inferred` additionally decides the ambiguous nested names
  from class evidence mined out of the binary's own symbols: a scope that owns a
  constructor, a destructor, a cv-qualified member or a `_ZTV`/`_ZTI`/`_ZTS` symbol
  is a class, so its members take `this`; a scope with no such witness is a
  namespace, so its functions do not. This reading refuses a 32-bit MSVC
  `__thiscall` member — that ABI passes `this` in ECX rather than as ordinary
  argument 0 — and reads an MSVC name only off a defined symbol; the MSVC arm
  below replaces it for MSVC names unless `msvcsig` is off. Like the DWARF arm the
  pass runs at `load file`, so both certainty tiers are computed there and stashed
  apart, and the mode selects which of them the analysis commit applies.
- **MSVC declarations** (`msvcsig`, `on|off`, default `on`, applied only while
  `cppsig` is not `off`;
  `decompiler/crates/kuna-analysis/src/analyzers/demangle/kuna_msvcsig.rs`, the
  signature half of Ghidra's `MicrosoftDemanglerAnalyzer`) reads an MSVC-mangled
  name as the full declaration it is, and reads it off the **PE imports** as well
  as off defined symbols. The Itanium reading above sees only `file.symbols()` and
  `file.dynamic_symbols()`, and a PE import lives in the import table, so a call
  through the IAT to `?IsValid@Arr@@QAEHXZ` was named `Arr::IsValid` and had no
  prototype: the `this` that MSVC passes in ECX was dropped, a hidden return
  pointer was left as the call's only argument, and the arguments a callee did
  not claim were handed to the next call (a copy constructor took the four pushes
  meant for the call after it). Unlike an Itanium name an MSVC name states the
  access specifier, `static`, the calling convention, the return type and every
  parameter type, so the arm decides five things from it. The **convention**: on
  32-bit x86 (a PE or COFF image) the stated `__cdecl`, `__stdcall`, `__thiscall`
  or `__fastcall` names the prototype model the pieces are laid out for, so a
  member takes `this` in ECX and a `__cdecl` callee leaves its arguments for the
  caller to pop; any other platform keeps its one default convention, and a
  convention with no model of its own in the spec (only an alias of the default)
  drops the declaration at the commit. **`this`**: a member that is not `static`
  takes one as argument 0. The **return type** is applied, which Itanium cannot
  offer; a constructor or destructor states none and keeps return recovery. The
  **hidden return pointer**: a class, struct or union returned by value comes back
  through a pointer the caller passes after `this`, and the callee returns that
  pointer in EAX — but not always, since MSVC returns a trivially copyable
  aggregate of 1, 2, 4 or 8 bytes from a free or `static` function in EDX:EAX and
  the name gives neither the size nor the triviality. The pointer is placed only
  where it is certain: for every non-static member (which always returns a class
  indirectly), and for any function whose class the image proves non-trivial by
  defining or importing its destructor (`??1`), a vftable (`??_7`), a deleting
  destructor (`??_G`/`??_E`) or a constructor that takes arguments (`??0`, a copy,
  move or user constructor) — a trivial special member is never emitted, so its
  symbol cannot exist. A default constructor is not a witness, because one that
  only runs member initializers is emitted for a class MSVC still returns in
  registers; and a free function returning a class with no witness is refused.
  The **parameters**: a primitive (at the MSVC width: `long` is 4 bytes, `wchar_t`
  2, `long double` 8), a pointer, a reference or a function pointer is placed. A
  class, struct, union or enum passed **by value** has a width the name does not
  give — MSVC copies it into the outgoing argument area at its own size — so on an
  **import** declared `__cdecl` the parameters before it are placed and the rest of
  the list is left open, the way a variadic declaration leaves it (the caller pops,
  so the open tail claims nothing about the stack), and everywhere else the
  declaration is refused: a callee-pops convention would claim a stack adjustment
  that depends on the missing size, and a defined function would lose the
  parameters its own body recovers. Each declaration is checked whole before any
  type is built, so a refused one leaves nothing in the type factory. Overloaded
  operators, which the Itanium reading refuses for its bracket-depth parse, are
  read here (`operator<<`, `operator()`, `operator new`, conversions), since the
  parameter list is found by matching parentheses from the end and an MSVC name
  states its `this` outright; special names (`` `vftable' ``, adjustor thunks),
  data symbols, function templates and the `__vectorcall`/`__clrcall` conventions
  are refused. At the commit an MSVC prototype is parked by entry address on every
  address the import resolver names (the IAT slot and each `FF 25` thunk), its
  model is recorded against that address
  (`decompiler/crates/kuna-decomp/src/infra/architecture.rs
  (Architecture::set_function_prototype_model_at)`), and it is also locked onto the
  function symbol as the prototype-bearing `TypeCode` a `--assert prototype`
  directive would lock (04 §4.1). The lock is what reaches a 32-bit IAT call:
  `ActionDefaultParams` sees the target of a `call [abs32]` as a temporary its
  flow has not linked to the slot yet, and `ActionDeindirect` later merges the
  prototype `query_function` reads off the symbol, so a prototype parked only as
  pieces is not seen there. The commit also records each locked address, and the
  flow makes a call through one of those slots direct before the spec is built
  (02 §2.1), so the locked prototype is copied in at flow instead of costing the
  function a restart. Measured on the local RE-challenge corpus, 175 distinct
  32-bit and 229 distinct 64-bit MSVC PE images that import MSVC-mangled names
  (the `msvcp` iostream and string API in most): calls printed with no arguments
  fall from 13,819 to 11,302 and from 18,858 to 17,355, 5.4% and 8.3% of the
  functions change, and total decompile CPU time moves by +0.3% and -0.5%.
  A parameter after a by-value class is not placed by the declaration, and where
  MSVC constructs that class in its outgoing slot through a pointer — a copy
  constructor, or a call returning into the slot — the call-site recovery refuses
  every slot above the one whose address was taken. So for such an import (one
  by-value class, no `...`) the arm also parks the whole declaration, the class a
  placeholder, and records every entry that builds an object at an address it is
  handed: a 32-bit `__thiscall` constructor (`??0`) and an applied declaration
  returning a class by value; `msvcbyval` (04 §4.4) sizes the class at each call
  from the caller's cleanup. LOSS: where it declines, those arguments render as stores before the
  call (`MakeStack(a1)`, after `Arr::Arr((Arr *)&v1,a2)`, keeps only its hidden
  return pointer). `--option msvcsig off` restores the Itanium-arm reading of MSVC
  names exactly.
- **Source-language detection**
  (`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/mod.rs
  (detect_compiler)`, the `SourceLanguageAnalyzer` detection half) is asked
  for its verdict several times per load: by the loader's language-id choice,
  by pass selection, for the engine fact below, by the `addrtakenentry` gate
  and by the CLI's runtime hints. So it reads the image in place. The PE arm
  tests `.comment` and `.rdata` as one NUL-delimited record stream (a record
  left open at the end of `.comment` continues into `.rdata`) without copying
  either, and decodes only the records around a substring hit of the record
  it looks for. On a 20 MB `.rdata` that is a few milliseconds per ask, where
  copying the section and splitting every record cost a quarter of a second.
  Detection shapes the pass list: `rustc version` records in
  `.comment` or Rust-mangled symbols → the Rust no-return list;
  `.go.buildinfo`/`.note.go.buildid` (any format's spelling) → the Go list plus
  the pclntab pass; a Swift 5 reflection-metadata section (any format's
  spelling of the namespace: `__swift5_…` on Mach-O, `swift5_…` on ELF,
  `.sw5…` in a PE), a Swift-mangled symbol (`$s`/`$S`/`_T0`, held to the
  scheme's next token so an assembler local like `$LN3` is not one), or a
  Swift runtime entry point in either symbol table (`swift_retain`,
  `swift_release`, …, so a stripped binary importing `libswiftCore` still
  reads as Swift) → `Compiler::Swift`, checked after Rust and before the
  toolchain conveniences, and on Mach-O before the Apple-platform fallback
  that would otherwise claim every Swift image for clang. Nothing gates on
  `Swift` yet — a Swift binary's pass set is pinned byte-identical to a
  clang one — the verdict exists so the engine fact below is right and the
  language packs (docs/multilang.md) have a plane to gate on. PE detection
  reads the MSVC Rich header / MinGW `GCC:` records, Mach-O the
  `LC_BUILD_VERSION` family. The `Gcc`/`Clang` values are a kuna convenience
  nothing gates on.

  A Go **PE** names nothing: Go's Windows linker emits only `.text`, `.rdata`,
  `.data` (plus the `.pdata`/`.idata`/`.reloc` bookkeeping), merging the
  build-info blob into the head of `.data` and the pclntab into `.rdata`, so
  the section-name test above can never fire on one. The PE arm therefore
  reads content, and asks two questions
  (`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/mod.rs
  (detect_compiler_pe)`). First, is there a build-info blob where Go's own
  `go version` looks for it
  (`decompiler/crates/kuna-analysis/src/loader/gobuildinfo.rs
  (pe_buildinfo_blob)`): the first writable initialized-data section, at a
  16-byte-aligned offset, holding a header that validates whole
  (`blob_is_buildinfo`) — the 14-byte `\xff Go buildinf:` magic, a pointer
  size of 4 or 8, no unknown flag bits, and a version string (`go1.x` or
  `devel …`, printable) that decodes, inline after zero padding since go1.18 or
  through the header's pointer before. The magic string alone, or a header
  shape with no version behind it, is not evidence. The scan visits only the
  aligned slots, so it costs one byte compare per 16 bytes of `.data` (1.5 ms
  on a 13.7 MB `.data`); on an internally linked Go image the blob is the
  section's first object. Second, is there a pclntab in **read-only** data
  whose table resolves and which the image's own `moduledata` names
  (`decompiler/crates/kuna-analysis/src/analyzers/pclntab/mod.rs
  (readonly_table_present, moduledata_anchored)`): a pointer-aligned record in
  writable data whose first word is the header's address and whose next
  pointer is the name table's (go1.16+, `pcHeader` then `funcnametab`) or,
  after the blob's length and capacity, the functab's (go1.2–go1.15,
  `pclntable` then `ftab`). The linker always writes that record for the
  module's own table. A Go image a C program merely carries as data has none
  pointing at where the copy sits, whichever section holds it: a payload in
  `.data` has a valid blob but its table is in writable data, and one carried
  twice (a const copy in `.rdata`, a writable one in `.data`) has a blob and
  a read-only table whose only `moduledata` names the address the table had in
  its own image. Both questions must hold. The arm runs first, as on every format, and
  returns before the `.rdata` toolchain-record scan the later arms do.
  Nothing else changes for a non-Go PE: its verdict is the same as before. The
  same blob lookup (`buildinfo_blob`) gives the version-keyed `goreg` shells
  their toolchain on a PE.

  Every consumer acts on the **effective** verdict
  (`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/mod.rs
  (effective_compiler, effective_compiler_bytes)`): the `KUNA_SOURCELANG`
  environment override when set, else detection. The override is the
  `sourcelang` option (`auto|c|rust|go|swift`, default `auto`), and it travels
  as an environment variable for the same reason `rexthunk` does — pass
  selection happens inside `load file`, upstream of every per-function
  `option` command, so the CLI binds it to the environment before loading
  (`decompiler/crates/kuna-cli/src/loadtime.rs (binding)`). The engine's copy
  of the verdict is `Architecture::source_lang_detected`, written once at
  `load file` (`decompiler/crates/kuna-console/src/engine.rs
  (bootstrap_from_object_with_isa)`) as a `SourceLang`
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_sourcelang.rs`), with
  the console `option sourcelang` arm layering a per-run force on top
  (`Architecture::source_lang` reports the effective value, and the catalog's
  `current` reports the option — `auto` until a run forces a language). The
  per-function rules that used to read the `source_is_rust`/`source_is_go`
  bools (`rustabi auto`, `reloadarg`'s Go stand-down) read that one fact now.
  Forcing a language never invents facts (forcing `go` on a non-Go image
  enables the pclntab pass, which finds no table); it changes which
  language-gated rules may act. It is also the escape hatch when detection
  misses: a Go PE whose build-info blob was wiped still has its pclntab in
  `.rdata`, and `--option sourcelang go` registers the Go passes, which find
  it.
  "Rust-mangled" is decided by the mangling grammar, not by a prefix
  (`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/mod.rs
  (is_rust_mangled)`). The v0 scheme spells a symbol `_R` followed by a path, and a
  path opens with one of the tags `C M X Y N I B` — but `_R` is not private to
  Rust. Mach-O prepends a platform underscore to every symbol it carries, so an
  ordinary C function named `Run`, `Read` or `RC4_set_key` is spelled `_Run`,
  `_Read`, `_RC4_set_key` in the image and opens the same two bytes. The name is
  therefore parsed, by the same `rustc_demangle` the demangle pass hands it to, and
  a name that does not parse is not evidence: `_RC4_set_key` gets as far as
  declaring a four-byte crate named `set_` and is then left holding `key`, which is
  no instantiating-crate path. On top of that the detector knows which formats
  carry the platform underscore
  (`decompiler/crates/kuna-analysis/src/analyzers/sourcelang/mod.rs
  (is_rust_mangled_in)`): on Mach-O rustc's own v0 symbols read `__R…`, so a
  single-underscore `_R…` there is a C name however well it parses. The demangle
  pass keeps the format-agnostic test, since what it holds is a bare name with no
  image behind it. The strictness is load-bearing rather than tidy: `Rustc`
  selects the Rust output language for the whole binary, turns `rustabi auto` on
  and widens the no-return list, so a single misread symbol re-languages a C
  program.
- **Call fixups** (`callfixup`,
  `decompiler/crates/kuna-analysis/src/analyzers/callfixup/mod.rs`, the
  `CallFixupAnalyzer` analog): a function whose name matches a cspec call-fixup
  `<target>` (the `-pg` `mcount`/`__fentry__` stubs) is tagged with the fixup's
  inject id so the engine replaces the CALL with the fixup body; guarded by
  upstream's only-if-no-fixup-set check so a hand-applied fixup is never clobbered.

The format- and language-gated recoveries (each registered only for its format, so
every other binary's pass list is byte-identical to before the pass existed):

- **Go runtime types** (`gotypes`, Go-detected binaries only, default-on;
  `decompiler/crates/kuna-analysis/src/analyzers/gotypes/mod.rs (GoTypesPass)`):
  phase 1 of the `docs/multilang.md` W3 Go provider. A stripped Go binary
  carries no DWARF, but the linker bakes the runtime's type graph in, and the
  pass walks it: moduledata is found WITHOUT symbols (its first field points at
  the pclntab header, which `locate_header` already finds on a stripped image;
  the anchor is the data-section word holding that address whose next three
  words parse as the `funcnametab` slice — go1.26+ emits `firstmoduledata`
  into its own `.go.module` section, which the scan covers, and a PE folds it
  into `.data` with the rest of the data segment), and the type
  metadata is then found by CROSS-VALIDATION inside the moduledata window in
  whichever of its two historical forms is present — never by hardcoded field
  offsets. Through go1.25: the `types`/`etypes` pair plus the `typelinks`
  slice, sampled entries required to decode as plausible `_type` records.
  From go1.26 the slice is gone: moduledata carries `types, typedesclen,
  etypes` and the records sit consecutively in `[types + 8, types +
  typedesclen)`, enumerated by advancing each record's own descriptor size
  (`internal/abi.Type::DescriptorSize` — the per-kind wrapper, the optional
  uncommon block and its methods, and the kind's trailing arrays), the walk
  accepted only when records decode back to back and refused whole on the
  first divergence. That is what lets one implementation hold across
  go1.18..go1.27's layout drift (verified under go1.22, go1.25 and go1.27;
  the e2e gate is `verify_gotypes`). Typelinks hold the pointer forms
  interface conversion reaches (`*main.Point`), so the walk follows a
  pointer record's elem to the named struct pointee. It interns
  package-qualified named struct shells (fields at their recorded offsets,
  zero-size embedded markers dropped, overlapping or over-extent layouts
  refused whole). A validated Go 1.18 build-info version selects the older
  `offset << 1 | embedded` struct-field encoding: the importer shifts the
  word before checking the field extent. Go 1.19 and later use byte offsets
  directly. An absent or unrecognized version retains the direct-offset
  interpretation; the importer never guesses from a plausible shifted layout.
  The same bounds and overlap checks apply after decoding. Stripped amd64
  and arm64 tests include an embedded pointer field at a nonzero offset.
  Named struct fields held by value are completed before their enclosing
  structs. The bounded iterative walk in
  `decompiler/crates/kuna-analysis/src/analyzers/gotypes/kuna_structorder.rs (complete_order)`
  follows their descriptors even
  when the child has no independent typelink. Pointer fields do not impose a
  layout dependency. Named shells use the factory's completion link, so pointers
  created before field import resolve to the completed record's size and fields.
  This includes self-references and mutually recursive named structs; an invalid
  layout leaves the linked shell incomplete. Cyclic value layouts and malformed
  descriptors stay opaque. A field whose factory type is still incomplete but whose metadata
  declares a nonzero size refuses the enclosing layout instead of disappearing
  as a zero-size marker. True zero-size fields retain the existing treatment.
  The pass also interns the well-known header shells `go.string`/`go.slice`/
  `go.iface`/`go.eface` with their `LangFacet` records
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_langfacet.rs`). Phase
  1 is OUTPUT-NEUTRAL by construction — nothing binds the shells to a
  variable yet, and the e2e proves the decompiled code byte-identical on vs
  off — the knowledge is for the type surfaces and the consumers that follow
  (typed globals, interface dispatch, signature recovery). Deliberately out of
  phase 1: itab/method resolution, generic instantiations, map/chan internals,
  named non-struct aliases and big-endian images. Little-endian 32-bit images
  use pointer-width reads through
  `decompiler/crates/kuna-analysis/src/analyzers/gotypes/kuna_layout.rs (GoImage)`.
  Their base type record is 32 bytes, moduledata and slice words are four bytes,
  and each struct field occupies three words. Header shells and pointer types
  use four-byte words as well. A build-info version identifying Go 1.18 through
  1.25 is required for 32-bit import; unknown versions and the newer 32-bit
  descriptor-region layout are refused until qualified.
  Stripped i386 and ARM tests cover integer, string, embedded-pointer and nested
  value fields, with the existing amd64 and arm64 tests as controls. Interning happens at
  `load file`, so the gate is the `KUNA_GOTYPES` env bridge
  (`decompiler/crates/kuna-decomp/src/p0_knowledge/kuna_gotypes.rs`, the
  `dwarfstructs` pattern), the walk is bounded (20,000 typelinks), and the
  pass registers before `gopclntab`, preserving its appended-last contract.

  Go permits named pointer types that refer to themselves, such as
  `type Pointer *Pointer`, and mutually recursive pointer definitions. The runtime
  field importer in
  `decompiler/crates/kuna-analysis/src/analyzers/gotypes/kuna_fieldtypes.rs`
  walks pointer descriptors iteratively, retaining each distinct pointer layer.
  A repeated descriptor address, an unreadable target or the 64-pointer expansion
  limit ends the chain with an opaque `void` pointee. This retains the field's
  machine-word size and the following fields' offsets without recursing forever.
  Named struct pointees still resolve through the existing struct shells; ordinary
  scalar, string, slice and interface field mappings are unchanged. This is part of
  `gotypes`, correcting a loader crash rather than adding a separate option.

- **Go pclntab** (`gopclntab`, Go-detected binaries only, default-on;
  `decompiler/crates/kuna-analysis/src/analyzers/pclntab/mod.rs`): the runtime
  needs the PC→name table for stack traces, so it survives stripping; the pass
  handles all four header magics (go1.2/1.16/1.18/1.20 layouts) and emits one
  function symbol per entry, so a stripped Go binary renders `main.main` and
  `runtime.*` instead of `sub_<addr>`. It is format-neutral: the table is located
  by its ELF `.gopclntab` / Mach-O `__gopclntab` section, or the
  `.lrodata_gopclntab` / `__lrodata_gopcln` section a link that splits out large
  read-only data gives it, or a scan of the data sections Go places it in. An
  internally linked ELF PIE from go1.25 or older keeps the table in
  `.data.rel.ro.gopclntab` (the relro spelling of `.gopclntab`, which no scanned
  section covers), so that name is on the section list too. The
  scan is the only route on a PE, whose linker writes no pclntab section and
  keeps the table inside `.rdata` among every other rodata symbol, so `.rdata`
  is on the list; and because a PE scan walks megabytes of other data before
  reaching the table, an 8-byte magic-shaped match is only a candidate — the
  header must also describe a table that resolves (a function count in range, a
  functab and a name table that both lie inside the image,
  `decompiler/crates/kuna-analysis/src/analyzers/pclntab/mod.rs
  (table_plausible)`), or the scan moves on. A plausible table can still be
  someone else's: a Go program that `//go:embed`s another Go executable keeps
  it in the same rodata, ahead of its own table, so the scan prefers the first
  table the image's `moduledata` names (`moduledata_anchored`, as in the PE
  detection above) and keeps the first plausible one only for an image where
  no table is named. An entry is admitted only
  when it lands in an executable extent — a corrupt table cannot mint a function
  over data. Because the `functab` also carries each function's **end**, the pass
  feeds those extents to the interior-entry rejection, so a jump-table case block
  or landing pad inside a Go function is no longer claimed as a `sub_<addr>` of its
  own (on arm64 that artifact used to clip every function that contained one).
  The last function ends at the table's closing `etext` entry, so host code an
  external link places after Go's is not swallowed. Go 1.26 stopped storing the
  text base in the header, so an `entryoff` is then resolved against the module's
  `moduledata.text` (the record in `.go.module` / `__go_module` / the data
  sections that opens with the header's address, accepted only when its
  `minpc`/`maxpc`/`text`/`etext` nest) — an external link puts `crt` code and
  `.init`/`.plt` ahead of `runtime.text` — falling back to the lowest code section
  when no record is found.
- **MSVC RTTI** (`rtti`, PE-only, default-off;
  `decompiler/crates/kuna-analysis/src/analyzers/rtti/mod.rs`): find the shared
  `type_info` vftable, byte-search back from each `.?A…@@` TypeDescriptor to its
  CompleteObjectLocator, validate the COL→RTTI3→RTTI2→RTTI1→RTTI0 reachability
  chain (x86 raw-VA vs x64 image-base-relative refs behind a refkind dispatch), and
  label `<Class>::vftable` / `RTTI_*` with the class names demangled by the
  existing MSVC arm. From each recovered `<Class>::vftable` base the pass then walks
  the slot array (`vftable.rs`), bounded at the first NULL or non-`.text` slot, and
  emits one **function** symbol per surviving slot at the address it points at. That
  symbol is named `<Class>::vfunc_<i>` — the class name comes from the RTTI0
  `TypeDescriptor` and the slot index is the only disambiguator MSVC metadata offers,
  since it records no per-method names. The stem is `vfunc_`, not `vftable_`, because
  the name lands on *code*: a class compiled under multiple inheritance genuinely owns
  more than one vftable, so an indexed `<Class>::vftable_<i>` reads as that class's
  i-th table and made `kuna functions` report hundreds of bytes of executable
  `std::basic_stringbuf` code as vtable objects. Only the table itself wears a
  `vftable` name, and it is unindexed.

  The pass runs at every PE load whatever its gate says (its facts are committed
  only when it is on), so its cost is paid by every command on a C++ DLL. Both of
  its byte-searches — from the TypeDescriptors back to the words that reference
  them, and from the validated CompleteObjectLocators forward to the meta slots
  before their vftables — are therefore one scan of the image for every class at
  once, grouping the hits by target and visiting them in image order, which emits
  exactly what a search per class would. A search per class is
  `O(classes × image)`: `torch_cpu.dll` (31,623 type descriptors in 309 MB) did
  not finish loading in 30 minutes that way.
- **(kuna) Itanium RTTI** (`itaniumrtti`, ELF-only, default-off;
  `decompiler/crates/kuna-analysis/src/analyzers/rtti/kuna_itaniumrtti.rs`): the
  GCC/Clang counterpart of the pass above, and a capability with **no Ghidra
  equivalent at all** — upstream's `RttiAnalyzer` is a Microsoft-PE analyzer and its
  GCC class recovery is script-tier, so on a stripped `g++` binary Ghidra leaves the
  vtable as an unnamed `DAT_<addr>`.

  Where the MSVC sibling has to *guess* which bytes are metadata (it byte-searches
  for `.?A` strings and treats `ref − 12` as a candidate structure), the Itanium
  graph offers an **exact anchor**. The three `__cxxabiv1` typeinfo vtables live in
  libstdc++, so on any dynamically linked C++ image every `_ZTI…` typeinfo object's
  leading `vptr` word is an undefined-symbol dynamic relocation naming
  `__class_type_info`, `__si_class_type_info` or `__vmi_class_type_info` with addend
  `2 × ptr` — and `.rela.dyn` is a loader input that `strip --strip-all` cannot
  remove. The relocation's offset *is* the typeinfo address and its symbol *is* the
  flavour, which fixes the object's layout past the `[vptr][name ptr]` prefix. A
  defined `_ZTI…` symbol is a second discovery source for the unstripped or
  statically linked case, its flavour sniffed from the object's shape.

  Each typeinfo's `_ZTS…` type-name string — the bare mangled-name component, which
  no demangler accepts alone — is recovered by wrapping it back into the `_ZTS`
  symbol form and demangling that, the exact analog of the MSVC `??_R0…@8` wrap and
  likewise adding no new demangler. Two details of that string are load-bearing and
  each one silently costs whole classes when missed. A **leading `*`** marks a type
  whose identity is local to one translation unit (ABI §2.9.1: compare `type_info`s
  by pointer, not by string); it is not part of the mangled name, and leaving it on
  makes every anonymous-namespace class — which is how most C++ spells a concrete
  implementation of an exported interface — undemangleable. And the demangled result
  is turned into an identifier by **folding** template arguments in
  (`Vec<int>` → `Vec_int`) rather than by the module-wide `strip_bracket_groups`
  reduction the rest of the demangler applies: two instantiations are two classes
  with two vtables, and collapsing both to `Vec` makes the second lose the idempotent
  symbol-commit race and keep `sub_<addr>` for every method. The `::` split is
  depth-aware so a separator inside an argument list is not read as a scope boundary.

  The `__si_`/`__vmi_` base lists then give the inheritance graph *with its byte
  displacements*, the datum the MSVC path discards along with its `pmd` fields.

  Vtables are reached **from** the typeinfo rather than guessed: every sub-vtable's
  second header word points at its most-derived class's typeinfo, so one scan for
  pointer slots holding a discovered typeinfo address yields them all, and two exact
  ABI constraints reject the coincidental hits (chiefly the base-class pointers
  inside other typeinfo objects, which also hold a typeinfo address) — `offset-to-top`
  is always `≤ 0`, and a real sub-vtable has at least one slot pointing into an
  executable section. A slot whose file word is zero but which carries a dynamic
  relocation is an *imported* virtual method (`__cxa_pure_virtual`, a base method
  defined in another image), so the walk steps over it instead of terminating and an
  abstract interface keeps its true extent.

  The pass emits `<C>_typeinfo`, `<C>_typeinfo_name`, `<C>_vtable` and `<C>_vptr`
  data labels — the last being the value an object's vptr actually holds, two words
  past the header, which is the constant a constructor stores — plus one
  `<C>::vtable_<i>` function symbol per virtual slot, and marks the slot arrays
  read-only. A secondary sub-vtable takes the name of the base subobject its
  displacement identifies (`Widget_vtable_for_Drawable`), and its slot names are
  prefixed accordingly, because a multiple-inheritance class has several sub-vtables
  whose indices all restart at 0. An inherited slot claimed by several classes'
  tables is attributed to the class that **defines** it, using the recovered base
  graph, so `Shape::perimeter` — repeated verbatim in `Circle`'s and `Square`'s
  tables — is named once, for `Shape`. Data labels join the class to the kind with
  `_` rather than `::` because the C printer emits a global by its leaf name, which
  would otherwise render every class's vptr as a bare, ambiguous `vptr`; function
  symbols keep the `::` form, whose qualification *is* rendered at a call site
  (§9, `cppcallnames`).

  The pass is blind to a `-fno-rtti` build by construction: no typeinfo is emitted,
  so no anchor exists and the output is empty. Independent code-pointer-run scanning
  — which would find such vtables heuristically — is deliberately **not** part of
  this pass.
- **Objective-C** (`objc`, Mach-O-only, default-off;
  `decompiler/crates/kuna-analysis/src/analyzers/objc/mod.rs`): walk
  `__objc_classlist` → `class_t` → `class_ro_t` → method lists (both absolute and
  small/relative forms), reading pointer slots through the chained-fixup overlay
  (§1.2) on arm64, and rename each IMP `-[Class sel]`/`+[Class sel]` behind the
  placeholder label gate.
- **PDB** (`pdb`, PE-only, default-on;
  `decompiler/crates/kuna-analysis/src/analyzers/pdb/mod.rs`): Windows' debug info
  lives in a separate `.pdb` the PE only fingerprints, so the pass reads the
  CodeView record, locates the file, applies a hard **fingerprint gate**, then walks
  the global symbol stream (S_PUB32/S_GPROC32) and renames stripped functions behind
  the label gate. Name-level only; types and lines are deferred. A C++ public is
  decorated (`??0Box@app@@QEAA@H@Z`), so the pass reduces it with the same
  name-only demangler the loader applies to a COFF or ELF symbol: `app::Box::Box`,
  nested under its namespace. MSVC spells a compiler-generated member and a
  function-local entity with backtick-quoted phrases; those become identifiers
  (`` Box::`scalar deleting destructor' `` is `Box::scalar_deleting_destructor`,
  `` `ns::f'::`2'::<lambda_1> `` is `ns::f::lambda_1`), as the anonymous namespace
  already does.

  Locating it is a short ordered search
  (`decompiler/crates/kuna-analysis/src/analyzers/pdb/locate.rs (pdb_candidates)`),
  most specific first: an explicit path in `kuna_pdb_path`, then the CodeView
  record's own filename resolved **beside the image**, then `<image stem>.pdb`
  beside the image. The middle tier is the one a `/Zi` build makes free — the
  linker writes the name of the `.pdb` it emitted into the binary, and in a normal
  build tree or release archive that file is sitting right there. What it does not
  do is trust that recorded string as a path: it is content written by whoever
  linked the image, so only its last segment is taken (splitting on `\` as well as
  `/`, since a Windows linker writes the former and a POSIX `Path` does not treat it
  as a separator), it must be a single ordinary `*.pdb` component, and it is only
  ever joined onto the directory the caller already opened the image from. A
  build-machine absolute path, a `..` run, and a Windows drive prefix therefore
  cannot escape that directory.

  The gate is what makes the search safe to run by default, and it runs per
  candidate: a `.pdb` is applied only when its own `pdb_information().guid/age`
  equals the PE's record, so a stale sidecar left beside a rebuilt binary, or an
  unrelated `.pdb` that happens to share the name, is skipped rather than applied —
  wrong names are worse than no names. A skipped-because-mismatched candidate gets
  one `[kuna pdb]` line on stderr naming it: once the search is automatic, silence
  would make "your `.pdb` is stale" indistinguishable from "there is no `.pdb`
  here". A candidate that simply does not exist is not reported; most images have no
  sidecar, and that is not a defect. The cost of the search is per *load* — at most
  three `open` attempts, only on a PE that carries a CodeView record — and the
  `.pdb` is parsed only when one of them opens and matches.
- **FID** (`fid`, default-off, Listing-gated, DB via `kuna_fid_db`;
  `decompiler/crates/kuna-analysis/src/analyzers/fid/mod.rs (FidPass)`): a
  byte-exact port of Ghidra's FunctionID hashing — the operand-masked FNV-1a64
  full hash over a function's instruction stream (mask via the SLEIGH
  `instruction_mask`, x86 NOP padding skipped) — looked up in a kuna `.fid`
  database built by `kuna fid build`. Only a bucket that collapses to exactly one
  name renames (never guess on a tie), and only through the placeholder label
  gate: the stripped-static-library recovery (`sub_4017c0` → `kuna_crc32`) with no
  way to clobber a real name.
- **Format strings** (`formatstring off|static|full`, default `static`;
  `decompiler/crates/kuna-analysis/src/analyzers/formatstring/mod.rs`): what a
  `printf`/`scanf`-family call does with its variadic arguments is stated by its
  format string, so reading that string types them. The pure spec-parser is the
  `FormatStringParser` state machine (length modifiers, conversion specs, `%%`,
  `*` widths, positional args; malformed input parses to nothing). It departs
  from Ghidra's parser in two places. A wide character (`%lc`, `%C`) is typed as
  an `int`-sized unsigned value, the promoted `wint_t` it is passed as, and a
  wide string (`%ls`, `%S`) as a `wchar_t *`. Ghidra's parser returns before the
  length modifier for `c` and `s`, so it types `%lc` as a `char`, which puts a
  truncating `(char)` cast on the argument, and it types `%C` as a pointer. And
  `l` on a floating conversion (`%lf`, `%le`, `%lg`, `%la`) is a `double`: C11
  7.21.6.1p7 gives it no effect in `printf`, and in `scanf` it selects a
  `double` destination over a `float` one, so the input type is a `double *`.
  Ghidra's `longLengthModification` falls through to `unsigned long` for every
  conversion it does not list. With the typing on by default that does not
  mistype one argument, it moves it: the `double` leaves `xmm0` for an integer
  register, the arguments after it shift, and the caller grows phantom
  parameters (e2fsck's `%16.4lf` memory ratio printed its bit counter). `%lp`
  is typed as `%p`. `%z` and `%t` (`size_t`, `ptrdiff_t`) are the `int`, `long`
  or `long long` as wide as a pointer. Ghidra takes `long` unless a pointer is
  narrower than one, which on an LLP64 target (Win64, Windows AArch64) is 4
  bytes for an 8-byte argument: the call keeps only the low half, so
  `printf("%zu\n", (n << 32) | 5)` printed `5` and the function lost `n`. The
  override construction is
  `decompiler/crates/kuna-analysis/src/analyzers/formatstring/apply.rs
  (build_override_pieces)` — the callee's fixed parameters followed by the
  format-derived argument types, with the varargs closed. The override's own
  parameters are left anonymous: a call-site override's parameter names reach the
  CALLER's locals, and a positional `param3` is the same name at every site, so
  two different values in neighbouring branches were rendered under one name with
  only one of them declared.

  The two values differ in **where the format constant is read**, which is the
  whole cost question.

  `full` is Ghidra's `FormatStringAnalyzer`, which is `DecompilerDependent`: the
  format pointer is an input varnode of a lifted `CALL`, so the caller must be
  decompiled, inspected, given the override, and decompiled again. The
  classification there is the name test
  (`apply.rs (classify_variadic_call)`: the name contains `printf` or `scanf`;
  the `scanf` family takes input types, i.e. each value type wrapped in a
  pointer). The loop lives in the shared per-function decompile step
  (`decompiler/crates/kuna-console/src/decompile_step.rs (decompile_one)`,
  chapter [00](00-overview.md) §0.2), so it applies identically to the console
  `decompile` command and to every whole-binary surface; when it ran only in the
  console command the option was inert on `decompile-all` (DIV-66). The second
  decompile is expensive — +43% to +77% on a printf-heavy whole binary, because
  the callers that re-decompile are the large ones — which is why this half is
  not the default. It also needs read-only propagation, since on ARM the format
  address is a PC-relative literal-pool load that only constant-folds through
  `Funcdata::fillin_read_only`; the step enables it for the duration of the
  decompile and restores the prior value. That side effect is much broader than
  the varargs typing itself: with it on, every literal-pool pointer in an ARM
  function resolves, which is why `formatstring full` rewrites most of a Cortex-M
  firmware function's body and not just its `printf` call sites.

  `static` (`analyzers/formatstring/kuna_fmtstatic.rs
  (FormatStringStaticPass)`) reads the same constant out of the **image**, at
  load, and parks the override in `Architecture::format_call_overrides` keyed by
  the containing function — so the first decompile already has it and there is no
  second one. Four facts the program-prep tier already holds are enough:

  1. **Which callees take a format**, and in which slot. Not a name list: a
     built-in signature qualifies when it declares a first-variadic slot and the
     fixed parameter immediately before it is a `char *`
     (`analyzers/protos/mod.rs (variadic_format_prototype)`) — Ghidra's
     `usesVariadicFormatString` read off the declaration instead of off a
     recovered prototype. That admits the `err`/`errx`/`warn`/`warnx`/`error`/
     `syslog` families, which the `printf`/`scanf` substring test never matched,
     and excludes `open`/`fcntl`/`ioctl` structurally (their last fixed slot is
     not a `char *`). `execlp`, whose trailing `char *` is `argv[0]`, is named
     as the one exception. The fixed parameter types come from the same table
     under the same `libctypes` layout the callee's own parked prototype uses, so
     an `fprintf` override carries the same `FILE *`.
  2. **Where it is called**: the Listing's edges into the callee
     (`Listing::refs_to`), with `function_containing` naming the caller. Two edge
     kinds count. A `Call` edge is the ordinary call site. A `Code` edge that is
     not a fall-through is a **tail jump** — `jmp printf@plt`, which gcc emits at
     `-O2` for a function whose last act is the format call — and it is a format
     call site too: the jump hands the callee the caller's own argument
     registers, and the lifter turns it into a `CALL` at the jump's own address,
     so the override keys exactly as it does for a real call. An indirect call
     through a function pointer produces no edge at all and is therefore
     invisible to this pass. All of this ties `static` to the Listing
     (`listing`). The decompiling CLI surfaces (`decompile`, `decompile-all`,
     `decompile-project`) build it under `--mode auto`, `aggressive` and
     `reliable`, whatever the binary's size; only `--mode fast` turns it off. The
     console and the XML datatest paths build it only when asked. Without a
     Listing the pass contributes nothing.
  3. **Which register holds it**: `ProtoModel::assign_parameter_storage` over the
     callee's signature, so the answer comes from the compiler spec rather than
     from a per-architecture table.
  4. **What it points at**: a bounded backward walk of the call site's own basic
     block (48 instructions, stopping at any address the Listing knows something
     branches to),
     re-lifted to p-code and constant-folded forward. The fold models
     `COPY`/`INT_*`/`SUBPIECE`/`PIECE`/extensions plus a `LOAD` from a section the
     image initializes and does not write, which is how an ARM literal pool
     resolves; a partial write invalidates the whole register, a write that
     follows a branch inside the same instruction is killed rather than set (x86
     `cmovcc` lifts to `if (!cc) goto inst_next; dst = src;`, so its destination
     is either value), and an intervening call clears everything. Whatever is not constant there is simply not
     resolved. The call instruction is lifted too, because a MIPS or SPARC call
     runs its delay slot before it transfers: a site, or a `gettext` hop, whose
     call instruction writes the format register is declined, since the window
     before it never sees that write. MIPS is inert today in any case: a
     non-PIC `jal printf@plt` stub is not resolved to an import name, and PIC
     code calls through `$t9`, which leaves no Listing edge.

  The one call that does not clear everything is the `gettext` hop. GNU programs
  pass `_(...)`, i.e. `dcgettext(NULL, "…%s…", 5)`, not the literal — so a format
  argument produced by a `gettext`/`dgettext`/`dcgettext` call is resolved through
  that call's msgid parameter. The translation shares the msgid's conversions
  (that is what `xgettext`'s `c-format` check enforces), and without the hop the
  pass finds almost nothing in coreutils, grep, tar or findutils.

  A parked override is consumed at flow time, so a function that has one never
  adopts IR that was followed before the park.

  Two more conditions decide whether the answer may be used at all, and both
  apply to `full` as well, since the two values build the override the same way.

  **The string must be one the program cannot rewrite.** The resolved address
  is read only when the whole string, NUL included, lies in a section the image
  initializes and does not write (the predicate the fold's `LOAD` uses; the
  `full` loop checks the loader's read-only ranges). A format kept in `.data`
  is whatever the program last stored there: one rewritten from `"v=%d"` to
  `"v=%s"` before the call typed the caller's `char *` parameter as an `int`.

  **The closed prototype must describe the same call.** The override hands
  each conversion to the compiler spec as a named argument, so it is sound only
  where the target passes a variadic argument exactly where it passes a named
  argument of the same type. That is a property of the ABI, recorded per target
  by `decompiler/crates/kuna-decomp/src/p1_partition/kuna_formatstring.rs
  (vararg_abi)` and checked for every conversion by `build_override_pieces`:

  - x86 (32- and 64-bit, SysV and Win64) and AArch64 under the standard AAPCS64
    pass every vararg as a named argument, so every conversion is typed. (Win64
    also copies a floating vararg into the integer register; the `XMM` copy the
    override reads holds the same value.)
  - ARM32, RISC-V, MIPS, PowerPC, and AArch64 in a PE image, pass an integer or
    pointer vararg no wider than a pointer as a named one, and a floating vararg
    differently: ARM hard-float passes it in `r2:r3` and a named `double` in
    `d0`, RISC-V passes it in integer registers, Windows on AArch64 in `x`
    registers, and RISC-V also aligns a double-width vararg to an even register
    pair. A site with a floating or wider-than-pointer conversion is declined
    there. Assigned to `d0`, the `%f` of `printf("x=%f\n", (double)x)` dropped
    the caller's `int` parameter and printed an uninitialized register. On
    ARM32 this reaches ARM-state code only: the window of a Thumb call site
    does not fold today, because the resolver's lift does not see the Thumb
    decode mode the Listing decoded that code with, so every Thumb site is
    declined and renders exactly as under `off`.
  - Apple AArch64 passes every vararg on the stack, so no site is typed there.
    On the in-tree `macho_imports_arm64`, a closed `printf("%d\n", ...)` read
    `w1`, invented a second parameter and printed it in place of `a0 * 3 + 7`.
    Every other processor is declined until it has been checked.

  Whether an AArch64 target is Apple's, Windows' or the standard one is a
  property of the container, not of the language id, so the console records it
  at `load file` (`Architecture::format_vararg_abi`, from the object-file kind)
  beside the other one-bit image facts. An Apple SLEIGH variant or a `windows`
  compiler spec settles it from the id alone. The XML path, which has no
  container, declines every AArch64 site.

  **How the override is installed, and why `static` resolves at load on x86
  only** (`kuna_formatstring.rs (reached_by_default)`); `full` resolves on every
  target the rule above admits. A resolved call's prototype changes more than
  that call. P4 keeps an unknown callee's argument only when the value is used
  by nothing but the call (`Funcdata::only_op_use`, upstream `onlyOpUse`), and a
  use by another call counts against it unless that call is still recovering
  its own arguments and has not taken the value (`check_call_double_use`). So
  the override is not installed closed: the call gets its declared arguments
  followed by `...`, is offered and scores the same trials past them that it
  gets under `off`, and sheds whatever it took there once every call in the
  function has its arguments (chapter [04](04-calls-and-prototypes.md),
  `decompiler/crates/kuna-decomp/src/p4_calls/kuna_formattail.rs`). A phantom
  it would claim under `off` therefore still keeps that value from the calls
  around it. Installed closed from the start it did not, and x86-64 showed
  both ways that goes wrong: gnulib's `version_etc` keeps its `va_list` in the
  lowest outgoing stack slots, so in Ubuntu's `/usr/bin/m4` three
  `__fprintf_chk` calls whose formats are not resolved grew from 9 to 12
  arguments; and clang keeps a small local in the slot its `push rax` makes,
  the call's first outgoing argument slot, so a `sscanf("%d", &a)` destination
  was folded to the value stored before the call.

  What the open tail leaves is the other direction: a declared argument is
  taken for certain, so it vetoes the same value at a neighbour where an open
  call's unscored trial would not have. Over 324 x86-64 decbench binaries and
  25 Ubuntu `/usr/bin` binaries every neighbouring call this moved lost a
  phantom argument (8 calls, all in decbench). Over 206 AArch64 and ARM32
  firmware binaries, measured with the prototype closed from the start, 19 of
  24 went wrong, and one of them is this direction: `ip`'s `parse_rtattr` lost
  the `len` its error path also prints (`subs w3` feeds `parse_rtattr` in `w3`
  and `fprintf` through `mov w2,w3`). The others gained an `x8` of `0` (the
  indirect-result register) ahead of their real arguments or picked up
  leftover registers. Those targets keep the typing behind `full`.

  **The drive has the last word.** The window is only as sound as the Listing's
  edges, and the Listing does not have all of them. Its walk does not read jump
  tables, so the case bodies of a `switch` are decoded by nobody, and a join
  they jump back to looks like straight-line code: when the default path falls
  into that join after loading its own format, the window reads the default
  path's string, and the closed prototype drops the arguments the other formats
  consume, together with the caller's parameter they came from. The
  prototype itself can also be wrong for the drive: in a function whose stack
  pointer the drive cannot track (an `alloca` frame), a closed prototype picked
  up the slot the call pushes its return address into as one more argument.
  The open tail treats that slot as the open call does, so the count now
  agrees there, but the check stays. So after the first drive the
  decompile step checks every parked site against the IR
  (`decompiler/crates/kuna-console/src/decompile_step.rs
  (audit_parked_format_sites)`) and keeps an override only when the call passes
  exactly the arguments it declares and every value that can reach the format
  argument, through copies and phi-nodes, is the resolved string, whether
  directly, as a load from read-only memory, or as the msgid of a
  `gettext`-family call. A contradicted override is withdrawn and the function
  is driven once more without it, so that call renders exactly as it does under
  `off`. The check is cheap and the re-drive is rare: over every coreutils
  binary at `O0`, `O2` and `O2-noinline` and 31 others, no site resolved at
  load is withdrawn. With the prototype closed from the start, 130 were, all
  for the argument count, in the `alloca` frames of `cp`, `mv`, `ginstall`,
  `df`, `stat`, `ls` and `ip`; those calls are typed now. The jump-table join
  occurs in `tar`, where a case body jumps into the window before an
  `__fprintf_chk` with a msgid of its own, and that site is still withdrawn.

  What `static` declines, in full: no Listing; no edge into the callee — an
  indirect call through a function pointer, or a site inside a function the
  Listing's walk never decoded (on x86-64 the walk is not seeded with the
  committed entry inventory, a ceiling shared by every Listing consumer); a format argument written outside
  the call's own basic block, or not constant there, or clobbered by an
  intervening call, or written by the call instruction itself (a delay slot); an
  address with no readable NUL-terminated string behind it;
  a string outside a read-only section; a conversion the target does not pass
  as a named argument (above); a format with no conversions; a site the first
  drive contradicts (above); and a format carrying `%Lf`, whose x86-64
  argument class the override pieces cannot spell (declining the whole site is
  what keeps a `long double` from being mis-parked as an eightbyte and inventing
  parameters). `full` still catches, with its second decompile, a site declined
  for want of a Listing edge or of a constant in the window; the read-only, ABI
  and `%Lf` rules bind it too.

## 1.5 Entry discovery

Function discovery decides what exists at all, so it is deliberately layered from
free-and-exact to speculative:

**The always-on oracle union** (`entry_disc`,
`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs (EntryDiscoveryPass)`)
fuses the feasible subset of Ghidra's `EntryPointAnalyzer`,
`ExternalEntryFunctionAnalyzer`, `FunctionStartAnalyzer`, and the
`GccExceptionAnalyzer` FDE oracle into one additive pass: (1) the ELF `e_entry`;
(2) `DT_INIT`/`DT_FINI` and the `INIT_ARRAY`/`FINI_ARRAY` pointer tables, carrying
Ghidra-faithful names (`_INIT_<i>`/`_FINI_<i>`/`_DT_INIT`/`_DT_FINI`) through the
`entry_names` overlay; (3) every `.eh_frame` FDE's `pcBegin` — the highest-value
oracle on C/C++ binaries, since unwind data survives stripping; (4) the
`_start`→`main` libc-start idiom (x86-64 PC-relative `lea rdi`, the
AArch64/ARM/RISC-V PIE form that loads `main` indirectly through an
`R_*_RELATIVE`-relocated GOT slot, and — for the non-PIE ARM form, which carries
no such relocation — the separately gated `armlibcmain` below) — (kuna) the disassembly-free stand-in for the
call-target sweep the tier cannot do without a Listing; and (5) a minimal always-on
set of three bare x86-64 gcc prologue byte patterns; and (6, kuna) the reset +
handler pointers of an empirically-detected **ARM Cortex-M hardware vector table**
(`cortexm_vector_entries`) — a stripped bare-metal firmware image has no symbols,
no `.eh_frame`, no libc idiom and no `$t` markers, so the hardware vector table at
the base of the loaded image is the only entry source. The table is confirmed when
`word[0]` is a plausible SRAM stack pointer (`0x2000_0000..=0x3FFF_FFFF`) and
`word[1] == e_entry` (the reset vector); the odd (Thumb) handler pointers are then
harvested, LSB-masked, up to the start of code. The table is looked for in every
section the **program headers** load as executable, not only the `SHF_EXECINSTR`
ones (`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs
(phdr_executable_sections)`): a `PT_LOAD` carrying `PF_X` maps its sections as
executable memory whatever their `sh_flags` say, and the table is DATA the CPU
reads, so requiring an executable section header of the *table* was a category
error — what must be executable is what the handler entries POINT AT, which the
harvest still checks. Bare-metal link scripts routinely leave `.isr_vector`
flagged `WA` at the base of the single `RWE` load segment. `SHF_EXECINSTR`
sections are still tried first, so an image that already matched matches the same
section, and an object with no program headers (a relocatable `.o`) has no widened
candidate set at all. Everything is unioned,
deduped, restricted to executable sections, and skipped where a real funcsym
already exists. That funcsym set
(`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs (existing_function_addrs)`)
is itself Thumb-masked on 32-bit ARM
(`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs (thumb_masked)`),
because an ARM/Thumb function's ELF symbol stores the mode bit in bit 0 of
`st_value` and the odd address is not an instruction boundary. Masking it is what
makes the skip comparable with the already-masked `e_entry` candidate — otherwise
a named function is re-emitted as a "new" start and picks up a generated
`sub_<addr>` name — and it keeps the raw odd address from being seeded as a
function start in its own right, which would yield a phantom entry that decodes
mid-instruction to an empty body. The mask is gated to `Architecture::Arm`: on a
byte-aligned ISA an odd entry address is genuine (x86-64 fixtures have real
functions at `0x40071d` and `0x1357`), and AArch64 has no Thumb state. A
discovered ARM `main` whose GOT pointer had the Thumb LSB set
also emits its own `TMode=1` paint (a stripped binary has no `$t` symbol to paint
from). On a confirmed Cortex-M image the ELF `e_entry` seed is additionally
LSB-masked to its even (decode) address, and `cortexm_thumb_paints` region-paints
`TMode=1` (Thumb) across every executable section — ARMv6/7/8-M is Thumb-only, and
a Thumb `BL` does not `globalset` the callee mode, so the region paint is what lets
`main` and the rest of the reset→main call tree decode as Thumb (wired into both
the analysis commit path and the Listing walk's `ContextPainter`). These ARM paths
are strict no-ops on x86-64 and on any ARM object without the vector-table
signature. PE and Mach-O dispatch to their own oracles (`.pdata`/TLS/entry;
`LC_FUNCTION_STARTS`/`LC_MAIN`/`__mod_init_func`). Failure mode: discovery-only —
a wrong entry is a garbage `sub_<addr>`; a missed one is invisible until a caller
overruns into it (§1.7).

(kuna) **The x86-64 half of oracle 4 reads two encodings, because "PC-relative" is
a link model and not part of the idiom.** `main` reaches `rdi` as a `lea
rdi,[rip+disp]` only in a position-independent crt; a non-PIE `_start` hands it
over as a bare address immediate — `mov edi,imm32`, `mov rdi,imm32` or `movabs
rdi,imm64` — immediately before the same `__libc_start_main` call. Matching the
`lea` opcode alone lost `main` outright on such an image, and with it everything
`main` calls, since nothing else seeds the walk into that subtree: a stripped
non-PIE executable built without `.eh_frame` has no second path to `main`, and the
always-on prologue patterns (5) do not match a `push rbp` that is not followed by
`mov rbp,rsp`. The inventory then stopped at the C runtime and one earlier entry
ran on through `main`'s bytes. The immediate forms are read only where the
PC-relative scan finds nothing
(`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs
(x86_64_immediate_main_target)`), so a PIE image decodes exactly as it did.

A bare immediate is far weaker evidence than a `lea` displacement — one opcode
byte, and any four bytes read as an address — so a candidate is emitted only when a
`call` (`e8 <rel32>` or `ff /2`) begins within sixteen bytes of it, when the
immediate lands inside an executable section, and when it is the **only**
immediate in the `_start` window that satisfies both. An ambiguous decode is a
clean miss rather than a guess, the same rule the ARM GOT-offset decode applies to
its candidates. Measured over 1,919 x86-64 ELF executables and shared objects,
1,788 carry the `lea` and are untouched by construction; of the 131 that reach the
immediate scan, 119 were runnable on both builds and two gained `main` — both
verified as real function prologues, and both correcting an earlier entry that had
run on through it.

(kuna) **With no section table, the plausible-code oracle is the program header.**
"Restricted to executable sections" is a filter every oracle above passes through
(`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs
(executable_sections)`), and it reads the section table alone. An image that has no
section table therefore has no executable sections, so the filter rejected every
candidate the oracles produced — including the image's own `e_entry` — and
discovery returned nothing on a file the loader had just mapped perfectly well and
could decompile function by function through `--addr`. Where the section table is
*absent* the `PF_X` `PT_LOAD` segments stand in for it
(`executable_segments`): they are the other, independent description of the same
image, and the one the loader itself works from. The substitution is coarser — a
read-execute `PT_LOAD` also spans `.rodata` and the ELF header — which is why it is
reached only when there is no section table at all: an image that has one has
already had its say about what is code, and is left with exactly the ranges it had.
One image is section-less and yet not a candidate: a **UPX-packed** one, whose load
segments are a decompressor around a compressed blob. Discovering the stub's
handful of routines would bury the far more actionable answer kuna already gives
such an image — "image appears UPX-packed; try `kuna unpack`", which is what a run
that discovers nothing produces — so a load segment carrying the `UPX!` magic
declines the fallback and keeps that behavior (`is_packer_stub`).

(kuna) The **data** half of that oracle takes the same substitution, and for the
same reason. A reference query classifies a candidate data operand by asking
whether its value lands in memory the image maps
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (mapped_ranges)`), and that
question was also asked of the section table alone — so on a section-less image
every data operand answered "nothing is mapped" and was discarded, while control
flow, which never consults it, survived intact. That asymmetry is what an agent
sees: `kuna disassemble` prints `LEA RDI,[0x6b22]`, and `kuna xrefs --to 0x6b22`
and `kuna strings` both answer zero, so the string a program plainly prints is
owned by no function. Where the section table is *absent* the `PT_LOAD` segments
stand in for it, and only there: an image that has sections which are **not** the
runtime layout — a relocatable object, whose section addresses are pre-link and
describe a different address space — is declined a step earlier and keeps
answering nothing rather than classifying every reference against the wrong
partition. The coarseness a `PT_LOAD` carries costs nothing measurable here,
because the value filter (`looks_like_address`) already rejects everything below
the address floor, which is where the inter-section padding and the ELF header of
a low-based PIE live: on a control pair differing only in whether the section
header table is present, the section-less image now answers the *same* data
references as the sectioned one over the same functions, with none added.

(kuna) A Mach-O section carries no allocation bit, and `object` derives its neutral
kind from a dozen `(segment, section)` name pairs, so `__DATA_CONST,__got`,
`__la_symbol_ptr`, `__DATA_CONST,__const`, `__cfstring`, the `__objc_*` and Go
sections, `__TEXT,__stubs` and a kext's `__TEXT_EXEC,__text` all classified as
unknown and the oracle answered "not mapped" for every one of them (GH #1376): an
arm64 dylib's `ldr x16,[x16]` of its `_malloc` GOT slot, and an x86-64 Mach-O's
`call qword ptr [_malloc@GOTPCREL]`, referenced nothing. dyld maps every section of
a segment it loads, so on Mach-O every section is mapped except a debug one
(`S_ATTR_DEBUG`, the `__DWARF` segment). That also makes an x86-64 Mach-O stub's
`jmp qword ptr [slot]` the forwarding veneer an ELF PLT entry already was. Over 52
real Mach-O images (arm64, x86-64, armv7, PowerPC, a kext) and the vendored Mach-O
fixtures, 22,625 rows are added, every one into a section of that kind. An `adrp`
page in such a section is filed only as the carry below allows: a page completed
into another address is a step, not a reference to whatever datum the page starts
with.

(kuna) **Not every `.pdata` record is a function** — the PE exception directory
answers "where does unwinding start from here", which is a coarser question than
"where does a function start"
(`decompiler/crates/kuna-analysis/src/analyzers/entry/pe_entry.rs (pdata_begins)`).
Two record properties separate the two, and both are read from the image rather
than inferred.

The first is `pdatachained` (default-on; kuna). MSVC splits one function across
several `RUNTIME_FUNCTION` records whenever it shrink-wraps a prologue or moves a
cold block out of line: the first record is the function, and every later one
points at an `UNWIND_INFO` whose flags carry `UNW_FLAG_CHAININFO` (bit `0x4` of
the high five bits of the first byte) plus a trailing chained `RUNTIME_FUNCTION`
naming the primary. Its `BeginAddress` is therefore a point *inside* the primary
— typically a register-save or spill run, never a prologue — and claiming a
function there puts a known entry in the middle of a body, which is exactly the
condition S2's `funcboundflow` truncates a fall-through at. The reported symptom
is the whole function: `sub_140002650` in `dobin/redtest` stops four statements
in, carrying the `funcboundflow` truncation warning, because the shrink-wrapped
chunk at `0x140002712` had become `sub_140002712`. Depending on what the
truncated instruction is, the residue is an empty `if` body, a `} while ;` that is
not C at all, or a decompile that fails outright. On, the third dword is resolved
against the loaded sections and a record whose flags set that bit contributes no
entry — Ghidra gates `markAsFunction` on the same predicate. The read is total: a
null `UnwindInfoAddress`, an RVA no section covers, or an empty slice all read as
*not chained*, so the rule can only ever subtract a record it has positively
identified. Almost always nothing is lost by subtracting it, because the chunk's
bytes are reached as the primary's own fall-through or branch target; measured on
an MSVC crackme with 193 records, 32 of them chained, the inventory drops 45
entries (the 32 chunks plus 13 zero-xref phantoms the chunks had seeded) while the
union of every function's extent is byte-for-byte identical at 196,943 bytes.

The residual is a fragment the primary's flow never reaches: it stays inside the
primary's extent but stops being decompiled, because nothing decodes it any more.
The shape that names it is an `__except` funclet entered only through the
exception dispatcher. A second, 240 KB MSVC image sizes the effect — comparing
`decompile-all --json` `line_mappings` on both arms, not extents, since the extent
union is blind to it. Of the 99 entries the option removes there (716 records, 93
of them chained), 97 keep their decompiled coverage inside the primary, and two
24-byte fragments, `0x140007498` and `0x140015dc8`, lose all of it: 48 bytes.
Neither of those two is a `.pdata` record. Both sit in holes in the exception
directory and are in the inventory only while the chunk entries around them are,
nothing in the image references either (`kuna xrefs --to` reports zero on both
arms), and both were mis-started to begin with — `0x140007498` is eight bytes into
a virtual-call thunk that starts at `0x140007490`, and `0x140015dc8` is one byte
into a `mov [rip+…],rax`, which is why its body read a variable nothing assigned.
That is also why the filter is not narrowed to keep a fragment the primary cannot
reach: the decision is taken in `pdata_begins`, inside `load file` and before a
single instruction is decoded, so "does the primary's flow reach this address" is
not a question the oracle can ask — and on this image no chained record loses
coverage for a narrower predicate to recover. Ghidra has the same residual.
`option pdatachained off` restores the previous x86/x64 discovery set exactly —
the stride below is not part of the gate.

The second is the record *stride*, which is not a judgement call and is therefore
not gated. `RUNTIME_FUNCTION` is the 12-byte `{BeginAddress, EndAddress,
UnwindInfoAddress}` only for x86 and x64; ARM, ARM64, ARM64EC and ARM64X use an
8-byte `{BeginAddress, UnwindData}` record whose `BeginAddress` carries the Thumb
bit in its low bit and whose second dword is an `.xdata` RVA only when its low two
bits are clear (packed unwind data otherwise, and never an address to dereference).
Walking an ARM64 table at the x64 stride reads the wrong dwords at the wrong
offsets: on a four-function probe it recovers two entries, one of them only
because record 0 happens to sit at offset 0. The stride follows
`FileHeader.Machine`, as Ghidra's `ExceptionDataDirectory` dispatches it, and a
machine that is neither an x86 nor an ARM variant — IA64, MIPS, SH, PowerPC, each
with its own record layout, a MIPS one being 20 bytes — has no readable shape, so
the directory is left alone rather than misparsed; Ghidra logs "Exception Data
unsupported architecture" and leaves its `functionEntries` null at the same point.
Chained fragments are not decoded on the ARM form — Ghidra does not decode them
either. Ghidra additionally routes an image whose load-config CHPE metadata
pointer is set to its ARM parser regardless of `Machine`; kuna parses no load
config, so an ARM64EC image that declares itself `AMD64` still reads at 12.

(kuna) **An address-taken function is described by nothing else in a PE**, and the
base-relocation table is what finds it
(`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_pereloccode.rs`). The
oracles above answer for functions the image declares — the entry point, an
export, a TLS callback, a `.pdata` record — and the recursive-descent walk claims
every direct `CALL` target. A function reached only through a stored pointer is in
none of those sets: a VM interpreter's handler table, a C++ vtable slot, a
callback handed to the runtime. The witness is an x64 MSVC crackme whose 30-entry
handler table in `.rdata` is read with `LEA RCX,[handler]`; four of its handlers
are leaves MSVC left out of `.pdata`, so `kuna functions` listed 228 entries with
none of them, and the bounder folded each into the function ahead of it —
`sub_140003c50` reported 32 bytes for a 16-byte function.

The relocation directory answers exactly the question the scan needs. It lists the
image words holding an absolute address, because the loader has to fix them up when
the image lands off its preferred base, so a relocated word whose value falls in an
executable section is a *stored code address* rather than a byte pattern that
resembles one. `IMAGE_REL_BASED_DIR64` is read on a PE32+ and
`IMAGE_REL_BASED_HIGHLOW` on a PE32, each against its own pointer width, and the
walk is total: an unreadable block or an RVA no section covers yields fewer
candidates, never an error.

A stored code address is a function start unless it is a label or is not code, and
`.pdata` separates both. A non-PIC switch jump table is a run of relocated
addresses pointing *into* the function that switches on them, so a candidate
strictly inside a `RUNTIME_FUNCTION`'s `[BeginAddress, EndAddress)` is dropped — a
`BeginAddress` itself is kept, being a start the `.pdata` oracle already has. And a
packed or single-section image breaks the executable-section test outright:
`jormungandr.exe` merges its payload into `.text`, so a UTF-16 locale table
(`hr-HR`, `ko-KR`, …) sits at executable addresses and 666 relocated pointers into
it read as code pointers. The same directory settles that too — its records cover
`0x1400091c0` upwards while every one of those strings lies below — so a candidate
must fall inside the span of its own section that the exception table vouches for.
On the witness that costs nothing: `vm.exe`'s records span `.text` end to end, and
the four handlers sit in holes inside it. The span before the first record is not dropped
for good, though: `addrtakenentry` takes the relocated addresses there as
candidates and admits the ones the decoded code shows to be functions — a
frame-less leaf cluster at the top of `.text` is that shape — while the span past
the last record, and a section with no record, stay out.

That guard is also the precondition. An image vouching for no code region — a PE32
with no exception directory, or an ARM/ARM64 PE whose 8-byte records carry no
`EndAddress` — cannot distinguish a jump table from a handler table, so the oracle
**abstains** there rather than seed unvetted addresses; 72 of the 152 PE images
swept are PE32 without `.pdata`, one of them carrying 3287 relocated code
addresses. The rule is not gated: a relocation is the image's own statement that
the word is an address, so the oracle corrects wrong output rather than trading one
plausible reading for another. Measured over 150 of those images, 38 inventories move,
747 starts are added and 31 removed — every removal a start the new seed supersedes,
including `0x140028d1c` in `CrackVM-V2.exe`, which was four bytes into the
`MOV RAX,[RSP+0x28]` that opens the function the vtable slot names.

The object bootstrap paints executable sections as Thumb for THUMB and ARMNT
machine values, and retains that context through the analysis commit. Per-entry
mode evidence for a generic ARM header remains a follow-up: the `BeginAddress`
low bit is masked off by the directory walk without producing a context paint.
Such a header permits mixed ARM/Thumb code, so its machine value cannot supply a
whole-image default. CHPE routing also remains a follow-up.

**The widened vector-table signature** (`cortexmvectors`, default-off; kuna;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_cortexmvectors.rs`)
relaxes all three of oracle 6's confirmation predicates, each of which measurement
over the ARM Cortex-M corpus showed over-constrains real firmware. The table is
data the CPU reads, so a bare-metal link script normally emits `.isr_vector` as an
`A`-only section inside a *read-only* `PT_LOAD` — which is neither
`SHF_EXECINSTR` nor inside a `PF_X` load, so even the program-header widening
above cannot see it. STM32F4 and `-M7` parts put the initial stack in CCM/TCM at
`0x1000_0000`, below the architectural SRAM block. And `e_entry` is the ELF's
start symbol, which a link script is free to point somewhere other than the reset
vector (nuttx points it at `__start`, crazyflie at the `.text` base). With the
option on a candidate is therefore **any allocated section** whose `word[0]` lies
anywhere in `0x1000_0000..=0x3FFF_FFFF` and whose slots from `word[1]` on yield at
least three Thumb handler pointers — a run of handlers replaces the `e_entry`
equality, because two conforming words can occur by chance inside a `.data`
structure and three consecutive ones essentially cannot. The run is counted by the
same harvest loop the oracle then seeds from, over accepted *slots* rather than
distinct addresses (a bare-metal table aims most of its vectors at one shared
`Default_Handler`). The harvest's "stop once the scan reaches the lowest handler,
i.e. the start of code" rule is also conditioned on the lowest handler lying at or
above the table's own base, since a table linked into RAM above the flash it
points at (betaflight) otherwise looks one word long. The widened scan runs
**only where the shipped signature found nothing**, so an image that already
resolved a table resolves the same section with the same harvest: the option can
add discovered entries, never remove one. It ships as its own `AnalysisPass`
rather than as a flag inside `entry_disc`, because a load-time pass runs before
`--option` is applied — the stash-at-load/gate-at-commit shape (§1.1) is what
makes an output-changing discovery flag observable at all. The pass emits entry
facts and the Thumb region paint and deliberately does **not** feed the Listing
walk (§1.6): the walk treats an unconditional `B` as same-function flow, so
seeding an ISR stub that tail-calls a shared handler makes the walk absorb that
handler and drop its own entry, which measured as a net loss. Output-changing
(more functions), hence default-off; ARM-only and real-object-path only, so every
XML datatest is structurally untouched.

**The full pattern corpus** (`funcstart_patterns`, default-off;
`decompiler/crates/kuna-analysis/src/analyzers/entry/patterns/mod.rs`) is the
faithful `FunctionStartAnalyzer` port over the vendored per-arch pattern XML
(x86/x86-64, AArch64, ARM, RISC-V, MIPS, PPC): a candidate is a start iff a
postpattern (the prologue shape) matches at it *and* a prepattern (RET/JMP/NOP
context) matches immediately before it, at instruction alignment. The
`after="defined"`/`validcode` post-rules need a pseudo-disassembler and are a
documented loss. It is the one **deferred** entry pass (§1.1): the sweep is far too
expensive to run at load and discard, so it runs at the commit point once its gate
is known. Output-changing, hence default-off — but (kuna, DIV-20) the
`decompile-all` driver turns it on for non-x86-64 binaries, where it is the
*primary* discovery source on stripped ARM firmware, alongside the always-on
Cortex-M vector-table oracle (6) above: with the vector-table seeds + Thumb region
paint, the pattern scan and the recursive-descent promotion (§1.6) lift betaflight
STM32F405 from 1 to ~1830 discovered functions (and libopencm3 `button` from 1 to
31, with `main` decoding as a real Thumb body rather than A32 garbage).
A candidate strictly inside the extent of a defined function symbol that states
its size is dropped (`entry/mod.rs (sized_function_bodies)`): the size is the
compiler's own statement of where that function ends, so a prologue shape inside
it is its code. gcc sinks a MIPS frame setup past an early `jr ra`
(`bnez a2,L; nop; jr ra; nop; L: addiu sp,sp,-32`), which matches the
return-then-stack-adjust pair, and the pass committed a `sub_` there that
`decompile-all` printed as a second copy of the function's tail; on a big-endian
object, whose analysis view kept its pre-link addresses until it was rebased in its
own byte order, the start landed at the section offset. The aggressive gap walk
(§1.6) follows the same rule for its accepts. Over 1,496 MIPS, PowerPC, SPARC, ARM
and x86 images this removes 492 starts, every one inside a sized symbol, and adds
none. A stripped shared object
keeps the sizes of its exported functions in `.dynsym`, and those filter the same
way; an image with no sized function symbol (a fully stripped executable, Mach-O)
is unchanged. The rule trusts the size: a symbol-less routine that hand-written
assembly places inside another function's `.size`, and that only a data pointer
reaches, loses its pattern start. One with an FDE or a direct call is still found
by those passes.

**LSDA landing pads** (`eh_frame_full`, default-off): the deeper
`GccExceptionAnalyzer` markup — follow each FDE's CIE `L` augmentation to its
`.gcc_except_table` LSDA, decode the call-site table, and emit each landing pad as
an entry; a catch/cleanup block is reached only by the unwinder, so nothing else
can see it. CFI itself (`DW_CFA_*`) is deliberately not recovered — kuna's own
frame analysis rebuilds the stack frame from the code.

**(kuna) FDE interiors are not function starts** (`fdeinterior`, default-**on**,
DIV-61; `decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_fdeinterior.rs`).
A kuna `FunctionSymbol` is an entry address with no extent, so the commit boundary
cannot answer *is this candidate already inside a known function?* — and every
oracle above is free to plant a `sub_<addr>` in the middle of a body it cannot
see. Three do it on ordinary compiler output: the landing pads `eh_frame_full`
emits sit mid-frame by definition; the aggressive gap walk (§1.6) starts one at the
first undecoded byte of an unwinder-only region, which is routinely *mid
instruction*; and the prologue patterns match an aligned `push rbp; mov rbp,rsp`
inside a larger body. Such a "function" inherits its parent's live frame pointer,
so it decompiles with an uninitialised `rbp` and every local becomes a garbage
dereference. `.eh_frame` supplies exactly the missing extent: each FDE records one
function's `[pcBegin, pcBegin + pcRange)` by construction (one
`.cfi_startproc`/`.cfi_endproc` pair), so an entry strictly inside one is not a
function on the unwinder's own authority — the model IDA Pro uses, where
`get_func()` of a landing pad returns the enclosing function taken from the FDE
range. This pass reports those bodies and the commit filters the *fully merged*
entry set against them (after the deferred Listing consumers, so the gap walk is
covered too). Not every FDE describes one function — the linker gives the whole
PLT a single FDE, and every stub inside it is real — so a range is used only when
it holds no other named function start, no other FDE `pcBegin`, and no linker-stub
section (`.plt`/`.plt.sec`/`.plt.got`/`.iplt`/`.MIPS.stubs`). An entry *at* an FDE
start is always kept, so oracle 3's own product survives. ELF-only and inert
without `.eh_frame` FDEs, which covers essentially the whole bare-metal ARM
population (they unwind through `.ARM.exidx`), so the ARM entry-recall options
compose with it unchanged.

**(kuna) Except where a `.cold` fragment is entered more than once**
(`coldentry`, default-**on**;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_coldentry.rs`). GCC's
hot/cold splitting moves a function's unlikely blocks into a separate `foo.cold`
fragment with its own FDE, and when several unlikely paths are split out they are
laid back to back in that ONE fragment, each reached by its own `jmp`/`jcc rel32`
from the hot body. The FDE oracle names only the fragment's first address, so every
later path is strictly inside an FDE body: no metadata oracle names it, and the hot
function's decompile inlines it through the jump. Ghidra makes each of those jump
targets a function, since it is reached from outside every body that holds it; on
Ubuntu 22.04's stripped `/bin/bash` that is 18 entries in `[0x30c3d, 0x312b3]`.
An address `t` strictly inside a single-function FDE body (the `fdeinterior`
eligibility above) is added when (1) a direct `jmp rel32`/`jcc rel32` outside the
body targets it — found by a byte scan of the executable sections for the `E9` /
`0F 8x` encodings and confirmed at an instruction boundary anchored by a known
FDE start, function symbol, or image entry point in the same executable section;
(2) a linear decode of the body from its start lands on `t`; and (3) the instruction before `t` is `ud2`,
`ret`, `hlt` or a direct `jmp`, so nothing inside the fragment flows into it. Guard
3 keeps an ordinary function's shared tail (reached by its own fall-through as well
as another function's jump) whole; an indirect `jmp` does not satisfy it, since the
block after one is a switch case as often as an entry. Candidates are pre-filtered
on the bytes before `t` and a body is decoded only up to its last surviving
candidate. Source candidates are checked in address order by walking instruction
lengths from their nearest known start, once per prefix. The containing instruction
must actually branch to `t`: an `E9` or `0F 8x` inside a `movabs` immediate supplies
no incoming edge, while a genuine prefixed branch still does. Sources without an
anchor in the same section are refused; a byte the decoder rejects (an instruction
SLEIGH does not model, such as `serialize`) is stepped over one byte at a time, as a
linear sweep does, so it does not hide the real branches after it. The pass costs
one scan of executable bytes plus the target and source prefix decodes. It uses
the engine `Translate`, so it runs as a
deferred entry pass at the commit point, and its entries join the inventory *after*
the `fdeinterior` filter (which would otherwise reject every one of them by
construction). x86/x86-64 ELF only; inert without `.eh_frame`.

**(kuna) `.pdata` interiors are not function starts either** (`pdatainterior`,
default-**on**, DIV-155;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_pdatainterior.rs`). The
PE half of the paragraph above, answering the same question from the container PE
actually ships. An x86/x64 PE's exception directory is an array of
`RUNTIME_FUNCTION` records, each holding `[BeginAddress, EndAddress)` — the image's
own statement that the range is one function's body — so an entry strictly inside
one is a point inside a function rather than a function. The oracle that trips it
here is the gap walk (§1.6): on an obfuscated image whose dispatcher recursive
descent cannot reach, it decodes the leftovers and starts a function at the first
undecoded byte, which lands mid-body and sometimes mid-instruction. The
fall-through bound (`funcboundflow`, §2) then truncates the enclosing function's
flow when it reaches one, so the function the image describes decompiles as a
fragment. Eligibility mirrors the FDE test minus the part with no PE analogue —
import thunks live in a section the exception table does not cover — so a range is
used only when it holds no other named function start and no other record's
`BeginAddress`, and only when it does not overlap the range kept before it (which
keeps the list disjoint for the interior search the two passes share). An entry
*at* a `BeginAddress` is always kept, so the `.pdata` start oracle's own product
survives. x86/x64 PE only: the 8-byte ARM/ARM64 `RUNTIME_FUNCTION` carries no
`EndAddress` and an image with no exception directory vouches for no body at all,
so the pass abstains on both rather than guess — the same stance the
base-relocation oracle takes.

**(kuna) Nor are the interiors of PDB procedures** (`pdbinterior`, default-**on**,
DIV-180; `decompiler/crates/kuna-analysis/src/analyzers/pdb/kuna_pdbinterior.rs`).
The exception table only describes functions that need unwind data, so a frameless
leaf has no `RUNTIME_FUNCTION`, and when the compiler also inlined that leaf into
its only caller the out-of-line copy has no caller either. Recursive descent never
decodes it and its name comes only from the `.pdb` (§1.4), so the gap walk sees an
undiscovered hole and accepts an aligned interior instruction whose prologue
matches the image's common one: on an MSVC `/O2` switch cascade that is the
`mov eax,imm ; mov edx,imm` fall-through of a CMOV-lowered case, and the
fall-through bound then drops that case from the emitted C. Every
`S_GPROC32`/`S_LPROC32` record in a module stream carries the procedure's code
length, so the pass reads those streams from the same fingerprint-matched `.pdb`
the naming pass found. A record yields an extent `[start, start + len)` only when
the length is non-zero, does not overflow, maps through the PDB's address map to
one contiguous range (an OMAP-rewritten image can scatter a procedure), agrees with
every other record at the same start, and lies inside one executable section of the
image. Eligibility is then the `.pdata` test with the PDB's own starts added: no
image symbol, PDB public or other procedure start strictly inside, no overlap with
the procedure kept before it. A `.pdata` `BeginAddress` inside a procedure does not
disqualify it, because MSVC splits one function's unwind data across chained
records and the procedure is the authority on where the function ends. The extents
travel on their own channel and are applied after the FDE/`.pdata` suppression,
under two more conditions checked at the commit. First, a procedure rejects
anything only when a function is committed at its start: an entry that survived
the first suppression, a function symbol an enabled pass emits, or a function
already in the symbol table. The naming pass admits starts from the publics, and a
`static` function has an `S_LPROC32` but no public (756 of the 3,268 procedures in
each GH-468 testbed image), so without that condition an entry inside a static
function nothing else found would be removed and its code left with no function at
all. Second, only the entries that function's own code reaches are rejected. The
commit decodes from the procedure's start, following fall-through and jumps but
never leaving the procedure, entering a callee, or falling through a call it cannot
prove returns — one to a target the decompiler treats as no-return (a no-return
fact this commit applies, a function already flagged no-return, or a callee whose
name is on the known no-return list), or one with no resolvable target at all (an
indirect `call [__imp_ExitProcess]` the exception these binaries take, or the
`int 0x29` fastfail). An interior entry is dropped only when it lies inside an
instruction some used procedure's walk decoded (at its first byte or in its middle)
and no used procedure calls it — a callee even in another procedure stays a named
function so its call site keeps naming it. Everything else inside the procedure keeps its entry, because nothing
else renders that code: on a 32-bit MSVC image a `__finally` block, a `catch` block
and the case bodies of a switch whose table the walk does not read all sit inside
the parent's procedure, and hand-written CRT math routines call labels inside their
own procedure. The procedures used are disjoint, so no used procedure's start lies
inside another and the suppression cannot remove the entry that admitted one. The bodies are committed
only while `pdb` is also on, and an image whose CodeView fingerprint does not match
the `.pdb` gets none. x86, x64 and ARM64 PE only; 32-bit ARM abstains because a
Thumb entry may carry the interworking bit, which would put an entry that is a
procedure's start one byte inside it.

(kuna) **The PE CRT entry-function prototype** (`entrymainproto`, default-on;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_entrymainproto.rs
(EntryMainProtoPass)`) is discovery's answer to a question the rest of the pipeline
cannot reach. kuna recovers a callee's parameters from the callee's OWN body — an
ABI argument register read before it is written is a parameter — which is why a
stripped PE's helpers come out correctly typed. It is also why `main` comes out
`void(void)`: a `main` that ignores `argc` and `argv` never reads `rcx`/`rdx`/`r8`,
so body-driven recovery finds nothing, and the agent reading that output sees a
callee declared to take nothing being called with three arguments a few lines up in
its own caller. The entry point is the one place where the arguments are visible
*without* the body, because on a PE the C runtime startup is inside the image and
kuna already decompiles it correctly: MSVC's `__scrt_common_main_seh` fetches each
argument through a named UCRT accessor (`__p___argc`, `__p___argv`/`__p___wargv`,
`_get_initial_narrow_environment`/`_get_initial_wide_environment`) in the
instructions immediately before the call. Those names are imported by the startup
and by nothing else, so the window between the accessor cluster and the next direct
call to a non-accessor names the entry function; the pass scans the executable
bytes for `E8 rel32` rather than disassembling, because the CRT startup is ordinary
compiler output with no overlapping encodings. The parameters are typed at the
WIDTH the call site establishes — the 4-byte `argc` slot and the two pointer-width
slots — and named after the accessor that produced each; they are deliberately not
typed `int` / `char **`, which would assert the C library's declaration of `main`,
and the pass has no evidence for that (the same shape carries `wmain`'s
`wchar_t **`, and a hand-rolled entry point need not be `main` at all). The address
rides out with the prototype as a discovered entry, because the prototype is parked
by ENTRY ADDRESS (`prototypes_at`) and on an obfuscated image whose prologue no
oracle recognises the callee is not a registered function, so the park would be a
silent no-op. Keying it by address rather than by the `sub_<addr>` name minted at
load is what lets it compose with `pemain`, which renames the same callee `main`.

One consequence is worth naming, because it is the price of the recovery rather
than a defect in it. Declaring `argc` makes the first ABI argument register live at
the entry function's own entry, so a call there to an import kuna has no prototype
for now finds a value in it and renders `IsDebuggerPresent(CONCAT44(dat_c,argc))`
where it used to render `IsDebuggerPresent()`. That is the standing behaviour at any
unprototyped callee reached with a live argument register — the same shape as a
call-site argument recovered for an unnamed helper — and the real answer is a Win32
prototype table beside the libc ones (§1.4), not withholding the entry prototype.
Measured over 139 PE crackmes: the byte scan locates a candidate on 37, the guards
reject 7, and of the 30 that fire, 4 gain one such argument — against 30 that gain
the entry prototype.

Three guards keep it from firing where it would be wrong. It is PE-only, and the reason is the
evidence rather than the symptom: a stripped ELF whose `main` ignores its arguments
comes out `sub_<addr>(void)` too, but on ELF the CRT lives in libc — `_start` hands
`main` to `__libc_start_main` and the argument passing happens in another image — so
there is no call site in the object to read. The ELF `main` oracle above finds the
address; asserting three slots there would be quoting the C convention rather than
observing a caller, a weaker claim than this pass makes (and body-driven recovery
already types the arguments wherever `main` uses them). The callee must carry **no** function symbol — a named `main`, from
`.symtab`, an export, a PDB or DWARF, already has a better signature coming from
that source. And a call to msvcrt's `__getmainargs`
shim family inside the window abandons the cluster: MinGW reaches the same three
values through OUT pointers and its shim calls `__p___argc`/`__p___argv` too, so the
accessor test alone matches inside it and the following call is `_set_new_mode`, not
`main`. Seven crackmes images have that shape. The unnamed-callee guard happens to
reject all seven — every candidate the shim produces is a named import — but that is
luck rather than reasoning, so the shim's own accessors are named and bailed on.

(kuna) **The PE user entry** (`pemain`, default-on;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_pemain.rs`). A PE's
`AddressOfEntryPoint` is the C runtime's startup, not the program, so on a stripped
Windows image the function the startup eventually calls is one more `sub_<addr>`.
The runtime is inside the image, and each toolchain calls the user entry from a
site the pass recognises by bytes, in this order:

1. MSVC with the dynamic UCRT, console: the accessor cluster `entrymainproto`
   already scans (`__p___argc`/`__p___argv`/`_get_initial_*_environment`
   immediately before the call). The wide accessors name the callee `wmain`,
   otherwise `main`.
2. MSVC with the dynamic UCRT, GUI: a call to the imported
   `_get_narrow_winmain_command_line` (`_get_wide_winmain_command_line`), then the
   first direct call into the image within 96 bytes whose argument setup references
   the image base, which is `invoke_main` passing `&__ImageBase` as `hInstance`.
   That callee is `WinMain` (`wWinMain`).
3. MinGW: `__tmainCRTStartup` stores `envp` into msvcrt's `__initenv`
   (`__winitenv`) data import immediately before `main(argc, argv, envp)`. The
   store reaches the IAT slot directly or through a `.refptr` word holding the
   slot's address, so both are markers; the next direct call into the image within
   96 bytes is `main` (`wmain`). A GUI MinGW image reaches `WinMain` through
   libmingw32's own `main`, so the name is still the honest one.
4. MSVC with the static CRT, x86-64 only: four consecutive direct calls within 64
   bytes, the second's result dereferenced as a qword, the third's as a dword, all
   four targets local and distinct. That is `invoke_main` with the accessors linked
   in. No name vouches for it, so it is tried only when shapes 1-3 found nothing and
   used only when exactly one site in the image has it.

Shapes 2 and 3 also refuse when two different callees match. An incremental-link
`E9` thunk at the recovered target is followed to the body, which is how a debug
static-CRT image resolves. The name is applied through the `entry_names` overlay
(§1.6) together with the address as an entry. The pass refuses anything that is
not a PE, a callee outside every executable section or at an import thunk or slot,
a callee that already carries a function symbol (a COFF symbol or an export names
it better), and an image that already defines a symbol spelled with the
chosen name. `kuna functions --summary` reports the result as its `main` field.

On the three Flare-On 12 PE samples it names `main` at the address the
challenge's own symbols give: `hopeanddreams.exe` (dynamic UCRT, shape 1),
`FlareAuthenticator.exe` (shape 1) and `ntfsm.exe` (debug static CRT with
incremental linking, shape 4 through the ILT thunk). Neither parity corpus can
observe it, because both are symbol-less bytechunks with no PE container.

(kuna) **The Mach-O `LC_MAIN` entry** (`machomain`, default-on, DIV-111;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_machomain.rs
(MachoMainPass)`) is the same question on the other container, and there the
answer needs no recovery at all. A stripped Mach-O executable answers
`kuna functions` with an inventory of `sub_<addr>` and nothing else, so the one
function an agent needs first — where the program starts — is indistinguishable
from the other twenty-three, and finding it means reading bodies until one looks
like a prompt loop. The image already says which it is, and says it somewhere
`strip` does not reach: `LC_MAIN` is a load command whose `entryoff` field is
documented as the file offset of `main()`, `ld64` emits it for every
normally-linked executable, and `dyld` calls `__TEXT.vmaddr + entryoff` as
`main(argc, argv, envp, apple)`. The name is therefore a restatement of the
container rather than an inference, and it is applied through the same
`entry_names` overlay the dynamic `_INIT_<i>`/`_DT_INIT` names ride (§1.6), so
the commit's idempotent cross-scope probe still lets a real symbol win. It is
spelled `main`, not `_main`: the underscore is the Mach-O assembler's C-symbol
decoration, and the C name is what was asked for.

The prototype rides the same fact, for the reason `entrymainproto` exists — body-driven
recovery has nothing to find in a `main` that ignores its arguments — but it is
typed differently on purpose. `entrymainproto` reports the widths a recovered PE
call site establishes and refuses to assert the C library's declaration, because
the evidence it has is a call site and the same shape carries `wmain`'s
`wchar_t **`. Mach-O has no in-image call site to read (the C runtime that calls
`main` lives in `libdyld.dylib`) and needs none, because `LC_MAIN` *is* the POSIX
`main` by definition: the honest spelling is `int main(int argc, char **argv)`,
which also lets a string literal render through `argv[i]`. `envp` is deliberately
not declared — `dyld` does pass it and a fourth `apple` pointer, but the extra
unused slots cost more noise than they buy, and a `main` that really reads `envp`
still shows the third argument register in its body.

The refusals are what keep the claim honest, and on the 23 Mach-O images of the
RE corpus they account for every one of the 15 the pass declines: 12 already
carry a `_main` symbol at that address (a named entry has a better name coming
from whatever named it, and the pass never overwrites one), and 3 are
`LC_UNIXTHREAD`-only pre-10.8 images whose entry is the crt's `start`, not
`main`, so nothing is claimed. It also refuses anything that is not an
`MH_EXECUTE` Mach-O, an entry outside every executable section, and an image that
already defines a symbol spelled `main`, which would make the by-name prototype
park ambiguous. Of the 8 that fire, 6 change only the declaration line; 2 also
gain one spurious argument at an unprototyped callee
(`___chkstk_darwin(CONCAT44(v7,argc))`) — the same standing behaviour the PE pass
above measures at 4 of its 30, and the same answer applies: a live argument
register at a callee with no prototype is a prototype-coverage problem, not a
reason to withhold the entry declaration. Structurally inert on every ELF, PE and
COFF target, which is also why neither parity corpus can observe it in either
direction: both are symbol-less ELF bytechunks.

(kuna) **The non-PIE ARM crt1 entry** (`armlibcmain`, default-on, DIV-132;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_armlibcmain.rs
(ArmLibcMainPass)`) is oracle 4's question again on the container that answers it
least directly. Oracle 4's ARM path is written around a relocation: crt1 loads
`main` from a GOT slot, and the slot is identified by the `R_ARM_RELATIVE` a
position-independent image must carry to relocate it. A non-PIE executable
carries no such relocation, because the linker knows the final address and simply
stores it — so the cross-check finds nothing, the oracle returns `None`, and
`main` is never discovered.

The cost of that miss is not a shorter inventory, which is the reason it survived
so long unnoticed. A kuna `FunctionSymbol` has no extent, so a discovered entry
is reported as running to the next one; on a stripped image the whole gap between
the last discovered entry and the end of `.text` is therefore *nominally* owned by
whichever entry precedes it — typically an `INIT_ARRAY` routine that ends in an
unconditional branch a few instructions in. Asking "is this address covered?"
answers yes. But the recursive-descent walk follows that routine's real control
flow, stops at its real terminator, and never decodes the rest of the gap, so
every literal the missing code loads has no reader: `kuna strings` reports the
program's own prompt with `xrefs_count 0` and an empty `functions` list, and
`kuna xrefs --to` that address finds nothing. On the witness (crackmes.one
`5ab77f5d33c5d40ad448c69c`, a stripped ARM keygen-me) `_INIT_0` declared a
3368-byte extent from `0x83e8` and the walk stopped 36 bytes in, at the `b 0x8350`
at `0x8404` — leaving `main` at `0x8cf8`, and the `ldr r0,[0x9024]` four
instructions before its `printf` call, undecoded.

The pass decodes the `_start` window as A32 and reads the value `r0` holds at the
call, in the two shapes glibc's ARM `crt1.o` has shipped: the classic literal-pool
form, `ldr r0,[pc,#imm]` whose pool word IS `main`'s address; and the GOT-indexed
form a modern `-no-pie` link supplies, `ldr r0,[pc,#imm]` followed by
`ldr r0,[rN,r0]`, where the pool word is a `.got`-relative offset and the slot at
`.got + off` holds `main` — written by the linker, with no dynamic relocation to
find it by. The GOT base is taken to be the `.got` section address, the same
invariant oracle 4's PIE path already relies on rather than simulating the
two-load-plus-add base computation.

Both shapes are anchored on one landmark: the `bl` whose target is the PLT stub
the import table names `__libc_start_main`. That is what makes the recovered word
`main` rather than a plausible code address — the ARM procedure call standard
puts the first argument in `r0`, so the last write to `r0` before that call is by
definition what the C runtime is being handed. Without the landmark nothing is
claimed, which is also the refusal that covers a static link and any entry point
that is not a C runtime at all. The pass further refuses anything that is not a
32-bit ARM ELF, a Thumb `_start` (glibc's ARM crt1 is A32), a `bl` with no
`ldr r0,[pc,#imm]` before it in the window, a recovered address outside every
executable section or equal to `_start` itself, and one that already carries a
function symbol — whatever named it has the better name. The address is emitted
through the same `entry_names` overlay (§1.6) as `main`.

Measured on 143 images — the 129 object fixtures of the workspace suite plus every
ARM binary in the RE corpus — it fires on exactly 2, both stripped non-PIE ARM
ELFs, and on both it adds exactly one function and moves no emitted C: every
pre-existing function's body is byte-identical in both arms, and the only other
change is that the gap-fill extent above it shrinks by the length of the function
now sitting there. It is structurally inert on the PIE ARM images oracle 4 already
resolves, and neither parity corpus can observe it for the reason `machomain`
cannot: both are symbol-less ELF bytechunks with no PLT.

(kuna) **The ELF libc-start `main`** (`elfmain`, default-on;
`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_elfmain.rs
(ElfMainPass)`) closes the gap the two passes above leave open. Oracle 4 already
recovers this address on x86-64, AArch64, ARM and RISC-V — that is what it was
written for — but it hands it to discovery as an address and nothing more, so on
a stripped ELF the program's own starting point arrives in the inventory as one
more `sub_<addr>` carrying whatever reading its body alone produces. On coreutils
`fmt` built `-O2` and stripped that is `unsigned long sub_26a0(int a0,char **a1)`:
the two slots exist because this `main` happens to read both of them, their widths
are right, and everything a reader actually wants is absent — which function this
is, that `a0` counts the strings `a1` points at, and that the value handed back is
the process exit status. On a `main` that reads only `argc` the same address comes
out `unsigned long sub_1405(int4 a0,unsigned long *a1)`, and on one that ignores
its arguments entirely, `void sub_<addr>(void)`.

The return type is the half of the declaration body-driven recovery can never
supply, and it is the half that is visible at every call site: `main`'s value is
consumed by `__libc_start_main`, outside the image, so nothing in the object
constrains it and kuna types it from the widest register write it can see. The
parameters are the half it supplies only by accident. Both are stated by the C
runtime's contract — the first argument to `__libc_start_main` IS `main`, and what
that runtime then calls is `main(argc, argv, envp)` — so this pass applies the
name through the `entry_names` overlay (§1.6) and parks that prototype by it,
exactly as `machomain` does from `LC_MAIN`, and for the same reason it spells the
real `int`/`char **` rather than `entrymainproto`'s call-site widths: a glibc
crt1's first argument is the POSIX `main` by definition, where a recovered PE call
site of the same shape can be `wmain`'s `wchar_t **`.

All three of those arguments are declared, including the `envp` most programs
ignore, and the reason is that the parked prototype is applied LOCKED. Declaring
two parameters is not a smaller claim than declaring three: it asserts that there
is no third one, and on a `main` that does read `envp` that assertion deletes a
parameter recovery had already found. The entry value stops being an input, the
read of it becomes an uninitialised local, and the emitted C passes that
undefined local on — which is what the in-tree ARM fixture `armlibcmain_le32`
@0x103dc did under the two-argument form, rendering `unsigned int v4; // r2` with
no assignment anywhere and still handing it to `__printf_chk`. Nothing readable at
load time separates that `main` from one that truly ignores its third argument:
it never touches `r2` at all, it sets up `r0`/`r1` and branches, and the only
evidence that `r2` carries a value is the callee's own signature. So a body walk
looking for a read of the third argument register would see nothing in either
case, and of the two mistakes only one is wrong output — an `envp` the program
ignores is an unused parameter in a declaration that is true of every hosted C
program, while an `envp` dropped from a program that uses it is a lie. The
declaration the runtime actually makes is therefore the one applied on the
stripped path, where the body-read arity is not probed.

The lock costs something in the other direction, and the corpus says how much. A
`main` whose body reads an argument register *past* the third keeps that read
only while the signature is body-driven: an undefined register read has nowhere
else to go, so recovery makes it a parameter and fills in the slots before it to
reach one. Declaring the three real ones takes that home away, and the value goes
one of two ways — dropped from the call site it was being handed to, or, when the
body stores it, declared as a local that nothing assigns. Over the 775 stripped
decbench ELFs, 645 have a `main` this pass names, 28 of those recover more than
three parameters from the body, and 13 of the 28 render at least one such local.
On the other 15 the body also writes that register somewhere, so the demoted slot
becomes an ordinary assigned local (shadow `usermod` @0x6340 assigns its `a5`
from `*v13` on five paths) or goes away with the fabrication entirely.
None of the extra slots is a real parameter: the runtime passes three, and on the
two loudest cases — openssh `sftp` `-O2` @0x5250 and shadow `login` `-O2` @0x3d20
— the unstripped twin's DWARF declares `int main(int argc, char **argv)` for
both, the forwarded `r8`/`r9` being an undefined read a variadic call site hands
on. So the lock does not delete a parameter that exists; it changes how an
undefined read is rendered, and on coreutils `true`/`false` the same flip is
plainly better, replacing the `undefined16 sub_2540(int a0,...,unsigned long a3)`
whose body ends `return v2._0_16_ << 0x40` with `return 0`. Both shapes are
pinned rather than only described: the in-repo fixture `elfmainextra_x86_64`
@0x1026 reads `r8` into a call argument and stores `r9` to a global, so its
body-driven signature is `unsigned long sub_1026(unsigned int a0,unsigned long
a1,unsigned long a2,unsigned long a3,unsigned long a4,unsigned long a5)` and the
default arm shows both losses at once (`tests/stages/kuna-elfmain.xml` §§5-8,
`tests/cli/elf-main-extra-register-args.json`). Whichever way call-site argument
recovery removes the fabrication, those assertions move.

The address is oracle 4's own (`libc_start_main_target`), never a second decode,
so the pass cannot disagree with the entry the discovery set already contains.
The one shape oracle 4 cannot see is the non-PIE ARM32 crt1 above, and there
`armlibcmain` already emits the entry and the name; `elfmain` contributes only the
prototype at that address, so `--option armlibcmain off` still restores that
pass's inventory exactly and the by-name park simply finds no `main` to land on.

What keeps the claim honest is that oracle 4's evidence is good enough to add a
function entry but not, on its own, to assert that the function is the C `main` —
its x86-64 arm matches an argument-setup encoding and a following `call`, and any
four bytes read as an address. So the pass additionally requires the image to name
`__libc_start_main` at all, in its static or dynamic symbol names with the GNU
version suffix stripped; that is the C runtime's own name, and a fully stripped
static image that states neither is refused rather than guessed at. It further
refuses a non-ELF image, a recovered address equal to `_start` or outside every
executable section, and an address that already carries a function symbol other
than `main`, whose name stays.

An executable that keeps its symbol table names `main` itself, and that name
stays, but the declaration does not come with it: the symbol is a name, and a
`main` whose body alone is read comes out with anonymous slots — the in-tree
`elfmainnamed_x86_64` fixture prints `unsigned int main(int a0,struct_0 *a1)`,
with `score(a1->field_0x8)` where its source says `score(argv[1])`. crt1
references `main` by name and the static linker resolves that reference to the
image's global `main`, so in an image that names `__libc_start_main` its defined
function `main` IS the routine the runtime calls, whether or not oracle 4 can
read `_start` (it has no i386 or MIPS arm, and a musl crt1 is a different shape).

Here the declaration may only name and type the parameters `main`'s own analysis
recovers — never add one and never drop one. Adding one is wrong because a
declared parameter is a live input: a `main(void)` that calls `printf` would hand
it `argc` (`printf("%d",tick(CONCAT44(v1,argc)))`), and a `-O0` `main` would
merge an undeclared-but-spilled third register with later `rdx` scratch. Dropping
one is wrong because the body's reads of it become unassigned locals. Nothing the
pass can read at load time gives that count: a `main` that passes `argc` and
`argv` straight to its first call reads them only through the call, and gcc's
interprocedural register allocation lets `argv` sit in `rsi` across a helper
call before it is read. So the count is taken from the analysis itself, at
decompile time.

The pass parks the full `int main(int argc, char **argv, char **envp)` through
`AnalysisOutput::main_decl_at`, keyed by ADDRESS (the symbol's, an ARM mode bit
cleared), and the commit keeps it OFF the symbol, in
`Architecture::elfmain_main_decl`. When the drive reaches that entry with no
other prototype for it — no operator declaration, nothing another stream parked
(a DWARF `main` is decompiled against DWARF alone) — it lays the declaration out
under the default calling convention
(`decompiler/crates/kuna-decomp/src/p1_partition/kuna_elfmaindecl.rs (Runtime)`), locks
only its `int` return (the inputs stay unlocked), and seeds the function with
the storage, name and type of `argc`, `argv` and `envp`
(`decompiler/crates/kuna-decomp/src/infra/decompile_drive.rs (decompile_func_full_with_objects)`).
Parameter recovery runs with the same machinery as with the option off; the one
input to it that changes is the locked `int` return. That return can also remove
an argument the option-off analysis invents for a call, a value only passed
through the registers it would otherwise have recovered as the return:
`protoorder_cyclestruct_x86_64` prints `look(v2)` where the option-off output has
`look(v3,v2)` and the source `look(&leaf)`. Every such case found agrees with
the source. The seed itself is consulted only through one question,
`decompiler/crates/kuna-decomp/src/p1_partition/kuna_elfmaindecl.rs (read_slots)`: are the
function inputs the body reads, in any storage the convention passes a parameter
in, exactly the first k runtime slots? When they are, type inference gives each
such input its runtime type
(`decompiler/crates/kuna-decomp/src/p1_partition/kuna_elfmaindecl.rs (input_type)`, at the
same unlocked seam `calleevote` votes through in `build_localtypes`); the type
holds through propagation (`propagate_type_edge` does not overwrite it) and record
synthesis gives way to it (`kuna_structsynth.rs (accepts)` refuses a runtime
`argv`), but it carries no type lock, so the ancestor-realistic trials at the next
call treat the input as they treat any recovered parameter. And
`coreaction_protos.rs (update_input_types)` gives the recovered parameter its
runtime name (`param_name`). The whole declaration is therefore applied in the one
decompile the function was getting anyway.

`decompiler/crates/kuna-decomp/src/p1_partition/kuna_elfmaindecl.rs (settled)` checks the
finished function: its parameters must be no parameter at all where the body reads
no runtime argument, or exactly the first k runtime slots, each named. Otherwise —
a `main` that reads `argv` but not `argc` (the recovery fills the unread slot
ahead of it), or `envp` alone, or hands `argc` to a callee as the whole 64-bit
register `argc` is the low half of, or reads past the third argument — it is
decompiled again without the seed and prints exactly what it prints with the
option off; the locked `int` return was the only thing the seed had changed. That
second decompile repeats `main`'s whole decompile, so a `main` that falls back
costs it twice: on small crackme mains that is 10-20 ms, 6-13% of the whole
process, and a large one pays its full decompile again. So
the fixture prints `int main(int argc,char **argv)` with `score(argv[1])`, a
`main(void)` prints `int main(void)`, and a `main` that reads `envp` declares all
three. The body differs from the option-off output only by the parameters' names
and types, the casts those types remove (and the locals that fold together once
two values share a type), and the `int` return: `return 0xffffffff;` prints as
`return -1;`, and a tail call whose value `main` returns as `return f();`. The
`int` return can restructure a very large `main` too, and costs there: an
8,000-line crackme `main` decompiles 6.7% slower (176.5 s to 188.4 s). Callers
of `main` see no declaration. In a whole-binary run `main`'s calls reach its
callees as any function's do, so what changed there carries one step further: a
callee handed `*argv` can take `char *` from `calleevote`, and a callee whose
value `main` now returns can take an `int` return from `voidret` (in-tree,
`fmtedge_x86_64`'s `show`, and the tail-called `accepted`, `emit` and `probe` of
three other fixtures).

The claim is refused on anything but an executable — `ET_EXEC`, or an `ET_DYN`
carrying a program interpreter or a `DT_FLAGS_1` with `DF_1_PIE` (a static-pie)
— so a shared library that exports `main` (an `LD_PRELOAD` shim, a plugin) is
left alone; when the image spells `main` more than once at different addresses,
or as anything but a defined function; and when oracle 4 decodes a different
address than the symbol's, since then two pieces of evidence disagree. An image
with no `__libc_start_main` name is refused here too: a bare-metal `main` is
called by a reset handler with nothing in its argument registers, and nothing
licenses `argc`/`argv` there.

Naming an address a second time makes one thing visible that was latent before it:
`--define-function <start>[-<end>]=<name>` and a discovery pass can now reach the
same address with different spellings, and which one is *reported* was decided by
`entry_name_rank`'s length tie-break, so `main` would quietly displace a caller's
`stage1`. A caller's declaration is an assertion, so it now outranks every
discovered name at that address
(`decompiler/crates/kuna-console/src/engine.rs (ConsoleProgram::declare_function)`
records the declared spelling, and both canonicalizers sort it first); the
discovered names stay as aliases, so a name-keyed lookup still resolves through
them.

The same `entryoff`-is-not-a-VMA fact is what every *reporting* surface has to
know, so it is stated once as
`decompiler/crates/kuna-analysis/src/analyzers/entry/mod.rs (image_entry_vma)`
rather than re-derived. `object`'s `File::entry()` hands back the raw header/
load-command field, which is already a virtual address for an ELF `e_entry`, for a
PE `AddressOfEntryPoint` and for a Mach-O `LC_UNIXTHREAD` (the saved thread state's
PC), and is a `__TEXT`-relative file offset for `LC_MAIN`. Reporting that field
directly answers `0x1ce0` for a program whose `main` is at `0x100001ce0` — an
address that matches no function, so the name resolves to a bare hex string and any
reachability walk rooted there returns nothing. The helper rebases only the
`LC_MAIN` case (via `macho_main_entry_vma`, which answers for nothing else) and
falls through to the raw field otherwise, so an `LC_UNIXTHREAD` image does not have
`__TEXT.vmaddr` added to an address that already carries it. A `0` entry is
reported as absent rather than as `0x0`, because a relocatable declares no entry
and `0` is a real address there. The loader keeps that answer, after the ELFv1
descriptor resolution of §1.3 and the ARM Thumb-bit fold, as
`decompiler/crates/kuna-analysis/src/loadimage_object.rs (ObjectLoadImage::image_entry)`,
and every reporting surface reads it from the loaded program's image metadata
instead of parsing the file again: `kuna functions --summary`'s
`entry`/`reachable_from_entry`, `kuna decompile-graph`'s `isEntryPoint`, and the
`kuna decompile-project` README's entry row.

**Address tables** (`addrtable`,
`decompiler/crates/kuna-analysis/src/analyzers/addrtable/mod.rs (AddrTablePass)`)
scan `.rodata`/`.data` for runs of pointer-width values all landing in executable
sections — vtables and absolute function-pointer arrays — emitting data symbols
plus a read-only range (never entries, never switch ranges; in-function switch
recovery is the inherited S2 engine machinery, a different thing entirely). Ghidra
ships this analyzer disabled, and kuna goes one further: the pass is implemented
and tested but **left out of the registered pass list** (`passes.rs` keeps its
registration commented out), because a pointer-run scanner over-accepts and the
relocation guard that defends it is weak on non-PIE executables.

## 1.6 The Listing tier

The Listing model (`listing`, default-off as an engine option;
`decompiler/crates/kuna-analysis/src/listing/mod.rs (Listing)`) is the program-wide
recursive-descent disassembly the analyzer tier otherwise lacks — three read-only
sub-models behind one facade: instructions, cross-references (call/code edges both
directions), and discovered functions. It is built **at the deferred commit point**,
not at load, when either the full `listing` tier or the bounded
`fast_funcdisc` consumer requests it. Both gates are `option` lines applied after
`load file`, and the decoder is the engine's own SLEIGH translator, whose loadimage
is attached only after the load-time passes run
(`passes.rs (run_listing_consumers)`, driven from
`engine.rs (commit_pending_analysis)`).

The build: seed with the union of real funcsym entries and the §1.5 oracle
discoveries, exec-filtered and deduped (`passes.rs (listing_seeds)`), plus the full
prologue-pattern starts when `funcstart_patterns` is on. The walk
(`decompiler/crates/kuna-analysis/src/listing/walk.rs (walk)`) is a two-level
worklist mirroring the S2 flow-follower's design without its weight: an outer
function worklist (every direct CALL target becomes a new function entry — the
program-wide recursion `FlowInfo` deliberately never does) and an inner
per-function instruction worklist over branch and fall-through successors, bounded
by the executable ranges and monotonic visit sets. The per-instruction body is
`walk.rs (step)` and exists exactly once: it files its record and its references
through sinks, and offers the successors it found to a `Successors` sink rather
than pushing them onto a worklist itself, so a driver that routes successors
somewhere else still runs the identical decode-and-claim policy. Indirect targets are recorded
with their computed/indirect predicates but contribute no static successor.

(kuna) Assembly capture retains operand bodies as per-instruction `String`s,
but mnemonic spellings repeat heavily across a Listing. The walker interns each
captured mnemonic into an immutable `Mnemonic` handle backed by shared text,
with one pool per serial walk or parallel decode lane. Records on a lane then
share one mnemonic allocation per distinct spelling; empty text uses an
allocation-free sentinel. Parallel lanes keep independent pools, so this does
not add a global lock, and identical spellings in different lanes may still
have separate allocations. The public `decode_one` result remains `String`;
`Insn` and `InsnLite` expose the string-like `Mnemonic` wrapper, so clients that
construct those public records directly must convert text with `.into()` or use
`Mnemonic::from`. This changes retained text ownership, not how assembly is
rendered: the interning sink receives the same callback from
`Translate::one_instruction_with_assembly` that `decode_one` captures.

(kuna) That `Successors` seam is what lets the same walk run on **N decode
lanes** under `kuna --jobs N`
(`decompiler/crates/kuna-analysis/src/listing/kuna_pdecode.rs`). On a 147 MB
x86-64 binary the walk is 71 seconds of an 80 second load, essentially all of it
SLEIGH decode, and the decompiler proper cannot thread — but this walk is not the
decompiler. The partition rule is a single sentence: **the sorted seed list is cut
into `32 x N` address intervals, and a lane decodes only the addresses it owns.**
A successor that falls outside a lane's interval — a branch target, a
fall-through, or an admitted CALL target — is routed to the interval that owns it
instead of being decoded locally, so exactly-once decode holds by construction,
with no shared visited map and no per-address atomic. The lanes run
bulk-synchronously: each claims intervals from an atomic cursor, runs them to
local quiescence, delivers its crossings into the owners' inboxes at a barrier,
and repeats until a round delivers nothing. Two rounds on that binary, eight on a
seed-starved image; the worst case is the longest chain of interval-crossing
discovered-function edges. The shards are then unioned in address order: the
seeds are pre-inserted exactly as the serial walk pre-inserts them, so a seeded
entry keeps its name, and each shard's discovered records fold in behind them.

The lanes produce the serial walk's Listing, byte for byte, and the argument has
two halves. First, under the gate below, `decode_one(a)` is a pure function of
(address, image bytes, context values): a language with no `ContextCommit`
constructor cannot write the context database from a decode, and the loader's
512-byte staging window is unobservable when every executable address is mapped
(the window only ever changes an answer for a fetch whose *first* byte is
unmapped, and every fetch the walk makes starts inside an executable range).
Second, the serial walk's output is the least fixpoint of a monotone system over
a finite address lattice — seeds and admitted CALL targets are functions,
functions and successors are instructions — and the lanes evaluate those same
equations, each address assigned to exactly one lane, with every cross-lane fact
delivered at the next barrier. Chaotic iteration over a monotone system converges
to the same least fixpoint whatever the schedule. The two first-writer-wins lines
in `walk.rs` are neutralised rather than avoided: the already-decoded test cannot
race because ownership is total, and the function claim inserts a record that is a
constant function of its address. Nothing downstream can see the schedule either —
every consumer iterates address-ordered maps, and `fast_funcdisc` sorts and dedups
again.

The gate is all-or-nothing and is evaluated once, before any thread is spawned;
whatever it refuses runs the serial walk, which is byte-identical by definition.
It asks for: at least two lanes; a standalone SLEIGH engine that can be rebuilt
from its `.sla` bytes (the Ghidra bridge translator is an RPC, not an engine);
**no `ContextCommit` in the loaded language**, which is the correctness
predicate and a property of the `.sla` rather than an architecture list (x86,
x86-64, AARCH64, RISC-V, SPARC, SuperH and Z80 pass; ARM, MIPS, PowerPC, PA-RISC,
PIC and M16C are refused); no delay slots, whose second fetch reaches past the
instruction; a loader that can share its **live, patched** bytes, so a lane reads
the dynamic relocations and `--assert bytes` overlays the parent applied rather
than a second parse of the file; an empty `ContextPainter`, since a per-address
decode mode is not carried by a context snapshot; every address of every
executable range mapped by some segment; and enough executable bytes (8 MiB) to
pay for the engine builds. Each lane then builds its own bare `Sleigh` from an
`EngineRecipe` (`decompiler/crates/kuna-decomp/src/infra/kuna_decodekit.rs`) over
the shared bytes, with the parent's context values copied in by value
(`decompiler/crates/kuna-sleigh/src/kuna_ctxsnapshot.rs`) and `allow_context_set`
off. Before anything is spawned, one such engine re-decodes 1,024 sampled seeds
and compares them against the parent's, because an engine that is not
decode-equivalent produces silently different bytes rather than an error.

Failure is a fallback, never a wrong answer: every lane body is caught, a lane
that dies poisons a cancellable barrier so the others wake instead of blocking
forever, and a lane fault, an unmapped fetch on the tripwire each lane carries, a
collision at the merge, a non-converging round loop or a parent context database
that moved all discard the shards and re-walk serially. A lane thread the OS
refuses is the one failure a lane cannot report for itself — the lanes already
parked at the first barrier are joined before the failure propagates — so the
spawner poisons the barrier, declines lane 0's own body and refuses with `thread
spawn failed`. `KUNA_DECODE_SELFCHECK=1` runs both walks and compares them field
by field, returning the serial result; the size floor is a parameter of the plan,
which `KUNA_DECODE_MIN_BYTES` sets on the CLI path and the equivalence tests pass
directly, so they are not vacuous on small fixtures. This is a driver-tier resource setting with no output
effect, so it is a CLI flag and an environment bridge rather than a settable
option (DIV-169).

The serial-fallback variants, their public enumeration order, and their stable
diagnostic strings share one declaration in
`decompiler/crates/kuna-analysis/src/listing/kuna_pdecode/refusal.rs`.
`Refusal::ALL` and `Refusal::COUNT` are generated from that declaration, so adding
a refusal cannot omit it from the documentation checks. A compatibility test
pins the existing order and spellings; the scheduling and fallback policies do
not depend on this representation.

(kuna) **The ARM decode mode the walk carries** (`armwalkmode`, default on;
`decompiler/crates/kuna-analysis/src/listing/kuna_armwalkmode.rs (ArmWalkMode)`,
driven by `decompiler/crates/kuna-analysis/src/listing/walk.rs (walk_carried)`).
ARM `TMode` chooses the instruction set an address decodes in, and an
interworking call (`blx imm`) runs a SLEIGH `globalset` that writes the
callee's mode into the `ContextDatabase` from its target up to the next address
where the mode was set explicitly. A stripped image has no such address, so
once the walk decoded a caller of a Thumb helper, every address above the
helper read as Thumb, and the walk decoded an A32 function placed there in
Thumb even when an A32 `bl` called it: in GH-780's 136-byte image the A32
helper at `0x2000080`, called after a `blx` to a Thumb helper at `0x2000040`,
decompiled to `halt_missing()` with a Thumb decode starting at `0x2000082`.
Ghidra's disassembler instead carries the context along the flow it follows
and applies a `globalset` to its target.

With the option on, the walk carries a mode the way the instruction set does,
starting from code whose mode the image states: an even `e_entry` and each even
function symbol, which the ELF for the ARM architecture makes A32. An
instruction decoded in a carried mode passes it to its branch targets and its
fall-through, and a direct call passes its target the mode it commits there
(`blx imm` switches) or else its own (`bl`); the first call to reach a target
decides. Each such instruction decodes through a context read override
(`Translate::set_context_read_override`), so the database's partition is not
touched while it decodes. A function entry nothing carries a mode to (a
prologue-pattern, pointer, callback or gap seed) and everything reached from
it read the database exactly as before, including what the walk's own `blx`
writes put there, so a Thumb function reached only through a pointer table
keeps the Thumb a `blx` below it wrote.

The instruction after a call or a user-defined p-code operation (`svc`,
`bkpt`, a barrier, a coprocessor access) is where a carried mode can run into
the next function, when the call or operation does not come back at its site.
The walk therefore holds each such address until it has walked every function
its worklist holds, so a function a call reaches decodes in its call's mode
before a fall-through can claim its first instruction. An address still
undecoded then carries the mode on when the database holds that mode there,
after an operation or an indirect call, or when the callee reaches a return
instruction or an indirect branch through decoded code; resuming one address
can decode the return another callee needs, so the walk repeats until no held
address qualifies, and only then lets the rest read the database. A local
function such as `b .` that never returns therefore leaves the bytes after its
calls to the database. The fall-through of an ordinary instruction and a
branch target are still trusted, so code a compiler leaves unreachable after
`__builtin_unreachable()` without a call can still carry the mode into what
follows it.

When the walk ends, every instruction it decoded in a carried mode whose span
the database holds in the other mode is painted with that mode
(`set_variable_region` over runs of adjacent instructions), so the decompiler
and every later walk read the instructions this walk found. The address after
each painted run is then marked as set with the mode it already holds: a
`blx` write at or inside the run, from a later walk or the decompiler, stops
at the run's end instead of filling the code placed after it, and one written
before the run stops at its start. Nothing else changes value.
The option applies to a linked ARM ELF with an even `e_entry`, no mapping
symbol, no odd (Thumb) function symbol, no Cortex-M vector table, no
`armfuncmode` extent and build attributes that allow A32 code
(`decompiler/crates/kuna-analysis/src/loader/kuna_armfloatabi.rs (thumb_only)`),
and not under an explicit `--isa`. Where metadata paints a mode, the walk reads
those paints as before. The parallel walk
declines every ARM image already (its decodes commit context), and the
validated-frame walk of `armframes` keeps its own context lifecycle.

(kuna) **Flow-proven ARM decode-mode paints** (`flowmode`, values `on`,
`aftercall` and `off`, default `off`;
`decompiler/crates/kuna-analysis/src/listing/kuna_flowmode.rs (disagreeing_runs)`).
ARM `TMode` chooses the instruction set an address decodes in, and the
`ContextDatabase` stores it per address. An interworking call (`blx imm`) runs a
SLEIGH `globalset` that writes the callee's mode from the target up to the next
address where the mode was set explicitly. A stripped image has no such address,
so once the walk decodes a caller of a Thumb helper, every address above the
helper holds Thumb: a `bl` to the A32 helper at `0x2000080`, two instructions
after a `blx` to a Thumb helper at `0x2000040`, decompiled to `halt_missing()`
with a Thumb decode starting at `0x2000082`. That is the walk `armwalkmode off`
runs; with it on (the default), the walk itself already decodes such code in
the mode its flow carries, and this proof finds nothing left to paint there.

The walk itself is not changed: its instructions, functions and references, and
every context write it makes, stay as they are. After it, kuna decodes again the
code whose mode the image proves, with the decode mode forced through a context
read override (`Translate::set_context_read_override`) and every context word's
writes masked, so these decodes leave the database exactly as the walk left it:
neither `TMode` nor the IT-block condition (`condit`) nor `LRset` is written.
An instruction inside an IT block therefore decodes with the condition the
walk's own decode stored at its address, if any. Proof starts at an even `e_entry` and at every even function symbol,
which the ELF for the ARM architecture makes A32. From proven code it carries
the mode on: a branch target keeps it (no direct branch changes the
instruction set), and so does the fall-through of an instruction that neither
calls nor runs a user-defined p-code operation (`CALLOTHER`); a direct call
target takes the mode the call commits there (read back from
`Translate::last_context_commits`, so `blx imm` switches) or else keeps the
caller's (`bl`).

The instruction after an unconditional call is not proven by the call. A
callee that can return does not show that this call returns: a compiler emits
nothing after `report_bad(x); __builtin_unreachable();`, after a call through a
`noreturn` alias of a function that can return, or after a `longjmp`-style
helper, so the bytes there are the next function, possibly in the other mode,
or a literal pool. With `aftercall`, the instruction after an unconditional
call is proven once the callee is proven to return, which means a return
instruction is reachable from its entry through proven code, computed as a
least fixpoint over each function's own reachability. That proves the A32
helper of the example above, called after a Thumb helper that returns, but it
also proves, and paints in the caller's mode, the next function after a call
that never returns at its site.

The instruction after one that runs a user-defined operation is never proven
by it, under either value. On ARM those are `svc`, `bkpt`, `hvc`, `smc` and
`hlt`, which raise exceptions, and also barriers and coprocessor accesses.
p-code does not say which of them come back: an exported `my_exit` that ends
in `svc #0` and then `__builtin_unreachable()`, or a function that ends in
`bkpt` the same way, is followed directly by the next function, which may be
in the other mode.

A function is complete when the proof followed every fall-through it left
unproven, so under `on` it makes no unconditional call and runs no
user-defined operation. Only the instructions of complete functions are
candidates for painting: a function is either decoded entirely in its proven
mode or exactly as the walk left it.
Every such instruction whose mode the database disagrees with after the walk is
handed to the analysis commit (`Listing::decode_mode_paints`, emitted by
`passes.rs (run_listing_consumers)` as the `flowmode` output), which paints it
with its proven mode after every other decode-mode paint. Nothing else is
painted, and the function inventory is the walk's. When two proven paths give
one address different modes, when proven instructions of different modes
overlap, or when a proven instruction fails to decode where the database holds
the other mode, the proof is not trusted and nothing is painted at all. `on`
fixes an A32 function that makes no unconditional call, reached from an even
entry or function symbol before any call, such as the helper of
`entry: bl arm_helper; blx thumb_helper`, and leaves the order of the example
above, and any function that calls, as the walk decodes it.

The default is `off`, under which the database is exactly as the walk leaves
it. Both other values still trust the fall-through of an ordinary instruction
and the target of a branch, and a compiler leaves either unreachable after
`__builtin_unreachable()`: clang at `-O0` ends a `noreturn` function that
stores to memory and then reaches `__builtin_unreachable()` with the store, or
with a conditional branch to the empty block at its end. The proof then
carries that function's mode into whatever the linker placed next, and paints
a static Thumb function there in A32.

The pass runs only on a linked ARM ELF whose metadata paints no `TMode` at all:
no mapping symbol, no odd (Thumb) function symbol, no Cortex-M vector table, and
an even `e_entry` or an even function symbol to start from. It skips an image
whose build attributes rule out A32 code (`Tag_CPU_arch_profile` `M` or
`Tag_ARM_ISA_use` 0, read by
`decompiler/crates/kuna-analysis/src/loader/kuna_armfloatabi.rs (thumb_only)`),
an image decoded with an explicit `--isa`, and an image whose database holds no
Thumb anywhere after the walk, where there is nothing to correct. Where a symbol
paints Thumb, those paints already run to the next change point and are what
gives many stripped libraries' static Thumb code its mode; the same leak still
reaches an A32 function placed after a Thumb function symbol there, and
`flowmode` does not change it.

(kuna) The seed set carries one more source, under the same `funcstart_patterns`
gate as the prologue starts: **the entries the load-time passes have already
committed**, handed down from `engine.rs (commit_pending_analysis)` rather than
recomputed. `listing_seeds` rebuilds its roots from the object, which is exactly
the §1.5 oracle union — so an entry that only a separately gated standalone pass
knows about was invisible to the walk. `armlibcmain`'s non-PIE ARM `main` is the
case that matters, because on such an image it is the *only* address that reaches
the program: nothing else names `main`, and `_start` hands it to
`__libc_start_main` through a literal pool word rather than a branch, so a walk
rooted only at `e_entry` stops inside crt1. A stripped ARM executable whose `main`
called 41 validators therefore reported 17 functions, one of them a 17 KB run-on
covering all 41, while `kuna xrefs` — which seeds its own descent from the
*committed* inventory — followed the same call graph and named every one of them.
The two surfaces disagreeing about what is a function is the defect; the seeds
are read off the merged output, so a pass whose gate rejected its entries does
not seed the walk with them either, and they are exec-filtered like every other
seed, so a junk-word CALL target outside the image stays a non-function.

(kuna) The two worklists must agree about what counts as code, and
`unmappedentry` (default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_unmappedentry.rs
(admits_call_entry)`) is what makes them. The instruction worklist gates every
address on the executable ranges above and drops anything outside them; the
function worklist did not, so a direct CALL into unmapped memory still became a
`DiscoveredFunction` that `fast_funcdisc` and `funcdisc_recursive` committed — an
entry with no bytes behind it, reported at size 0 and decompiling to nothing.
Those targets are not decode failures; the CALL decoded correctly and the operand
is junk. An always-taken branch followed by anti-disassembly filler produces one
directly: `xor eax,eax; je +1; e8 ...` puts the `e8` one byte before the real
instruction, and following the (never-executed) fall-through reads a call to an
address four gigabytes above a 25 KB image. The gate applies the *same* predicate
the instruction worklist uses, so the walk claims a function only where it is
willing to disassemble. It withholds the function claim only: wherever the
reference model is being built at all, the Call cross-reference is filed in both
directions either way, because the instruction really does encode a call to that
address. Where that model was not built the Listing's own xref API answers
"none" for this edge as for every other; the `kuna xrefs` and `decompile-graph`
answers are unaffected either way, because they come from a separate index over
the same bytes (`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (build)`)
and not from the Listing. A target inside an executable section is admitted
exactly as before even when the decode there fails — that is a genuine gap in
the walk, not a fabricated entry — so the gate can never remove an entry that
had a body. Measured over 234 crackmes images it removes 150 entries on 19 of
them and adds none; every one is `size: 0` and outside every executable section,
and emitted C over 6,085 functions of those images changes in exactly one
function, where two parameters wrongly typed `code *` (a phantom sat at the
address they pointed to) come back as the data pointers they are. Off restores the previous, phantom-producing discovery set exactly.

(kuna) The same seam carries `ppclocalentry` (default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_ppclocalentry.rs (fold_map)`),
which answers a different question about a CALL target: not whether it is code,
but whether it is a *function*. The OpenPOWER ELFv2 ABI gives a PPC64 function
two entry points — the symbol's `st_value`, whose first instructions materialise
the TOC pointer `r2` from `r12`, and a **local entry** a few bytes later, which
is where a caller that already holds the right `r2` (anything in the same module)
branches instead. The distance is recorded per symbol in the ELF `st_other`
field, packed in bits 5-7 as `(1 << n) >> 2 << 2`, and `readelf -sW` prints it as
`[<localentry>: 8]`. Nothing read that field, so the walk saw an intra-module
`bl` land eight bytes past a function symbol and minted a function there like any
other CALL target. On ordinary `gcc` ppc64le output that splits **every locally
called function in two**: the named symbol truncated to its 8-byte TOC prologue,
plus the whole real body under an anonymous `sub_<hex>` — and because S2's
`funcboundflow` truncates a fall-through that reaches a known function entry, the
named symbol then decompiles to an empty husk carrying a `funcboundflow`
truncation warning while its body is reachable only under the generated name. On,
an address that a defined `STT_FUNC` symbol declares to be its own local entry is
never claimed as a function, because by the ABI's own construction the two
entries are the same routine. Four guards keep the fold honest: the `st_other`
field must decode to a real offset (only `n` in 2..6 — 0 and 1 mean the entries
coincide, 7 is reserved), a sized symbol must contain its own local entry, the
local entry must not be the address of some other defined text symbol, and the
global entry must itself be a walk seed with no other seed between the two. That
last guard is what makes the walk's instruction closure invariant under the fold
— the bytes at the local entry are reached as the global entry's fall-through
either way — so the fold can only ever remove the duplicate second entry, never a
body. As with `unmappedentry` only the function claim is withheld; the Call
cross-reference is filed in both directions either way. PPC64-only, and inert on
an image whose symbols carry no local-entry annotation. Off restores the previous,
husk-producing discovery set exactly.

(kuna) `thunkentry` (default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_thunkentry.rs (thunk_entries)`)
answers the opposite question about a *jump* target: whether it is a function
although no CALL reaches it. A function whose whole body is one direct `jmp` is a
thunk, and the walk attributed the routine it jumps to to the thunk, because only a
CALL target becomes an entry. MSVC `/INCREMENTAL` routes the image entry and every
call through a table of 5-byte `jmp rel32` thunks at the start of `.text`, so on
such an image the walk found the thunks and none of the bodies, `fast` listed no
real function at all, and the last thunk's extent ran over every body after it.
The pass reads the completed walk and promotes the target of a walk entry that
opens with a direct unconditional jump to a decoded instruction when three
conditions hold. No decoded instruction falls through into the target and no
conditional branch targets it, so the target is not the middle of a straight-line
run or a loop head. The address right after the thunk's jump holds no ordinary
code: it is undecoded, a function entry, another direct jump (the next thunk of a
table), or the target itself; a function that opens with a jump over its own loop
body to the loop condition fails here, because the walk decoded that body as a
branch target of the condition. And the thunk is itself an entry, including one the
pass promoted, so a thunk-to-thunk chain resolves; the chain is followed at most
four jumps from a walk entry, so an obfuscator's chain of tens of thousands of
jumps adds four entries rather than one per jump. The second condition reads the
growing entry set, so acceptance runs over a worklist to its least fixpoint. The
promoted targets join `fast_funcdisc` and `funcdisc_recursive`, wherever the walk's
own set is committed, and nothing else: they are branch successors of the thunks,
so the walk decoded them either way and no instruction or Listing consumer changes.
x86 only. Measured on five x64 MSVC `/INCREMENTAL` images scored against their own
`.pdb` (kept where kuna cannot read it), all 84 added entries are real function
starts, no real body is split and no entry is lost. On 88 crackmes that carry a thunk
table it adds 5,087 entries in `fast` mode and removes none; 98% of them start at a
thunk or right after padding or a `ret`, and the rest checked by hand are function
starts after a thunk table or after a Delphi `jmp`-over-`ret` prologue. On 464
stripped x86-64 ELFs and 12 i386 PEs without incremental linking it adds and removes
nothing, so their output is unchanged (`decompile-all` is byte-identical on `gzip`,
`dash`, `diff` and two of the PEs). Off restores the previous discovery set exactly.

(kuna) `addrtakenentry` (default-on;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_addrtakenentry.rs (AddrTaken)`)
answers the same question for code that no flow reaches at all: a function the
program only ever calls through a pointer it takes itself. A registration stub
that stores `lea rax,[rip+handler]` to a global, a callback handed to the runtime
in a register — the walk decodes the instruction that takes the address but never
the code it names, and the extent bounder then folds that code into the function
before it. On an x64 PE a frame-less leaf has no `.pdata` record either, so no
load-time oracle names it: the GH-1039 witness, a stripped zig/MinGW build, reports
its 16-byte handler `0x140001040` inside a 32-byte `sub_140001030`, and on a 16 MB
MSVC image the reporter counted 2,065 reference starts inside larger kuna extents,
none with a `.pdata` record. Two kinds of evidence name a candidate. A decoded
instruction materializes it: a RIP-relative `lea`, a `mov` of an immediate into a
register or memory, or a `push` of an immediate, read off the instruction's own
bytes. Or, on a PE, a base-relocated word holds it and it lies before the first
`RUNTIME_FUNCTION` of its executable section — the span the relocation oracle's
hull guard leaves out (`decompiler/crates/kuna-analysis/src/analyzers/entry/kuna_pereloccode.rs (pre_record_code_pointers)`).
Either may still name a label or data, so a candidate becomes an entry only when
four things hold. It is undecoded executable memory: no decoded instruction covers
it, so no flow the walk followed reaches it. It starts where a function starts: the
decoded instruction before it (or one this pass accepted, in address order) does
not fall through, and only padding or zero fill lies between the two, or between
the candidate and the start of its section. It ends like a function: decoded
inside its gap, every path ends in a return, a computed jump, a trap (`int3`,
`ud2`), a call followed by padding, or a jump to a known function entry; no path
falls out of the gap into other code or jumps into the middle of decoded code; no
`ret` is reached with the stack pointer above where it entered, and no `leave` on a
path that never set the frame pointer — either is a frame torn down that the
routine never built; it does not open with `int3`, an address in
the middle of a padding run is not a function that opens with a `nop`, and no
instruction of it is zero fill or `hlt`. That last test is what refuses a data
table in `.text`: MinGW's `dlltool` puts each `__DELAY_IMPORT_DESCRIPTOR_*` there,
`__tailMerge` takes its address with `lea`, and it sits after a `ret` and decodes to
`add [rax],eax ; add [rax],al ; ... ; ret 0`. And it is not a label of a function
that takes it. A computed `goto` or a threaded interpreter takes its labels with
`lea` and reaches them through `jmp rax` or `jmp [table+rax*8]`; the labels sit
between the function's blocks (clang `-O0`) or right after the dispatch jump (gcc),
fall through into nothing and end in another dispatch, a jump back or a return,
just as a function would. So inside a taker's function region (up to the next known
entry) that holds such a jump — a register- or memory-indirect `jmp`, but not `jmp
[rip+slot]`, which is a tail call through an import — a candidate is refused when
more of the region's decoded code follows it, or when its own code dispatches. A
return block is refused by the frame test: gcc `-O2` places the `return` label
right after the jump and pops the frame with `add rsp,0x38` before its `ret`, and
gcc `-O0` places it after the shared `jmp *%rax` and ends it with `leave`. A
candidate after the function's code that neither dispatches nor tears down a frame
is kept, because that is a lazy-binding stub's fallback: the stub stores `lea
rax,[fallback]` or `GetProcAddress`'s result and tail-calls through `jmp rax`.
The accepted entries re-seed the walk, which resumes from the Listing it
already has (`decompiler/crates/kuna-analysis/src/listing/mod.rs (Listing::resume)`)
and moves its instruction store rather than copying it, so their callees and the
addresses their own code takes are found too; acceptance repeats for at most four
rounds. The walk's closure does not depend on the order it reaches addresses in, so
the resumed Listing is the one a fresh build from the grown seed set makes. Like
`thunkentry` it applies wherever the walk's own set is committed (`fast_funcdisc`,
`funcdisc_recursive`), so `reliable` mode on x86-64 is unchanged.

Measured with each stripped image scored against its own symbols: on 7 x64 MSVC PEs
scored against their `.pdb`, 283 true starts are gained and none is lost, no entry
lands inside a sized function body, and of the 870 other entries 696 are the
`/INCREMENTAL` jump thunks the pointers name — the same thunks kuna already lists
where they are called — and the rest are 16-aligned starts in spans the `.pdb` has
no symbol for; 115 MinGW x64 PEs gain 2 true starts; 830 x86-64 ELFs (663 decbench
twins and 167 crackmes, PIE and non-PIE) are unchanged, because `.eh_frame` already
names every function a pointer reaches. Without `.eh_frame` (`-fno-asynchronous-unwind-tables`
and a stripped `.eh_frame`) a signal handler, a `qsort` comparator and an `atexit`
callback are found, and twelve gcc/clang `-O0`/`-O2`/`-Os` builds of a computed-`goto`
interpreter, PIE and non-PIE, are unchanged. On `jormungandr.exe` the 612 relocated
pointers into the UTF-16 locale table that sits before its first record are all
refused: the strings run into other code. On Wine's PE DLLs, the ones that
delay-load a DLL included, every new entry is a symbol-table start. Over 583 x64 PE
crackmes 1,292 entries are added and 29 removed; 27 of the removals are Aggressive
Instruction Finder entries a few bytes into a function whose real start the pointer
names, and the other two, in two builds of one Rust crackme, are a true start the
gap walk now plants four bytes late over the richer Listing.

x86-64 only, and not on a Go binary. A Go binary's `pclntab` already names every
function (`gopclntab`), so a candidate could only re-seed a known one, and the
wider walk then turns calls into the middle of `runtime.duffzero` into entries. On
i386 every address is an absolute immediate, and the same shape names a MinGW SJLJ
landing pad — it sits after its function's `ret` and alignment padding, and the
function stores its address with `mov [ebp-0x1c],imm` — so 40 i386 PEs would gain
210 true starts but lose 574 and grow 4,974 mid-body entries. Two shapes still pass,
both hand-written assembly rather than compiler output: a pushed return address
(`lea rsi,[cont] ; push rsi ; jmp f`) makes `cont` a function, and a lea'd data
table in `.text` whose first byte is `0xc3` reads as an empty function. Off restores
the previous discovery set exactly.

(kuna) `callerreads` (default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_callerreads.rs (call_returns)`)
reads the completed walk for the decompiler rather than for the inventory: every
Call cross-reference, paired with the address its calling instruction falls through
to, as `(callee entry, return address)`, sorted and de-duplicated
(`AnalysisOutput::call_returns`). The commit parks the list on the architecture,
and a single-function decompile of a function recovered `void` decodes its callers
from those addresses to see whether they read its return register (chapter
[04](04-calls-and-prototypes.md)). It adds no entry and no decode to the walk; off,
nothing is filed.

A context painter applies the ARM/MIPS decode-mode paints per address before each
decode, so a Thumb or MIPS16 body disassembles in the right ISA. Each instruction
is decoded with a capturing p-code sink
(`decompiler/crates/kuna-analysis/src/listing/decode.rs (decode_one)`). When
assembly text is requested, `Translate::one_instruction_with_assembly` captures
both results: SLEIGH reuses the p-code parse when safe, retaining its post-lift
assembly fallback for context commits and delay slots. Other translators use the
trait's sequential fallback. Assembly errors remain best-effort after a successful
lift; a lift error ends the decode without an assembly retry. Without text, the
walk calls `Translate::one_instruction` once. The resulting instruction is
classified by a lifted transliteration of the S2 flow rules
(`decompiler/crates/kuna-analysis/src/listing/classify.rs (classify)`), whose three
load-bearing gotchas are worth restating: a constant-space branch operand is
p-code-relative (an intra-instruction branch), never a VMA; fall-through is decided
by the *last* op only; and delay slots are already folded into the reported length.

(kuna, GH-299) A predicated call — an A32 `blgt`, or a `bl` inside a Thumb `it`
block — lifts to a `CBRANCH` to the next instruction (the skip when the condition
fails) followed by the `CALL`. `classify` collects the target of every branch op,
and the walk makes every target of a call instruction a function, so the
instruction after each such call became a `sub_<addr>`: a mid-body entry that cut
its own function short, and evidence for the no-return discovery pass, which
counts the calls to a callee that are followed by a function start and at three
marks it no-return, truncating every caller in the image. The skip is the call's
fall-through and is now dropped from a call's targets; a call to the next
instruction (the i386 `call $+5` idiom), which carries no such branch, keeps its
target. Over 26 images (ARM, x86-64, i386 PE, AArch64, MIPS, PowerPC and RISC-V)
only the ARM inventories change: 37 entries fewer in all, 23 of them right after a
predicated call and the rest mid-body entries that sat in the functions those
entries had cut short, with no symbol-table start lost.

The instruction model stores records in 1,024-row chunks. Its private address
index groups sorted `(address, row number)` pairs into 4 KiB pages, with a B-tree
of populated page keys for ordered lookup
(`decompiler/crates/kuna-analysis/src/listing/kuna_insnstore.rs (InstructionStore)`).
Exact lookups binary-search one page; range queries visit only intersecting pages
and slice the boundary pages at their search positions. Growing the walk allocates
bounded chunks without copying a whole-image buffer. Every record retains its
flow targets, assembly and lazy p-code fields. Exact, range and interior queries
still borrow the original record in address order. The index key remains
independent of mutable instruction addresses. Replacing an address reuses its row.
Rebuilds that preserve ARM frames copy the paged address index but share immutable
record chunks. A shared chunk is copied only when a write reaches it through
`get_mut` or replacement, or when the walk appends into a shared partial tail
(`decompiler/crates/kuna-analysis/src/listing/kuna_insnstore.rs
(InstructionChunk::clone)`). The copy retains full chunk capacity and leaves the
prior Listing independent. Serial and parallel walks use the same store. This
changes allocation and lookup layout, not the instruction partition or the facts
any consumer receives.

The optional lazy p-code list is an owned boxed vector, so an instruction with
no retained p-code reserves a pointer-sized slot rather than a vector header
(`decompiler/crates/kuna-analysis/src/listing/model.rs (Insn)`). Populated lists
keep the same order and mutable vector operations, and cloning a record clones
its owned list. This changes the public `Insn.pcode` field from
`Option<Vec<RawOp>>` to `Option<Box<Vec<RawOp>>>`; a populated constructor uses
`Some(Box::new(ops))`. The usual Listing walk leaves the slot empty. A populated
slot adds the box allocation in exchange for reducing every record's fixed
storage; instruction contents and discovery remain unchanged.

After loading, committing analysis and applying caller assertions, the in-process
CLI returns unused glibc heap pages before selecting and decompiling functions
(`decompiler/crates/kuna-cli/src/kuna_allocrelease.rs (after_analysis)`). Dropping
the Listing ends its ownership, but small tree and string allocations can leave
resident pages in allocator arenas. A single `malloc_trim(0)` at this boundary
releases free pages without discarding live program facts or imposing a memory
budget. This applies on GNU/Linux; other platforms retain their allocator's
ordinary release policy. It reduces post-analysis residency, while the chunked
instruction store reduces the construction peak on every platform. Worker
admission still uses the measured high-water mark, not the trimmed current RSS.

Three things the walk deliberately does **not** always produce. First, the human
assembly text on each instruction: capturing it means rendering every
instruction's assembly (`Translate::one_instruction_with_assembly`, which still
falls back to a second SLEIGH parse where the p-code parse cannot be reused), a
real per-instruction cost on top of the lift. Operands remain one owned string
per instruction, while repeated mnemonic spellings share one immutable text
allocation per decode lane. Capturing assembly is still pure waste whenever
nothing reads the text. Every bulk consumer of it — `noreturn_propagate`'s
call/NOP idiom checks, `tailcallentry`, and `poolentry`'s literal-load operands —
sits behind `listing`, so the walk captures text exactly when `listing` is on and
leaves the fields empty on the `fast_funcdisc`-only path, which is the path a
whole-binary export takes on any image large enough for `--mode auto` to resolve
to `fast`. The one other reader is AIF's function-start fingerprint (§1.5), which
needs the mnemonics of just the first two instructions of each *discovered*
function; rather than force whole-image capture for that, it falls back to
re-decoding those addresses through its own gap decoder when the Listing carries
no text. That the re-decode reproduces the walk's own reading is checked rather
than assumed: decoding an instruction commits the `globalset` context writes its
constructor asks for, and both the ARM and MIPS specs globalset a decode mode
(`TMode`, `ISA_MODE`) at a branch target, so a *later* decode can leave an address
in a different mode than the walk read it in — and the re-decode would then hand
back a mnemonic belonging to a different instruction while the stride and total
length still came from the Listing. Instruction length is the observable of
exactly that disagreement, since an alternate-ISA reading is a different width, so
the fingerprint compares the re-decoded length against the Listing's and declines
to fingerprint the function at all when they differ. Declining is the safe
direction: a function that contributes no fingerprint only makes the histogram
smaller, which can never admit a gap candidate the text-carrying path would have
rejected. Where the two agree the histogram — and every gap-walk and
pointer-target decision keyed off it — is unchanged, which is what keeps the
pointer-only entries `fast_funcdisc` exists to find.

Second, the cross-reference model itself, on the same reasoning and the same
gate. An edge is filed for every control-flow successor of every instruction, a
plain fall-through included. The walk collects each edge once in a contiguous
buffer, including edges whose destination is not decoded. After the walk, it
sorts and deduplicates that buffer by `(source, target, kind)` and makes one copy
sorted by `(target, source, kind)`
(`decompiler/crates/kuna-analysis/src/listing/kuna_compactrefs.rs (ReferenceIndex)`).
Stable sorting preserves the first edge's operand metadata when duplicates are
removed. Incoming and outgoing queries binary-search the corresponding buffer
and borrow the matching slice; source iteration skips adjacent equal sources.
There is no separate map node or growable vector for each instruction's
fall-through. The reference model keeps the same edges, ordering, distinct-site
counts and absence queries as the former bucket maps. Serial walks, decode-lane
merges and ARM frame-preserving rebuilds all use this representation. During
index construction, the deduplicated buffer is trimmed to its length before it
is copied, and the copy is sorted in place, its keys being unique; every rebuild
still owns its instruction partition.

The readers, including `noreturn_disc`, `tailcallentry` and static format-string
analysis, are `listing` consumers, so a `fast_funcdisc`-only walk — again, the whole-binary export's path
on any image `--mode auto` resolves to `fast` — builds neither reference buffer and every xref
query answers "none" for every address. What must hold is that nothing else about
the walk changes, and nothing does: the reference filing is a pure sink, so the
instructions decoded, the functions discovered and the executable ranges are
identical either way, and `Listing::has_refs` reports which model was built rather
than leaving a caller to read an empty map as an answer. On a 147 MB C++ server
image (20.2 million instructions, 392,814 functions) the skipped model is 23.3
million edges: the whole `kuna functions` run drops from 12.9 GB resident to 6.0
GB and from 90.9 s to 73.7 s. The output of that command is byte-identical:
`kuna functions` carries no per-function budget, so nothing it prints can depend
on how long the run took. The whole-binary decompile surfaces do carry one —
`decompile-all`, `decompile-project` and `decompile-graph` under `--mode fast`
abandon a function after ten seconds of WALL CLOCK
(`decompiler/crates/kuna-console/src/project.rs`,
`FAST_WHOLE_BINARY_FN_BUDGET_SECONDS`) — so a run that spends less time
elsewhere legitimately finishes functions a slower one gave up on: measured on
this image, 4 of 2,233 A/B function pairs differ, in both directions, every one
of them at that budget. Those surfaces are byte-identical at a fixed budget
(`--max-fn-seconds 0`), and the wall-clock watchdog is the documented exception
— the same exception for any change that moves the clock.

Third, instruction-byte coverage, which is *derived* from the instruction map
rather than mirrored into a range list: because a range list merges overlapping
but not adjacent ranges, a straight-line run of instructions would cost one node
per instruction, and the undefined-gap queries already answer from the
instruction map.

**Fast function discovery with conservative pointer validation** (`fast_funcdisc`, default-off;
`decompiler/crates/kuna-analysis/src/analyzers/fast_funcdisc/mod.rs
(pointer_table_seeds)`) reuses that one walk without enabling the full Listing
tier. Its initial roots are only the loader-backed function symbols and the §1.5
format oracles; full `funcstart_patterns` roots are included only when both
`listing` and that option are on. The Listing walk recursively follows every
static CALL from those trustworthy roots, and `fast_funcdisc` commits all
resulting function entries.

On a Go image the walk leaves out the roots the pclntab already accounts for
(`gowalkprune`, default-on;
`decompiler/crates/kuna-analysis/src/analyzers/pclntab/mod.rs
(function_entries)`). The pclntab names every Go function and gives its extent,
and the `gopclntab` pass puts each in the inventory. Walking them finds those
same functions again, and on an x64 PE it is expensive: Go's Windows linker
writes a `.pdata` record for every Go function, so with those records as roots
the walk decoded the whole Go text. A root at a pclntab function entry is
therefore dropped before the walk, and every other root is kept, so cgo's C
code and anything else the image's own records name is still walked. (Go's
internal linker lists a cgo image's C functions in the pclntab too, so there
they reach the inventory through the table; an external link leaves them out of
it, and they stay roots.) The cost is what the walk could reach only through a
pclntab function's body: it is no longer found unless something else names
it. Go code calls C only through function pointers (`asmcgocall`, the cgo
wrappers' data words), so this takes Go assembly that CALLs C code directly, in
an externally linked image whose C carries neither symbols nor unwind records;
there the called function and its callees are lost and the function before them
absorbs their bytes. Measured on four Go images (gh 2.89.0 for Windows and
Linux, two other Go PEs), on cgo builds (internal and external link, the race
detector, c-shared, plugin) for Linux and Windows, and on Go builds for macOS
and the BSDs, the inventory's addresses, names and sizes do not change. What changes is that a
Go function the walk reached only by a call no longer also carries a
`sub_<addr>` alias; a function another source of entries names (a `.pdata`
record, an entry oracle) keeps its alias as before; the decompiled C is the
same. The pruning applies only where `fast_funcdisc` builds the walk without
the full Listing, which is fast mode on every surface. With the Listing on,
every root is walked as before. The pruning also waits for the `gopclntab`
pass: it applies only when the load-time verdict is Go (the verdict that chose
the pass set, so a `sourcelang` force issued after the load does not count)
and `gopclntab` is on, since with the pass off nothing else would put the
dropped roots' functions in the inventory. `--option gowalkprune off` walks
the Go functions again.

The second source covers indirect-only callbacks. On non-ARM objects, scan
allocated, initialized, non-executable data for pointer-width runs of at least
two absolute values into executable ranges. Ignore a table longer than 256
slots. If the remaining tables produce more than 512 unique targets, discard
targets referenced by fewer than two distinct tables. Rank the survivors by
independent-table count and validate at most 4096. A candidate must still be
undefined in the Listing and must satisfy both AIF corroborators: its first two
decoded instruction mnemonics and their byte length form a fingerprint seen at
least four times among already-reached functions, and the bounded
`check_valid_subroutine` probe must cover more than two instructions without a
bad decode or out-of-image flow and reach either a terminal/computed jump or an
informative call/edge into known code. Accepted bodies are claimed so a later
candidate cannot split them. ARM instead reuses the existing Thumb-pointer
oracle: an aligned odd code pointer is accepted only at an undefined
frame-establishing prologue that passes the same valid-subroutine probe.

**Headerless-image function discovery** (`rawdiscover`, default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_rawdiscover.rs`) is the raw
analog of that walk. A `--raw-image` load has no `object::File`, so the whole
tier above declines: the consumer entry point opens by parsing the object, and
every §1.5 oracle under it reads a symbol table, an exception table or a section
list. The inventory is then exactly the `--entry` addresses the caller named,
which on a firmware image is one function spanning the file.

Neither of the two things that actually find functions needs that metadata, so
both run over the raw loader's synthetic `CODE` section instead. A **linear
call-target sweep** decodes each executable range end to end and collects the
statically derivable target of every direct call, dropping targets outside the
executable ranges; on a failed or zero-length decode it advances by the code
space's addressable unit rather than stopping, so a run of data costs
resynchronization instead of the rest of the range. Those targets join the
caller's seeds as roots of the ordinary recursive descent, which decodes each
for real and promotes the direct-call closure. Seeds are never dropped, so the
inventory can only grow.

The three walk inputs that come from the object file take the values a
headerless image honestly records: the executable universe is the raw loader's
single `CODE` section, the decode-mode painter is empty (there are no ARM `$t`
markers or Cortex-M vector table to read, and `--isa arm|thumb` has already
painted any whole-image mode claim), and the PPC64 local-entry fold is empty.
The gap-filling AIF walk is not run: it needs at least 20 already-discovered
functions to build its prologue fingerprint histogram, which is a corpus a raw
image does not have until this pass has already produced one.

Because a seed no longer bounds the run, `--entry` seeds a raw load without
*selecting*: with a discovered inventory beyond it, an entry that also filtered
would hide everything found from it. `--addr` continues to do both. What this
cannot recover is what the input does not record: a function no direct call
reaches and no seed names stays undiscovered, and `--define-function` remains
the way to assert it. Raw-container only, so every object-format result is
byte-identical; `--option rawdiscover off` restores the seeds-only inventory.

(kuna) **On an MS-DOS executable the sweep keeps only the calls a DOS program
can make** (`mzsweep`, default-on;
`decompiler/crates/kuna-analysis/src/listing/kuna_mzsweep.rs (MzEvidence)`). An
`MZ` load reaches this pass as a raw image (§1.2), but unlike a
firmware image its load module is mostly data: a large-model program's far data
segments (bitmaps, fonts, tables) and its DGROUP sit beside its code, the sweep
decodes them like code, and every `e8`/`9a` byte pattern it reads there becomes
a call whose target is minted as a function, most often a run of zero fill that
decompiles as repeated `ADD [BX+SI],AL`. The loader therefore hands the sweep
its relocated module and the linear address of every word a relocation entry
adjusted, and three rules apply to the sweep alone. A far `CALL`/`JMP
ptr16:16` counts only when the relocation table names its segment word: the
linker cannot know the paragraph DOS loads the module at, so an unrelocated
segment is absolute and does not land in the module. A call read in a
straight-line run (the decode stream since the last call, branch or return)
that also read zero fill or an undecodable byte does not count, since it is a
decode of data rather than a call an instruction makes. And a target counts
only when its own straight-line run, read up to its first control transfer (at
most 32 instructions), reads no zero fill and no undecodable byte and does not
end in an unrelocated far branch: a function opens with code. The far-branch
arm needs a relocation table. A module whose header lists no relocation
(EXEPACK's, whose fixups its stub applies after unpacking, or one an unpacker
stripped) carries its far calls unrelocated, so there a function that opens
with one, as a large-model prologue's `call far __chkstk` does, is still
code; the far call itself still counts for nothing, since its segment was
never moved to the load address and its target is not where the call goes.
The second rule does cost a real call now and then: a
function that only the sweep reaches and whose first call follows data in the
code segment (a switch table that decodes to an undecodable byte) with no
decoded branch in between loses that call, and its callee goes with it when
nothing else names it. `HLT`, which
SLEIGH lifts as a branch to itself, does not end a run, because the CPU resumes
after it. The seeds are never filtered, and the recursive descent still
promotes every target that code it reaches calls, so a refused call drops only
a target nothing else names. On the deark-unpacked DAZZLE.EXE of issue #1288
this removes the 24 swept entries IDA classifies as data (23 in the four far
data segments in front of the code, one in DGROUP; 321 functions become 297,
functions whose decode hits bad instruction data go from 15 to 3, and the
zero-run bodies from 15 to none) and keeps every function IDA has; the bodies
of every function that stays are byte-identical. `MZ` loads only, so every other
input, `--raw-image` included, is byte-identical; `--option mzsweep off`
restores the whole-module sweep.

Table-derived roots are committed but are deliberately not fed through a
second recursive walk. Thus the bounded path obtains direct-call closure and
high-confidence callback/vtable roots while avoiding the full prologue scan,
the AIF cursor over every undefined code gap, and recursive expansion from
disconnected pointer roots. Turning on `fast_funcdisc` alone does not run no-return, FID, AIF, or any
other ordinary Listing consumer.

Executable-section operands use a narrower rule because instruction immediates
are not pointer tables. On x86, the walk records an address-like executable
constant only when p-code stores that constant as the instruction's value (not
as a LOAD/STORE address); it is promoted when the instruction is `PUSH`, a
straight-line run of at most sixteen instructions reaches the next call, the
target is not an existing instruction or an interior instruction byte, and the
strict bounded subroutine probe reaches a valid termination. Accepted stack
callback roots are added to the Listing seeds and the walk is rebuilt, up to
four rounds and 1,024 roots, so a dialog callback that registers a second
callback contributes both bodies to one project inventory. Other code-looking
immediates, targets already claimed by a body, and targets that only happen to
decode without a valid return path remain unpromoted.

Candidate provenance is deduplicated by target before storage and bounded to
4,096 target/source pairs per walk. Only a constant STORE value earns the
on-demand mnemonic decode, preserving the reference-free Listing detail used by
fast discovery. A stable hash rank samples the bounded set across the address
space without traversal-order or low-address bias; the root budget and
four-generation limit still prefer bounded load time over complete recovery of
adversarially deep or unusually callback-dense registration graphs.

The full Listing **consumers** run over the built model and are individually gated before
invocation (with the commit gate retained defensively): the
no-return consumers of §1.7 (`noreturn_disc`, and `noreturn_propagate` carrying
the `noreturn_error`/`noreturn_reach` sub-rules), the FID matcher (§1.4), the AIF
gap-walk, and (kuna) the recursive-descent promotion `funcdisc_recursive`, which
commits the walk's discovered CALL targets as real functions (coupled to the
`funcstart_patterns` flag; this is what finds call-only targets with no
recognizable prologue). **AIF** (`aif`, default-off with upstream's own "IT MAY
CREATE A LOT OF BAD CODE!" warning;
`decompiler/crates/kuna-analysis/src/analyzers/aif/mod.rs (run_aif)`) speculatively
decodes each undefined gap between discovered functions and accepts a gap start
only when it both disassembles into a valid subroutine (a clean flow to RET, more
than 2 instructions, no bad byte or out-of-range flow) *and* its prologue matches a
start fingerprint shared by at least 4 already-discovered functions
(`FINGERPRINT_THRESHOLD`) — the exhaustive gap oracle for functions with no
static or accepted pointer-table root.

The gap cursor caches its current undefined span instead of repeating Listing
lookups at every candidate. The next known instruction still bounds subroutine
validation; an executable-range boundary only bounds cursor advancement. Once
the cursor advances, cached decode successes and failures below it are retired:
validation never decodes below its candidate. Forward results retain their first
decode, including across processor-context changes. This bounds retention on long
rejected padding runs without imposing a discovery cutoff or a universal cache
size limit on branch-heavy inputs. Shared immutable records avoid copying text
and flow vectors on cache hits; fingerprint equality remains two mnemonics and
their total instruction length. The validation walk reuses its visited-address
hash set and work stack, preserving successor order and the 4,000-step limit.
Accepted bodies are converted back to address-sorted sets. One already-decoded,
fixed-stride fall-through prefix can stand in for its visited addresses on the
next overlapping validation. Its deferred branch targets and information flags
are replayed in their original order under the same validation policy. All prefix
instructions still count toward the step limit; backward edges into the prefix
are already visited, and accepted bodies include every prefix address. Terminal
instructions, missing fall-throughs and stride changes end the prefix. Cache
retirement trims it, so reuse never skips a new decode or a context update.

AIF obtains flow and assembly through `Translate::one_instruction_with_assembly`
(`decompiler/crates/kuna-sleigh/src/translate.rs`). Its default implementation
performs the original lift followed by best-effort assembly. SLEIGH reuses the
resolved parse for instructions without context commits or delay slots; otherwise
it reparses assembly after the lift, preserving the context updates and consumed
length. P-code errors still fail the probe, while assembly errors do not replace
a successful lift. Emitters must leave the image and translation context unchanged.
The combined SLEIGH path retains at most eight constructor decisions keyed by the
full instruction buffer, context words, table and operand offset. Each address
still evaluates operands, applies context changes and generates p-code normally;
this is not a cache of lifted instructions. Pattern-mask capture bypasses the
cache, and changing the processor spec invalidates it.

(kuna, GH-299) That gap walk slides its cursor **one byte at a time**, because the
undefined partition is byte-granular by construction, so every byte of every hole is
a candidate function start and both acceptance tests are applied to addresses that
cannot be instruction boundaries — a candidate starting mid-instruction reads the
tail of one encoding plus the head of the next, and that synthetic pair matches a
common prologue about as often as a real one. On a large stripped i386 PE the walk
plants roughly 2,100 entries in the middle of a function body, a third of them inside
a function the discovery set already has an entry for. `aifstrict` (default-off,
carried by the `aggressive` preset;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_aifstrict.rs`) narrows the
cursor: it advances to the next 4-byte boundary rather than the next byte, and a
candidate is probed only when it is 4-byte aligned **or** it is the first byte of its
hole. The hole-start exemption is the whole distinction the option draws — a hole
boundary is evidence, since the recursive-descent walk decoded up to exactly there
and stopped, while an interior byte the cursor slid onto is a guess. The stride is 4
on every architecture deliberately: 16-byte alignment kills nine tenths of the bad
Cortex-M entries but takes four fifths of the real ones with it. Declining a probe
also *recovers* entries rather than only removing them, because an accept advances
the cursor past the accepted body — a phantom accepted one halfword inside a literal
pool consumes the real function behind it. Off restores the byte-granular cursor
exactly.

(kuna, GH-299) The complementary reject the issue asks for — refuse a candidate
bracketed by a known function — is `aifbracket` (default-on;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_aifbracket.rs`). Some holes
are not gaps between functions but blocks inside a function the walk already knows,
behind a dispatch it could not follow, an undecodable instruction, or a call it
believes does not return; a block there that opens with a common prologue and
branches back into the function's decoded code passes both acceptance tests, since
the validity walk counts that branch as adding information. The Listing's function
model is entry-ordered and carries no extents, so "this hole lies inside one body"
cannot be read off the interval between known entries — on a sparsely discovered
image nearly every hole lies between two of them, and an interval test swallows
whole unexplored regions. (Where a defined function symbol states its size, the
extent is known and no accept strictly inside it is emitted at all, the rule of
`funcstart_patterns` in §1.5.) It is the `fdeinterior` question (§1.5) asked of an image
with no unwind extents, and the candidate's own speculative body answers it instead:
an accept is a fragment of its enclosing function when that body falls through or
jumps (not calls) into an instruction the walk decoded that is not a function entry
and lies in the same entry interval as the candidate. A fragment is refused unless
boundary evidence says a function starts there anyway: the walk files a reference to
it, or an aligned pointer-sized word in an allocated section holds its address; it
lies within the first word of a hole that a return, a direct unconditional jump or a
no-return call opens (the word admits the function behind a one-word A32 literal
pool); or the instruction ending exactly at it is alignment padding (`nop`, `int3`,
a self-move or self-`lea`), a return or an unconditional jump. A hole a computed jump
opens has no such boundary, which is exactly the unresolved-switch case. Like an
`aifcorroborate` refusal, a refused fragment still consumes its body so the cursor
does not resume inside it. The refusal runs only in the plain gap walk (both the
Listing and the reference-walk callers); the frame-prefix reconciliation, which
replaces one accepted root by another, is untouched. Scored against unstripped twins
it removes 1,291 to 2,874 mid-body entries per corpus and mode (ARM ELF, i386 PE)
without losing or gaining a true function start; most of the mid-body entries that
remain never touch decoded code — the tail of a function that ends in its own return
— and are outside what a flow-join proof can see.

(kuna, GH-299) No gap entry starts on filler: `aifnoppad` (default-on;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_aifnoppad.rs`). The holes
between functions are mostly alignment padding, which the fingerprint test normally
refuses because no four discovered functions open with two `nop`s. Some images do
have them — Wine's exported unimplemented-function stubs open with nine `nop`s — and
then the `nop` run between each relay thunk's `ret` and the next thunk's
hot-patchable `mov edi,edi` entry passes both tests (a fingerprint match, and a valid
subroutine that falls through into decoded code) and becomes a function of its own
in front of one kuna already has; zero halfwords around ARM literal pools are
accepted the same way, and an accepted zero run swallows the function behind it. A
candidate whose first instruction is filler is therefore classified by the run of
filler it opens. Zero fill (x86 `add [eax],al`, A32 `andeq r0,r0,r0`, Thumb
`movs r0,r0`) is never probed. Padding — `nop` of any width, `int3`, a self-`lea`,
or a register self-move on a 32-bit target — is not probed when the run ends
exactly at a known function entry; when it ends at undecoded code the candidate is
probed as before, but an accept is planted on the first instruction after the
padding, since that is where the function the walk just validated begins. Padding
is never refused outright in front of undecoded code because it is also a
legitimate first instruction: symbol tables start 903 functions with `nop` in the
i386 PE corpus and 56 in the ARM one (Wine's stubs, an empty `-O0` function's
`nop; bx lr`), and `-fpatchable-function-entry` starts every function with one.
`mov edi,edi` is never padding — it is the MSVC hot-patch prologue that opens 7,827
true starts in the PE corpus — and neither is any self-move on a 64-bit target,
where a 32-bit one zero-extends its register. A self-`lea` on a wide target is
padding only when both operands name the same full-width x86-64 general-purpose register.
`lea esi,[esi]` and `lea r8d,[r8d]` clear the upper half of their destination, so
entry discovery retains them even though the printed register names match. A
full-width `lea rsi,[rsi]` still counts as padding. A refusal is a plain reject, not a
body claim, so the cursor moves on through the filler. Like `aifbracket` it runs
only in the plain gap walk. Scored against unstripped twins in the default mode it
loses no true function start on any corpus and gains 50 on the i386 PEs (the
function behind padding, now at its own address) and 38 on the ARM ELFs (the
function a zero run used to swallow); it removes 7,446 non-start PE entries and a
net 77 mid-body ARM ones, and leaves i386 and x86-64 ELFs unchanged.

(kuna, GH-299) No gap entry starts on a literal-pool word: `aifpoolslide`
(default-on; `decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_aifpoolslide.rs`).
ARM code keeps its constants in pools right after the code that loads them, so a
pool usually sits between one function and the next, and the walk never decodes
it. The gap walk then reads a pool word as an instruction — an A32 image address
`0x608xxxxx` as `addvs`, the high half of a Thumb SRAM pointer `0x2000xxxx` as
`movs r0,#0` — whose pairing with the next function's prologue matches the
fingerprint, and whose speculative body runs into that function and validates. The
entry lands a word or half a word early, and because an accept consumes its body,
the function behind it is never probed: on a stripped A32 u-boot this hid 334 real
functions. `poolentry` repairs the same shape after the fact, but only in
`--mode aggressive`, only for a pool behind a return (u-boot's often follow a call
to a no-return function), and only by adding a second entry. Here the walk keeps a
set of literal words: every word an `ldr` or `vldr` of the decoded Listing loads
PC-relatively (its absolute `[0x...]` operand or its `[pc,#imm]` form, both words
of a 64-bit load; an `adr` only takes an address, so a function whose address it
takes is not a pool), extended with the literal words of each body the walk
accepts or consumes, so the pool behind a gap-found function is known by the time
the walk reaches it. A candidate inside a run of adjacent literal words is probed
as before, but its accept is planted on the first address after the run when its
body decoded an instruction there, and it is rejected otherwise, so the cursor
reaches the code after the pool and probes it on its own. When that address is
data — bytes that begin a printable NUL-terminated string, or an even address some
literal word of Thumb code holds, since a Thumb code address carries bit 0 — the
candidate is refused but still consumes its body: a body the walk accepts over a
string table decodes text as `ldr`s, and those bogus literal words must not move an
entry onto a string the code passes as an argument. A bracket refusal also keeps
consuming its body. It is 32-bit ARM only and runs only in the plain gap walk.
Scored against unstripped twins in the default mode: over the 93 non-u-boot ARM
ELFs of the decbench corpus mid-body entries 4,375 to 1,866 net and true starts
+222; on the two u-boot images 1,415 to 1,081 and +334; no true start lost, and
`CMSIS_DAP.axf`, the i386 PE corpus and x86-64 images unchanged. Besides the 556
true starts, the new entries are 5 mid-body entries and 63 on data (none on a
string start), against 88 such data entries removed, 77 of them on a string. It
shares `poolentry`'s one disclosed split: a literal
reference that resolves onto a function's own first word (the SPLIT shape of
`cortexm_poolentry_le32`) moves that function's entry four bytes in, which the
gap walk without this option gets right in `--mode reliable`; the corpus
measurement has no such case.

(kuna, GH-313) Upstream applies a **second** fingerprint test that kuna's port
dropped. Its analyzer refuses a candidate twice — once on the shared-prologue count
alone, and again after the validity walk, where a routine that adds no information
must match a prologue shared by fifty discovered functions rather than four. kuna
ported the first refusal and the "no two-instruction routines" half of the second,
so a self-contained routine that calls nothing, jumps nowhere known, and merely
reaches a return is accepted on a two-mnemonic coincidence. `aifcorroborate`
(default-off, **in no preset**;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_aifcorroborate.rs`) restores
it: an accept must either add information — a call, or a jump into already-discovered
code — or match a prologue that fifty discovered functions share. The corroborating
fact is recomputed the upstream way rather than reusing the flag the
valid-subroutine gate already carries, because that one also counts a plain
fall-through out of the hole into decoded code, which is the *signature* of a
mid-body phantom rather than evidence against one. And a refused candidate still
consumes its body: the gap cursor advances past an accepted routine but only one byte
past a rejected one, so an accept-side refusal that released the cursor would hand it
back to the interior of the same hole, replacing one bad entry with a worse one.

The option ships opt-in because it was **measured out of the default path**, not
because it is unevaluated. Over the same corpus `aifstrict` was measured on it cuts
roughly a third of the remaining mid-body entries but costs about half a real
function for each one removed, raises recall on none of the images, and takes real
functions off the A32 targets AIF's remaining justification rests on — which is the
finding, not the failure: upstream's guard assumes a function worth finding calls
something the analyzer already knows, and on bare-metal firmware the functions only
AIF can find are precisely the leaf helpers that call nothing. The per-image numbers
are in the option's catalog row, and the instrument that produced them is
`scripts/decbench/entrysweep.py` (§ the decbench loop), which scores kuna's function
entries for a stripped image against its unstripped twin's symbol table — the
discovery-tier measurement the GED loop cannot make.

`operand_refs` (default-off, matching
upstream's ELF-off default) shares the deferred slot for the same
decoder-availability reason but does its own linear decode rather than reading the
Listing, planting `char[N]` facts for immediate operands that point into read-only
data. (kuna) An immediate the instruction adds to a value it does not know, to
form the address of a load two or more bytes wide, is left out
(`decompiler/crates/kuna-analysis/src/analyzers/operand_refs/mod.rs
(IndexedBases)`): `jmp *table(,%rax,8)`, `call *tbl(,%rdi,8)` and
`movzwl map(%rdi,%rdi)` index an array of wider elements, a jump table, a table
of function pointers or a word map, and typing its first bytes `char[N]` because
they happen to be printable made the printer index a short literal
(`*(unsigned long *)&"7A@"[i * 8]`) instead of the table. That test sees one
instruction, so a table the code reaches any other way still began with a
printable run: `movabs $tbl,%rax` before the indexed call (`-mcmodel=large`),
`mov $tbl,%edi` to pass it, or `movq $vtable+16,(%rax)` in a constructor, and a
non-PIE x86-64 entry such as `26 42 40 00 00 00 00 00` (0x404226) reads `"&B@"`.
Once one scalar planted the `char[4]`, every use of the table printed the
literal: `pick("&B@",a0)`, `*(char **)operator new(8) = "dB@"`. So the target is also refused when it
is a pointer slot, the same test the strings pass applies
(`decompiler/crates/kuna-analysis/src/analyzers/strings/kuna_ptrslot.rs (PointerSlots)`).
On a PE with base relocations that test is exact: an MSVC i386 image's vtable
entries are relocated and refused, while its 4-aligned `"INF"` is not and keeps
its literal.

(kuna) A run as short as one character is also the first element of many arrays
whose elements are wider than a byte: `static const int arr[] = {65, 66, 67, 68}`
starts `41 00`, which is `"A"`, and `L"hellow"` starts `68 00`, which is `"h"`, so
`sum(arr,n)` printed `sum("A",a0)` and `lenw(L"hellow")` printed `lenw((int *)"h")`.
Two more refusals cover them. A sized data object of the image's symbol tables that
starts at the target with a size other than the run's says what the bytes are
(`decompiler/crates/kuna-analysis/src/analyzers/operand_refs/mod.rs (DataObjects)`):
`arr` is a 16-byte object at the target, and the reference prints as its name. An
object that only contains the target, such as a table of `char` rows, does not
refuse the string it holds there. Without symbols the bytes decide
(`wide_element_neighbour`): at an address aligned to the width, two 4-byte elements
that are each one printable byte followed by zeros (a `wchar_t` or `char32_t`
string, an `int` table of character codes), or three 2-byte ones, the third
possibly the terminator (`char16_t`, a `short` table), open an array of character
codes. A merged string section lays one-character literals side by side in the
same 2-byte shape (`78 00 79 00 77 00` is `"x"`, `"y"`, `"w"`), and a literal that
ends a block at a 4-aligned address can sit right before an `int` table in the 4-byte
one, so the run is refused only when nothing marks its second element as a thing of
its own: no declared object starts there, no operand the scan found points at it,
and the image holds no pointer to it (`held_pointers`) -- in a pointer-aligned slot
of an allocated section or as the addend of a dynamic relocation. Beside a 2-byte
run of an ELF image, the merged-literal case, an entry of a table of 32-bit offsets
from the table's own start at an operand target counts too: the shape of clang's
position-independent lookup table of string addresses (`.long .str - table`,
`relative_string_table`). Such a table must not itself open a string, and its
entries are read up to the first that is zero, a small positive character code
(the first unit of a wide string or code table the read has run into), points back
into the table or lands on no string, with at least two remaining. A 4-byte run
never consults one: read as offsets, a struct's leading `int`s or a wide string's
units can land on the second unit of any wide string nearby. A 2-byte run of
`char16_t` or `short` data can still be kept that way, as on main, when a struct
holding it starts with `int`s that equal the offsets of its own units. A literal beside the
first is usually referenced from one of those places; the second element of an
array is not. When nothing visible refers to it the literal loses its string with
the array and prints as its address: a neighbour left behind by code that
`--gc-sections` removed, or, stripped, the 4-byte case before an `int` table, which
only that table's symbol tells apart. The other way round, a wide or `char16_t`
string whose suffix is referenced on its own, such as a tail-merged `L"xbind"`
whose `L"bind"` another call passes, or `u"b"` inside `u"xb"`, still prints as its
first character, as on main; only a scan for strings of the matching width would
recover it, which `widestrings32` does for the 4-byte case (its `wchar4` fact
commits first and takes the address). The scans run once, and only when some run is about to
be refused. Refusing drops the fact and nothing else, so the
reference prints as the array's symbol or address (`sum(arr,a0)`,
`lenw(&dat_2004)`), never as a different value. A stripped array whose second
element is no character code, such as `int {65, 1000}`, still reads as `"A"`.

(kuna) Three ARM-only seed scans run between the walk's first pass and those
consumers, each re-seeding the walk and rebuilding the Listing when it finds
anything, all gated by the `funcstart_patterns` flag: the existing raw unpaired
Thumb scan
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_thumbframes.rs`),
the code-pointer-table scan
(`decompiler/crates/kuna-analysis/src/analyzers/aif/mod.rs (code_pointer_table_seeds)`
— every 4-byte-aligned odd word in any allocated section whose masked target lands
in an undefined gap, *and* opens with a frame-establishing Thumb prologue, *and*
passes the same probe), and the AIF gap walk above. The additional default-off
`armframes` option walks shared validated ARM/Thumb frame roots in place of the
Thumb scan
(`decompiler/crates/kuna-analysis/src/analyzers/aif/mod.rs (raw_arm_prologue_seeds)`):
mode-matched LR-saving `STMDB SP!`, `PUSH` or `PUSH.W` in an undefined gap must
pass the strict valid-subroutine probe. It keeps the entries the Thumb scan and the
gap walk would have reported (see the ARM reference walks later in §1.6), and when it validates
no frame at all the Thumb scan runs exactly as with the option off.

**Pointer-referenced entries** (`ptrentry`, default-off; kuna;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_ptrentry.rs`) re-admits
what the second of those throws away. Measurement over the ARM Cortex-M corpus
found its two shape predicates — a frame prologue, and more than two instructions —
reject the bulk of the pointer-referenced population: 93% of the missed entries
establish no frame at all, and 41% are leaves of eight bytes or less, down to a
bare `bx lr`, which is a perfectly valid Cortex-M exception handler. Deleting the
two predicates is not an option on its own: it admits `ldr pc,[pc,r]` switch tables,
whose slots point *into* the function that holds the table, so a fifth of the new
entries split a real function body — a cost the per-ground-truth-function benchmark
cannot see and a real user pays in full. With the option on, a target is instead
admitted on **containment** evidence: no word referencing it may overlap a decoded
instruction (such a word is an instruction's operand bytes read four-aligned, not a
table slot), and none may lie in the same discovered function as the target itself
(that pairing *is* the switch table). The length floor is replaced by a
terminating-routine check — the same speculative walk, accepting when it reaches a
clean `RET`/computed jump or a call into discovered code with no undecodable byte,
no flow out of the image and no escape into another dark region, with no minimum
instruction count. This is the kuna form of the line Ghidra draws between
`OperandReferenceAnalyzer`, which creates functions from *instruction operands*, and
its data-side sibling `DataOperandReferenceAnalyzer`, which overrides
`createFunctions` to a no-op; kuna cannot use Ghidra's version directly because the
Listing records only control-flow references, so the containment pair recovers the
same discrimination from the code/data partition the walk leaves behind. Table-run
corroboration — requiring a run of consecutive code-pointer words — was measured
and is dominated: the switch tables it targets are runs themselves, so it removes
almost no additional split while costing a fifth of the recovered entries. Unlike
the three scans above, the accepted targets are emitted as an additive entry-fact
stream and **never** re-seed the walk: measured, re-seeding drops hundreds of
already-recovered entries through the same tail-call absorption that constrains
`cortexmvectors` (§1.5), so keeping the pass purely additive makes "never removes
an entry" a property of the wiring rather than of a heuristic. Output-changing
(more functions), hence default-off; ARM-only and Listing-tier, so it is a strict
no-op on every other architecture, with `listing off`, and on the XML datatest path.

**Tail-call entries** (`tailcallentry`, default-off; kuna;
`decompiler/crates/kuna-analysis/src/listing/kuna_tailcallentry.rs (tail_call_entries)`)
closes the walk's other structural blind spot. The recursive-descent walk
(`decompiler/crates/kuna-analysis/src/listing/walk.rs`) makes a new function entry
at a CALL target and treats every other flow target as a same-function successor,
so a routine reached only by a tail `B` is absorbed into whichever function
branched to it and never becomes a function at all — the second largest class of
the ARM entry-recall gap. Splitting at a tail call cannot change *which*
instructions the walk decodes: a function entry is walked, hence decoded, either
way, so moving a target from the instruction worklist to the function worklist
leaves the walk's closure fixed and only grows the function set. The split is
therefore computed **after** the walk, where complete predecessor and region
information is available instead of whatever the worklist order happened to
expose, and — like `ptrentry` — emitted as an additive entry-fact stream that
never rebuilds the Listing. Recognising the tail call is easy; telling one from a
rotated loop head is the whole problem, and the naive rule (split at every
unconditional-branch target whose predecessor ends the flow) measures 39%
precision, splitting a real function body more often than it finds one. Four
guards, each measured on the corpus, take that to 94.6% with no split bodies:
every predecessor of the target must be an unconditional branch (a fall-through or
conditional-branch predecessor means the caller's straight-line code runs into it,
which is ordinary intra-function flow); the branch must **leave the caller's
entry-ordered function region**, so at least one other discovered entry lies
between the branch and its target; the target's flow region must reach a `RETURN`
or a computed jump, the same terminating-routine validity `ptrentry` uses and with
the same absence of a length floor; and the target must not open with a stack
restore, because a function does not begin by tearing down a frame it never built
— that shape is the caller's shared epilogue. The region crossing is the
load-bearing one: dropping it costs 43 points of precision and splits over five
hundred real bodies, while a stack-discipline model (reject a branch taken with an
unmatched `PUSH`/`SUB SP` still open) was implemented, measured, and dominated by
it on both precision and recall. As with `ptrentry`, the region is the
entry-ordered one — the nearest preceding discovered entry — which is the
granularity the tier has and errs conservative on a sparsely discovered image.
Two of the four guards are satisfied by an *absent* model rather than by
evidence: the predecessor test reads the reference model and the epilogue test
the disassembly text, and a walk can be told to capture neither (above), which
would leave the naive rule — and on the fixture it accepts the shared epilogue
the full model rejects. So the pass checks for both models up front and yields
nothing without them. In production the gate that enables the pass is the same
one that enables the models, so the check is invisible there; it is what keeps a
later change to either gate from quietly reducing the four guards to the rule
they replaced. Output-changing (more functions), hence default-off; ARM-only and Listing-tier, so
it is a strict no-op on every other architecture, with `listing off`, and on the
XML datatest path.

**Literal-pool inference** (`poolentry`, default-off; kuna;
`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_poolentry.rs`) is aimed at
the gap walk itself rather than at what the walk misses. AIF advances its cursor by
**one byte** on a reject, with no instruction-alignment filter, because the
undefined-gap query it drives is byte-granular by construction. An ARM PC-relative
literal pool is data, so it *is* an undefined gap, and the cursor probes every byte
of it. On a Cortex-M image the pool words are SRAM addresses `0x2000_xxxx` whose
high halfword decodes as `movs r0,#0`, which clears the two-mnemonic fingerprint
gate as reliably as a real prologue does; AIF therefore accepts an entry one
halfword *before* the real function, falls through into it, reaches its return, and
on accept jumps the cursor past the whole body — so the true entry is never probed
at all. In A32 there is no halfword granularity and conditional execution makes
almost any word a legal instruction, so the same mechanism plants the phantom on the
pool word itself. Upstream Ghidra does not have this defect and needs no equivalent
of this pass: its reference analyzer defines pc-relative literal targets as **data**
before AIF runs, so those bytes are not an undefined gap there. kuna's Listing has no
literal-pool data-definition step, and this pass reconstructs the missing definition
after the fact.

The reconstruction is **reference-driven**. A word counts as a literal only when
some instruction actually loads it: either the resolved absolute `[0x…]` operand the
ARM disassembly prints for `ldr rN,[pc,#imm]`, or the unresolved `[pc,#imm]` form
that `vldr`/`ldrd` print because they compute the target in the semantic body — plus
the second word of a 64-bit literal, which nothing loads on its own. Completing that
second form is not a detail: without it every pool holding a float or a 64-bit
constant under-runs and the additive consumer below plants its entry *on* a pool
word, which is the difference between 19 split bodies at 89.7% precision and one at
98.4% over the measured corpus. The `[pc,#imm]` base needs the decode mode, which is
read from the engine's context database — the same `TMode` the bytes at that address
were decoded under, whichever pass painted it — so a language with no such context
answers "no mode" and the form is disabled outright, which is one of the reasons the
predicate is vacuous off ARM. The scan reads the decoded Listing **and** the
speculatively-decoded bodies of the gap-discovered routines, because a pool
sandwiched between two gap-discovered functions is referenced only from inside one
and a Listing-only scan silently finds nothing at exactly the shape being targeted.
A pool is then a **maximal run of adjacent referenced words**: unreferenced words
break the run, which makes the inference strictly more conservative than an ELF `$d`
mapping-symbol oracle, and bridging them was measured and rejected — a bridged run
swallows short real functions and destroys reachable bodies.

Two consumers hang off that one predicate, and they rest on different warrants. The
**recall** consumer emits an entry fact at the first address after a pool that abuts
a *return-class* terminal, when that address is still undefined and passes AIF's own
fingerprint and valid-subroutine tests. The return class is what separates an
inter-function pool, which follows a `bx lr` or `pop {..pc}`, from an intra-function
pool, which follows the unconditional branch the compiler emits to jump over it; and
because the fact is purely additive and never re-seeds the walk, "never removes an
entry" is a property of the wiring here exactly as it is for `ptrentry` and
`tailcallentry`. The **precision** consumer drops an AIF accept that lies inside an
inferred pool — but only when that pool's end carries a replacement entry, one this
pass just added or one another stage already found. That pairing clause is the whole
safety argument: the predicate's soundness (no accept inside an inferred pool was
ever a real function address, across 4,220 removals on the measured corpus) says
nothing about whether the *body* the phantom was decompiling survives, and unpaired
suppression leaves 531 real functions with no entry at any address while paired
suppression leaves zero. A paired removal is a MOVE, which restores a wiring-level
guarantee to the half that removes.

One residue is disclosed rather than gated away. When a literal reference resolves
onto the first word of a function the Listing never decoded, the inference cannot
tell that word from a pool word, and the entry moves four bytes into a real body.
It happens once in the measured corpus, and the only guard that removes it —
refusing to emit at a known branch target — costs 108 of 189 recovered entries, so
it is dominated. Output-changing (it both adds and relocates functions), hence
default-off; ARM-only in effect and Listing-tier, so it is a strict no-op without
`listing`, without `aif`, on the XML datatest path, and on every architecture whose
constants live in `.rodata` rather than in `.text` interstices.

**The four ARM entry passes reach the default path through the preset** (DIV-93).
`cortexmvectors`, `ptrentry`, `tailcallentry` and `poolentry` each ship default-off in
the catalog, which is what keeps the XML datatest corpus and an explicit
`--mode reliable` byte-identical; but all four are members of `AGGRESSIVE_OVERRIDES`,
and `auto` selects `aggressive` for any binary under 500 KiB, so on the whole-binary
surfaces (`decompile-all`, `functions`, `decompile-project`, the WASM front-end and the
benchmark) a stripped ARM image of that size gets all four. The preset supplies
`listing` and `aif` ahead of them in the same list, which is what the last three
consume; a preset that enabled them without `listing` would enable nothing. They are
evaluated jointly because they compose: measured over the 110 stripped non-x86-64
decbench twins (50,724 symbol-table function starts), entry recall rises 44,957 ->
47,330 (88.63% -> 93.31%) while mid-body false entries *fall* 8,333 -> 7,117. 98.8% of
the 2,402 added entries are real function starts, no ground-truth entry is lost, and
`poolentry`'s 1,217 removals contain no ground-truth address — so the combination
improves recall and precision at the same time rather than trading one for the other.
Off ARM the flip is a measured no-op, not merely an intended one: entry sets are
identical over 90 x86-64 twins and the 12 i386 PE images inside the ARM corpus, and
emitted C is byte-identical over 8 x86-64 binaries. Three of the four enforce that
with an explicit architecture early-return; `poolentry` instead keys on PC-relative
literal pools, which no non-ARM target in the corpus produces. The cost is real work for real
output — discovery-only `kuna functions` runs about 6% longer on a Cortex-M image
because it discovers and reports more functions — and is amortized away end to end,
where the extra bodies dominate the extra discovery.

Driver defaults (kuna): `kuna decompile-all` and `kuna decompile` inject
`option listing on` unless the caller names `listing` (DIV-15/DIV-22) — without it
the default-on no-return propagation is a structural no-op and a stripped binary's
unnamed exit wrappers swallow the functions after them. Under the `fast` preset
(DIV-41), those full-tier injections stay off and `fast_funcdisc` is on for
unfiltered `decompile-all`, `decompile-project`, and `functions` inventory runs.
An explicit address selection suppresses the preset-provided walk unless the
caller spells `--option fast_funcdisc on`. Text-surface name selection also
suppresses a preset-provided walk on the first attempt and restores it in a
retry a name miss triggers, ahead of the held-back non-x86-64 discovery-bundle
retry, so a miss is diagnosed exactly as with the walk on; when the preset
leaves the walk off there is nothing to defer and no extra attempt. A placeholder
spelling (`sub_<hex>`, `FUN_<hex>`, `func_0x<hex>`) keeps the walk from the
start, since its entry may exist only because the walk found it. Selection remains exact even when
analysis is forced on. Under `reliable`, `kuna functions` keeps the Listing off: metadata-only
name enumeration gains nothing from the 0.21 s → 5.7 s full decode measured for a
stripped tar (DIV-15). The console and XML datatest paths never build either model
by default, which keeps every parity gate byte-identical.

(kuna) **The on-demand cross-reference query**
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (build)`) is a second reader
of the same bytes, and is not an `AnalysisPass` at all: it is the read-only index
behind `kuna xrefs` and `kuna strings`, built after the caller has already
committed a program, and it commits nothing back. It repeats the Listing's
two-worklist descent but keeps every input varnode of every p-code op rather than
just `in0`, because the data references an RE agent navigates by — who reads this
global, who takes this string's address — are exactly the part the Listing model
drops. Two rules carry the weight. First, a **direct** flow op's `in0` is the
branch target and is filed as control flow, but an **indirect** one's is not a
target at all: `JMP qword ptr [__imp_VirtualProtect]` lifts to a single
`BRANCHIND` whose `in0` is the import slot, and treating that like a direct
branch's operand made every import veneer in a program reference nothing. Second,
an import has **two addresses under one name** — the IAT/GOT slot and the
forwarding veneer that jumps through it, both of which `pe_iat` (§1.3) names —
so the query joins them into an alias class along the decoded forwarding jump
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (veneer_at)`) and answers
`--to` over the whole class, with the forwarding jump itself excluded. A veneer
is recognised only when its indirect jump reads a **decode-time constant**
address, which is what distinguishes it from a jump table (whose address is
computed, and which therefore lifts to a `LOAD` through a temporary); the class is
never derived from a shared symbol name, which would fold genuinely distinct
same-named functions together. A shared library that calls its own export
through `name@plt` adds a third address: callers reach the body only through the
stub and its GOT slot. When the query selects a function **by name**, its class is
widened by every veneer whose slot carries a dynamic relocation against a symbol
the image defines at that body's address
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (export_alias_class)`). The
join is again the relocation's binding, not the name, and a query by address keeps
the plain class.

(kuna) The **call** spelling of that first indirection needs a third rule, because
it does not arrive in the shape the first one reads. `CALL qword ptr
[__imp_HeapAlloc]` — what MSVC emits for every Win32 call — does not put the slot
in the flow op's own `in0` the way `JMP` does: SLEIGH lowers it as `$U = COPY
(ram,slot,8); ...; CALLIND $U`, so the slot reaches the generic
direct-memory-operand arm and was filed as a `Read` of a pointer. A read is not a
call-graph edge, so on the filing image — a Windows PE — a function Ghidra lists
33 callees for came back with 9, and every one of the 24 missing was an imported
API the function plainly calls. The walk now resolves a `CALLIND`'s destination
back through the single-instruction `COPY` chain that materialised it
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (is_indirect_call_slot)`)
and files the slot it lands on as a `Call`. The chain is bounded at four copies
and never leaves the one instruction, so the rule can only re-label an operand
that instruction genuinely fetched its destination from; every other data operand
of the same instruction is judged exactly as before. The `Call` row **replaces**
the `Read` rather than joining it: one instruction makes one reference, carrying
the strongest claim it supports, which is already the collapse rule the
whole-binary graph states (§9.7). The cost is that a caller filtering `--kind
read` for data readers no longer sees the slot, which is the right trade — the
instruction is a call site, and the slot is where the callee is named. The same
rule files a `BRANCHIND` directly through a slot as `Jump`, making a forwarding
veneer a call-graph edge to the import. That edge and `forwardsTo` describe the
same relation; the alias-class query still excludes the forwarding instruction
from inbound results, so asking who calls the import does not count its own
veneer. This intentionally changes the public xref `kind` for PE `FF 25` veneers
and x86 ELF PLT stubs from `read` to `jump`.

(kuna) A call materialises its own **return address**, and the constant scan must
not read it as a reference: it is the instruction's fall-through, which x86 pushes
as a constant, A32 copies into `lr` and MIPS into `$ra`, so a call's fall-through
is never filed as `Data`. AArch64 spells it differently — `bl` and
`blr` lift `x30 = inst_start + 4` to one `INT_ADD` of two constants — so the
fall-through never appears as a constant and the scan filed the first addend, the
`bl`'s own address, as a `Data` reference from every call site to itself (and,
`--to` a call site, as an incoming one). In an instruction that calls, an op that
adds two constants into the fall-through is that same return address, and neither
addend is filed
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (is_return_address_sum)`).
The rule names the call's sum, not the instruction's own address: `adr x0,.`, a
constant equal to the instruction's address, a PC-relative sum that lands anywhere
but the fall-through, and the same sum outside a call — a Thumb-2 `vldr
s0,[pc,#8]` reads `pc` as `inst_start + 4`, which is its fall-through only by
width — are reported as before.

(kuna, GH #1360) Not every constant equal to the fall-through is a return address:
`adr x0,.+4` forms the address of the next instruction exactly as `adr x0,.` and
`adr x0,.+8` form theirs, and the scan dropped it along with the return
addresses. The fall-through is now skipped only where the instruction leaves a
return address
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (is_return_address)`).
One that **links**
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (links)`) transfers
control: a `CALL`, `CALLIND`, `BRANCH` to an address, `BRANCHIND` or `CALLOTHER`.
That covers the links SLEIGH spells without a `CALL`: x86 `call $+5` is a push
and a `BRANCH`; PowerPC `bcl 20,31,$+4`, `bl` to the next instruction, RISC-V `jal
t0` and MIPS `bal` past its delay slot write the link register and `BRANCH`; a
RISC-V PLT entry's `jalr t1,t3` is a `BRANCHIND`; x86-64 `syscall` saves the
address in `rcx` beside a `CALLOTHER`. The AArch64 sum rule above applies in
the same instructions. An instruction that does not branch can still leave a
link value, in two shapes. A32 `mov lr,pc` lifts `lr = inst_next + 4` for the `bx` after it, so a
fall-through combined with another constant in one op is not an address the
instruction forms. MIPS `nal` (`bltzal $zero`) is a branch that is never taken
and lifts to nothing but `ra = inst_next`; it is told apart by its delay slot
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (has_delay_slot)`): its
fall-through lies past the slot, beyond its own encoding, and only a branch has
one. The compiler spec is no help here, since MIPS64's names no
`<returnaddress>`. A slot behind an instruction that does branch — a `RETURN`
or a `CBRANCH` to an address (`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (branches)`)
— is an ordinary instruction, so SuperH `rts; mova` and `bt/s; mova`, which form
the address right after the slot, file it. The slot is asked only of an
instruction that moves the fall-through whole and does not branch, so the walk
pays the second decode almost nowhere. Anything else that moves the fall-through whole — a copy or an extension
of it, or a store of it — files it as `Data`: AArch64 and A32 `adr`, Thumb-2
`adr.w`, x86-64 `lea rax,[rip]`, `mov eax,offset next`, `push offset next`, SuperH `mova`. The
register-pair carry and the PIC base harvest below made the same assumption
about a value they compose, and skip it only in an instruction that calls (the
carry) or links (the harvest), so an `auipc`+`addi` pair that ends right before
the label it forms files the label. Over 112 images (x86-64, i386 ELF and PE,
AArch64 ELF and arm64 Mach-O, A32/Thumb, MIPS, PowerPC, RISC-V) no row changes:
armel libc's 1,130 `mov lr,pc`, PowerPC libc's `bcl` thunks, x86-64 libc's 436
`syscall`s, every RISC-V PLT `jalr t1,t3` and the `nal` in MIPS64 `ld.so.1`'s
`_dl_start` still file nothing, and no image there forms an address at its own
fall-through, so only the fixtures gain rows.
Emitted C is unchanged; the query is not on the decompile path.

(kuna) An edge also has to survive being resolved to a **node**, and the walk's
function set is the wrong authority for this one. The walk calls nothing outside
an executable section a function — an IAT slot lives in `.rdata`, so it is never
one — while the inventory does name it, because `pe_iat` (§1.3) registered the
import there. For PE, the graph therefore falls back from the walk's function
set to the inventory extent containing the target
(`decompiler/crates/kuna-cli/src/callgraph.rs (CallGraph::callee_of)`), which
is the same fold it already applies to every callee it reports. ELF historically
inventories the PLT veneer only, not its GOT slot, so the graph admits the slot
half of each decoded forwarding relation as a zero-extent node; `decompile-graph`
materializes that missing node as a bodyless row with the veneer's name. The
ordinary named import case classifies as `import`, while an unnamed linkage
target such as ELF PLT0 classifies as `data`. Its `forwardsTo` target and
jump-edge endpoint are therefore the same row on both formats. This is
deliberately confined to the graph model: `kuna functions`
keeps its established loader inventory, while an ELF `decompile-graph` document's
`functionCount` and `functions` array gain the recovered GOT-slot rows. An address
in neither the inventory nor a decoded forwarding relation is still not an edge.
Measured over 120 in-tree images, seven changed and none lost an edge: on
`pe_imports.exe` the functions reachable from the entry point went 47 -> 52 and
those with no caller 115 -> 103.

(kuna) The same two addresses make the import's **name** a selector that matches
two entries, and the selector model's answer to that is a refusal naming every
candidate — which would refuse a question that has exactly one answer, since either
address alone answers it. So a contested name is not decided at lookup time at all:
whether its candidates are one callable is a property of the decoded forwarding
jumps, which only exist once the walk has run. The candidates are carried into the
walk as its focus set, so every one of them is decoded, and the ambiguity is settled
afterwards against the alias class
(`decompiler/crates/kuna-cli/src/xrefs.rs (Resolution::settle)`). Candidates that all
lie in one class are one callable and the query proceeds at the class's code half —
the forwarding veneer rather than the pointer slot, because that is the address the
answer will next be disassembled at, with the lowest address breaking a tie between
several veneers through one slot. Candidates that do not all share a class are
distinct functions and keep the refusal, with every candidate still named. The fold
therefore still rests on the decoded jump and never on the shared name; the name only
selects which addresses to check.

(kuna) Because the query runs that descent **itself**, it takes its own analysis
bundle rather than a decompiling surface's. `kuna functions` and `kuna decompile-all`
inject the DIV-15/DIV-20/DIV-68 defaults (the Listing, the prologue-pattern scan,
AIF); the query surface takes the two *discovery* flags and declines the Listing,
because the Listing's walk is this walk — a second recursive descent over the same
bytes, decoded a second time. On a 466 KB obfuscated i386 image that walk, plus
`operand_refs`' third linear decode, was 1.66 s of a 3.4 s answer that is
byte-identical without either.

The two discovery facts the Listing fed are produced from the query's own decode
instead. The `<patternpairs>` prologue starts are handed straight to the walk as
seeds (`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (discovery_seeds)`,
gated by `funcstart_patterns` and to the non-x86-64 architectures the injection
covered, so x86-64's seed set is exactly the caller's inventory). The speculative
gap-walk (`aif`) is run over the instruction partition the query's own walk leaves
behind (`gap_entries` → `Listing::from_partition`), and every function it accepts is
walked like any other seed, so the references inside it join the index. That recall
is not optional decoration: a function whose only inbound edge is an indirect call
through a data table has no CALL edge for any descent to follow, and without the
gap-walk a `--to` query loses every call site that lives inside one — measured on a
stripped i386 PE as 61 of one function's 174 callers.

(kuna) ARM reference walks also recover the
LR-saving frame roots used by the Listing when both `funcstart_patterns` and
`armframes on` are enabled. The default `armframes inventory` recovers A32 frames
for the function inventory only, and no CLI discovery bundle or mode preset
selects `on`. Below `on`, reference discovery keeps its existing seeded/AIF walk;
with `off`, the Listing also keeps its Thumb-only inventory recovery.

Frame recovery never drops an inventory entry the option-off pipeline reports
without evidence against it
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_frameretain.rs`). Once
at least one root validates, the Listing pass first computes that frameless
inventory under a discarded decode context: the walk after the Thumb prologue
scan, plus the AIF, pool and pointer entries over it. Two mechanisms would
otherwise lose those entries. A recovered frame's walk follows a tail branch into
a routine the gap walk had found on its own and absorbs it as same-function flow;
on a stripped U-Boot this dropped `invalidate_dcache_range`, reached by `b` from a
newly recovered caller. And the prefix scan below can replace a root with
literal-pool words in front of it that happen to decode as straight-line code,
which dense Thumb encodings do readily. So a root the frameless walk already has
is replaced by a prefix only when it lies inside one of the prefix's instructions,
as the false `PUSH.W` halfword of a `LDR.W` does, and after the last rebuild every
frameless entry the recovered inventory lacks is published unless the evidence
contradicts it:
the entry is data or lies inside a decoded instruction; a fall-through or a
conditional branch runs into it; its first instruction is predicated, with a flow to
its own fall-through, which no function entry can be because the condition flags
are undefined there (literal-pool words in front of an A32 frame decode this way);
an accepted body of the post-frame gap walk runs into it, a body that walk refused
covers it, or a later interworking call contradicted its decode mode; or non-call flow from it reaches decoded code that is no function entry,
as a switch case does when its function's computed jump stayed unresolved. A
shrink-wrapped `cmp; ble` prefix still replaces a push the gap walk had reported,
because the push then has a fall-through predecessor. Over the 98 stripped ARM
images of the DecBench dataset, scored against their original `STT_FUNC` symbols,
the option dropped 1,756 symbol starts the default inventory found and now drops
34; nearly all of the rest are still entered by a fall-through from literal-pool
words in front of them. It keeps 1,738 of the 1,746 starts it adds. Entries without
a matching symbol go from 8,528 to 8,583, 54 of them on three Cortex-M images where
no frame validates and the option now reproduces the default inventory exactly.
Computing the frameless inventory adds about 12% to frame recovery on the 5.4 MB
U-Boot image.
The shared
`raw_arm_prologue_seeds` scan matches unconditional A32 `STMDB SP!, {…,lr}`
only at word-aligned ARM addresses and Thumb `PUSH` / `PUSH.W` only where the live
`TMode` selects Thumb, in the selected decoder's instruction byte order.
This includes BE8 images whose ELF data are big-endian and instructions are
little-endian. A Thumb-shaped halfword inside
an ARM instruction is not a Thumb prologue. Metadata and explicit `--isa` paints
therefore control both ordinary decoding and root recovery.

A matching prologue is only a candidate: its bounded validity walk must stay in
executable memory, avoid known instruction overlap and unclaimed escapes, and
reach a valid termination. Claims cover every byte of each reachable instruction,
including the second halfword of a Thumb-2 instruction. Candidate admission
rechecks those spans after earlier roots or explicit focus addresses have walked.
A conditional return records a terminating path, and the frame probe keeps
following its not-taken successor so the rest of the function is claimed. A
computed jump ends its path. Code reached only through a call's fall-through is
speculative, because the callee may never return and literal-pool words often
follow such calls: an undecodable word, an invalid flow or the step cap on a
speculative path ends that path instead of rejecting the candidate, and a
speculative path stops at another prologue candidate rather than absorbing the
next function. Invalid flow reached directly, without an intervening call, still
rejects the candidate, and a push on a valid direct successor path remains body
code. Only frame probes follow a conditional return this way; the AIF gap walk,
pool, pointer and referenced-target validators stop at every terminal
instruction exactly as before (`decompiler/crates/kuna-analysis/src/analyzers/aif/mod.rs (follow_subroutine)`).
With `aif` enabled, a fingerprint-supported prefix outside the claimed frame bodies
that reaches a recovered push replaces that push as the root before either the
Listing or the reference query finalizes boundaries. Interior AIF candidates
remain owned by the earlier frame that reaches them. Prefix probing is restricted
to gaps containing frame candidates. After the frames and explicit focus are
walked, prefixes are rechecked using the expanded fingerprint corpus and the
original gap partition, where the whole prefix-plus-frame body is still available
for validation. Both prefix guards use that original partition to exclude
established code; the expanded corpus supplies fingerprint evidence, not new
coverage boundaries. A prefix reached only through a provisional call remains
eligible for validation and replacement of its interior frame.
Direct calls protect a frame only when their source is reachable
independently of the proposed obsolete bodies. Reconciliation considers all
validated frame candidates, including ones first reached as speculative callees.
It substitutes validated prefix instructions into the recorded successor graph,
then follows branches, fall-through and calls from the original entries,
admitted explicit focus, surviving frames and validated prefixes. Unreached
call cycles cannot establish their own boundaries; a reachable independent
caller protects the whole recursive call chain. Both Listing and xref consumers
use this same support rule
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_framecalls.rs`).
Any replaced provisional frame is removed from the function and graph seed sets.
When replaced bodies cannot be retained, the reference walk rebuilds from
the supplied seeds, original query focus and reconciled frame roots before the
ordinary AIF gap pass. Its decoded partition, references, discovered callees,
successor graph, indirect-call sites and switch records are rebuilt together;
instructions reached only through a discarded speculative body cannot survive
as ownerless references or seed unrelated callees. Queries with no replacement
reuse their existing walk.
The rebuild reconsiders every independently validated frame candidate, including
ones already reached as callees before their candidate was processed. Admission
checks the surviving bodies again, so a discarded caller cannot hide a real
unreferenced frame, and an interior candidate does not become a boundary.
Both consumers recheck prefixes after each rebuild, until no roots change.
Discarding a speculative call can make its former callee eligible for prefix
replacement on the next pass. Reconciled candidates replace the prior candidate
set, so removed roots are never reinstated; replacements move roots strictly
toward earlier validated prefixes, ensuring progress. Ordinary queries without
late replacements perform no extra rebuild; compatible ARM prefix extensions
can also keep unrelated bodies, as described below.

A provisional frame can also have been decoded in the wrong ISA before a later
interworking call establishes its mode. Both walks record the decoded spans of
each candidate's reachable body and the `TMode` used for each span. A direct call
into any covered byte, including the interior of a former instruction, withdraws
the candidate if its newly established mode disagrees. Rebuilding removes its
instructions, references and derived callees together. Prefix replacements run
first, so calls from discarded interiors cannot settle a frame's mode.
The saved context and mode checks remain available through the ordinary AIF gap
pass. The inventory walks accepted pointer-table and checked AIF roots before
publishing Listing consumers, so their calls can invalidate provisional frames
as well. Each inventory rebuild copies the original independently decoded
instructions, function records, references and proven mode corrections before
walking speculative roots.
Recovered calls publish their modes only over successfully decoded instruction
spans, so they cannot repaint retained callers. New callees keep their
interworking evidence outside that partition. Only the original partition is retained: discarded
frames and their derived callees are still rebuilt from surviving roots.
Pointer-table additions refresh the corpus before AIF runs. Before any
AIF body is walked, `ptrentry` and `poolentry` inspect the pre-AIF partition. Their
accepted pointer entries, pool-end additions and filtered AIF entries are retained
as one result. Only surviving AIF entries seed the interworking rewalk; pointer
and pool entries remain additive facts. This prevents speculative coverage from
rejecting a pointer target or hiding a pool boundary, and prevents a filtered AIF
entry from being recommitted by `funcdisc_recursive`. A frame replacement or ISA
invalidation discards the cached checks and recomputes them against the rebuilt
partition (`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_entrychecks.rs`).
Mode correction also runs with AIF disabled
(`decompiler/crates/kuna-analysis/src/listing/kuna_framemode.rs`).

Frame recovery retains its original validation records across reconciliation.
When `aifpoolslide` is enabled, frame-prefix reconciliation uses the same literal
word evidence as the ordinary AIF gap pass, including loads from validated frame
bodies before any prefix is considered. An accepted prefix on a referenced pool
word moves to the code after the pool. Its retained decode records exclude the
pool instructions, so neither their register writes nor their calls can supply
frame evidence. If the corrected address is already a frame root, that root
keeps its place; reconciliation never replaces an entry with itself
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_framepool.rs`).
A prefix pass reuses frame validity and claimed spans, and retains accepted prefix
bodies directly from the gap scan instead of validating them again. An unchanged
root set and unchanged fingerprint acceptance thresholds reuse the prior scan;
independent call support is still checked against the current graph. Corpus growth
that crosses a threshold triggers reconsideration
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_framecache.rs`).
For an ARM prefix whose validated body contains every old frame instruction with
identical decoding, and which contains no BLX, unrelated bodies can survive the
replacement. Both the saved and live context must select ARM throughout the
prefix body, the old body must have decoded in ARM, and the new entry must remain
undecoded. Only the affected callers' partition, references, flow, switch records
and fingerprint-context records are removed and rewalked. This recomputes data
references whose values originate in the newly admitted prefix. All other
replacements, including Thumb instruction interiors and changed modes, retain the
full rollback and rebuild
(`decompiler/crates/kuna-analysis/src/listing/kuna_prefixreuse.rs`).

The reference walk can reuse a validated instruction's p-code only when the
translator certifies that the lift commits no context and depends on no other
instruction. The immutable image, address, translator and complete context words
must match. Instructions without that certificate are translated normally;
interworking and IT-state writes therefore still execute. Prefix probes apply the
same context check before reusing such decode records
(`decompiler/crates/kuna-analysis/src/listing/kuna_decodereuse.rs`).

ARM frame and prefix probes use private decoder-context scopes. They preserve
the selected `TMode` while allowing local commits such as Thumb IT conditions,
then discard all probe writes. Provisional reference and Listing walks also
retain their pre-walk context: late replacement restores it before rebuilding;
otherwise accepted walks keep their legitimate interworking changes. Prefix
validation temporarily restores the saved pre-walk context. The xref corpus
instead retains the context words seen before each instruction's translation,
stored as runs in decode order. Only the two fingerprint instructions per entry
are rendered, each under its recorded context in a private scope. This retains
new callees' legitimate interworking modes as well as earlier fingerprints that
a later speculative branch could repaint, including callees identified after
their instructions were already decoded as body code. Rebuilds discard these
records with the obsolete partition. Rendering checks instruction lengths and
restores the live context afterward
(`decompiler/crates/kuna-analysis/src/listing/kuna_fingerprintcontext.rs`). These
scopes preserve context defaults, split-point values and explicit-set masks,
tracked registers, and cache write settings, including across nested scopes
(`decompiler/crates/kuna-sleigh/src/kuna_contextscope.rs`).
Prefix reconciliation compares roots with complete instruction spans, including
roots inside Thumb-2 instructions rather than only at their starts.
The ordinary AIF gap pass runs after the
recovered roots and explicit focus have been walked: their function count and
fingerprints can cross acceptance thresholds that the initial partition did not.
Mode changes from recovered calls remain confined to decoded instruction spans,
including discontiguous callee blocks. Undefined gaps retain their input modes
for this pass; no separate restoration scan or repeated body decode is needed.
Both reference queries and the inventory retain pre-frame validation bounds
for the later AIF check. AIF still admits starts only in current gaps, but its
non-strict body validator may follow a branch across a new frame boundary within
the same original gap. Pointer and pool checks still use the pre-AIF partition.
This preserves previously discoverable discontiguous callers without extending
validation across independently established code boundaries. Strict frame and
pointer validation keep their existing limits.
This admits rare frame prologues without a fingerprint-frequency requirement,
retains calls after an early return on another path, and assigns those calls to
the entry that reaches them. Discovery probes use the existing partition; only
late root replacement or contradicted frame mode rebuilds the reference walk. Disabling either `funcstart_patterns` or `armframes` disables this scan;
disabling `aif` does not. Recovery remains heuristic and bounded: frames with other
prologues, undecodable paths or uncorroborated flow escapes can remain undiscovered.

The `inventory` value is the default: it validates A32 frame starts in the
function inventory while retaining the existing Thumb-only inventory path.
The `on` value also validates Thumb frames and expands independent reference
walks; `off` restores the prior discovery path. The same function-start and
Listing prerequisites still apply. In the optimized DecBench U-Boot pilot,
full frame recovery adds 770 listed bodies and loses none; the corresponding
Betaflight pilot exchanges one gained body for one lost body. Default recovery
therefore targets A32 inventory roots. Short callbacks and vector-only handlers
remain separate discovery sources.

With `armframes` enabled (`inventory`, the default, or `on`), the Listing walk
also follows an A32 jump table. Unlike frame recovery, table following needs no
other option: not `funcstart_patterns`, which is off by default, and in the
reference walk not `listing` either. GCC
lowers an A32 switch to `cmp rN,#n` and a predicated `ldrls pc,[pc,rN,lsl #2]`
with its table of case addresses 8 bytes past the dispatch, or to `addls
pc,pc,rN,lsl #2` followed by one `b` per case. The dispatch's p-code is folded
with the switch-table lattice; only those two PC-relative shapes answer. The
case count comes from the guard, read as a Thumb `tbb` guard is, with the
dispatch's own condition as the range branch when it is predicated. An
unguarded dispatch reads nothing. Word-table entries must lie in the
dispatcher's executable section. The cases become successors and code
references of the dispatch
(`decompiler/crates/kuna-analysis/src/listing/kuna_a32switch.rs`). Without this,
frame recovery left every case block undefined. The AIF fingerprint histogram,
which frame recovery fills with the whole program, then accepted case blocks as
function entries and cut the dispatcher apart. Following a switch also decodes
the code its cases reach, and the walk absorbs a routine reached only by a tail
branch into the code that branches to it, as it does everywhere else. On stripped
U-Boot O2-noinline that absorbs 7 of the 2,836 functions, all of which frame
recovery without switch following lists: four tail-branch targets of `pointer`'s
cases, and `memalign_simple`, `efi_process_event_queue` and `malloc_trim`, the
tail-branch targets of functions the walk now reaches through a followed case.
`tailcallentry` splits such routines off.

A frame root is also withdrawn when the frame-expanded Listing enters it by
straight-line flow, the way a contradicted mode withdraws it. The instruction
just before the root must be a non-call that falls through or conditionally
skips into it. Tracing back, its run must start at a function entry or a branch
target. A shrink-wrapped routine saves LR a few instructions after its entry,
and once a caller reaches that entry, its fall-through runs into the `push`. A
run that begins at a call's fall-through is speculative and keeps the root: a
literal pool after a no-return call decodes as such a run into the next routine
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_frameflow.rs`). A
retained prior entry that a jump-table dispatch reaches is a case block and is
contradicted too. On the stripped U-Boot O2-noinline image these rules leave
recall at 92.0% and raise precision from 92.6% to 98.6%; `parse_label` and
`malloc` stay whole.

One inventory recovery shares its decodes. Frame validation, the AIF gap walks
(including the prior inventory's), prefix reconciliation and every Listing
rebuild decode the same image again. A decode is kept only when SLEIGH certifies
it context-free, together with the effective context words it read. It is reused
only while its address still reads those words, so a reused record is the
record a fresh decode makes, and it reports no context commits. These records
keep no p-code: the inventory never replays a frame body into a reference walk,
so the inventory's own validation records keep none either. A record is a
fixed-size slot per halfword of executable code, with its text and flow targets
in shared arenas, so the whole image's records cost about 16 bytes per halfword
(`decompiler/crates/kuna-analysis/src/listing/kuna_decodememo.rs`).
A `--jobs` worker does not search at all. The parent's recovery leaves a record of
its final roots, code-pointer and AIF entries and retained prior entries
(`AnalysisOutput::arm_frames`). The worker builds the final Listing from that
record under the same context lifecycle
(`decompiler/crates/kuna-analysis/src/analyzers/aif/kuna_framereplay.rs`).

Full reference expansion can substantially increase query cost. In a historical
measurement on a 400,556-byte stripped ARM BusyBox ELF,
`xrefs --to puts --kind call` initially reached 2,271 instructions; frame
recovery expanded the walk to about 74,000. The recovered query found 70 call
references instead of 43 and took roughly twice as long. Disabling `aif` with
`armframes` enabled retained 66 references at lower cost. Speed comparisons use
release builds, one new process per query and warm filesystem caches; a repeated
query does not reuse an index from another process.

ARM runtime reference queries with `funcstart_patterns` enabled retain decoded
fall-through, branch and switch successors to resolve caller ownership after all
entries are known. Each entry owns only
instructions it reaches without passing another entry; shared blocks prefer the
greatest entry that reaches them. An unrelated function in a gap cannot absorb
another caller's discontiguous block merely by preceding it in memory. A later
direct call can still establish a separate callee in previously decoded code.
Incoming owner labels, outgoing buckets, intra-function branch filtering and
indirect-call flags all use these same body owners. This graph walk reuses the
decoded instructions and does not invoke the decoder again.
CLI call-graph ownership projects these reachable owners onto the canonical
inventory too, so direct callers, callback references and graph edges agree with
the reference index for discontiguous bodies. Where no reachable owner is
available, bounded inventory extents still resolve undecoded import slots.
Graph seeds are appended during discovery, then sorted and deduplicated once
when the index is finalized, before any instruction-count query reads them.

(kuna) A reference query also seeds the walk with **the address it was asked
about**. The same structural gap applies to the query target itself: `--from <entry>`
about a function no descent reaches answered `count: 0` about a function that plainly
has references. The named address is walked after the seeded descent and the
recovered prologue candidates are merged with explicit focus addresses in address
order. A recovered frame's walk stops at another pending frame candidate unless
its own validated body claimed that instruction, so a frame whose call never
returns cannot absorb the function placed after its literal pool.

ARM runtime xref walks with both `funcstart_patterns` and `armframes`, and inventory rebuilds that
admit recovered frames share one context lifecycle
(`decompiler/crates/kuna-analysis/src/listing/kuna_walkcontext.rs`):

- Independent seeds, frames, AIF entries and focuses select their input mode
  from the context captured before the walk. A queued direct callee retains
  its call's mode, even if another seed is walked first.
- Branches, fall-through and switch successors carry the decoding instruction's
  mode. A SLEIGH mode commit at the successor supplies an explicit change;
  ordinary calls inherit the caller's mode. Thus a distant block does not
  inherit the mode of a different function placed between it and its entry.
- Automatic SLEIGH `TMode` writes are masked throughout the walk. Their recorded
  commits remain available as control-flow evidence. Other context fields,
  including Thumb IT state, keep their existing decode semantics.
- Each instruction uses a temporary effective read mode without changing database
  boundaries. Failure publishes no selected mode. Success publishes it only over the
  instruction's complete byte span. Fingerprint and decode-reuse keys observe
  the same effective context as the instruction.
- Speculative frame scopes retain their bodies, references and bounded context
  changes together. A full rebuild rolls them back and clears queued mode
  evidence. Prefix extension reuses only compatible ARM bodies; replaced
  instruction/reference records are removed before the extension walks.
- Final publication needs no gap or body repair pass: only surviving decoded
  spans changed mode. Unclaimed bytes retain their input modes with AIF off,
  below its corpus threshold, or enabled. Repeated queries and later
  decompilation therefore see the same unrelated instruction streams.

Initial Listing discovery keeps its own context behavior, `armwalkmode`'s
carried modes and the optional `flowmode` proof policy. Already established Listing bodies are retained during
a recovery rebuild. Provisional
bodies contradicted by direct interworking, including calls into instruction
interiors, are invalidated using the recorded call mode. Inventory rebuilds
retain these rejected heuristic entries for the rest of the discovery run;
later AIF scans and prefix replacements cannot restart the same stale retry.
Pointer and pool checks continue to use the partition preceding the AIF rewalk.
Frame and AIF probes are scoped, and original-context prefix validation remains
separate from the expanded fingerprint corpus. Scoped read and write policies
are restored on exit. Ordinary ARM AIF scans, including recovery-disabled xref
gap scans and their fingerprint rendering, also run in a context scope. Speculative
`TMode` writes are masked while other fields, including Thumb IT state, remain
active inside the scan. Dropping the scope restores values, write boundaries,
and read/write policies on every exit. Accepted entries are returned as facts;
the subsequent real walk supplies their interworking effects. Non-ARM walks
retain their existing context behavior.

A focus preceding its frame claims
the reachable push as body code before it can become a boundary; an earlier
recovered root still owns an interior focus.
An address the natural walk already claimed is already in `decoded` and attributed
exactly as before — the focus pass can only add
coverage, never re-attribute an instruction another entry owns. An address that does
not decode is dropped rather than recorded as a function, so a byte in the middle of
a string does not become `sub_<addr>`.

(kuna, GH #1406) A focus address is decoded only where the walk decodes at all: in
a section the linker marked as code. The loader obeys the segment instead, so memory
can be executable without being marked. An Apple toolchain links a function placed
in `__TEXT,__const` with no instruction attribute although `__TEXT` is `r-x`, a
bare-metal link script leaves `.ramfunc` flagged `WA` in an `RWE` `PT_LOAD`, and GNU
ld links AArch64 `.rodata` into the `R E` segment. `kuna xrefs --from` such an
address answered `count: 0`, the same document a function with no references gets.
The walk still does not decode that memory on its own account: most of it is
strings and tables, and the Mach-O inventory keeps its symbols out of
`kuna functions` (GH #1339). An explicit `--from` source there is decoded as code when the image
says it is code
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (build_with_unflagged_focus)`).
The section holding it must lie wholly inside a segment the image maps executable
(ELF `PF_X`, Mach-O `initprot` execute) and have a type that can hold instructions
(ELF allocated `SHT_PROGBITS` that is neither TLS nor merged strings; Mach-O
`S_REGULAR`, `S_SYMBOL_STUBS` or `S_COALESCED`)
(`decompiler/crates/kuna-analysis/src/listing/kuna_unflaggedcode.rs (placement)`).
An ELF symbol table must not declare a data object at the address, and something
must say the address is code: a symbol names it and a direct call or branch the
seeded walk decoded targets it (checked when the focus pass reaches it, after that
walk has drained), or an ELF symbol table declares a function there, an ARM
`STT_FUNC`'s Thumb bit aside
(`decompiler/crates/kuna-analysis/src/listing/kuna_unflaggedcode.rs (declared_function)`).
The symbol is any Mach-O `nlist` or ELF function or untyped label, never a mapping
symbol (`decompiler/crates/kuna-analysis/src/listing/kuna_unflaggedcode.rs (named_at)`).
A call alone is not enough: on a static ARM glibc image the Thumb `_start` read in
A32 is a `bleq` into the `.rodata` strings, and that target is no more code than any
other string.
Selection alone is not enough, because the same memory is mostly data: GNU ld put
x86-64 `.rodata` in the `R E` segment until `-z separate-code` became its default
(binutils 2.31), and still does on AArch64, and a string there decodes to a run of
plausible conditional jumps. A Mach-O `nlist` carries no type,
so a symbol alone is not evidence there. Only the source's own body is decoded: its
branches are followed while they stay in that section, and a call out of it is
filed and walked under the ordinary rules. The seeded descent can reach the address
first, as a callee, and stops at it as before; only the focus pass decodes it.
`--to`, and every other surface built on the walk, decodes nothing new. A PE
section is its own mapping unit, executable and walked or not executable at all, so
PE has no such gap.

Every answer also carries a `coverage` object
(`decompiler/crates/kuna-cli/src/xrefs.rs (coverage_of)`): whether the walk decoded
the queried address, the section it is in, whether that section is marked as code
and whether its memory is executable, and the call and jump targets in executable
memory not marked as code that the walk filed but did not decode and a symbol names
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (undecoded_flow_targets)`).
The references those targets make are missing from every answer. Only a direct
call or branch counts, never a call through a slot: Go's closure call `MOV
RAX,[funcval]; CALL RAX` is a `call` row to the funcval word in `__rodata`, which
holds a code address and is not code. A `--from` answer
about anything other than code decoded in a code section, and a `--to` answer while
such targets exist, say so in a note.

(kuna) Both of those rules read a reference out of *one instruction's* p-code,
which is the whole answer on x86-64 and no answer at all in 32-bit
position-independent code. There the address of a string, a global or a function
pointer is never a constant in the instruction that uses it: the program
materialises the GOT pointer at run time — `call <next instruction>; pop ebx; add
ebx,imm`, an idiom that exists for no other purpose — and every literal is reached
as base-plus-displacement, so the address occurs nowhere in the image and the
constant scan reports that every string in the program is referenced by nothing.
**PIC base folding** (`picbase`, default-on,
`decompiler/crates/kuna-analysis/src/listing/kuna_picbase.rs`) closes that with a
deliberately tiny abstract machine over the same whole p-code the query already
keeps: a value is a constant or an offset from the stack pointer, memory is
modelled only at stack offsets (enough to follow the `call`'s push into the
`pop`), a constant is tainted as PC-derived when it equals its own instruction's
fall-through, and only a tainted value may establish a base — so a plain
`mov ebx,imm` cannot. GCC's out-of-line form is covered by the same machine: a
direct call whose callee delivers the return address in a register (probed like a
veneer, at most two instructions) hands that register the call's own
fall-through. Three shapes are then read off each instruction *independently*, with
the base seeded and nothing else assumed, so no state crosses a control-flow
edge: the address a `LOAD` reads, the address a `STORE` writes, and a constant
that lands in a register, which is the address-taken case. A value computed only
into a temporary is deliberately not reported — in an indexed access the array
base lands in one, and filing it would claim a reference the instruction does not
form.

Two claims hide in that and they are licensed differently. A function that runs
the idiom *itself* computes the value and assumes nothing. A function that only
uses an inherited base — which is the case that matters, because kuna's own
inventory splits the filing crackme's prompt routine at its `int3` traps and the
`lea` that forms the prompt lands in a different entry from the idiom that set the
register up — is relying on the i386 System V ABI reserving that register as the
module's GOT pointer, so the recovered value is cross-checked against the image's
own `_GLOBAL_OFFSET_TABLE_` (the `.got.plt`/`.got` address) and every idiom in the
program must agree on one register and one value; absent that, nothing is claimed
module-wide. The rule that keeps ownership honest is refusal rather than
guesswork, because attributing a string to a function that merely sits near it is
worse than reporting nothing and no parity gate could see it: the base is offered
to a function whose body never writes the register at all, or from its own
establishment up to the next write of it (in GCC output, the epilogue's restore),
and to no other function. A body that reuses the register for its own purposes
contributes no references rather than wrong ones.

(kuna) One indirection further out is the same defect on ARM, and PIC base
folding does not reach it: an ARM immediate cannot hold an arbitrary address, so
the compiler parks the constant in a **literal pool** in `.text` and the code
loads it PC-relatively (`ldr r0,[0x86e4]` at 0x862c, and the word at 0x86e4 is
the string). SLEIGH resolves the pool address at decode time, so the walk files
that read — and stops, because 0x86e4 is all the instruction says. The literal
itself is referenced by nothing, and on the filing image `kuna strings --json`
reported `xrefs_count: 0` and no owning function for a string
`__libc_start_main` plainly prints. **Literal-pool following**
(`decompiler/crates/kuna-analysis/src/listing/kuna_poolref.rs`) closes that with
exactly one dereference, of content that cannot change: a `Read` of a
pointer-sized, pointer-aligned location in an **allocated, non-writable** section
with file content, whose word passes the same `checkOperands` value filter the
constant scan uses and lands in a mapped section, files a second edge to that
word's value. The edge is filed from the **instruction**, not from the pool word,
which is the whole point — a pool word is data and belongs to no function, so
attributing the reference to it would answer the question with another address
instead of a name.

Each clause is a refusal that would otherwise be a fabricated reference. The read
must be pointer-*sized*, and the width has to come from the access rather than
from the address varnode, because a `LOAD`'s address is pointer-sized whatever
the access is — without that, `ldrh r0,[pool]`, which is reading a number out of
a pool, reads as a pointer dereference. The section must be non-writable: a GOT
entry or a `.data` pointer holds whatever the loader or the program last wrote
there, and the image's copy of it is not evidence. And the value must clear the
address floor, so a read-only word holding 42 stays a number. The kind filed is
`Data`, the address-taken case, because that is what the load did. Measured over
a 15-image sweep: zero edges added on every x86-64 ELF and PE in it (a RIP-relative
load already encodes the address it forms), zero attributions lost anywhere, and
on the ARM images 2,239 new string-to-function attributions on u-boot and 763 on
the filing crackme — of which an independent capstone-plus-symtab oracle
corroborates 2,234 and 761 as real PC-relative pool loads, with every one of the
remainder confirmed by hand as a load the oracle's own sweep missed.

(kuna) Literal-pool following assumes the pool holds a *pointer*, and in a
position-independent ARM image it holds no pointer at all. There the pool word is
the signed distance from the instruction that consumes it to the datum, and the
address exists only once the two are put together: `ldr r0,[0x6a0]` at 0x660 and
`add r0,pc,r0` at 0x664 form 0x66c + (-0x1c1) = 0x4ab, the success string of the
filing crackme. The word is not an address and lands in no section, so following
it as a pointer correctly declines, and every string reference in the function is
lost — the reported `xrefs_count: 0` and empty owner list were not one site but
all four the function makes. **PIC pool composition**
(`decompiler/crates/kuna-analysis/src/listing/kuna_picpool.rs`) closes that by
composing the two decode-time constants the pair already carries. It is PIC base
folding with a per-site base rather than a module-wide one: there the base is a
register a prologue establishes once and the whole function inherits, so there is
something to detect and to scope; here each reference carries its own base — the
PC of its own `add` — so there is nothing to detect once, and what the walk
carries instead is the pool word itself, from the load to whatever composes it.

A pool word is admitted as a *displacement* only where it comes out of the same
read-only, pointer-sized, pointer-aligned slot literal-pool following already
vouches for, whatever the word itself looks like: in an ARM executable linked at
a fixed low address (0x10000) a displacement often lands in a mapped section by
chance, and only the PC fold below decides that it is one. A32 reads the slot
with a `LOAD` from a constant address; Thumb's literal loads, the 16-bit `ldr`
and `ldr.w`, export the slot itself with the word-aligned PC already folded in,
so they lift as a `COPY` out of the image, and both forms are read. Both of
these, the mapped-looking word and the Thumb `COPY`, are admitted only in an
image that has a GOT (`.got` or `.got.plt`) or a `.dynamic` section, which is
what position-independent code links into; a static image with none of them,
which is what bare-metal firmware is, admits only an A32 `LOAD` of a word that
is not a mapped address. That keeps the walk on such firmware, whose Thumb code
is dense with literal loads of pointers, at the cost it had before Thumb was
read, and its output is unchanged: over the 98 decbench ARM firmware images, their
stripped copies, and firmware relinked at 0x0, the wider admission formed no
reference. It is then
carried forward along fall-through alone, for a bounded run of instructions, and
dropped at the first write of its register, at any branch or return, and at a
call unless its register is callee-saved (GCC schedules the load before a call
and its `add` after). A user-defined operation ends it too, except inside a
call, where it is the Thumb `bl`'s instruction-set switch and the call's own rule
decides — the walk is breadth-first, so the values are keyed by
the address they reach rather than held as "the previous instruction's state",
which is what makes the carry independent of the order the queue happens to visit
a function in. The composition itself is a one-instruction constant fold over
`COPY`/`INT_ADD`/`INT_SUB` and nothing else, and it reports a value only when
**both** a pool word and a constant the instruction materialised from its own
address contributed to it (`inst_start + 8` on A32, `+ 4` on Thumb). That second taint is the whole guard: `add r0,r0,#4`
on the same word can land on a real literal, and only the missing PC separates it
from a reference. A value that stays in a temporary is not reported, for the same
reason PIC base folding does not report one — the GOT idiom `ldr r1,[pool]; ldr
r1,[pc,r1]` composes its slot address into a temporary and dereferences it, and
the slot is not what the instruction formed.

The `checkOperands` address floor is deliberately not applied to the composed
value. That floor asks whether an *immediate* is an address or an integer; here
the PC has already settled the question, and the filing image is an Android PIE
whose whole layout lives under 0x2828 — applying the floor there would discard
every reference in the program. Landing in a mapped section is the whole test the
result has to pass. Measured over a 417-image sweep of the crackme corpus, the
vendored fixtures and a set of host binaries: no edge is added on any x86-64 or
PE image (a RIP-relative load already encodes the address it forms), no
attribution is lost anywhere, and the composed edges are all on ARM images.

When a pool word that is itself a mapped address is carried on, literal-pool
following's pointer edge for it is held until the function's walk ends and is
filed only if no PC fold consumed the word, so a displacement is never also
reported as an absolute pointer from its load.

ARM `-fPIC` code also reaches data and functions through the GOT. The function
makes the GOT address once with the same pair (`ldr r4,[pool]; add r4,pc,r4`) and
keeps it in a callee-saved register; each use loads a GOT offset from the pool
and reads the slot (`ldr r2,[r4,r2]`). A composed value that lands in `.got` is
therefore tracked as a **GOT base** along every edge of the function, branches
included, and across a call when its register is callee-saved, until the register
is written. A load whose address is a GOT base plus a carried pool word files a
read of the slot and, when the slot's file word is a mapped address, a data
reference to that word from the load. `.got` is writable, so literal-pool
following does not hold it; its file bytes are what the loader starts from, and
in a non-PIE executable the linker writes a local function's or object's address
there with no relocation (an import's slot holds 0 and names nothing). Only base
plus a pool word (the GOTOFF form) is an address: base plus an immediate is
arithmetic on the base and names nothing, and a plain copy of the base files
nothing but is itself a base, so `mov r5,r4; ldr r3,[r5,r3]` still finds the
slot. A switch's case bodies are the dispatcher's own code, so each case target
receives the bases the dispatch holds. On ARM a Thumb function's slot word, and a
Thumb function's PC-composed address, carry bit 0. Whether an odd address whose
even half lies in an executable section is such a pointer or a datum at an odd
address (a string in a `.rodata` linked into `.text`) is decided once the whole
walk is done: it names the function, bit 0 cleared, when the walk decoded an
instruction or knows a function at the even address, or when the nearest ARM
mapping symbol at or below it is `$t`; a `$d` or `$a` there leaves it at its own
address. An image with no mapping symbols says nothing either way, and the
Thumb pointer, by far the commoner of the two, is assumed.

Because the walk decodes each instruction once, breadth-first, it can decode a
join before it has seen every edge into it, so what it carries is only a
candidate. Each instruction that sees a tracked value is recorded with the
values it was handed, what it passes on and which addresses it forms, each
naming the incoming values it was computed from; every edge is recorded as it is
taken, switch cases included, whether or not the dispatch carried anything. When
the walk of the function ends, a value is kept at an instruction only if every
recorded predecessor passes on the same one, and everything computed from a
dropped value goes with it, repeated until nothing changes. Only addresses whose
inputs all survived are filed. The entry needs no rule of its own: the walk
decodes it first, so nothing is carried into it. This is stricter than Ghidra's
`SymbolicPropogator`, which follows each path with its own copy of the state and
keeps the union of what the paths find.

A predicated instruction lifts as a branch to the next instruction when its
condition fails, ahead of its body, so it reaches the next instruction along two
edges: the one where it ran and fell through, and the one where it did not run,
which carries what it was handed less what its condition wrote. A base meets
both, so a conditional write to the base ends it after the instruction, while a
predicated return such as `popeq {r4-r6,pc}` leaves the base to the path that
falls past it. Pool words follow the instruction when it falls through, because
a predicated pair (`ldrne; addne`) runs under one condition.

Nothing is recorded before a body's first pool load, since nothing can be in
flight; this keeps the walk's cost on bodies, and architectures, that never form
one of these pairs to one scan of each instruction's operations. Soundness does
not need the earlier edges: at the first load, everything the walk has queued and
not yet decoded was queued by an instruction that carried nothing, so nothing
holds there, which is exactly what the meet over every edge would answer. An
instruction that a recovered frame's walk refused to enter is treated the same
way, because the frame's edge into it is in no other body's record.

Six shapes are not covered, or not exactly. A GOT base inherited from a caller
(one the function never forms itself) is not tracked: on ARM the register that holds it is
only callee-saved, not reserved, so assuming it would need every caller to
agree. A pool word does not cross a branch, so a slot load reached by a branch, as when
GCC merges the tails of switch cases into one shared `ldr r3,[r6,r3]`, files
nothing, even when every path brings the same offset. Code that a function walked
later reaches by jumping into a body already walked is not part of that body's
meet. A pool word the PC meets only inside an address (`ldr r3,[pc,r3]`, the A32
read of a TLS initial-exec slot) composes nothing a register holds, so the slot is
not read, and a word that is itself a mapped address keeps its pointer edge from
the load. A position-independent static image with no GOT and no `.dynamic`
section (code that touches only its own strings and statics) is read as
firmware. And in an image stripped of its mapping symbols, a datum at an odd
address inside an executable section is filed one byte low.

(kuna) PIC base folding and PIC pool composition each recognise one idiom; the
general form of their defect is any ISA whose instructions cannot hold an address.
AArch64 builds one as a page (`adrp x0,0x100000000`) plus a twelve-bit offset
(`add x0,x0,#0x488`, or the offset of an `ldr`/`str`), RISC-V as `lui`'s or
`auipc`'s high twenty bits plus an `addi`/`lw`/`sw`/`ld` offset, MIPS as `lui` plus
`addiu`, PowerPC as `lis` plus `addi`; neither instruction names the datum, so the
constant scan reported a static string that a function returns, a global that it
reads and a function pointer that it loads as referenced by nothing, on arm64
Mach-O, AArch64 ELF and RV32/RV64 ELF alike. **Register pair carrying**
(`decompiler/crates/kuna-analysis/src/listing/kuna_regcarry.rs`) carries a
register's constant to the instructions that fall after it. A register an
instruction leaves holding a constant that passes the `checkOperands` floor is
handed to its fall-through, and each instruction that receives one evaluates its
own p-code with it seeded, over the same small integer fold PIC base folding uses.
The three shapes that machine reads are read here too, with one difference in
kind: the address a `LOAD` reads is a `Read`, the address a `STORE` writes a
`Write`, and an address an `INT_ADD`/`INT_SUB` composes into a whole register is
`Data` — forming an address is not reading it. Only a value a carried register
contributed to is reported (the instruction's own constants are the scan's), and a
value that stays in a temporary is not, for the indexed-access reason above.

A carried value lives for at most eight instructions, is dropped when its
register is written with anything the fold cannot follow, and survives a call only
in a register the default prototype leaves unaffected and the call instruction did
not itself write (ARM's cspec lists `lr` as unaffected, yet the `bl` writes it). An
instruction whose p-code branches inside itself — a predicated A32 instruction, an
x86 `rep` — passes on no register it writes, and nothing it computes past a
p-code-relative label is filed, because a value there may come from either side
of the label (`cinc x0,x0,eq` leaves `x0` or `x0 + 1`). Values travel only along
fall-through, and the walk is breadth-first, so each reference records the
instructions its value passed through; once the whole walk has drained, a
reference is filed only if none of them is a branch target, a switch case or a
function entry. A join is where another path may hand the register a different
value, and two `adrp`s meeting at one `add` therefore form nothing. This gives
up a value that every path agrees on, which the meet PIC pool composition runs
would keep; the carry is meant for the two halves of one pair, which a compiler
keeps in one straight run.

The `Data` shape is narrower than the other two because nothing dereferences the
value to vouch for it, and the same pair builds integers. A copy of a carried
value (`mv a1,a0`, which RISC-V spells `addi a1,a0,0`) is the reference its source
already was. Bitwise composition (`movk`, `ori`, `movt`) and an add narrower than
the register it lands in (RV64 `addiw`, which truncates through a `SUBPIECE`) are
how a program builds a number. A value formed only to form the next one — the
middle `add` of an A32 PLT entry, whose register the very next instruction uses as
a base and overwrites — is a step, not an address, and an access that writes its
own address back (`ldr pc,[ip,#0x2f0]!`, `lwzu`) is one reference, the access. And
in an ELF `ET_DYN` image, which is relocated as a whole, an absolute immediate is
a number, never an address (`lui s2,0x3; addi s2,s2,-5` in a RISC-V shared object is
12283, and a PJSIP library forms thousands of `70000`-range status codes that
way), so there a constant starts a carry only when it was computed from the
instruction's own address: `auipc`'s `imm + inst_start`, A32's `pc` read as
`inst_start + 8`. x86-64 and AArch64 are exempt, because SLEIGH folds their
PC-relative operands (`lea [rip+…]`, `adrp`) into a plain constant, so the PC is
not visible, and neither builds a number from an add of two immediates. RV32 is
where the two shapes coincide in an executable: `li a1,70000` assembles to
`lui a1,0x11; addi a1,a1,0x170`, exactly the `%hi`/`%lo` pair of an address, so in
an RV32 `ET_EXEC` a number that lands in a mapped section files a `Data` row — the
same floor the constant scan applies to a lone immediate. RV64 builds that number
with `addiw` and is not affected. The page or high half on its own is not a
carried reference.

A constant subtracted from a carried address biases that address rather than
naming another one. Swift builds a string literal's object as `adrp/add` of the
literal, `sub x8,x8,#0x20`, then `orr x1,x8,#0x8000000000000000`, and the literal,
not the 32 bytes before it, is what the code references: so the `sub` files no
`Data` row and does not make the literal's `add` a step (with the `add` folded
into `adr x8,lit; nop` by the linker, the `adr` is the row). Over the Mach-O sweep
above this drops 294 rows naming whatever lay 32 bytes before a literal and
restores 14 rows naming the literal. Only a subtraction is a bias: an add of a
negative constant is how RISC-V and MIPS complete a `%hi` whose `%lo` is negative.

An AArch64 `adrp` page that is a mapped address is also a `Data` row of the
constant scan's own, which names whatever datum the page starts with: `adrp
x8,_hook@PAGE` in a function that only goes on to `add x8,x8,#0x8` and read
`_pair` is no reference to `_hook`. So the carry tracks the page, and when an
instruction it holds across completes the page into a different address — the
`add`, the `ldr x1,[x1,#0x5a8]` of a selector reference, the `ldr x16,[x16,#0x18]`
of a stub — the page was a step to that address and the scan's row is withdrawn.
A page the run also uses at offset 0 is the datum itself and keeps its row,
whatever else completes it: an access at the page (`ldr x16,[x16]`, the first
register of `ldp x0,x1,[x8]`, a post-indexed `ldr x0,[x8],#8`), or the `add
x0,x0,#0` that is the `:lo12:` half of a page-aligned symbol. That `add` is the
only trace of a symbol at the page that is used by address: clang compiles
`s.d = 5; use(&s)` for a page-aligned `s` to `adrp x0,s; add x0,x0,#0; str
x8,[x0,#0x18]; b use`, and the `str` alone would withdraw the only row naming `s`.
A page nothing completes, or that is completed only past a join, keeps its row
too. What the carry cannot see is a use of the page itself on a path it does not
follow (the far side of a conditional branch, past a join) or the page stored,
compared or returned without that `add`; a page completed elsewhere on its run
then loses its row. Compilers do not emit that shape — every such use in the
sweep below is a register spill the function reloads as a base — and keeping each
page live across a conditional branch would restore 458 false rows there to
recover none. Only an `adrp` is a page, read off its encoding: an `adr` of a
page-aligned label lifts to the same `COPY` and is the label's address. Over the
Mach-O sweep above (each universal binary split into its slices) and 79 ELF and
PE controls on eight architectures, 11,924 page rows are withdrawn: 6,627 on
AArch64 ELF, among them every `.plt` entry's `adrp x16` of the `.got.plt` page,
and 5,297 on Mach-O, most from `__stubs` and `__objc_stubs`. Every one is an
`adrp` whose completing instruction names another address, and no other row
changes.

(kuna) **A call through a loaded slot** (GH #1376). x86's `call qword ptr
[slot]` takes its destination out of a fixed slot in one instruction, and the scan
files it as a `Call` to the slot, which is where an import's name lives. A
fixed-width ISA spells the same call in three: `adrp x16,_malloc@GOTPAGE; ldr
x16,[x16,…]; blr x16`, and x86-64 sometimes in two, `mov rax,[rip+slot]; call
rax` (MSVC's i386 `mov esi,[__imp_X]; call esi`, GCC's `if (hook) hook();`). The
carry already read the `ldr` as a `Read` of the slot; the register it fills now
holds *the word at that slot*, and a `CALLIND` whose destination is that register,
or a copy of it, is a `Call` to the slot, filed from the call instruction on the
same join rule as every carried reference. Only a pointer-width load leaves such a
word, and a direct pointer-width memory operand copied whole into a register
starts one (`mov rax,[rip+slot]`). The word itself is unknown, so it is inert: an
add, a mask or a partial read of it is no value, and a load through it is no
reference. The load stays the `Read` it was, so an agent sees both observations,
the read and the call through what was read. `call [slot]` in one instruction is
still the scan's row alone. Over the Mach-O sweep above plus 30 x86-64 ELF images,
4 i386 PE and 45 ELF images across eight architectures, the rule adds 981 `Call`
rows and removes none: GOT and IAT slots (`blr x1` in `ld-linux-aarch64.so.1`,
`call esi` after `mov esi,[GetProcessHeap]`), function-pointer globals (`tar`'s
`error_hook`) and Go closures (`mov rax,[fv]; lea rdx,[fv]; call rax`). The
decompile graph gains the edge to a slot the inventory names, an import; a global
the inventory does not name gains none. An indirect *branch* through such a register (an arm64
stub's `br x16`, a tail call) is not filed: the forwarding relation is
the veneer walk's
(`decompiler/crates/kuna-analysis/src/listing/xrefs.rs (veneer_at)`), which reads
the slot from the branch's own operand.

Most instructions never reach the evaluation. One is evaluated when a carry
reaches it, or when it could start one: it calls nothing, some modelled op yields
an address-like constant, some register is written by a modelled op from constants
and temporaries alone (the first register an evaluation can know is always written
that way), and in an `ET_DYN` image some modelled op reads a constant in the
instruction's PC window. An instruction failing any of these would leave nothing
to carry or keep, so the gate decides what is evaluated, never what is filed. A
register copied whole from a pointer-width direct memory operand also passes the
gate.

Measured over 86 images (AArch64 ELF and Mach-O, ARM, MIPS, PowerPC, RISC-V,
x86-64, i386 PE and the vendored fixtures): no row is lost, and of the 14,550 rows
added, 10,994 on RISC-V match GNU objdump's own `lui`/`auipc` pair annotation
exactly, 895 more trace back through a base objdump annotated, 2,237 on AArch64,
MIPS, PowerPC and x86-64 match an independent capstone def-chain resolver, the 344
ARM PLT slot reads match the entries' own `add`/`add`/`ldr` arithmetic, and the
other 80 (Thumb `adr` + `ldrd` pool reads, a MIPS delay-slot `addiu`, a RISC-V
`c.lui` store and an `amoswap` on a lock) were checked by hand. The walk
itself costs about 2% more on x86-64 and ARM, where little is carried, 2-3% more
on MIPS and PowerPC, and 4-7% more on AArch64 and RISC-V, where a high half
precedes nearly every global access. Roughly half of that is the evaluation; the
rest is the new rows themselves, rendering each one's instruction text (about
2 µs a row on AArch64) and filing it (the 9,331 rows of a RISC-V PJSIP library).
Emitted C is unchanged.

(kuna) **Addresses below the floor** (GH #1364). The `checkOperands` floor tells a
number from an address among *immediates*, and a zero-based image keeps real
addresses under it: an arm64 Mach-O dylib's `__TEXT` starts at 0, ld.lld puts an
ELF shared object's or PIE's `.rodata` in its first page, GNU ld an older x86-64
or AArch64 PIE's `.text`, and firmware is linked at 0. There the floor dropped
every address a program formed into that page — `adrp x0,0x0; add x0,x0,#0x378`
naming a dylib's first function, `_start`'s `lea rdi,[rip+0xe6]` passing `main`.
Lowering the floor is no answer: `mov w0,#0x378` and `add x1,x1,#0x378` carry the
same constant, and in such an image nearly every small immediate lands in a mapped
byte (with no floor at all, the sweep below gained some 13,000 rows, almost all
`mov`/`cmp`/displacement immediates landing in `.dynsym`, `.rela` and their
neighbours). What separates the two is the PC, so a value computed from the
instruction's own address is exempt from the floor and has only to land in a
mapped section — the rule PIC pool composition already applies. SLEIGH folds most
PC-relative operands at decode time and leaves a plain constant in the p-code, so
**PC-relative forms** (`decompiler/crates/kuna-analysis/src/listing/kuna_pcform.rs`)
recognises them from the instruction's encoding and recomputes their value from
its bytes: AArch64 `adr`/`adrp`; x86-64 RIP-relative `lea`, whose value is the
fall-through plus its last four bytes (an instruction that ends in an `imm32`
would need the value `next + imm32`, which it never carries); A32 and Thumb `adr`,
a four-byte ARM word being read both ways because the value must match. Only a
constant equal to the recomputed value is exempt, both in the one-instruction
scan and as a carried value. Register pair carrying also takes an instruction's
own address as SLEIGH spells the PC (`inst_start`, Thumb's `+ 4`, A32's `+ 8`) to
be PC-relative where an add or subtract reads it (RISC-V `auipc`), and keeps a
value PC-relative through an add or subtract of something that is not; the
difference of two (a switch's `sub eax,r13d` after two RIP-relative `lea`s) is a
distance, and a mask, a shift or a truncation below 32 bits of one (`movzx
ecx,al`, Thumb `uxtb`) is a number. PIC base folding exempts what it composes
through the proven base for the same reason (an ld.lld i386 PIE's `lea
eax,[ebx-0x3088]` into its first page). The recogniser is built only for an image
that maps something below the floor. Every PIE and shared object does (its
`.dynsym`, a PIE's `.interp`), so only a fixed-address executable's walk is
untouched. Nor does a folded `adr` change which constants may *start* a carry in
an `ET_DYN` image (only a visible PC does), which keeps the internal address
register of SLEIGH's `ldm` out of an ARM shared object's rows.

Measured over 375 images (the 127 above, 220 zero-based ELF images from the angr
test corpus and the vendored fixtures, 30 decbench x86-64 PIEs, and zlib linked
for seven targets by ld.lld and two by GNU ld): no row is lost, and 700 rows are
added in 67 images, each a PC-relative formation — 236 x86-64 `lea [rip]`, 179
A32 and Thumb `adr` and the 170 PLT slot reads they start, 39 AArch64 `adrp`
pairs and `adr`, and 76 RISC-V `auipc` pairs and the loads through them. 682
match an independent capstone evaluation of the instruction and its straight-line
predecessors; the other 18 match GNU objdump's `auipc` pair annotation or were
checked by hand. A PIE whose first page holds only metadata (every decbench x86-64
image) gains nothing. The walk costs no measurable time: an in-process interleaved
A/B over x86-64, AArch64, ARM and RISC-V C libraries and bash stays within ±1.5%,
the same spread an A/A run shows. Recomputing the forms costs 6 to 24 ns per
decoded instruction, 0.1–0.4% of the walk over the x86-64, AArch64 and ARM C
libraries and bash. Emitted C is unchanged.

(kuna) Every rule above widens what the walk reads out of an instruction it
reached; the complementary defect is the instructions it never reaches at all.
The descent's successors are `classify`'s static targets plus fall-through, and a
`BRANCHIND` has neither by construction — it is where the design defers to
jump-table recovery, which runs over a *decompiled* function and so is not
available to this tier. So the walk stops dead at every switch dispatch. On the
filing image, an MSVC i386 window procedure, `--from` its entry filed 61
references whose source addresses run up to the dispatch `JMP dword ptr [EAX*0x4
+ 0x4017c4]` and then resume in the epilogue: the whole 758-byte case-body region
between them was undecoded, and `kuna strings` reported the message the handler
plainly pushes with `xrefs_count: 0` and no owning function.

**Jump-table following**
(`decompiler/crates/kuna-analysis/src/listing/kuna_switchtable.rs`) closes that
with one table read, of content that cannot change, bounded by the image's own
partition. The table base is the address the dispatching instruction itself
materialises — the `Data` reference the constant scan already files for it, which
is what makes the rule format-independent rather than a pattern match on `JMP
dword ptr [reg*n + imm]`. A base in a *data-space varnode* is deliberately not a
candidate: `jmp qword ptr [__imp_X]` and an ELF PLT entry encode their slot that
way, the constant scan files it as a `Jump`, and a veneer must not be read as a
one-entry table of whatever its unrelocated slot happens to hold. From the base
the entries are read in order through the same read-only dereference literal-pool
following uses, and each one is admitted only while it is pointer-sized,
pointer-aligned, drawn from allocated non-writable memory with file content, and
an address inside the **same executable section** as the dispatch — a case body
is code, and it is the dispatcher's own code. The first word that is not all of
those ends the table, which is what stops the scan at the `int3` padding after
the last case on the filing image; a run shorter than two entries is not a table
at all, because one plausible word after a constant is a coincidence and a
compiler does not lower a one-case switch through a table.

What the accepted entries become is the other half of the rule. They are queued
as successors of the **dispatching function**, not as function entries of their
own, so the case bodies are walked under the name of the switch that reaches them
and every reference they form is attributed there. That is what the query was
asked for: an agent looking for the handler that prints a message wants the
handler, not `sub_<the case body's address>`. Measured over a 33-image crackme
sweep, two images changed and neither lost a reference: the filing image gained
10 string references and 7 owned strings, and a second gained 8 and 7 — on that
one the walk also *re-attributed* three strings out of `zlib`'s `inflate`, which
had been claimed by an address inside `inflate`'s own extent because the real
entry's descent could not get past the `state->mode` switch, onto the containing
function.

(kuna) That rule reads the one table shape whose base is an operand of the jump.
Neither of its two premises holds on an x86-64 image: the base is materialized by
an instruction of its own — `lea jt(%rip),%rdx` on gcc, `LEA RDX,[__ImageBase]` on
MSVC — so the dispatch files no data reference at all, and the entries are signed
32-bit **displacements** rather than pointers, measured from the table on the gcc
form and from the image base on the MSVC one. So the whole of a `switch`'s direct
callees was missing from `kuna decompile-graph`: on the filing PE the reporter's
function listed 9 callees where Ghidra listed 33, and the missing ones were exactly
the `CALL`s inside case bodies.

**Delta-table following** closes that by asking what the branch register holds
instead of searching for a constant that might be a table. From the dispatch the
walk takes a **backward slice** over instructions it has already decoded: an
instruction joins the slice only where it defines something the chain still wants,
and the walk stops the moment the chain wants nothing. That is what keeps the cost
where the value is — a computed jump is usually not a switch at all, and `jmp *%rdx`
fed by `mov 0x8(%rax),%rdx` is settled one instruction back, because a value that
reaches the branch through an operation the fold does not model (a multiply, a mask,
a call's return) is unknown and asks for nothing further. The slice is then folded
forward through four values: a constant, a constant plus an unknown index, a word
read out of the array at that address, and that word composed with a constant. A
table is read only where the `BRANCHIND`'s own input is the last of those, so a jump
through a plain pointer, a virtual dispatch and a returned function pointer all
decline before any memory is read. A branch on a *data-space* varnode declines
first of all, which is the forwarding veneer the shipped rule already refused.

How far the table runs is the other half, and it cannot come from the entries. Two
delta tables laid back to back — which is what `-O2` gnulib's
`quotearg_buffer_restyled` has, an eleven-case table immediately followed by a
127-case one — continue each other seamlessly: read past the end of the first and
the second one's entries are real code addresses in the right section, merely
measured from the wrong base, and the walk decodes the middle of unrelated
functions. The bound therefore comes from the switch's own range check, which a
compiler always emits ahead of a table dispatch: `cmp $0xa,%r11d; ja default` lifts
to `INT_LESS(sel, 0xa)` feeding a `CBRANCH`, and eleven is the case count. The
search for it stops one instruction past that branch, so an unrelated comparison
further up the block cannot widen the bound, and a dispatch with no readable range
check is declined outright rather than read unbounded. Measured over a 16-image
sweep of the fixture corpus: no call-graph edge lost anywhere, and gained where the
image has a delta switch — `mcount_x86_64` 495 to 508 functions reachable from the
entry, the gnulib image 89 to 100, the MSVC fixture 2 to 6. `kuna strings` over the
896 KB `mcount_x86_64`, which holds 470 computed jumps, 676 ms to 704 ms.

(kuna) gcc's own dispatches kept most of a switch's callees out of that read all
the same — 3,913 of the 186,139 direct call sites in 51 x86-64 decbench binaries,
2,609 of them at `-O0`, where every computed jump of a PIE fails. Five things
were in the way, and each is now read. **Switch reach** (`switchreach`,
default-on) gates how far the read follows a dispatch — the unscaled index, the
long slice across calls, the sixteen-instruction search for the range check,
the masked index and the re-read below; off, the slice and the search stop at
eight instructions and at the first call, as they did. How the range check is
read once it is found is *not* gated, so the option off is not the old walk:
ssh `-O2`'s dispatch at `0x42a26` in `main` reads 9 of its 13 cases on the old
walk, all 13 with the option on, and none with it off.

*The `-O0` chain.* gcc spends seven instructions between its `ja` and the jump:
`mov %eax,%eax; lea 0(,%rax,4),%rdx; lea jt(%rip),%rax; mov (%rdx,%rax,1),%eax;
cltq; lea jt(%rip),%rdx; add %rdx,%rax`. The table base sits in the *unscaled*
index slot, which x86 SLEIGH spells as a multiply by one, so the slice follows a
multiply by one as a copy (a multiply by anything else still prunes the
selector's chain). The 32-bit load writes `rax = zext(eax)`, which retires the
tracked `eax` before `cltq` reads it back, so a register with no value of its
own reads as the low part of the wider register holding one, in the processor's
byte order: a constant truncated, a table entry as it is. The range check is
then ten instructions up, and it has a window of its own (sixteen instructions)
rather than the slice's.

*The range check.* The guard is the nearest conditional branch above the
dispatch that leaves its own instruction — a `cmov` or a `rep` prefix branches
only to the end of the instruction it is in, and clang's Duff's device in bash's
`internal_malloc` has a `cmovae` between its mask and its jump — and the bound
is a comparison that feeds that branch's condition —
in the branch itself, or in the nearest instruction above it that writes what
the condition reads. Instructions that leave the condition alone may sit in
between (gcc `-O2` puts a `movb $0x3f,0x34(%rsp)` between `cmpb $0x56,0x9c(%rbx)`
and its `ja`); a comparison anywhere else is not a bound, which drops the carry
a `sub $0x18,%rsp` in the dispatch chain used to contribute and the carry of a
`cmp` ahead of a `je`. Which side of the comparison the dispatch is on comes
from evaluating the condition twice, with the comparison as it comes out for a
selector above the constant `c` and for one below it and every other flag the
comparison sets clear. A branch taken for the large selector leaves the
dispatch `c + 1` cases. A branch taken for the small one leaves it the selectors
from `c` up, which bounds an unsigned `w`-byte selector at `2^(8w) - c` when that
is within `jumptablemax` and is no bound otherwise: bash's `cmp
$0xfffffffb,%r12d; jb default` guards a five-case table indexed by `sel + 5`, and
reading it as `0xfffffffb + 1` cases ran on into the table after it. The
comparison may have its constant on either side and in a temporary of the same
instruction, which is how AArch64 SLEIGH spells `cmp x8, #6` (`tmp = 6; tmpCY =
tmp <= x8`). Nothing checks that the comparison is on the selector: the nearest
one may test another value entirely. An index masked by `and $m`, followed back
over the code that falls into the dispatch through scaling, copies and zero
extensions, states at most `m + 1` cases whatever the range check says — clang
guards `switch (x & 3)` under `if (y <= 200) *p = y;` with the `cmp $0xc8`, which
read as 201 cases ran twenty entries into the next functions' tables, and the
Duff's device checks the byte count against 32 above its `and $0x7` — and where
no range check bounds the selector the mask is read only when all `m + 1`
entries are cases.

*A base far above the jump.* gcc `-O2` hoists the base out of a loop into a
callee-saved register, as far as the prologue: diff's `main` loads its option
table with `lea jt(%rip),%r15` right after the pushes and dispatches some sixty
instructions and nine calls later. The slice reaches 96 instructions back; a
call no longer ends it when everything it still wants is a register the default
prototype model lists as unaffected, and the fold keeps only those values
across the call. Stepping back over an instruction that does not fall through
(a `jmp`, a `ret`) leaves the block, so the slice stops there.

*Order.* The walk is breadth-first, and a `.cold` fragment that sorts ahead of
its parent jumps back into the parent's loop, so a dispatch can be decoded
before the code that falls into it. A read that stopped because no decoded
instruction ends where the slice needed one records that address. When any body
later decodes an instruction that falls through to it, that body reads the
table again once its own queue drains and walks the cases as its own: it reaches
the dispatch by falling into it, and it is the function the cold fragment
belongs to.

With all five, the 51 binaries miss 156 direct call sites instead of 3,913 —
none at `-O0` outside tar and e2fsck — and the call graph gains 1,868 edges and
loses three, two of which were jumps from a table read past its end. What is
left is a selector the code never range-checks because its type cannot exceed
the table (tar's `parse_expression` switches on a token type held in a byte,
whose table is followed directly by another one, so there is no safe place to
stop), and AArch64's byte and halfword tables scaled by four (`ldrb w11,
[x9,x8]; add x10,x10,x11,lsl #2; br x10`), whose entries the fold does not
compose, and a range check on another value than the selector with no mask to
overrule it.

A complete call graph is not a better one for every consumer. Case bodies are
where an interpreter recurses, so the new edges merge recursive functions into
larger strongly connected components of `decompile-all`'s callee-first plan, and
`protoorder` (`cycles`) gives no member of a cycle the prototypes of its callees:
bash `-O0`'s `execute_*` recursion grows from 206 to 367 functions and 33 of its
signatures change, mostly to plainer integer types (`extract_arithmetic_subst`
from `char *(char *,int *)` to `unsigned long(unsigned long,unsigned long)`,
`execute_command`'s `struct_69 *` to `unsigned long`), as do dash's
`subevalvar` and `evaltreenr` and coreutils `numfmt`'s `main`. With `protoorder
off` those functions come out the same with the option on and off.

(kuna) Both reads stop at the engine's own jump-table ceiling,
`Architecture::max_jumptable_size` — 1024 unless `option jumptablemax <n>` raises
it — so one value decides how far a switch is followed in both tiers. A range
check that states more cases than the ceiling is not a reason to decline: the
first `jumptablemax` entries are still read and walked, and the walk records the
switch as **truncated** (`SwitchTable`, with the case count the range check
states and the number read, which is zero when the ceiling is below the two
entries a table needs). A table with no range check that reads up to the
ceiling is recorded the same way, with no stated count.

(kuna, GH-299) Neither read covers the dispatch Cortex-M firmware uses for
almost every switch, and the function-discovery walk (`walk.rs`) had no table
read at all: a computed jump there has no successor, so the case region behind
every `tbb`/`tbh` stayed undecoded, and the AIF gap walk planted entries in it —
a case body that opens with a common prologue and ends in its own return is a
valid subroutine with a known fingerprint. **Thumb offset tables** (`thumbswitch`,
default-on; `decompiler/crates/kuna-analysis/src/listing/kuna_thumbswitch.rs`)
read them in both walks. `tbb [pc,rN]` and `tbh [pc,rN,lsl #1]` jump to
`inst_next + 2 * table[rN]`, where the byte or halfword table starts at
`inst_next`; the dispatch's own p-code is folded through the same lattice as the
delta-table read, extended with a narrow table word and its doubling, and only
this PC-relative form — table and base both the instruction's own `inst_next` —
is an answer. The table states no length either, so the count again comes from
the range check: the `cmp rN,#n` the dispatch sits behind lifts to
`INT_LESSEQUAL(n, rN)`, and when a conditional branch follows it within three
instructions with nothing in between writing `rN` or overwriting the comparison
flags, the table has `n + 1` entries if `bhi` sends indices above `n` away from
the dispatch, and `n` if `bcs` sends indices at or above `n` away. The condition's
p-code must establish that upper bound; reading the same flags with the opposite
polarity (`bls` or `bcc`) is insufficient. A branch to the dispatch itself,
intervening control flow, or a signed condition establishes no such bound, so
neither it nor a dispatch with no check is read. Over the jump-table ceiling the first `jumptablemax` entries are
read, and the xrefs walk records the switch as truncated like any other table. Because the offsets are
unsigned and the cases are laid out after the table, an entry that lands inside
the table, or outside the dispatcher's executable section, refuses the whole
read rather than truncating it. The cases become same-function successors of the
dispatch, as a branch target is, plus a code reference from it. Scored against
the symbol tables of the 93 non-u-boot 32-bit ARM ELFs in the decbench corpus,
default mode: mid-body entries 6,946 to 4,375 net (2,606 gone; 35 new, all
gap-walk entries in other holes of the functions whose cases are now decoded)
and true function starts 41,822 to 42,180 (the functions only a case
body calls), with none lost; on the Keil-built `CMSIS_DAP.axf`, whose tables
sit behind `bcs`, 18 to 16 and 300 to 301; the A32 u-boot images and the i386
PE corpus are unchanged. A function a case body calls is now walked too, and
its own tail `b` takes the target in as any branch the walk follows does: on an
armhf `libc.so.6` a case body calls `0x73248`, whose tail `b` pulls in
`0x73078`, a true start nothing else reaches, so it is no longer listed;
`tailcallentry` (on in `--mode aggressive`) recovers it. The walk decodes the
case bodies, and what they call, on every Listing build, so discovery alone
takes longer where tables are read (`kuna functions` about 8% on betaflight and
that libc), while a whole-binary run gets faster because no case body is
decompiled as a function of its own. It is ARM-only and needs a walk, so it is inert without `--option listing on`.

**A32 tables in the reference walk.** The two A32 forms the Listing walk follows
under `armframes` (above, `kuna_a32switch.rs`) are read by the xrefs walk too,
with the same reader and the same option. A guarded `addls pc,pc,rN,lsl #2`
walks each `b caseN` after `b default`; a guarded `ldrls pc,[pc,rN,lsl #2]`
walks each word after it. The A32 read comes before the table-base read: the
dispatch's PC-relative operand names the dispatch itself, which is not a table.
The cases are the dispatcher's own code, walked as its successors with the state
the dispatch holds, so a GOT base made before the dispatch reaches every case
(the `picpool` rule above). The dispatch files one `Jump` to each case, as
Ghidra's `ArmAnalyzer` adds a computed-jump reference per case. The words of an
`ldr` table are data the dispatch reads: they are not decoded and file no
pointer row, which matches Ghidra, whose ARM switch recovery labels and
disassembles the targets but adds no reference from the words. A predicated
dispatch lifts as a skip to `b default` ahead of its jump. `classify` keeps that
skip as one of the jump's flows with no fall-through, on every architecture and
under every option, so PIC pool composition, no-return propagation and every
other consumer of the instruction see one shape: a pool word loaded before
`bxne r3` still reaches the `add rN,pc,rM` after it along the skip, and a
function that leaves through `bxne r0` or `bl abort` is proved no-return
exactly as before. Where A32 tables are read, both walks only recognise the
skip (`Classified::predicated_skip` in
`decompiler/crates/kuna-analysis/src/listing/classify.rs`): a computed jump
whose only flow is its skip is read as a table, and the reference walk files
no `Jump` row for the skip. Under `armframes off`, and on every other
architecture, the skip keeps its row and no A32 table is read. The switch record states the guard's case count, so a table longer than
`jumptablemax` is marked truncated. A dispatch whose table gives no case (a run
shorter than two entries, or `b caseN` slots past the section end) states no
count, and the other table readers run on it only when it is unpredicated: a predicated computed jump
that is no A32 table gets no table at all. A literal-pool word after a call that the walk falls into is one
such jump, since a GOT offset like `0x000ff4a8` decodes as `andeq pc,pc,...`, and the pool words after it
must not become its cases. The reader takes a dispatch only when its index is scaled by four (`lsl #2`),
so 8-byte slots and an unscaled `add pc,pc,rN` are not read as tables, and an `ldr` table ends before its
first word with bit 0 set, an interworking target rather than an A32 case. A dispatch the walk reaches before the
guard that falls into it (a branch into the dispatch, or breadth-first order)
waits at the address the guard read stopped at and is read again, A32 reader
first, once that code is decoded.
Without this, the walk stopped at the dispatch and followed only `b default`.
GCC 14 no longer emits either form from C in ARM state (it compresses the table
to bytes, `ldrb rN,[rT,rN]; add pc,pc,rN,lsl #2`); that form is not read. Thumb
`ldr pc` tables are not read either: their PC is 4 bytes ahead, not 8.

(kuna, GH-299) **Bounded i386 switch coverage** (`x86listingswitch`, default-off;
`decompiler/crates/kuna-analysis/src/listing/kuna_x86listingswitch.rs`) extends
the discovery Listing for linked little-endian i386 ELF and PE images. It
recognizes a computed jump whose own p-code loads a four-byte destination from
`table + index * 4`. An unsigned guard on that exact whole 32-bit index must
constrain the dispatch along one local predecessor chain, with at most sixteen
instructions and 256 p-code operations. The proof tracks machine-width values,
flag arithmetic, and supported normalization; it refuses unrelated comparisons,
signed bounds, unknown upper bits, partial-register clobbers, unproved address
wrap, calls, and alternate incoming edges that bypass the guard. Incoming edges
come from decoded instruction flow and previously admitted table edges, so
dropping captured references in a partition-only Listing does not weaken the
proof. The nearest preceding function entry supplies no ownership evidence.

The reader takes exactly the proved number of aligned words, capped by the
live `jumptablemax`; fewer than two entries is not a switch. Every byte read
must belong to allocated, read-only, file-backed data, and every destination
must be in the dispatch's executable section. No destination may lie inside
an instruction that starts in the fifteen bytes below it, even where another
instruction also starts at it: two words of one table a byte apart decode
both, and the overlapping decode can reach code nothing else does, so the
re-check against the completed candidate refuses it. An invalid in-bound word refuses
the whole table. No missing proof falls back to an unbounded pointer scan. A
callback word immediately after a four-case table therefore stays outside its
successors. `PoolImage::contains_bytes` enforces the complete read contract;
the existing object loader already clips PE data to its virtual/raw section
bounds. This does not change the separate xrefs walk's pointer-scan policy.

After the ordinary serial or parallel walk finishes, shared reconciliation
keeps that ordinary model as the fallback and builds an isolated candidate.
Proved targets are instruction roots, not function entries; ordinary calls from
newly reached code retain the existing function-claim rules. Reconciliation
collects dispatches in address order, extends their decoded successors, and
repeats for at most sixteen rounds. Before publication it proves every admitted
dispatch again against the completed candidate, including newly exposed direct
and computed incoming edges and new function claims. An invalidated proof, a
newly conflicting entry, a required seventeenth round, or exhausted memory
budget discards the whole candidate, including earlier independent expansions.
No provisional instructions, references, or callees escape into the fallback.
Resume rebuilds ordinary coverage before applying this feature, including when
the option is disabled after an earlier expansion, so extended coverage cannot
be mistaken for ordinary fallback provenance.

The budget is at most 1 GiB and one quarter of available host memory, or
128 MiB when availability is unknown. It accounts for the ordinary model,
added instructions, pending targets/references, and retained dispatch edges;
incoming-edge collection and table rows also consume a checked aggregate
record allowance before allocation. Resident growth is checked when available,
but its absence does not remove the record allowance. Refusal preserves the
ordinary model rather than retaining an incomplete expansion.

Coverage records exact decoded instruction members. Cases may surround an
independent function and an undefined gap: neither the intervening bytes nor
an entry inside the first/last case span becomes owned by the dispatcher.
Existing seeds and direct-call claims remain authoritative; an established
case-entry conflict refuses the proof. Separate entry heuristics, including
`fast_funcdisc` and tail-call entry recovery, retain their own policies. The
feature remains opt-in because additional ordinary successor coverage can
change which otherwise unreferenced functions the gap walk discovers. The
measured corpus loses seven real tail-callee entries. Newly discovered entries
can also make existing `funcboundflow` truncate emitted branches: crypt32's
`0x6e8ee740` loses `memcpy` paths when `0x6e8eea21` becomes an entry, and
`0x6e904a20` loses part of case five. Local table admission is not proof of
improved whole-function C. Kernelbase's `GetComputerNameExW` also changes a
520-byte array into a scalar used as a large output buffer. The preserved
`abace009d9` audit reviewed 726 changed comparisons and 1,482 code or
semantic-metadata hunks. A fresh `e265bf23` capture strictly verifies
726 comparisons and 1,480 hunks, preserving every semantic API field,
399 removed addresses and all seven true-start losses. Exact prior content
permits annotation reuse; eighteen changed contexts and their 27 hunks were
manually read again. The same seventeen addresses still fail in both arms,
with no success-to-error transition or error repair. Fresh raw results
retain eleven `new-error` labels from changed stopping diagnostics and six
identical errors; natural queries omit
the budget flag and all actual failures report 120 seconds, while forced
supplements set it explicitly. Forced interior requests are not newly valid
entries. Completed review is not a claim of correct whole-image C.

On latest tested base `dd4f9fde`, all 141 entry inventories and 744 arm models
remain exact, as do complete-record panels on 20 controls and 13 known unsafe
anchors. Native serial/parallel/stream fixture exports pass. The full 21-image
C capture remains explicitly labeled with its `e265bf23` predecessor; these
bounded current-base checks do not imply a new full-corpus C capture.
Contention-logged current-base timing records enabled Wine discovery at
+7.17% wall and +7.17% child CPU. All samples/ranges are retained;
`quiet=false` does not certify a tight global overhead bound. The feature stays
off in every mode and adds no new function-boundary or tail-call policy. It is a
partial improvement for GH-299; its original private PE and crackme
acceptance cannot be established without those artifacts.

(kuna) The walk's decode set is global, so it cannot say how long one function
is: code two entries share is decoded under whichever entry reached it first. A
gcc `.cold` fragment sits below its parent and jumps back into the parent's body,
so the fragment's walk claims the parent's tail and the parent's own walk stops
where that tail begins (on python3.10, `PyType_Ready`'s 12 KB body claimed 200
instructions and its 1.9 KB fragment 2,782). `build_measured` therefore keeps the
successor graph the walk decoded, one `(vma, len, falls through)` row per
instruction plus one row per branch or switch-case edge, and
`function_instruction_counts` re-runs each requested entry's own descent over it,
stopping at every other seeded entry and at a caller-given cap. Shared code then
counts for every entry that reaches it, whatever order the walk claimed it in.
The plain `build` keeps no graph, so `kuna xrefs`, `strings`, `crypto` and the
plain `kuna functions --json` listing pay nothing for it. `kuna functions
--summary` (and `--reachable-from`, which already walk the image) count up to
`maxinstruction + 1` to flag, before any decompile, the functions whose body
exceeds `maxinstruction`, and list each truncated switch under the function whose
extent contains its dispatch. On the MSVC state machine that motivated it (a
16.6 MB function dispatching through a 90,781-entry image-base-relative table),
the default walk reads 1024 entries and reports the switch; with `jumptablemax
100000` it reads the whole table, and the body the cases reach is over the
100000-instruction budget.


(kuna) The same pool word is a second defect one surface over, in the **listing**
rather than the reference walk. A function's extent contains its pool, so a
straight-line disassembly of `main` walks off the end of the code and decodes the
constant: `1337ARM`'s `main` ended `ldmia sp,{r4,r11,sp,pc}` and then
`0x8458 39050000 andeq r0,r0,r9, lsr r5` — four bytes nothing executes, listed as
an instruction, in place of the success constant `0x539` the program is about.
**Pool-word folding** (`decompiler/crates/kuna-console/src/litpool.rs`, fed by
`ConsoleProgram::add_fixed_refs_at`) lists such a word as the constant it holds
(`.word 0x00000539`) instead. The evidence is the listing's own and nothing
wider: as each row is decoded, the fixed addresses it names are harvested from
its p-code — the constant locations it READS, in the two shapes SLEIGH spells one
in (a `LOAD` off a constant address, and a direct memory varnode), and the
constant addresses its flow ops name. A word read by some instruction in the
range, and branched to by none of them, is data.

That the evidence has to be *in the range* is what makes the rule predictable and
steerable rather than a global guess: listing the pool word on its own contains
no such load, so it decodes exactly as before, and that is the escape hatch. Four
further refusals bound it — a writable section (a GOT slot is read by address
too, and a writable `.text` is a packer), an address a function symbol sits on
(code by declaration), an unaligned or non-scalar width, and a width that does
not tile a whole number of decoded rows. As in the reference walk, the width has
to come from the ACCESS rather than from the address varnode, which a `LOAD`
makes pointer-sized whatever it reads; and an instruction's own fall-through is
not counted as a branch target, because every predicated ARM instruction lowers
to a `CBRANCH` over its body and a literal pool is a run of words that decode as
predicated instructions — counting it would veto every pool word but the first. The last one is what keeps the listing
stable: a fold only ever merges whole rows over the same bytes, so no address
after it can shift and a wrong fold costs one mis-rendered row rather than a
re-aligned listing. The residual false positive is a literal that lands on real
code — `cortexm_poolentry_le32` carries one deliberately, where a pool reference
resolves onto an undiscovered function's first word — and it costs exactly that
one row, with the bytes beside it and the raw decode one command away.

(kuna) The tiling refusal has a prerequisite the walk itself has to supply: a
pool word is only foldable if it **starts a decoded row**, so anything that puts
the listing off the instruction grid vetoes every word after it. A byte the
translator refuses is listed as a `.byte` row rather than ending the listing, and
where the walk resumes from one is architecture-dependent
(`decompiler/crates/kuna-console/src/disasm.rs (resume_grid, recovery_span)`).
Advancing one byte is right where any address can start an instruction and wrong
where they must be aligned: on ARM a refused pool word cost one byte, and the
four rows after it started at `main+0xd5`, `+0xd9`, `+0xdd` and `+0xe1` —
addresses no ARM instruction can begin at, so the four remaining pool words the
function's own `ldr`s named were not row starts and none of them folded. One
refused byte therefore took the whole pool with it. The recovery row instead runs
**to the next grid boundary**, in one row rather than a run of one-byte rows,
which is what puts the following row back on the grid. The grid is the alignment
every row decoded so far shares — the OR of their addresses and sizes — so an ARM
listing of 4-byte rows resumes on 4 and a Thumb listing that has decoded a 2-byte
row resumes on 2; an architecture that declares no instruction alignment
(SLEIGH `define alignment=1`), or a listing with nothing decoded yet to infer a
grid from, keeps the byte-at-a-time recovery unchanged.

(kuna) The walk also has to carry its own **end of mapped memory**, because the
load image will not stop it. `LoadImage::load_fill` answers a read that STARTS on
a mapped address for its whole length, zero-filling every byte past the last
segment it crosses — the upstream BFD contract
(`decompiler/crates/kuna-analysis/src/loadimage_object.rs`), and what makes a
`.bss` tail read back as zeroes rather than as a hole. Only the start address is
therefore ever checked, and a windowed listing that runs off the end of the code
decodes the fill: on a crackme whose executable `PT_LOAD` stops at `0x080d1904`
with the next segment a page and a half above it, `kuna disassemble 0x80d18b0
--count 30` walked to `0x80d191b` and reported eight `ADD byte ptr [EAX],AL` rows
out of bytes that are not in the file — while `kuna disassemble 0x80d190b`, an
address inside the same hole, correctly refused. The listing clips its own length
to the **contiguous mapped run** holding the start
(`decompiler/crates/kuna-console/src/disasm.rs (mapped_run)`, over
`LoadImage::get_segments`): adjacent and overlapping segments are one run, since
a listing crossing from one `PT_LOAD` into the next at the byte the first ends
has crossed no hole, and a loader that publishes no segments at all (the XML
`<binaryimage>` corpus, a relocatable object) is silence rather than a bound. A
decode that would STRADDLE the bound is refused the same way the translator's own
refusal is, so the mapped bytes under it list as `.byte` rather than as an
instruction the file only half contains; and the stop is stated in the listing's
`notes`, with the next mapped address, because a short answer is otherwise
indistinguishable from one the caller's own `--count` ended.

## 1.7 The no-return family

Whether a call falls through decides the CFG of every caller, so no-return facts
are program-prep facts, computed before any function is decompiled. Five analyzers
cooperate, each subsuming the last's blind spot; all of them emit the same
`NoReturnFact` through the same commit arm (address-resolved
`set_function_no_return`, §1.1), and the flow consequence — an artificial halt at
the call site, dead fall-through never decoded — is inherited from the engine's
flow layer (`decompiler/crates/kuna-decomp/src/p2_lift/flow.rs`), never
re-implemented per pass.

**Known names** (`noreturn_known`,
`decompiler/crates/kuna-analysis/src/loader/noreturn.rs (NoReturnKnownPass)`, the
`NoReturnFunctionAnalyzer` port) flags every function symbol whose name — leading
underscores stripped in a loop, so `__stack_chk_fail` matches `stack_chk_fail` —
appears on a shipped list, under upstream's namespace guard (global names and
exactly `std::`, never a class method like `Menu::_exit`). Which list applies is
format- and language-selected, the `noReturnFunctionConstraints.xml` model: the
vendored ELF list (`decompiler/crates/kuna-analysis/data/ElfFunctionsThatDoNotReturn`
— `exit`, `abort`, `__assert_fail`, `pthread_exit`, `__cxa_throw` and the C++
terminate family, and two kuna divergence blocks appended in place, each fenced by
its own `# (kuna divergence, DIV-nn)` comment: (DIV-21) the genuinely-unconditional
libc additions upstream omits — the BSD `err`/`errx`/`verr`/`verrx`/`errc`/`verrc`
family, `quick_exit`, `__assert_perror_fail`, `__chk_fail`, `__libc_fatal`;
`warn`/`warnx` return and stay out — and (DIV-78) the libstdc++ `std::__throw_*`
family, below — plus a GNU Fortran block: the four libgfortran fatal diagnostics
`_gfortran_runtime_error`, `_gfortran_runtime_error_at`, `_gfortran_os_error` and
`_gfortran_os_error_at`, which libgfortran declares no-return; the warning
`_gfortran_runtime_warning_at` and the recoverable I/O error
`_gfortran_generate_error` return and stay out, and the block lists exact names, not
a `_gfortran_` prefix), widened by a Rust wildcard list (`core::panicking::panic*`,
`handle_alloc_error`, `rust_begin_unwind`) or a Go exact list (`runtime.gopanic`,
`runtime.throw`, `runtime.goexit`, …) when source-language detection fires (§1.4),
or replaced by the PE/Mach-O list (`__fastfail`, `_invoke_watson`, the same GNU
Fortran block, plus the shared C names) off-ELF. The scan mirrors the exact symbol
streams the loader installs and emits the *install* address — for a UND import, the
PLT-stub address, since the `.dynsym` entry is address 0 and demangling means a
raw-name lookup would miss.
Name-based: free, exact, and useless on stripped custom wrappers.

**Pclntab names** (`gonoreturn`,
`decompiler/crates/kuna-analysis/src/analyzers/pclntab/kuna_gonoreturn.rs
(GoNoReturnPass)`, kuna, default-on, Go-detected binaries only): the known-names
pass above reads the object's symbol tables, and a production Go binary is
stripped — both tables gone, zero facts emitted, so the whole vendored Go list
(`runtime.gopanic`, `runtime.panicshift`, `runtime.panicunsafestringlen`, …)
went unused on exactly the binaries it was vendored for, and every
`runtime.panic*` call site kept a bogus fall-through edge (rendered as flow
into the INT3 padding after the function, and it breaks the `gomorestack`
fold's shape wherever the stack-growth arm follows such a call). The names
survive stripping in the pclntab, so this pass walks the same table the
`gopclntab` pass recovers names from — same `recover_go_table` parse, same
executable-range admission — and matches each recovered `(addr, name)` against
the same vendored list with the same reader (`name_matches`), emitting
ordinary address-keyed `NoReturnFact`s through the same commit arm. Pass order
installs the pclntab names before the no-return arm resolves addresses, so the
facts land whether or not a `.symtab` exists; unstripped, they are idempotent
duplicates of `noreturn_known`'s. Registered only for `Compiler::Go` (beside
`gopclntab`, preserving that pass's appended-last contract), so every non-Go
pass set is byte-identical; `option gonoreturn off` restores the fall-through
reading, and `option noreturn_known` keeps gating only the symbol-table pass.

**Discovered, ≥3 evidence** (`noreturn_disc`,
`decompiler/crates/kuna-analysis/src/analyzers/noreturn_disc/mod.rs`, the
`FindNoReturnFunctionsAnalyzer` evidence tally; Listing-gated, default-on per
DIV-22 as in Ghidra): a callee is concluded no-return when at least **3** of its
call sites (`EVIDENCE_THRESHOLD`) show no valid fall-through, plus a bounded
fixpoint promotion for a caller whose body contains a terminal call to an
already-concluded callee and no RETURN anywhere. The threshold buys robustness to
disassembly noise at the price of blindness to rarely-called functions; and the
predicate has a structural blind spot: a no-return call followed by alignment **NOP
padding** reads as a valid fall-through and contributes no evidence at all.

What counts as "no valid fall-through" is itself a decision, exposed as
`noreturn_discstrict` (default-ON, DIV-92;
`decompiler/crates/kuna-analysis/src/analyzers/noreturn_disc/kuna_discstrict.rs`).
A call with no fall-through address at all — a tail jump lowered to a call — is
evidence under either setting: that is a property of the call instruction. What
differs is how its *successor* is read. On the default only **positive** evidence
counts: the successor is data (outside every executable range, so the compiler
emitted nothing there to fall into), or the successor is another function's entry
(the compiler left the caller no tail at all). With the option off a third arm is
restored ahead of those two — the successor is not a decoded instruction start.

That third arm is a statement about kuna, not about the program. The Listing walk
(§1.7) pushes **every** call's fall-through onto its per-function instruction
worklist unconditionally, and that worklist drains before the function is left, so
a call's successor is always attempted; it fails to become an instruction start in
exactly three ways — `decode_one` returned an error, the decode was zero-length, or
the address is outside every executable range. The Listing records no decode
outcome (a failed decode and an unvisited byte are the same `Undefined` code unit),
so the arm is precisely a decode-failure detector: three bytes kuna cannot decode
are enough to conclude that a function whose body is `mov $7,%eax ; ret` never
returns, after which the flow layer deletes the live tail of every one of its
callers (GH-312). Dropping the arm is also what makes the data arm reachable for
the first time — `is_data` implies `!is_instruction_start`, so under the legacy
order the arm above consumed every site it would have caught. Measured over the 660
stripped x86-64 binaries and 110 stripped non-x86-64 binaries of the decbench
corpus on which the Listing is built, the two tallies conclude the *same* 581
callees no-return: the arm's entire marginal output there is decode-failure votes
that never reach the threshold on their own.

**Propagation fixpoint** (angr; `noreturn_propagate`,
`decompiler/crates/kuna-analysis/src/analyzers/noreturn_propagate/mod.rs
(propagate_noreturn)`, the CFGFast returning-analysis idea): seed the terminal set
from the Known-flagged functions, then sweep the call graph to a fixpoint with
**no evidence threshold**. The base rule is a strict tail-call rule
(`function_is_no_return`), conservative by construction: a function is concluded
no-return only when its last *real* instruction — trailing NOP padding skipped,
closing exactly the blind spot above — is a CALL or tail JMP to a terminal-set
member, AND no RETURN exists in the body, AND no computed jump exists, AND every
static branch target stays inside the reachable body or is itself terminal. Each
conclusion joins the terminal set and re-enqueues callers, so a wrapper-of-a-wrapper
converges (sweeps bounded by candidate count + 2). This catches the canonical miss:
a cold wrapper like coreutils' `xalloc_die` — single-digit call sites, under the ≥3
threshold; `call abort` followed by padding, invisible to the evidence predicate —
which unconditionally cannot return. Without it, every caller grows a spurious
fall-through edge into the cold path that structures into an invalid
`while(true)`+`goto`.

An import stub is never a candidate (`import_stubs`, read from the same
`resolve_imports` stream the Known pass and the `error` recognizer use, keeping
only `ImportSymKind::Import` entries). A stub's body is the dynamic linker's
trampoline, not the import, so whether it returns belongs to the import: the
Known pass decides that by name at the stub address, and propagation draws
nothing from the body. MIPS is where the body misleads. A `.MIPS.stubs` lazy
stub is `lw $t9,-0x7ff0($gp); move $t7,$ra; jalr $t9; li $t8,<dynsym index>`;
the resolver jumps to the import, which returns to the caller through `$t7`, so
control never reaches the word after the stub. The Listing still models the
`jalr` as a returning call whose fall-through is the next stub's entry, and the
reachability rule below therefore concluded every stub laid out in front of a
Known no-return stub (`exit`, `abort`, `__stack_chk_fail`) no-return, then the
stub in front of that one, and so on. Ordinary imports such as `memcpy`,
`fopen64` and `pthread_once` then truncated every caller at the call.

The deferred analysis commit also seeds the Listing from function symbols already
marked no-return, including `option noreturn <name>` applied before `read symbols`.
These explicit facts must reach propagation before caller flow is constructed;
they do not depend on the known-name analyzer being enabled. A wrapper that calls
a marked leaf and then has unreachable INT3 bytes is handled by the reachability
rule below. Marking the leaf does not conclude a wrapper with a reachable return,
an unresolved jump, or an unmodelled escaping path. Without a known or explicit
no-return fact, a call followed by INT3 alone does not establish that its callee
cannot return. The existing `listing`, `noreturn_propagate`, and `noreturn_reach`
gates still control this inference.

Two rules fold into the same fixpoint, both Ghidra-derived:

- **The `error(nonzero,…)` value rule** (`noreturn_error`, DIV-16): glibc `error()`
  and `error_at_line()` exit when `status != 0` but return for `status == 0`, so
  `error` can never be a Known name. The recognizer resolves the `error` entry
  addresses, then per call site backward-scans the straight-line predecessors for
  the defining write of the first integer-argument register (x86-64 SysV
  `EDI`/`RDI`): only a literal `MOV` of a nonzero constant accepts; `XOR EDI,EDI`,
  any non-constant definition, an intervening call or branch all reject — a false
  positive would delete live caller code. A qualifying *tail* call concludes the
  wrapper no-return (GNU `pfatal_with_name`), and independently *every* qualifying
  call site is emitted as a `no_fallthru_calls` fact that the drivers apply as a
  per-site CALL_RETURN flow override
  (`decompiler/crates/kuna-cli/src/decompile_all.rs`) — the fall-through prune that
  stops the flow-follower from absorbing the next function.

  These scans read through a borrowed view of the existing Listing, bounded to
  `[function entry, next function entry)`, instead of copying each function's
  instructions into temporary collections. The strict call-site scan keeps its
  address-order predecessor rule: a gap between decoded instructions does not by
  itself stop the scan, but instructions from the preceding function are out of
  bounds. The reachability scan keeps the stricter straight-line rule from its
  former predecessor window: every step must have an explicit fall-through to
  the next instruction, so a gap breaks the argument proof. Both reject an
  intervening call, branch, or terminal instruction before accepting a constant.
- **CFG reachability** (`noreturn_reach`, DIV-19; the
  `targetOnlyCallsNoReturn` rule of Ghidra's discovered analyzer,
  `function_reaches_only_noreturn`): the tail rule is a subset — it cannot conclude
  a wrapper whose no-return call is mid-body with a dead tail after it (openssh
  `sshpkt_fatal`), whose RETURN is present but unreachable, or that routes through
  a switch whose every arm is no-return (`sshpkt_vfatal`). The generalization walks
  the instruction-level reachable graph from entry, treating a transfer to a
  terminal callee as ending its path, and concludes no-return iff no RETURN is
  reachable and at least one path ends at such a transfer. Every uncertainty — a
  reachable RETURN, an unresolved indirect jump, an escape to a possibly-returning
  neighbour, a call with no modelled fall-through — answers "returns". (ida) The
  one recorded over-conclusion and its fix: a GCC `-O2` hot/cold-split check
  (`jcc <.cold>` where the cold fragment is `call abort`) was short-circuited like
  an unconditional transfer, skipping the returning fall-through arm and marking
  the whole `quotearg_*` family no-return; a conditional jump now walks both arms,
  the returning shape IDA Pro and Ghidra both produce.

Finally, (angr) **flow-time extern matching** closes the case no address-keyed fact
can reach: in an ET_REL `.o`, a libc no-return is a UND symbol with no address and
no PLT, so nothing above ever marks it, and flow runs off the function's end into
alignment padding decoded as garbage `add [rax],al` statements.
`noreturn_externmatch`
(`decompiler/crates/kuna-decomp/src/p2_lift/kuna_noreturn_externmatch.rs`) applies
the same vendored name list and namespace guard *at the flow query seam*
(`decompiler/crates/kuna-decomp/src/infra/decompile_drive.rs
(query_call_no_return)`); its sibling `noreturn_extern` applies an equivalent
name match in the same query, differing in gate flag, name-resolution path, and
name set — `noreturn_extern` carries a frozen hard-coded copy of upstream's 21
names rather than reading the shipped list, so neither kuna divergence block
reaches it; it is queried only after `noreturn_externmatch` (which does read the
list, and is default-on) has already declined. On a
normally-linked ELF the proto flag is already set, so both are no-ops there. These
two run inside the engine, not the analysis tier — chapter 02 owns the halt
mechanics they feed.

**The libstdc++ throw family (kuna, DIV-78).** Every `std::__throw_*` helper in
`<bits/functexcept.h>` (and `__throw_regex_error` in `<bits/regex_error.h>`) is
declared `__attribute__((__noreturn__))` and every body ends in
`_GLIBCXX_THROW_OR_ABORT` — a `throw`, or `abort()` when the library is built
`-fno-exceptions` — so none of them can return. Upstream Ghidra's list names
`__cxa_throw` and the terminate entry points but omits this whole family, and the
attribute is a compile-time fact that survives into no binary artifact: at the
decompiler's boundary `std::__throw_length_error` is an ordinary undefined
`.dynsym` import reached through a PLT stub. Nothing but the shipped list can prove
the call cannot return, so without the entries the fall-through is followed and the
code after every such call — most often clang's `call __stack_chk_fail`
unreachable-trap, or the next function's entry — is emitted as if it ran. The
family is on the list twice over, because the two matchers see two different
spellings of the same symbol: the analysis-tier scan matches the **mangled**
`.dynsym` name *before* demangling, written as a trailing-`*` wildcard over the
Itanium `ZSt<len>__throw_<name>` prefix so a signature change (`__throw_ios_failure`
gained a `const char*, int` overload in GCC 7) cannot age the entry out; the
flow-time matcher sees the **demangled** display name, which the `std`-only
namespace guard admits and the leading-underscore strip reduces to
`throw_length_error`. A same-named method on a user class stays out by the
namespace guard, and the mangled prefixes are exact ABI encodings of
`std::__throw_*`, so neither spelling can reach an unrelated symbol.

## 1.8 In-engine image binding

Inside the engine, P1 is the architecture/loader binding —
`decompiler/crates/kuna-decomp/src/p1_partition` — three front-ends over one base,
the C++ inheritance chain modeled by composition:

- `decompiler/crates/kuna-decomp/src/p1_partition/sleigh_arch.rs
  (SleighArchitecture)` is the base every path shares: resolve a language id
  against the `.ldefs` records scanned from the spec roots (the C++ file-level
  statics become an explicit `LanguageDatabase` value the bootstrap owns), find the
  `.pspec`/`.cspec`/`.sla` files, build the SLEIGH translator, and run the
  `Architecture::init` tail (type factory, prototype models, print language). The
  upstream translator-reuse cache is deliberately not ported — it affects build
  speed only — and is the recorded loss here.
- `decompiler/crates/kuna-decomp/src/p1_partition/xml_arch.rs (XmlArchitecture)`
  binds the decompiler's XML `<binaryimage>` container — the datatest corpus's
  entire load path, and the reason the analysis tier can be default-on without
  touching parity: this front-end never sees an `ObjectLoadImage`.
- `decompiler/crates/kuna-decomp/src/p1_partition/raw_arch.rs
  (RawBinaryArchitecture)` is the catch-all leaf for a raw byte image: its file
  match always succeeds (so capability sorting pushes it last), the language must
  be supplied by the target, and the loader is a plain offset-mapped
  `RawLoadImage`. The live CLI reaches it only through `--raw-image`, with an
  explicit target, base, and one or more numeric entry seeds. It resolves and
  initializes the language first, attaches the default code space, and only then
  applies the VMA. This order gives nonzero bases defined word-addressed behavior.
  Base and entry values arrive in code-space address units and are checked before
  conversion to internal byte offsets. The complete nonempty file is published as
  one `CODE` section, and only caller-supplied entries are installed. ARM32 also
  requires an explicit ARM/Thumb state, painted across that section and preserved
  through the deferred analysis commit. Function pointers consume the ARM state bit,
  while data and property addresses preserve it. Presentation converts an address with
  its own address space's word size; data-space `dat_<hex>` tokens retain the coordinate
  emitted in C rather than inheriting the code space's word size, and merge with a named
  data label only when both the address space and presentation coordinate match. An
  ordinary load accepts XML only after parsing a document containing `<binaryimage>`;
  parse failures retain the headerless-image command guidance even when the first byte
  is `<`.

The real-binary path of §1.2 is the fourth binding, console-side: `bootstrap_from_object`
plays the leaf role itself — it resolves the language from the object header
(with the compiler-model fallback retry), runs `build_engine_and_init`, attaches
the default code space to the loader (the `postSpecFile` contract), and hands the
loader to the engine as the byte source every subsequent instruction decode reads
through.

When the input explicitly selects an ARM ISA, frame recovery retains the
successfully decoded instruction spans from its final accepted walk as inventory
metadata. Inventory-seeded xref walks select those modes at matching seeds;
later direct-call evidence takes precedence. The hints survive recovery retries.
Ordinary decompilation context is not repainted by this metadata, and unrelated
roots retain the explicit input mode. Discarded rounds and unclaimed gaps publish
no hints. The behavior requires Listing, function-start patterns, and `armframes`.
Automatic ISA selection continues to use loader mode facts without extra hints.

Xref result formatting reuses the query's canonical inventory for names
and fallback ownership. ARM address normalization and discovered-entry naming
retain their existing precedence; formatting does not rebuild the inventory
for each endpoint of every result row.

### Stable Rust compiler-version evidence

The standalone loader also records an optional stable Rust compiler version from
ELF `.comment` in `Architecture::rustc_stable_version`. The record parser
in `decompiler/crates/kuna-analysis/src/analyzers/sourcelang/kuna_rustversion.rs`
requires three numeric components and rejects prerelease suffixes, malformed
Rust records and conflicting versions. Missing metadata remains unknown even
when `sourcelang` is forced. This image fact survives option resets and lets
versioned consumers such as P9 `rustfmtliteral` reject unsupported layouts.

For verified stable Rust 1.93.0/1.93.1 images, the standalone loader also retains
primitive integer Display callback types in `Architecture::rust_display_formatters`.
The reader in `decompiler/crates/kuna-analysis/src/analyzers/sourcelang/kuna_rustformatters.rs` accepts only linked 64-bit little-endian ELF images. It reads full demangled object-function symbols and their aliases before normal
symbol-name normalization removes trait qualifiers. Exact standard-library trait
identities qualify; conflicting aliases invalidate the address. The P9
`rustfmtargs` consumer independently checks language, layout and call shape.
This evidence does not rename symbols or infer a generic formatter's pointee type.

The same symbol walk records integer formatting traits in
`Architecture::rust_integer_formatters` for P9 `rustfmtflags`. Display, Debug,
LowerHex, UpperHex, Octal, Binary, LowerExp and UpperExp retain exact type and
trait identity; the Display-only map is derived from these facts without another
object parse. Unknown or conflicting aliases invalidate the shared address.
