package main
import("fmt";"os";"strconv")
// main.pair
func pair(a int64, b int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax | rcx
  
  v1.result0 = a + b
  v1.result1 = a - b
  return v1.result0,v1.result1
}
// main.apply
func apply(fn func(int64, int64) (int64, int64), r0 int64, r1 int64) (int64, int64) {
  return fn(r0,r1)
}
// main.indirectFirst
func indirectFirst(fn func(int64, int64) (int64, int64), r0 int64, r1 int64) int64 {
  var v1 int64 // rax
  
  v1 = func(r0 int64, r1 int64) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{r0, r1} }(fn(r0,r1)).result0
  return v1
}
// main.indirectSecond
func indirectSecond(fn func(int64, int64) (int64, int64), r0 int64, r1 int64) int64 {
  var v1 int64 // rbx
  
  v1 = func(r0 int64, r1 int64) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{r0, r1} }(fn(r0,r1)).result1
  return v1
}
// main.identityPair
func identityPair(a int64, b int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  v1.result1 = b
  v1.result0 = a
  return v1.result0,v1.result1
}
// main.signedUnsigned
func signedUnsigned(a int64, b int64) (int64, uint64) {
  var v1 struct { result0 int64; result1 uint64 } // rbx:rax | rcx
  
  v1.result0 = a + b
  v1.result1 = uint64(a - b)
  return v1.result0,v1.result1
}
// main.indirectNarrow
func indirectNarrow(fn func(int64, int64) (int64, int64), r0 int64, r1 int64) int32 {
  var v1 int32 // eax
  
  v1 = int32(func(r0 int64, r1 int64) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{r0, r1} }(fn(r0,r1)).result1)
  return v1
}
var calls int
func counted(a,b int64)(int64,int64){calls++;return pair(a,b)}
func main(){a,_:=strconv.ParseInt(os.Args[1],10,64);b,_:=strconv.ParseInt(os.Args[2],10,64);x,y:=pair(a,b);fmt.Println(x,y);calls=0;x,y=apply(counted,a,b);fmt.Println(x,y,calls);calls=0;x=indirectFirst(counted,a,b);fmt.Println(x,calls);calls=0;x=indirectSecond(counted,a,b);fmt.Println(x,calls);calls=0;n:=indirectNarrow(counted,a,b);fmt.Println(n,calls);x,y=identityPair(a,b);fmt.Println(x,y);x,u:=signedUnsigned(a,b);fmt.Println(x,u)}
