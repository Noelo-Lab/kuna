#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
typedef int64_t int8;typedef uint64_t uint8;typedef int32_t int4;
typedef struct { int8 result0,result1; } __kuna_go_pair_i64_i64;
typedef struct { int8 result0;uint8 result1; } __kuna_go_pair_i64_u64;
__kuna_go_pair_i64_i64 pair(int8 a,int8 b)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax | rcx
  
  v1.result0 = a + b;
  v1.result1 = a - b;
  return v1;
}
__kuna_go_pair_i64_i64 apply(__kuna_go_pair_i64_i64 (*fn)(int8,int8),int8 r0,int8 r1)
{
  return (*fn)(r0,r1);
}
int8 indirectFirst(__kuna_go_pair_i64_i64 (*fn)(int8,int8),int8 r0,int8 r1)
{
  int8 v1; // rax
  
  v1 = (*fn)(r0,r1).result0;
  return v1;
}
int8 indirectSecond(__kuna_go_pair_i64_i64 (*fn)(int8,int8),int8 r0,int8 r1)
{
  int8 v1; // rbx
  
  v1 = (*fn)(r0,r1).result1;
  return v1;
}
__kuna_go_pair_i64_i64 identityPair(int8 a,int8 b)
{
  __kuna_go_pair_i64_i64 v1; // rbx:rax
  
  v1.result1 = b;
  v1.result0 = a;
  return v1;
}
__kuna_go_pair_i64_u64 signedUnsigned(int8 a,int8 b)
{
  __kuna_go_pair_i64_u64 v1; // rbx:rax | rcx
  
  v1.result0 = a + b;
  v1.result1 = a - b;
  return v1;
}
int4 indirectNarrow(__kuna_go_pair_i64_i64 (*fn)(int8,int8),int8 r0,int8 r1)
{
  int4 v1; // eax
  
  v1 = (int4)(*fn)(r0,r1).result1;
  return v1;
}
static int calls;
static __kuna_go_pair_i64_i64 counted(int8 a,int8 b){calls++;return pair(a,b);}
int main(int argc,char**argv){(void)argc;int8 a=strtoll(argv[1],0,10),b=strtoll(argv[2],0,10);__kuna_go_pair_i64_i64 p=pair(a,b);printf("%ld %ld\n",p.result0,p.result1);calls=0;p=apply(counted,a,b);printf("%ld %ld %d\n",p.result0,p.result1,calls);calls=0;int8 x=indirectFirst(counted,a,b);printf("%ld %d\n",x,calls);calls=0;x=indirectSecond(counted,a,b);printf("%ld %d\n",x,calls);calls=0;int4 n=indirectNarrow(counted,a,b);printf("%d %d\n",n,calls);p=identityPair(a,b);printf("%ld %ld\n",p.result0,p.result1);__kuna_go_pair_i64_u64 m=signedUnsigned(a,b);printf("%ld %lu\n",m.result0,m.result1);}
