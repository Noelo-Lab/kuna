from pathlib import Path
import subprocess,os,json,hashlib
w=Path(__file__).parent;r=Path('/home/mahaloz/kwt/angr-go-pair-results');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
goharness='''package main
import("encoding/binary";"unsafe")
var calls int
func pair(a,b int64)(v [16]byte){calls++;binary.LittleEndian.PutUint64(v[:8],uint64(a+b));binary.LittleEndian.PutUint64(v[8:],uint64(a-b));return}
'''
gomain='''func main(){for _,a:=range []int64{-9223372036854775808,-4294967297,-1,0,1,4294967297,9223372036854775807}{for _,b:=range []int64{-9223372036854775808,-1,0,1,9223372036854775807}{calls=0;x,y:=forward(a,b);if x!=a+b||y!=a-b||calls!=1{panic("opaque carrier")}}}}
'''
cpre='''#include <stdint.h>
#include <assert.h>
typedef int64_t int8;
typedef struct{int8 result0,result1;}__kuna_go_pair_i64_i64;
static int calls;
static unsigned __int128 pair(int8 a,int8 b){calls++;return (unsigned __int128)(uint64_t)(a+b)|((unsigned __int128)(uint64_t)(a-b)<<64);}
'''
cmain='''int main(void){int8 as[]={INT64_MIN,-4294967297LL,-1,0,1,4294967297LL,INT64_MAX},bs[]={INT64_MIN,-1,0,1,INT64_MAX};for(int i=0;i<7;i++)for(int j=0;j<5;j++){int8 a=as[i],b=bs[j];calls=0;__kuna_go_pair_i64_i64 v=forward(a,b);assert(v.result0==a+b&&v.result1==a-b&&calls==1);}return 0;}
'''
for v in ['go1.22.5','go1.27.3']:
 for lang in ['c','go']:
  body=w/(v+'-'+lang+'.body');src=w/(v+'.'+lang);src.write_text((cpre if lang=='c' else goharness)+body.read_text()+'\n'+(cmain if lang=='c' else gomain))
  variants=['O0','O2']if lang=='c' else ['go1.22.5','go1.27.3']
  for variant in variants:
   exe=w/(v+'-'+lang+'-'+variant);compiler='cc'if lang=='c' else '/tmp/kuna-toolchains/'+variant+'/go/bin/go';cmd=[compiler,'-std=gnu11','-'+variant,'-fwrapv',str(src),'-o',str(exe)]if lang=='c' else [compiler,'build','-p','4','-trimpath','-o',str(exe),str(src)];p=subprocess.run(cmd,capture_output=True,text=True,env=os.environ|{'GOTOOLCHAIN':'local','CGO_ENABLED':'0','GOMAXPROCS':'4'});(w/(exe.name+'-build.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr;p=subprocess.run([str(exe)],capture_output=True,text=True);assert p.returncode==0,(p.stdout,p.stderr)
   records.append({'fixture':v,'fixture_sha256':sha(r/'tests/fixtures/go-pair-results'/(v+'-pair')),'language':lang,'variant':variant,'compiler':subprocess.check_output([compiler,'--version']if lang=='c'else[compiler,'version'],text=True).splitlines()[0],'body_sha256':sha(body),'source_sha256':sha(src),'executable_sha256':sha(exe),'whole_body_unchanged':True,'boundary_pairs':35,'exactly_one_call':True})
(w/'record.json').write_text(json.dumps({'capture':json.loads((w/'capture-build.json').read_text()),'scope':'Named 16-byte integer result override exercises opaque carrier adaptation into the automatically imported paired caller; complete caller emitted unchanged. Source-equivalent producer packs both words and increments a call counter.','native_comparisons':280,'records':records},indent=2)+'\n');print('OPAQUE C/GO PASS: 280 boundary comparisons, exact one call, both Go compilers and C O0/O2',flush=True)
