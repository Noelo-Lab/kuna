package main
import("fmt";"os";"strconv";"unsafe")
var calls uint64
// main.pair
func pair(a int64, b int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax | rcx
  
  v1.result1 = a - b
  v1.result0 = a + b
  return v1.result0,v1.result1
}
// main.divmod
func divmod(a int64, b int64) (int64, int64) {
  var v1 int64 // rax
  var v2 struct { result0 int64; result1 int64 } // rbx:rax | rdx
  
  if uint64(b) != 0xffffffffffffffff { // branch-flip
    v1 = a / b
    a = a % b
  } else {
    v1 = -a
    a = 0
  }
  v2.result1 = a
  v2.result0 = v1
  return v2.result0,v2.result1
}
// main.unsignedPair
func unsignedPair(a uint64, b uint64) (uint64, uint64) {
  var v1 struct { result0 uint64; result1 uint64 } // rbx:rax | rcx
  
  v1.result1 = b ^ a
  v1.result0 = a + b
  return v1.result0,v1.result1
}
// main.branchPair
func branchPair(a int64, b int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax | rcx
  var v2 struct { result0 int64; result1 int64 } // rbx:rax | rcx
  
  if a < b {
    v1.result1 = a
    v1.result0 = b
    return v1.result0,v1.result1
  }
  v2.result1 = b
  v2.result0 = a
  return v2.result0,v2.result1
}
// main.consume
func consume(a int64, b int64) int64 {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  v1.result0,v1.result1 = pair(a,b)
  return v1.result0 ^ v1.result1
}
// main.first
func first(a int64, b int64) int64 {
  return func(r0 int64, r1 int64) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{r0, r1} }(pair(a,b)).result0
}
// main.second
func second(a int64, b int64) int64 {
  return func(r0 int64, r1 int64) struct { result0 int64; result1 int64 } { return struct { result0 int64; result1 int64 }{r0, r1} }(pair(a,b)).result1
}
// main.forward
func forward(a int64, b int64) (int64, int64) {
  return pair(a,b)
}
// main.effect
func effect(a int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  calls = calls + 1
  v1.result1 = a + 1
  v1.result0 = a
  return v1.result0,v1.result1
}
// main.consumeEffect
func consumeEffect(a int64) int64 {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  v1.result0,v1.result1 = effect(a)
  return v1.result0 ^ v1.result1
}
// main.zeroPair
func zeroPair() (uint64, uint64) {
  return func(v struct { result0 uint64; result1 uint64 }) (uint64, uint64) { return v.result0, v.result1 }(struct { result0 uint64; result1 uint64 }{0x0,0})
}
// main.lowPair
func lowPair(a uint64) (uint64, uint64) {
  var v1 struct { result0 uint64; result1 uint64 } // rbx:rax
  
  v1.result1 = 0x0
  v1.result0 = a
  return v1.result0,v1.result1
}
// main.signedLowPair
func signedLowPair(a int64) (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  v1.result1 = 0
  v1.result0 = a
  return v1.result0,v1.result1
}
// main.highPair
func highPair(a uint64) (uint64, uint64) {
  var v1 [16]byte // rax | rbx
  
  *(*uint64)(unsafe.Add(unsafe.Pointer(&v1),8)) = 0
  *(*uint64)(unsafe.Add(unsafe.Pointer(&v1),0)) = a
  return func(v struct { result0 uint64; result1 uint64 }) (uint64, uint64) { return v.result0, v.result1 }(struct { result0 uint64; result1 uint64 }{0,*(*uint64)(unsafe.Pointer(&v1))})
}
// main.onesPair
func onesPair() (int64, int64) {
  var v1 struct { result0 int64; result1 int64 } // rbx:rax
  
  v1.result1 = -1
  v1.result0 = -1
  return v1.result0,v1.result1
}
// main.choosePair
func choosePair(a uint64, b uint64) (uint64, uint64) {
  var v1 struct { result0 uint64; result1 uint64 } // rbx:rax
  
  if a == 0x0 {
    return func(v struct { result0 uint64; result1 uint64 }) (uint64, uint64) { return v.result0, v.result1 }(struct { result0 uint64; result1 uint64 }{0x0,0})
  }
  v1.result1 = b
  v1.result0 = a
  return v1.result0,v1.result1
}
func division(a,b int64)(line string){defer func(){if recover()!=nil{line="panic"}}();x,y:=divmod(a,b);return fmt.Sprintf("%d %d",x,y)}
func main(){a,_:=strconv.ParseInt(os.Args[1],10,64);b,_:=strconv.ParseInt(os.Args[2],10,64);x,y:=pair(a,b);fmt.Println(x,y);x,y=forward(a,b);fmt.Println(x,y);x,y=branchPair(a,b);fmt.Println(x,y);u,v:=unsignedPair(uint64(a),uint64(b));fmt.Println(u,v);fmt.Println(consume(a,b),first(a,b),second(a,b));calls=0;e:=consumeEffect(a);fmt.Println(e,calls);fmt.Println(zeroPair());fmt.Println(lowPair(uint64(a)));fmt.Println(signedLowPair(a));fmt.Println(highPair(uint64(a)));fmt.Println(onesPair());fmt.Println(choosePair(uint64(a),uint64(b)));fmt.Println(division(a,b))}
