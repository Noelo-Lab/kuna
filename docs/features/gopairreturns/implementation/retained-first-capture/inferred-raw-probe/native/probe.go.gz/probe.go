package main
import("fmt";"os";"strconv")
var calls int
//go:noinline
func pair(a,b int64)(int64,int64){calls++;return a+b,a-b}
//go:noinline
func effect(a int64)(int64,int64){calls++;return a,a+1}
//go:noinline
func mergeCarrier(a,b int64)(int64,int64){var x,y int64;if a<0{x,y=effect(a)}else{x,y=pair(a,b)};return x^1,y^1}
func main(){a,_:=strconv.ParseInt(os.Args[1],10,64);b,_:=strconv.ParseInt(os.Args[2],10,64);fmt.Println(mergeCarrier(a,b));fmt.Println(calls)}
