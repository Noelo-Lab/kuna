package main
import "fmt"
//go:noinline
func pair(a,b int64)(int64,int64){return a+b,a-b}
func main(){fmt.Println(pair(7,3))}
