#include <stdint.h>
#include <assert.h>
typedef int64_t int8;
typedef struct{int8 result0,result1;}__kuna_go_pair_i64_i64;
static int calls;
static unsigned __int128 pair(int8 a,int8 b){calls++;return (unsigned __int128)(uint64_t)(a+b)|((unsigned __int128)(uint64_t)(a-b)<<64);}
__kuna_go_pair_i64_i64 forward(int8 a,int8 b)
{
  return ((union { unsigned __int128 carrier; __kuna_go_pair_i64_i64 value; }){.carrier = pair(a,b)}).value;
}
int main(void){int8 as[]={INT64_MIN,-4294967297LL,-1,0,1,4294967297LL,INT64_MAX},bs[]={INT64_MIN,-1,0,1,INT64_MAX};for(int i=0;i<7;i++)for(int j=0;j<5;j++){int8 a=as[i],b=bs[j];calls=0;__kuna_go_pair_i64_i64 v=forward(a,b);assert(v.result0==a+b&&v.result1==a-b&&calls==1);}return 0;}
