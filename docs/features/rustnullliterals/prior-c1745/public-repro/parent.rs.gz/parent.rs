#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn zero() -> *mut u8
{
  return core::ptr::null_mut__;
}

fn main() { assert!(unsafe { zero() }.is_null()); }
