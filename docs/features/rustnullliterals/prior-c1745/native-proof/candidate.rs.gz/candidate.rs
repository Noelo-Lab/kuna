#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn null_pointer() -> *mut u8
{
  return core::ptr::null_mut();
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn maybe_pointer(mut choice: u64, mut pointer: *mut u8) -> *mut u8 // early-return
{
  if choice != 0x2a {
    return core::ptr::null_mut();
  }
  return pointer;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn pointer_is_null(mut pointer: *mut u8) -> i32
{
  return (pointer == core::ptr::null_mut()) as i32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn clear_pointer(mut slot: *mut *mut u8)
{
  *slot = core::ptr::null_mut();
  return;
}
fn main() {
 let choice:u64=std::env::args().nth(1).unwrap().parse().unwrap();
 let mut byte=17u8; let pointer=&mut byte as *mut u8; let mut slot=pointer;
 unsafe { let null=null_pointer(); let selected=maybe_pointer(choice,pointer); clear_pointer(&mut slot);
 println!("{} {} {} {} {}",null.is_null(),selected==pointer,slot.is_null(),pointer_is_null(null),pointer_is_null(pointer)); }
}
