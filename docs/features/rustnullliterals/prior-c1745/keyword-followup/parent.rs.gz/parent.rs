#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn type(mut match: i32) -> i32
{
  return match + 1;
}
