unsigned char *zero(void) { return 0; }
