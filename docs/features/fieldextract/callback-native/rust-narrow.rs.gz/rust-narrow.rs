#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn narrow_second(mut fn: *mut *const (), mut a: i64, mut b: i64) -> i32
{
  return (*fn)(a,b).second as i32;
}