package main
type Pair struct { first int64; second int64 }
var calls uint64
func make_pair(a int64, b int64) Pair {
  var v1 Pair // rdx:rax
  
  calls = calls + 1
  v1.second = a - b
  v1.first = a + b
  return v1
}
func first(fn func(int64, int64) Pair, a int64, b int64) int64 {
  return fn(a,b).first
}
func second(fn func(int64, int64) Pair, a int64, b int64) int64 {
  var v1 int64 // rdx
  
  v1 = fn(a,b).second
  return v1
}
func both(fn func(int64, int64) Pair, a int64, b int64) int64 {
  var v1 Pair // rdx:rax
  
  v1 = fn(a,b)
  return v1.first ^ v1.second
}
func forward(fn func(int64, int64) Pair, a int64, b int64) Pair {
  return fn(a,b) // jump-as-call
}
func narrow_second(fn func(int64, int64) Pair, a int64, b int64) int32 {
  return int32(fn(a,b).second)
}
func scalar(fn func(int64, int64) int64, a int64, b int64) int64 {
  return fn(a,b) // jump-as-call
}
func invoke_void(fn func(int64, int64), a int64, b int64) {
  fn(a,b) // jump-as-call
}
func scalar_op(a,b int64) int64 { calls++; return a^b }
func void_op(a,b int64) { calls++ }
func main() {
 values:=[]int64{-9223372036854775808,-9223372036854775807,-4294967296,-65536,-17,-1,0,1,17,65536,4294967295,9223372036854775806,9223372036854775807}
 for _,a:=range values { for _,b:=range values {
  calls=0;x:=first(make_pair,a,b);if x!=a+b || calls!=1 {panic("first")}
  calls=0;y:=second(make_pair,a,b);if y!=a-b || calls!=1 {panic("second")}
  calls=0;z:=both(make_pair,a,b);if z!=(a+b)^(a-b) || calls!=1 {panic("both")}
  calls=0;p:=forward(make_pair,a,b);if p.first!=a+b || p.second!=a-b || calls!=1 {panic("forward")}
  calls=0;s:=scalar(scalar_op,a,b);if s!=a^b || calls!=1 {panic("scalar")}
  calls=0;n:=narrow_second(make_pair,a,b);if n!=int32(a-b) || calls!=1 {panic("narrow_second")}
  calls=0;invoke_void(void_op,a,b);if calls!=1 {panic("void")}
 } }
}
