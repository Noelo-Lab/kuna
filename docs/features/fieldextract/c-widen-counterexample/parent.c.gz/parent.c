#include <stdio.h>
struct Pair { long first,second; };
struct Pair pair(long a,long b){return (struct Pair){a+b,a-b};}
int direct_narrow(long a,long b)
{
  return pair(a,b).second;
}
long widened_narrow(long a,long b)
{
  return pair(a,b).second;
}
int main(void){printf("%d %ld\n",direct_narrow(4294967297L,0),widened_narrow(4294967297L,0));}
