#include <stdio.h>
struct Pair { long first,second; };
__attribute__((noinline,noclone)) struct Pair pair(long a,long b) { return (struct Pair){a+b,a-b}; }
__attribute__((noinline,noclone)) int direct_narrow(long a,long b) { return pair(a,b).second; }
__attribute__((noinline,noclone)) long widened_narrow(long a,long b) { return (int)pair(a,b).second; }

int main(void){printf("%d %ld\n",direct_narrow(4294967297L,0),widened_narrow(4294967297L,0));}
