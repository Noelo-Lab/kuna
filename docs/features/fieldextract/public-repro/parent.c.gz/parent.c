long widened_narrow(long a,long b)
{
  return pair(a,b).second;
}
