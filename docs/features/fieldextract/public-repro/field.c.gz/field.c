struct Pair { long first,second; };
__attribute__((noinline,noclone)) struct Pair pair(long a,long b) { return (struct Pair){a+b,a-b}; }
long widened_narrow(long a,long b) { return (int)pair(a,b).second; }
