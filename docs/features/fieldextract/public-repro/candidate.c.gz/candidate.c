long widened_narrow(long a,long b)
{
  return (int)pair(a,b).second;
}
