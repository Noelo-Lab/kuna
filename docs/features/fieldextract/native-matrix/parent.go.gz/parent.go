package main
import "fmt"
type Pair struct { first int64; second int64 }
type UPair struct { first uint64; second uint64 }
var calls uint64
func make_pair(a,b int64) Pair { calls++; return Pair{a+b,a-b} }
func make_unsigned(a,b int64) UPair { calls++; return UPair{uint64(a)+uint64(b),uint64(a)-uint64(b)} }
func signed_int8(a int64, b int64) int8 {
  return make_pair(a,b).second
}
func signed_int8_wide(a int64, b int64) int64 {
  return int64(make_pair(a,b).second)
}
func signed_uint8(a int64, b int64) byte {
  return make_pair(a,b).second
}
func signed_uint8_wide(a int64, b int64) uint64 {
  return uint64(make_pair(a,b).second) & 0xff
}
func signed_int16(a int64, b int64) int16 {
  return make_pair(a,b).second
}
func signed_int16_wide(a int64, b int64) int64 {
  return int64(make_pair(a,b).second)
}
func signed_uint16(a int64, b int64) uint16 {
  return make_pair(a,b).second
}
func signed_uint16_wide(a int64, b int64) uint64 {
  return uint64(make_pair(a,b).second) & 0xffff
}
func signed_int32(a int64, b int64) int32 {
  return make_pair(a,b).second
}
func signed_int32_wide(a int64, b int64) int64 {
  return int64(make_pair(a,b).second)
}
func signed_uint32(a int64, b int64) uint32 {
  return make_pair(a,b).second
}
func signed_uint32_wide(a int64, b int64) uint64 {
  return uint64(make_pair(a,b).second) & 0xffffffff
}
func unsigned_int8(a int64, b int64) int8 {
  return make_unsigned(a,b).second
}
func unsigned_uint8(a int64, b int64) byte {
  return make_unsigned(a,b).second
}
func unsigned_int16(a int64, b int64) int16 {
  return make_unsigned(a,b).second
}
func unsigned_uint16(a int64, b int64) uint16 {
  return make_unsigned(a,b).second
}
func unsigned_int32(a int64, b int64) int32 {
  return make_unsigned(a,b).second
}
func unsigned_uint32(a int64, b int64) uint32 {
  return make_unsigned(a,b).second
}
func first_narrow(a int64, b int64) int32 {
  return make_pair(a,b).first
}
func shift8(a int64, b int64) byte {
  return SUB161(make_unsigned(a,b),9)
}
func shift32(a int64, b int64) uint32 {
  return SUB164(make_unsigned(a,b),0xc)
}
func signed_high(a int64, b int64) int64 {
  return make_pair(a,b).second >> 0x20
}
func signed_as_unsigned(a int64, b int64) uint64 {
  return uint64(make_pair(a,b).second)
}
func unsigned_as_signed(a int64, b int64) int64 {
  return int64(make_unsigned(a,b).second)
}
func exact_signed(a int64, b int64) int64 {
  return make_pair(a,b).second
}
func exact_unsigned(a int64, b int64) uint64 {
  return make_unsigned(a,b).second
}
func main() { values:=[]int64{-9223372036854775808,-9223372036854775807,-4294967297,-4294967296,-65537,-65536,-32769,-32768,-257,-256,-129,-128,-1,0,1,127,128,255,256,32767,32768,65535,65536,4294967295,4294967296,4294967297,9223372036854775806,9223372036854775807}; for _,a:=range values { for _,b:=range values {
calls=0; fmt.Printf("%016x\n",uint64(signed_int8(a,b))); if calls!=1 {panic("signed_int8")}
calls=0; fmt.Printf("%016x\n",uint64(signed_int8_wide(a,b))); if calls!=1 {panic("signed_int8_wide")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint8(a,b))); if calls!=1 {panic("signed_uint8")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint8_wide(a,b))); if calls!=1 {panic("signed_uint8_wide")}
calls=0; fmt.Printf("%016x\n",uint64(signed_int16(a,b))); if calls!=1 {panic("signed_int16")}
calls=0; fmt.Printf("%016x\n",uint64(signed_int16_wide(a,b))); if calls!=1 {panic("signed_int16_wide")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint16(a,b))); if calls!=1 {panic("signed_uint16")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint16_wide(a,b))); if calls!=1 {panic("signed_uint16_wide")}
calls=0; fmt.Printf("%016x\n",uint64(signed_int32(a,b))); if calls!=1 {panic("signed_int32")}
calls=0; fmt.Printf("%016x\n",uint64(signed_int32_wide(a,b))); if calls!=1 {panic("signed_int32_wide")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint32(a,b))); if calls!=1 {panic("signed_uint32")}
calls=0; fmt.Printf("%016x\n",uint64(signed_uint32_wide(a,b))); if calls!=1 {panic("signed_uint32_wide")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_int8(a,b))); if calls!=1 {panic("unsigned_int8")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_uint8(a,b))); if calls!=1 {panic("unsigned_uint8")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_int16(a,b))); if calls!=1 {panic("unsigned_int16")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_uint16(a,b))); if calls!=1 {panic("unsigned_uint16")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_int32(a,b))); if calls!=1 {panic("unsigned_int32")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_uint32(a,b))); if calls!=1 {panic("unsigned_uint32")}
calls=0; fmt.Printf("%016x\n",uint64(first_narrow(a,b))); if calls!=1 {panic("first_narrow")}
calls=0; fmt.Printf("%016x\n",uint64(shift8(a,b))); if calls!=1 {panic("shift8")}
calls=0; fmt.Printf("%016x\n",uint64(shift32(a,b))); if calls!=1 {panic("shift32")}
calls=0; fmt.Printf("%016x\n",uint64(signed_high(a,b))); if calls!=1 {panic("signed_high")}
calls=0; fmt.Printf("%016x\n",uint64(signed_as_unsigned(a,b))); if calls!=1 {panic("signed_as_unsigned")}
calls=0; fmt.Printf("%016x\n",uint64(unsigned_as_signed(a,b))); if calls!=1 {panic("unsigned_as_signed")}
calls=0; fmt.Printf("%016x\n",uint64(exact_signed(a,b))); if calls!=1 {panic("exact_signed")}
calls=0; fmt.Printf("%016x\n",uint64(exact_unsigned(a,b))); if calls!=1 {panic("exact_unsigned")}
}}}
