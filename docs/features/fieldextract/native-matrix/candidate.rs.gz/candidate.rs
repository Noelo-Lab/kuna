#![allow(non_camel_case_types,dead_code,unused_mut,unused_parens)]
struct Pair { first:i64, second:i64 }
struct UPair { first:u64, second:u64 }
static mut CALLS:u64=0;
unsafe fn make_pair(a:i64,b:i64)->Pair { CALLS+=1; Pair{first:a.wrapping_add(b),second:a.wrapping_sub(b)} }
unsafe fn make_unsigned(a:i64,b:i64)->UPair { CALLS+=1; UPair{first:(a as u64).wrapping_add(b as u64),second:(a as u64).wrapping_sub(b as u64)} }
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int8(mut a: i64, mut b: i64) -> i8
{
  return make_pair(a,b).second as i8;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int8_wide(mut a: i64, mut b: i64) -> i64
{
  return ((make_pair(a,b).second as u8) as i8) as i64;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint8(mut a: i64, mut b: i64) -> u8
{
  return make_pair(a,b).second as u8;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint8_wide(mut a: i64, mut b: i64) -> u64
{
  return make_pair(a,b).second & 0xff;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int16(mut a: i64, mut b: i64) -> i16
{
  return make_pair(a,b).second as i16;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int16_wide(mut a: i64, mut b: i64) -> i64
{
  return (make_pair(a,b).second as i16) as i64;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint16(mut a: i64, mut b: i64) -> u16
{
  return make_pair(a,b).second as u16;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint16_wide(mut a: i64, mut b: i64) -> u64
{
  return make_pair(a,b).second & 0xffff;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int32(mut a: i64, mut b: i64) -> i32
{
  return make_pair(a,b).second as i32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_int32_wide(mut a: i64, mut b: i64) -> i64
{
  return (make_pair(a,b).second as i32) as i64;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint32(mut a: i64, mut b: i64) -> u32
{
  return make_pair(a,b).second as u32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_uint32_wide(mut a: i64, mut b: i64) -> u64
{
  return make_pair(a,b).second & 0xffffffff;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_int8(mut a: i64, mut b: i64) -> i8
{
  return make_unsigned(a,b).second as i8;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_uint8(mut a: i64, mut b: i64) -> u8
{
  return make_unsigned(a,b).second as u8;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_int16(mut a: i64, mut b: i64) -> i16
{
  return make_unsigned(a,b).second as i16;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_uint16(mut a: i64, mut b: i64) -> u16
{
  return make_unsigned(a,b).second as u16;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_int32(mut a: i64, mut b: i64) -> i32
{
  return make_unsigned(a,b).second as i32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_uint32(mut a: i64, mut b: i64) -> u32
{
  return make_unsigned(a,b).second as u32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn first_narrow(mut a: i64, mut b: i64) -> i32
{
  return make_pair(a,b).first as i32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn shift8(mut a: i64, mut b: i64) -> u8
{
  return (make_unsigned(a,b).second >> 8) as u8;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn shift32(mut a: i64, mut b: i64) -> u32
{
  return (make_unsigned(a,b).second >> 0x20) as u32;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_high(mut a: i64, mut b: i64) -> i64
{
  return make_pair(a,b).second >> 0x20;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_as_unsigned(mut a: i64, mut b: i64) -> u64
{
  return make_pair(a,b).second;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn unsigned_as_signed(mut a: i64, mut b: i64) -> i64
{
  return make_unsigned(a,b).second;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn exact_signed(mut a: i64, mut b: i64) -> i64
{
  return make_pair(a,b).second;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn exact_unsigned(mut a: i64, mut b: i64) -> u64
{
  return make_unsigned(a,b).second;
}
fn main() { let values:[i64;28]=[-9223372036854775808,-9223372036854775807,-4294967297,-4294967296,-65537,-65536,-32769,-32768,-257,-256,-129,-128,-1,0,1,127,128,255,256,32767,32768,65535,65536,4294967295,4294967296,4294967297,9223372036854775806,9223372036854775807]; unsafe { for a in values { for b in values {
CALLS=0; println!("{:016x}",signed_int8(a,b) as u64); assert!(CALLS==1,"signed_int8");
CALLS=0; println!("{:016x}",signed_int8_wide(a,b) as u64); assert!(CALLS==1,"signed_int8_wide");
CALLS=0; println!("{:016x}",signed_uint8(a,b) as u64); assert!(CALLS==1,"signed_uint8");
CALLS=0; println!("{:016x}",signed_uint8_wide(a,b) as u64); assert!(CALLS==1,"signed_uint8_wide");
CALLS=0; println!("{:016x}",signed_int16(a,b) as u64); assert!(CALLS==1,"signed_int16");
CALLS=0; println!("{:016x}",signed_int16_wide(a,b) as u64); assert!(CALLS==1,"signed_int16_wide");
CALLS=0; println!("{:016x}",signed_uint16(a,b) as u64); assert!(CALLS==1,"signed_uint16");
CALLS=0; println!("{:016x}",signed_uint16_wide(a,b) as u64); assert!(CALLS==1,"signed_uint16_wide");
CALLS=0; println!("{:016x}",signed_int32(a,b) as u64); assert!(CALLS==1,"signed_int32");
CALLS=0; println!("{:016x}",signed_int32_wide(a,b) as u64); assert!(CALLS==1,"signed_int32_wide");
CALLS=0; println!("{:016x}",signed_uint32(a,b) as u64); assert!(CALLS==1,"signed_uint32");
CALLS=0; println!("{:016x}",signed_uint32_wide(a,b) as u64); assert!(CALLS==1,"signed_uint32_wide");
CALLS=0; println!("{:016x}",unsigned_int8(a,b) as u64); assert!(CALLS==1,"unsigned_int8");
CALLS=0; println!("{:016x}",unsigned_uint8(a,b) as u64); assert!(CALLS==1,"unsigned_uint8");
CALLS=0; println!("{:016x}",unsigned_int16(a,b) as u64); assert!(CALLS==1,"unsigned_int16");
CALLS=0; println!("{:016x}",unsigned_uint16(a,b) as u64); assert!(CALLS==1,"unsigned_uint16");
CALLS=0; println!("{:016x}",unsigned_int32(a,b) as u64); assert!(CALLS==1,"unsigned_int32");
CALLS=0; println!("{:016x}",unsigned_uint32(a,b) as u64); assert!(CALLS==1,"unsigned_uint32");
CALLS=0; println!("{:016x}",first_narrow(a,b) as u64); assert!(CALLS==1,"first_narrow");
CALLS=0; println!("{:016x}",shift8(a,b) as u64); assert!(CALLS==1,"shift8");
CALLS=0; println!("{:016x}",shift32(a,b) as u64); assert!(CALLS==1,"shift32");
CALLS=0; println!("{:016x}",signed_high(a,b) as u64); assert!(CALLS==1,"signed_high");
CALLS=0; println!("{:016x}",signed_as_unsigned(a,b) as u64); assert!(CALLS==1,"signed_as_unsigned");
CALLS=0; println!("{:016x}",unsigned_as_signed(a,b) as u64); assert!(CALLS==1,"unsigned_as_signed");
CALLS=0; println!("{:016x}",exact_signed(a,b) as u64); assert!(CALLS==1,"exact_signed");
CALLS=0; println!("{:016x}",exact_unsigned(a,b) as u64); assert!(CALLS==1,"exact_unsigned");
}}}}
