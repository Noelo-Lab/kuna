#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_narrow(mut a: i64, mut b: i64) -> i32
{
  return pair(a,b).second;
}
