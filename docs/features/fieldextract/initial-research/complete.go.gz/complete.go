package main
type Pair struct { first int64; second int64 }
func pair(a,b int64)Pair{return Pair{a+b,a-b}}
func direct_narrow(a int64, b int64) int32 {
  return pair(a,b).second
}

func main() {}
