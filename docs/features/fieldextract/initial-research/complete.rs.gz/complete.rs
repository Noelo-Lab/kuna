struct Pair { first:i64,second:i64 }
unsafe fn pair(a:i64,b:i64)->Pair{Pair{first:a.wrapping_add(b),second:a.wrapping_sub(b)}}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_narrow(mut a: i64, mut b: i64) -> i32
{
  return pair(a,b).second;
}

fn main() {}
