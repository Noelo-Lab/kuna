func direct_narrow(a int64, b int64) int32 {
  return pair(a,b).second
}
