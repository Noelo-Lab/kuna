struct Pair { long first,second; };
__attribute__((noinline,noclone)) struct Pair pair(long a,long b) { return (struct Pair){a+b,a-b}; }
__attribute__((noinline,noclone)) int direct_narrow(long a,long b) { return pair(a,b).second; }
int main(void) { return direct_narrow(13,7)!=6; }
