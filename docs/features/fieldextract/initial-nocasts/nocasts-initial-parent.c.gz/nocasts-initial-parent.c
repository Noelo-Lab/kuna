long signed_int32_wide(long a,long b)
{
  return make_pair(a,b).second;
}
