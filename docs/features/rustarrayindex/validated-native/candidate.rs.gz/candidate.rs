#![allow(dead_code,unused_mut,unused_variables,unused_parens,non_snake_case)]
#[repr(C)]struct ArrayFields{before:u64,i8:[i8;9],u8:[u8;9],i16:[i16;9],u16:[u16;9],i32:[i32;9],u32:[u32;9],i64:[i64;9],u64:[u64;9],after:u64}
#[repr(align(8))]struct Buffer([u8;std::mem::size_of::<ArrayFields>()]);
static mut TRACE:u64=0;
unsafe fn counted_index(i:i64)->i64{TRACE=TRACE*10+1;i}
unsafe fn counted_base(p:*mut ArrayFields)->*mut ArrayFields{TRACE=TRACE*10+2;p}
unsafe fn counted_value(v:i32)->i32{TRACE=TRACE*10+3;v}
fn bytes(v:&[u8]){for x in v{print!("{:02x}",x);}println!();}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i8_s(mut p: *mut ArrayFields, mut i: i64) -> i8
{
  return (*p).i8[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i8_s(mut p: *mut ArrayFields, mut i: i64, mut value: i8)
{
  (*p).i8[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i8_u(mut p: *mut ArrayFields, mut i: u64) -> i8
{
  return (*p).i8[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i8_u(mut p: *mut ArrayFields, mut i: u64, mut value: i8)
{
  (*p).i8[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u8_s(mut p: *mut ArrayFields, mut i: i64) -> u8
{
  return (*p).u8[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u8_s(mut p: *mut ArrayFields, mut i: i64, mut value: u8)
{
  (*p).u8[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u8_u(mut p: *mut ArrayFields, mut i: u64) -> u8
{
  return (*p).u8[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u8_u(mut p: *mut ArrayFields, mut i: u64, mut value: u8)
{
  (*p).u8[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i16_s(mut p: *mut ArrayFields, mut i: i64) -> i16
{
  return (*p).i16[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i16_s(mut p: *mut ArrayFields, mut i: i64, mut value: i16)
{
  (*p).i16[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i16_u(mut p: *mut ArrayFields, mut i: u64) -> i16
{
  return (*p).i16[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i16_u(mut p: *mut ArrayFields, mut i: u64, mut value: i16)
{
  (*p).i16[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u16_s(mut p: *mut ArrayFields, mut i: i64) -> u16
{
  return (*p).u16[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u16_s(mut p: *mut ArrayFields, mut i: i64, mut value: u16)
{
  (*p).u16[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u16_u(mut p: *mut ArrayFields, mut i: u64) -> u16
{
  return (*p).u16[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u16_u(mut p: *mut ArrayFields, mut i: u64, mut value: u16)
{
  (*p).u16[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i32_s(mut p: *mut ArrayFields, mut i: i64) -> i32
{
  return (*p).i32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i32_s(mut p: *mut ArrayFields, mut i: i64, mut value: i32)
{
  (*p).i32[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i32_u(mut p: *mut ArrayFields, mut i: u64) -> i32
{
  return (*p).i32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i32_u(mut p: *mut ArrayFields, mut i: u64, mut value: i32)
{
  (*p).i32[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u32_s(mut p: *mut ArrayFields, mut i: i64) -> u32
{
  return (*p).u32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u32_s(mut p: *mut ArrayFields, mut i: i64, mut value: u32)
{
  (*p).u32[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u32_u(mut p: *mut ArrayFields, mut i: u64) -> u32
{
  return (*p).u32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u32_u(mut p: *mut ArrayFields, mut i: u64, mut value: u32)
{
  (*p).u32[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i64_s(mut p: *mut ArrayFields, mut i: i64) -> i64
{
  return (*p).i64[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i64_s(mut p: *mut ArrayFields, mut i: i64, mut value: i64)
{
  (*p).i64[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_i64_u(mut p: *mut ArrayFields, mut i: u64) -> i64
{
  return (*p).i64[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_i64_u(mut p: *mut ArrayFields, mut i: u64, mut value: i64)
{
  (*p).i64[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u64_s(mut p: *mut ArrayFields, mut i: i64) -> u64
{
  return (*p).u64[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u64_s(mut p: *mut ArrayFields, mut i: i64, mut value: u64)
{
  (*p).u64[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn load_u64_u(mut p: *mut ArrayFields, mut i: u64) -> u64
{
  return (*p).u64[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn store_u64_u(mut p: *mut ArrayFields, mut i: u64, mut value: u64)
{
  (*p).u64[i as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn constant_load(mut p: *mut ArrayFields) -> i32
{
  return (*p).i32[3];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn zero_load(mut p: *mut ArrayFields) -> u64
{
  return (*p).u64[0];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn array_address_s(mut p: *mut ArrayFields, mut i: i64) -> *mut i32
{
  return &mut (*p).i32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn array_address_u(mut p: *mut ArrayFields, mut i: u64) -> *mut i32
{
  return &mut (*p).i32[i as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn callback_load(mut p: *mut ArrayFields, mut i: i64) -> i32
{
  let mut v1: i64; // rax | rbx
  
  v1 = counted_index(i);
  return (*counted_base(p)).i32[v1 as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn callback_store(mut p: *mut ArrayFields, mut i: i64, mut value: i32)
{
  let mut v1: i32; // eax | ebp
  let mut v2: i64; // rax | rbx
  
  v1 = counted_value(value);
  v2 = counted_index(i);
  (*counted_base(p)).i32[v2 as usize] = v1;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn nested_load_s(mut p: *mut [i32; 9], mut i: i64, mut j: i64) -> i32
{
  return (*p.wrapping_byte_offset((i as isize).wrapping_mul(36)))[j as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn nested_store_s(mut p: *mut [i32; 9], mut i: i64, mut j: i64, mut value: i32)
{
  (*p.wrapping_byte_offset((i as isize).wrapping_mul(36)))[j as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn nested_load_u(mut p: *mut [i32; 9], mut i: i64, mut j: u64) -> i32
{
  return (*p.wrapping_byte_offset((i as isize).wrapping_mul(36)))[j as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn nested_store_u(mut p: *mut [i32; 9], mut i: i64, mut j: u64, mut value: i32)
{
  (*p.wrapping_byte_offset((i as isize).wrapping_mul(36)))[j as usize] = value;
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn right_context(mut p: *mut ArrayFields, mut shift: u64) -> i32
{
  return (*p).i32[(::core::convert::identity::<u64>(7 >> (shift as u8 & 0x3f)) as u64) as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_context(mut p: *mut ArrayFields, mut shift: u64) -> i32
{
  return (*p).i32[(::core::convert::identity::<i64>((-8 >> (shift as u8 & 0x3f)) + 8) as i64) as usize];
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn left_context(mut p: *mut ArrayFields, mut shift: u64) -> i32
{
  return (*p).i32[(::core::convert::identity::<i64>(1 << (shift as u8 & 3)) as i64) as usize];
}
fn main(){unsafe{for v in [0u64,1u64,2u64,0x7fu64,0x80u64,0xffu64,0x7fffu64,0x8000u64,0xffffu64,0x7fffffffu64,0x80000000u64,0xffffffffu64,0x7fffffffffffffffu64,0x8000000000000000u64,0xffffffffffffffffu64,0x0123456789abcdefu64,0xfedcba9876543210u64,0xaaaaaaaa55555555u64]{for i in 0..9i64{
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i8_s {:016x}",load_i8_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i8_s(p,i as i64,v as i8);print!("store_i8_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i8_u {:016x}",load_i8_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i8_u(p,i as u64,v as i8);print!("store_i8_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u8_s {:016x}",load_u8_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u8_s(p,i as i64,v as u8);print!("store_u8_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u8_u {:016x}",load_u8_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u8_u(p,i as u64,v as u8);print!("store_u8_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i16_s {:016x}",load_i16_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i16_s(p,i as i64,v as i16);print!("store_i16_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i16_u {:016x}",load_i16_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i16_u(p,i as u64,v as i16);print!("store_i16_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u16_s {:016x}",load_u16_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u16_s(p,i as i64,v as u16);print!("store_u16_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u16_u {:016x}",load_u16_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u16_u(p,i as u64,v as u16);print!("store_u16_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i32_s {:016x}",load_i32_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i32_s(p,i as i64,v as i32);print!("store_i32_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i32_u {:016x}",load_i32_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i32_u(p,i as u64,v as i32);print!("store_i32_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u32_s {:016x}",load_u32_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u32_s(p,i as i64,v as u32);print!("store_u32_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u32_u {:016x}",load_u32_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u32_u(p,i as u64,v as u32);print!("store_u32_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i64_s {:016x}",load_i64_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i64_s(p,i as i64,v as i64);print!("store_i64_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_i64_u {:016x}",load_i64_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_i64_u(p,i as u64,v as i64);print!("store_i64_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u64_s {:016x}",load_u64_s(p,i as i64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u64_s(p,i as i64,v as u64);print!("store_u64_s ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("load_u64_u {:016x}",load_u64_u(p,i as u64) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}store_u64_u(p,i as u64,v as u64);print!("store_u64_u ");bytes(&buffer.0);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("constant_load {:016x}",constant_load(p) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("zero_load {:016x}",zero_load(p) as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("array_address_s {:016x}",(array_address_s(p,i as i64)as usize).wrapping_sub(p as usize)as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("array_address_u {:016x}",(array_address_u(p,i as u64)as usize).wrapping_sub(p as usize)as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}TRACE=0;let result=callback_load(p,i as i64)as u64;let trace=TRACE;println!("callback_load {:016x} {}",result,trace);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}TRACE=0;callback_store(p,i as i64,v as i32);let trace=TRACE;print!("callback_store {} ",trace);bytes(&buffer.0);}
}for i in -1i64..=1{for j in 0..9i64{
{let mut a=[[0i32;9];5];for row in 0..5{for col in 0..9{a[row][col]=v.wrapping_add((row*31+col)as u64)as i32;}}let p=a.as_mut_ptr().add(2);println!("nested_load_s {:016x}",nested_load_s(p,i,j as i64)as u64);}
{let mut a=[[0i32;9];5];for row in 0..5{for col in 0..9{a[row][col]=v.wrapping_add((row*31+col)as u64)as i32;}}let p=a.as_mut_ptr().add(2);nested_store_s(p,i,j as i64,v as i32);print!("nested_store_s ");bytes(std::slice::from_raw_parts(a.as_ptr()as *const u8,180));}
{let mut a=[[0i32;9];5];for row in 0..5{for col in 0..9{a[row][col]=v.wrapping_add((row*31+col)as u64)as i32;}}let p=a.as_mut_ptr().add(2);println!("nested_load_u {:016x}",nested_load_u(p,i,j as u64)as u64);}
{let mut a=[[0i32;9];5];for row in 0..5{for col in 0..9{a[row][col]=v.wrapping_add((row*31+col)as u64)as i32;}}let p=a.as_mut_ptr().add(2);nested_store_u(p,i,j as u64,v as i32);print!("nested_store_u ");bytes(std::slice::from_raw_parts(a.as_ptr()as *const u8,180));}
}}for shift in 0u64..64{
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("right_context {:016x}",right_context(p,shift)as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("signed_context {:016x}",signed_context(p,shift)as u64);}
{let mut buffer=Buffer([0xa5;std::mem::size_of::<ArrayFields>()]);let p=buffer.0.as_mut_ptr() as *mut ArrayFields;for k in 0..9{(*p).i8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i8;}for k in 0..9{(*p).u8[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u8;}for k in 0..9{(*p).i16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i16;}for k in 0..9{(*p).u16[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u16;}for k in 0..9{(*p).i32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i32;}for k in 0..9{(*p).u32[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u32;}for k in 0..9{(*p).i64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as i64;}for k in 0..9{(*p).u64[k]=0x9e3779b97f4a7c15u64.wrapping_mul(k as u64).wrapping_add(v) as u64;}println!("left_context {:016x}",left_context(p,shift)as u64);}
}}}}
