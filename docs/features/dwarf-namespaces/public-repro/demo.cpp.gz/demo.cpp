#include <cstdio>
namespace left { __attribute__((noinline)) unsigned target(unsigned x) { return x + 10; } }
__attribute__((noinline)) unsigned target(unsigned x) { return x + 40; }
extern "C" __attribute__((noinline)) unsigned direct(unsigned x) { return left::target(x); }
int main(int argc, char **) { std::printf("%u %u\n", direct(argc), target(argc)); }
