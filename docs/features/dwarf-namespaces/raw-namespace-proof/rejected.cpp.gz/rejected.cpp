#include <cstdio>
#include <cstdlib>
namespace raw_scope {}
unsigned int raw_scope::union::target(unsigned int x)
{
  return x + 10;
}
unsigned int direct_target(unsigned int x)
{
  return raw_scope::union::target(x); // tail-call
}
int main(int argc,char **argv) { unsigned int x=static_cast<unsigned int>(std::strtoul(argv[1],nullptr,0)); std::printf("%u\n",direct_target(x)); }
