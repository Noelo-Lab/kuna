#include <cstdint>
#include <cstdio>
#include <cstdlib>

namespace left {
__attribute__((noinline)) uint32_t target(uint32_t x) { return x + 10; }
__attribute__((noinline)) uint32_t same(uint32_t x) { return target(x); }
namespace deep {
__attribute__((noinline)) uint32_t target(uint32_t x) { return x + 20; }
}
}
namespace right {
__attribute__((noinline)) uint32_t target(uint32_t x) { return x + 30; }
__attribute__((noinline)) uint32_t cross(uint32_t x) { return left::target(x); }
}
__attribute__((noinline)) uint32_t target(uint32_t x) { return x + 40; }

unsigned int direct_left(unsigned int x)
{
  return left::target(x);
}
unsigned int direct_nested(unsigned int x)
{
  return left::deep::target(x);
}
unsigned int direct_right(unsigned int x)
{
  return right::target(x);
}
unsigned int direct_global(unsigned int x)
{
  return target(x);
}
unsigned int direct_shadow(unsigned int left)
{
  return left::target(left);
}
int main(int argc, char **argv) { uint32_t x = static_cast<uint32_t>(std::strtoul(argv[1], nullptr, 0)); std::printf("%u %u %u %u %u\n", direct_left(x), direct_nested(x), direct_right(x), direct_global(x), direct_shadow(x)); }
