extern crate self as dwarf_namespaces;
mod left {
    #[inline(never)]
    pub fn target(x: u32) -> u32 { x.wrapping_add(10) }
    #[inline(never)]
    pub fn same(x: u32) -> u32 { target(x) }
    pub mod deep {
        #[inline(never)]
        pub fn target(x: u32) -> u32 { x.wrapping_add(20) }
    }
}
mod right {
    #[inline(never)]
    pub fn target(x: u32) -> u32 { x.wrapping_add(30) }
    #[inline(never)]
    pub fn cross(x: u32) -> u32 { super::left::target(x) }
}
#[inline(never)]
fn target(x: u32) -> u32 { x.wrapping_add(40) }

#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_left(mut x: u32) -> u32
{
  return dwarf_namespaces::left::target(x); // tail-call
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_nested(mut x: u32) -> u32
{
  return dwarf_namespaces::left::deep::target(x); // tail-call
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_right(mut x: u32) -> u32
{
  return dwarf_namespaces::right::target(x); // tail-call
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn direct_global(mut x: u32) -> u32
{
  return dwarf_namespaces::target(x); // tail-call
}
fn main() { let x = std::env::args().nth(1).unwrap().parse::<u32>().unwrap(); unsafe { println!("{} {} {} {}", direct_left(x), direct_nested(x), direct_right(x), direct_global(x)); } }
