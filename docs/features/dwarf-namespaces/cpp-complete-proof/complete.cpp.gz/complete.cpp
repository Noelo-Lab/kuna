#include <cstdio>
#include <cstdlib>
namespace left { unsigned int target(unsigned int); unsigned int same(unsigned int); namespace deep { unsigned int target(unsigned int); } }
namespace right { unsigned int target(unsigned int); unsigned int cross(unsigned int); }
unsigned int left::target(unsigned int x)
{
  return x + 10;
}
unsigned int left::same(unsigned int x)
{
  return left::target(x);
}
unsigned int left::deep::target(unsigned int x)
{
  return x + 0x14;
}
unsigned int right::target(unsigned int x)
{
  return x + 0x1e;
}
unsigned int right::cross(unsigned int x)
{
  return left::target(x);
}
unsigned int target(unsigned int x)
{
  return x + 0x28;
}
unsigned int direct_left(unsigned int x)
{
  return left::target(x);
}
unsigned int direct_nested(unsigned int x)
{
  return left::deep::target(x);
}
unsigned int direct_right(unsigned int x)
{
  return right::target(x);
}
unsigned int direct_global(unsigned int x)
{
  return target(x);
}
unsigned int direct_shadow(unsigned int left)
{
  return left::target(left);
}
int main(int argc,char **argv)
{
  char *nptr; // rdi
  unsigned int v2; // eax | esi | stack - 0x34
  unsigned int v3; // eax | r15d
  unsigned int v4; // eax | r12d
  unsigned int v5; // eax | r13d
  unsigned int v6; // eax | ebp
  unsigned int v7; // eax | r14d | stack - 0x48
  unsigned int x; // ebx
  
  x = 0;
  if (2 <= argc) {
    nptr = argv[1];
    x = (unsigned int)strtoul(nptr,NULL,0);
  }
  v2 = direct_left(x);
  v3 = direct_nested(x);
  v4 = direct_right(x);
  v5 = direct_global(x);
  v6 = direct_shadow(x);
  v7 = left::same(x);
  printf("%u %u %u %u %u %u %u\n",v2,v3,v4,v5,v6,v7,right::cross(x));
  return 0;
}
