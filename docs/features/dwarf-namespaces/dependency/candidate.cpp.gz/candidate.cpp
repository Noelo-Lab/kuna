#include <cstdio>
#include <cstdlib>
#include <cstdint>
namespace left { unsigned int target(unsigned int); }
unsigned int left::target(unsigned int x)
{
  return x + 10;
}
unsigned long get_target(void)
{
  return (unsigned long)target;
}
int main(int argc,char **argv)
{
  char *nptr; // rdi
  unsigned int x; // edi
  
  x = 0;
  if (2 <= argc) {
    nptr = argv[1];
    x = (unsigned int)strtoul(nptr,NULL,0);
  }
  printf("%u\n",left::target(x));
  return 0;
}
