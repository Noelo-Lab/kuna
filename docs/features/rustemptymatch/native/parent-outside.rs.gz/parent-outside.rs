#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn empty_case(mut x: u64) -> i32
{
  let mut v1: i32; // eax
  
  v1 = 0;
  match x >> 0x20 {
    0 => {
      break;
    }
    1 => {
      v1 = 1;
    }
    2 => {
      v1 = 2;
    }
    3 => {
      v1 = 3;
    }
    4 => {
      v1 = 4;
    }
    5 => {
      v1 = 5;
    }
    6 => {
      v1 = 6;
    }
    7 => {
      v1 = 7;
    }
    8 => {
      v1 = 8;
    }
    9 => {
      v1 = 9;
    }
    10 => {
      v1 = 10;
    }
    0xb => {
      v1 = 0xb;
    }
    0xc => {
      v1 = 0xc;
    }
    0xd => {
      v1 = 0xd;
    }
    0xe => {
      v1 = 0xe;
    }
    0xf => {
      v1 = 0xf;
    }
    0x10 => {
      v1 = 0x10;
    }
    0x11 => {
      v1 = 0x11;
    }
    0x12 => {
      v1 = 0x12;
    }
    0x13 => {
      v1 = 0x13;
    }
    0x14 => {
      v1 = 0x14;
    }
    0x15 => {
      v1 = 0x15;
    }
    0x16 => {
      v1 = 0x16;
    }
    0x17 => {
      v1 = 0x17;
    }
    0x18 => {
      v1 = 0x18;
    }
    0x19 => {
      v1 = 0x19;
    }
    0x1a => {
      v1 = 0x1a;
    }
    0x1b => {
      v1 = 0x1b;
    }
    0x1c => {
      v1 = 0x1c;
    }
    0x1d => {
      v1 = 0x1d;
    }
    0x1e => {
      v1 = 0x1e;
    }
    0x1f => {
      v1 = 0x1f;
    }
    0x20 => {
      v1 = 0x20;
    }
    0x21 => {
      v1 = 0x21;
    }
    0x22 => {
      v1 = 0x22;
    }
    0x23 => {
      v1 = 0x23;
    }
    0x24 => {
      v1 = 0x24;
    }
    0x25 => {
      v1 = 0x25;
    }
    0x26 => {
      v1 = 0x26;
    }
    0x27 => {
      v1 = 0x27;
    }
    0x28 => {
      v1 = 0x28;
    }
    _ => {
      v1 = 0x29;
    }
    
  }
  return v1 + 7;
}
fn main(){println!("{}",unsafe{empty_case(0)});}
