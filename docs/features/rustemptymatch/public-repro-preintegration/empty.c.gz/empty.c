int check(int x) { int v=0; switch(x) { case 0: break; case 1: v=3; break; case 2: v=9; break; case 3: v=16; break; case 4: v=-4; break; case 5: v=28; break; default: v=41; } return v+7; }
