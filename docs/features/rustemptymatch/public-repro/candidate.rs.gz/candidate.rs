#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn check(mut x: i32) -> i32
{
  let mut v1: i32; // eax | stack - 0xc
  
  v1 = 0;
  match x {
    0 => {
    }
    1 => {
      v1 = 3;
    }
    2 => {
      v1 = 9;
    }
    3 => {
      v1 = 0x10;
    }
    4 => {
      v1 = -4;
    }
    5 => {
      v1 = 0x1c;
    }
    _ => {
      v1 = 0x29;
    }
    
  }
  return v1 + 7;
}
fn main(){unsafe{println!("{}",check(0));}}
