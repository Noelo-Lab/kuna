#define same_address original_same_address
#define cross_address original_cross_address
#define foreign_address original_foreign_address
#define nested_address original_nested_address
#define right_address original_right_address
#define global_shadow original_global_shadow
#define scope_shadow original_scope_shadow
#define main original_main
#include "function_pointer_namespaces.cpp"
#undef same_address
#undef cross_address
#undef foreign_address
#undef nested_address
#undef right_address
#undef global_shadow
#undef scope_shadow
#undef main
namespace left { uintptr_t same_address(); }
namespace right { uintptr_t cross_address(); }

unsigned long left::same_address(void)
{
  return (unsigned long)left::target;
}
unsigned long right::cross_address(void)
{
  return (unsigned long)left::target;
}
unsigned long foreign_address(void)
{
  return (unsigned long)left::target;
}
unsigned long nested_address(void)
{
  return (unsigned long)left::deep::target;
}
unsigned long right_address(void)
{
  return (unsigned long)right::target;
}
unsigned long global_shadow(unsigned long target)
{
  return (unsigned long)::target;
}
unsigned long scope_shadow(unsigned long left)
{
  return (unsigned long)::left::target;
}

int main() {
    unsigned inputs[] = {0, 1, 7, 12345, 0x7fffffffU, 0x80000000U, 0xffffffd7U, 0xfffffff5U, 0xffffffffU};
    uintptr_t valid[] = {reinterpret_cast<uintptr_t>(&left::target), reinterpret_cast<uintptr_t>(&left::deep::target), reinterpret_cast<uintptr_t>(&right::target), reinterpret_cast<uintptr_t>(&::target)};
    for (unsigned x : inputs) {
        uintptr_t actual[] = {left::same_address(), right::cross_address(), foreign_address(), nested_address(), right_address(), global_shadow(x), scope_shadow(x)};
        uintptr_t expected[] = {left::original_same_address(), right::original_cross_address(), original_foreign_address(), original_nested_address(), original_right_address(), original_global_shadow(x), original_scope_shadow(x)};
        for (unsigned i = 0; i < 7; ++i) {
            bool known = false;
            for (uintptr_t address : valid) known |= actual[i] == address;
            unsigned actual_value = known ? reinterpret_cast<Callback>(actual[i])(x) : 0;
            unsigned expected_value = reinterpret_cast<Callback>(expected[i])(x);
            std::printf("%u %u %u %u %u %u\n", x, i, actual[i] == expected[i], known, actual_value, expected_value);
        }
    }
}
