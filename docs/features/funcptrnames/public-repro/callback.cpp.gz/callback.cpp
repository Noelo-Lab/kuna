namespace left { __attribute__((noinline)) unsigned target(unsigned x) { return x + 10; } }
__attribute__((noinline)) unsigned target(unsigned x) { return x + 40; }
extern "C" unsigned long get_target() { return reinterpret_cast<unsigned long>(&left::target); }
int main() { return 0; }
