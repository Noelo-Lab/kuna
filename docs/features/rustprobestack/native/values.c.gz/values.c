#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

unsigned int probe_page(unsigned int x)
{
  return x + 7;
}
unsigned int probe_tail(unsigned int x)
{
  return x + 7;
}
unsigned int probe_pages(unsigned int x)
{
  return x + 7;
}
unsigned int probe_observes_r11(unsigned int x)
{
  return x + 8;
}
unsigned int probe_zero(unsigned int x)
{
  return x;
}
unsigned int probe_one(unsigned int x)
{
  return x + 1;
}
unsigned int probe_page_r11(unsigned int x)
{
  return x + 0x1000;
}
unsigned int probe_plus_one(unsigned int x)
{
  return x + 1;
}
unsigned int probe_pages_r11(unsigned int x)
{
  return x + 0x1000;
}
unsigned int probe_saved_rbp(unsigned int x)
{
  return x;
}
unsigned int probe_return_slot(unsigned int x)
{
  return 1;
}
int main(int argc,char **argv){unsigned int x=(unsigned int)strtoul(argv[1],0,10);printf("%u %u %u %u %u %u %u %u %u %u %u\n",probe_page(x),probe_tail(x),probe_pages(x),probe_observes_r11(x),probe_zero(x),probe_one(x),probe_page_r11(x),probe_plus_one(x),probe_pages_r11(x),probe_saved_rbp(x),probe_return_slot(x));}
