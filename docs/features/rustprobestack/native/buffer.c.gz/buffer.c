#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

uint32_t fill_probe_page(uint8_t *out, uint32_t x) {
    for (unsigned int i = 0; i < 4096; ++i)
        out[i] = (uint8_t)(x + i);
    return out[0] + (uint32_t)out[4095] * 257;
}

unsigned int probe_buffer(unsigned int x)
{
  unsigned char v1 [4096]; // stack - 0x1018
  unsigned long v2; // stack - 0x18
  
  v2 = 0x5627f;
  return fill_probe_page(v1,x);
}
int main(int argc,char **argv){unsigned int x=(unsigned int)strtoul(argv[1],0,10);printf("%u\n",probe_buffer(x));}
