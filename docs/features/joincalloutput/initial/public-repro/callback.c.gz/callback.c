struct Pair { long first,second; };
long second(struct Pair (*fn)(long,long),long a,long b) { return fn(a,b).second; }
