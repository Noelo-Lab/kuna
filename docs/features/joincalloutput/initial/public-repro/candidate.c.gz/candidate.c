long second(Pair (*fn)(long,long),long a,long b)
{
  long v1; // rdx
  
  v1 = (*fn)(a,b).second;
  return v1;
}
