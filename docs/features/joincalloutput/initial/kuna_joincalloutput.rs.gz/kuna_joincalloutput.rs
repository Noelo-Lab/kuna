//! Rebuild call flow when a late prototype supplies a joined return value.

use crate::fspec::FuncProto;

pub(crate) fn needs_reflow(proto: &FuncProto) -> bool {
    proto.is_output_locked() && proto.get_output().get_address().is_join()
}
