long second(Pair (*fn)(long,long),long a,long b)
{
  long v1; // rdx
  
  (*fn)(a,b);
  return v1;
}
