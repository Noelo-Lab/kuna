package main
type Pair struct { first int64; second int64 }
var calls uint64
func make_pair(a int64, b int64) Pair {
  var v1 Pair // rdx:rax
  
  calls = calls + 1
  v1.second = a - b
  v1.first = a + b
  return v1
}
func first(fn func(int64, int64) Pair, a int64, b int64) int64 {
  return fn(a,b).first
}
func second(fn func(int64, int64) Pair, a int64, b int64) int64 {
  var v1 int64 // rdx
  
  v1 = fn(a,b).second
  return v1
}
func both(fn func(int64, int64) Pair, a int64, b int64) int64 {
  var v1 Pair // rdx:rax
  
  v1 = fn(a,b)
  return v1.first ^ v1.second
}
func forward(fn func(int64, int64) Pair, a int64, b int64) Pair {
  return fn(a,b) // jump-as-call
}
func narrow_second(fn func(int64, int64) Pair, a int64, b int64) int32 {
  return fn(a,b).second
}
func scalar(fn func(int64, int64) int64, a int64, b int64) int64 {
  return fn(a,b) // jump-as-call
}
func invoke_void(fn func(int64, int64), a int64, b int64) {
  fn(a,b) // jump-as-call
}
func main(){}
