from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import os,sys,time,json,subprocess,resource,statistics,random,itertools,hashlib,threading,runpy,shutil,multiprocessing

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def sample():
    return {'time':time.monotonic(),'cpus':{int(p[0][3:]):list(map(int,p[1:]))for line in Path('/proc/stat').read_text().splitlines()if(p:=line.split())and p[0].startswith('cpu')and p[0][3:].isdigit()}}

def case(job):
    config,plan,row,index,cpu,digests,attempt=job
    root=Path(config['root']);base=Path(config['base']);name,binary,selector,language=row
    os.sched_setaffinity(0,{cpu});assert os.sched_getaffinity(0)=={cpu}
    binary=Path(binary);fixture_sha=sha(binary);rng=random.Random(plan['seed']+index)
    raw={side:[]for side in ['baseline','off','patched']};orders=[]
    def run(side):
        executable=(base if side=='baseline'else root)/'decompiler/target/release/kuna'
        options=['--option','godwarfsig','on']if language=='go'else[]
        options+=config.get('extra_options',{}).get(name,[])
        if side=='off':options+=['--option',config['option'],'off']
        command=['taskset','-c',str(cpu),str(executable),'decompile',str(binary),selector,'--language',language]+options
        before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.perf_counter()
        subprocess.run(command,cwd=root,env=os.environ|{'KUNA_SPECS':str(root/'specs')},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
        wall=time.perf_counter()-started;after=resource.getrusage(resource.RUSAGE_CHILDREN)
        return {'wall_ms':wall*1000,'cpu_ms':1000*((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))}
    for _ in range(plan['warmups_per_arm']):
        order=list(raw);rng.shuffle(order)
        for side in order:run(side)
    for block in range(plan['samples_per_arm']//6):
        permutations=list(itertools.permutations(raw));rng.shuffle(permutations)
        for order in permutations:
            orders.append(order)
            for side in order:raw[side].append(run(side))
        if(block+1)%8==0:print(name,'completed rounds',(block+1)*6,flush=True)
    assert sha(binary)==fixture_sha
    medians={s:{m:statistics.median(x[m]for x in xs)for m in ['cpu_ms','wall_ms']}for s,xs in raw.items()}
    means={s:{m:statistics.mean(x[m]for x in xs)for m in ['cpu_ms','wall_ms']}for s,xs in raw.items()}
    deltas={a+'_to_patched':{m:100*(medians['patched'][m]/medians[a][m]-1)for m in ['cpu_ms','wall_ms']}for a in ['baseline','off']}
    record={'method':'balanced_randomized_block_bootstrap','execution':'independent worker per case on a disjoint physical CPU pair','plan':plan,'baseline_commit':config['baseline_commit'],'fixture':name,'sha256':fixture_sha,'selector':selector,'language':language,'samples':plan['samples_per_arm'],'warmups':plan['warmups_per_arm'],'affinity_cpu':cpu,'binaries_sha256':digests,'medians':medians,'means':means,'delta_pct':deltas,'raw':raw,'orders':orders}
    Path(attempt,f'timing-{name}.json').write_text(json.dumps(record,indent=2)+'\n')
    print(name,'sampling complete',flush=True)
    return record

def quantile(values,q):
    values=sorted(values);position=q*(len(values)-1);lo=int(position);hi=min(lo+1,len(values)-1)
    return values[lo]+(position-lo)*(values[hi]-values[lo])

def inference(record,plan,index):
    raw=record['raw'];keys=[(s,m)for s in ['baseline','off','patched']for m in ['cpu_ms','wall_ms']]
    blocks=[[sum(raw[s][i][m]for i in range(start,start+6))for s,m in keys]for start in range(0,plan['samples_per_arm'],6)]
    distributions={a+'_to_patched':{m:[]for m in ['cpu_ms','wall_ms']}for a in ['baseline','off']};rng=random.Random(plan['seed']+1000+index)
    for _ in range(plan['bootstrap_resamples']):
        totals=[0.0]*6
        for _ in blocks:
            block=rng.choice(blocks)
            for j,x in enumerate(block):totals[j]+=x
        for side,index in [('baseline',0),('off',2)]:
            for m,j in [('cpu_ms',0),('wall_ms',1)]:distributions[side+'_to_patched'][m].append(100*(totals[4+j]/totals[index+j]-1))
    upper={a:{m:quantile(values,plan['upper_quantile'])for m,values in metrics.items()}for a,metrics in distributions.items()}
    record['confidence_upper_delta_pct']=upper
    record['confidence_method']=f"Percentile bootstrap of {len(blocks)} complete six-round blocks; simultaneous family alpha {plan['family_alpha']} across {plan['comparisons']} CPU/wall comparisons."
    record['speed_budget_passed']=all(v<=plan['budget_pct']for group in [record['delta_pct'],upper]for metrics in group.values()for v in metrics.values())
    return record

