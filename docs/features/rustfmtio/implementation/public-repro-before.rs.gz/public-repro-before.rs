#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn write_value(mut a0: *mut u64, mut a1: u32) -> u64
{
  let mut v1: u64; // rdi
  let mut v2: u32; // esi | stack - 0x14
  let mut v3: *mut u32; // rax | stack - 0x10
  let mut v4: *mut *const (); // stack - 0x8
  
  v3 = &mut v2;
  v4 = fmt;
  v1 = *(*a0 as *mut u64);
  v2 = a1;
  return _std::io::stdio::Stdout::write_fmt(v1,0x62d9,&mut v3);
}
