#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
extern unsigned int narrow_guard(uint64_t);
extern unsigned int wide_guard(uint64_t);
extern unsigned int explicit_zext(uint64_t);
extern unsigned int byte_guard(uint64_t);
extern unsigned int word_guard(uint64_t);
extern unsigned int signed_guard(uint64_t);
int main(int argc, char **argv) {
    if (argc != 2) return 1;
    uint64_t x = strtoull(argv[1], 0, 0);
    printf("%u %u %u %u %u %u\n", narrow_guard(x),wide_guard(x),explicit_zext(x),byte_guard(x),word_guard(x),signed_guard(x));
    return 0;
}

unsigned int narrow_guard(unsigned long x)
{
  switch(x >> 0x20) {
    case 0:
      return 3;
    case 1:
      return 10;
    case 2:
      return 0x11;
    case 3:
      return 0x18;
    case 4:
      return 0x1f;
    case 5:
      return 0x26;
    case 6:
      return 0x2d;
    case 7:
      return 0x34;
    case 8:
      return 0x3b;
    case 9:
      return 0x42;
    case 10:
      return 0x49;
    case 0xb:
      return 0x50;
    case 0xc:
      return 0x57;
    case 0xd:
      return 0x5e;
    case 0xe:
      return 0x65;
    case 0xf:
      return 0x6c;
    case 0x10:
      return 0x73;
    case 0x11:
      return 0x7a;
    case 0x12:
      return 0x81;
    case 0x13:
      return 0x88;
    case 0x14:
      return 0x8f;
    case 0x15:
      return 0x96;
    case 0x16:
      return 0x9d;
    case 0x17:
      return 0xa4;
    case 0x18:
      return 0xab;
    case 0x19:
      return 0xb2;
    case 0x1a:
      return 0xb9;
    case 0x1b:
      return 0xc0;
    case 0x1c:
      return 199;
    case 0x1d:
      return 0xce;
    case 0x1e:
      return 0xd5;
    case 0x1f:
      return 0xdc;
    case 0x20:
      return 0xe3;
    case 0x21:
      return 0xea;
    case 0x22:
      return 0xf1;
    case 0x23:
      return 0xf8;
    case 0x24:
      return 0xff;
    case 0x25:
      return 0x106;
    case 0x26:
      return 0x10d;
    case 0x27:
      return 0x114;
    case 0x28:
      return 0x11b;
    default:
      return 1000;
    
  }
}
unsigned int wide_guard(unsigned long x)
{
  switch(x >> 0x20) {
    case 0:
      return 3;
    case 1:
      return 10;
    case 2:
      return 0x11;
    case 3:
      return 0x18;
    case 4:
      return 0x1f;
    case 5:
      return 0x26;
    case 6:
      return 0x2d;
    case 7:
      return 0x34;
    case 8:
      return 0x3b;
    case 9:
      return 0x42;
    case 10:
      return 0x49;
    case 0xb:
      return 0x50;
    case 0xc:
      return 0x57;
    case 0xd:
      return 0x5e;
    case 0xe:
      return 0x65;
    case 0xf:
      return 0x6c;
    case 0x10:
      return 0x73;
    case 0x11:
      return 0x7a;
    case 0x12:
      return 0x81;
    case 0x13:
      return 0x88;
    case 0x14:
      return 0x8f;
    case 0x15:
      return 0x96;
    case 0x16:
      return 0x9d;
    case 0x17:
      return 0xa4;
    case 0x18:
      return 0xab;
    case 0x19:
      return 0xb2;
    case 0x1a:
      return 0xb9;
    case 0x1b:
      return 0xc0;
    case 0x1c:
      return 199;
    case 0x1d:
      return 0xce;
    case 0x1e:
      return 0xd5;
    case 0x1f:
      return 0xdc;
    case 0x20:
      return 0xe3;
    case 0x21:
      return 0xea;
    case 0x22:
      return 0xf1;
    case 0x23:
      return 0xf8;
    case 0x24:
      return 0xff;
    case 0x25:
      return 0x106;
    case 0x26:
      return 0x10d;
    case 0x27:
      return 0x114;
    case 0x28:
      return 0x11b;
    default:
      return 1000;
    
  }
}
unsigned int explicit_zext(unsigned long x)
{
  switch((int)(x >> 0x20)) {
    case 0:
      return 3;
    case 1:
      return 10;
    case 2:
      return 0x11;
    case 3:
      return 0x18;
    case 4:
      return 0x1f;
    case 5:
      return 0x26;
    case 6:
      return 0x2d;
    case 7:
      return 0x34;
    case 8:
      return 0x3b;
    case 9:
      return 0x42;
    case 10:
      return 0x49;
    case 0xb:
      return 0x50;
    case 0xc:
      return 0x57;
    case 0xd:
      return 0x5e;
    case 0xe:
      return 0x65;
    case 0xf:
      return 0x6c;
    case 0x10:
      return 0x73;
    case 0x11:
      return 0x7a;
    case 0x12:
      return 0x81;
    case 0x13:
      return 0x88;
    case 0x14:
      return 0x8f;
    case 0x15:
      return 0x96;
    case 0x16:
      return 0x9d;
    case 0x17:
      return 0xa4;
    case 0x18:
      return 0xab;
    case 0x19:
      return 0xb2;
    case 0x1a:
      return 0xb9;
    case 0x1b:
      return 0xc0;
    case 0x1c:
      return 199;
    case 0x1d:
      return 0xce;
    case 0x1e:
      return 0xd5;
    case 0x1f:
      return 0xdc;
    case 0x20:
      return 0xe3;
    case 0x21:
      return 0xea;
    case 0x22:
      return 0xf1;
    case 0x23:
      return 0xf8;
    case 0x24:
      return 0xff;
    case 0x25:
      return 0x106;
    case 0x26:
      return 0x10d;
    case 0x27:
      return 0x114;
    case 0x28:
      return 0x11b;
    default:
      return 1000;
    
  }
}
unsigned int byte_guard(unsigned long x)
{
  switch(x >> 0x38) {
    case 0:
      return 3;
    case 1:
      return 10;
    case 2:
      return 0x11;
    case 3:
      return 0x18;
    case 4:
      return 0x1f;
    case 5:
      return 0x26;
    case 6:
      return 0x2d;
    case 7:
      return 0x34;
    case 8:
      return 0x3b;
    case 9:
      return 0x42;
    case 10:
      return 0x49;
    case 0xb:
      return 0x50;
    case 0xc:
      return 0x57;
    case 0xd:
      return 0x5e;
    case 0xe:
      return 0x65;
    case 0xf:
      return 0x6c;
    case 0x10:
      return 0x73;
    case 0x11:
      return 0x7a;
    case 0x12:
      return 0x81;
    case 0x13:
      return 0x88;
    case 0x14:
      return 0x8f;
    case 0x15:
      return 0x96;
    case 0x16:
      return 0x9d;
    case 0x17:
      return 0xa4;
    case 0x18:
      return 0xab;
    case 0x19:
      return 0xb2;
    case 0x1a:
      return 0xb9;
    case 0x1b:
      return 0xc0;
    case 0x1c:
      return 199;
    case 0x1d:
      return 0xce;
    case 0x1e:
      return 0xd5;
    case 0x1f:
      return 0xdc;
    case 0x20:
      return 0xe3;
    case 0x21:
      return 0xea;
    case 0x22:
      return 0xf1;
    case 0x23:
      return 0xf8;
    case 0x24:
      return 0xff;
    case 0x25:
      return 0x106;
    case 0x26:
      return 0x10d;
    case 0x27:
      return 0x114;
    case 0x28:
      return 0x11b;
    default:
      return 1000;
    
  }
}
unsigned int word_guard(unsigned long x)
{
  switch(x >> 0x30) {
    case 0:
      return 3;
    case 1:
      return 10;
    case 2:
      return 0x11;
    case 3:
      return 0x18;
    case 4:
      return 0x1f;
    case 5:
      return 0x26;
    case 6:
      return 0x2d;
    case 7:
      return 0x34;
    case 8:
      return 0x3b;
    case 9:
      return 0x42;
    case 10:
      return 0x49;
    case 0xb:
      return 0x50;
    case 0xc:
      return 0x57;
    case 0xd:
      return 0x5e;
    case 0xe:
      return 0x65;
    case 0xf:
      return 0x6c;
    case 0x10:
      return 0x73;
    case 0x11:
      return 0x7a;
    case 0x12:
      return 0x81;
    case 0x13:
      return 0x88;
    case 0x14:
      return 0x8f;
    case 0x15:
      return 0x96;
    case 0x16:
      return 0x9d;
    case 0x17:
      return 0xa4;
    case 0x18:
      return 0xab;
    case 0x19:
      return 0xb2;
    case 0x1a:
      return 0xb9;
    case 0x1b:
      return 0xc0;
    case 0x1c:
      return 199;
    case 0x1d:
      return 0xce;
    case 0x1e:
      return 0xd5;
    case 0x1f:
      return 0xdc;
    case 0x20:
      return 0xe3;
    case 0x21:
      return 0xea;
    case 0x22:
      return 0xf1;
    case 0x23:
      return 0xf8;
    case 0x24:
      return 0xff;
    case 0x25:
      return 0x106;
    case 0x26:
      return 0x10d;
    case 0x27:
      return 0x114;
    case 0x28:
      return 0x11b;
    default:
      return 1000;
    
  }
}
unsigned int signed_guard(unsigned long x)
{
  if (((int)(x >> 0x20) <= 0x28) && (0 <= (long)x)) {
    switch(x >> 0x20) {
      case 0:
        return 3;
      case 1:
        return 10;
      case 2:
        return 0x11;
      case 3:
        return 0x18;
      case 4:
        return 0x1f;
      case 5:
        return 0x26;
      case 6:
        return 0x2d;
      case 7:
        return 0x34;
      case 8:
        return 0x3b;
      case 9:
        return 0x42;
      case 10:
        return 0x49;
      case 0xb:
        return 0x50;
      case 0xc:
        return 0x57;
      case 0xd:
        return 0x5e;
      case 0xe:
        return 0x65;
      case 0xf:
        return 0x6c;
      case 0x10:
        return 0x73;
      case 0x11:
        return 0x7a;
      case 0x12:
        return 0x81;
      case 0x13:
        return 0x88;
      case 0x14:
        return 0x8f;
      case 0x15:
        return 0x96;
      case 0x16:
        return 0x9d;
      case 0x17:
        return 0xa4;
      case 0x18:
        return 0xab;
      case 0x19:
        return 0xb2;
      case 0x1a:
        return 0xb9;
      case 0x1b:
        return 0xc0;
      case 0x1c:
        return 199;
      case 0x1d:
        return 0xce;
      case 0x1e:
        return 0xd5;
      case 0x1f:
        return 0xdc;
      case 0x20:
        return 0xe3;
      case 0x21:
        return 0xea;
      case 0x22:
        return 0xf1;
      case 0x23:
        return 0xf8;
      case 0x24:
        return 0xff;
      case 0x25:
        return 0x106;
      case 0x26:
        return 0x10d;
      case 0x27:
        return 0x114;
      case 0x28:
        return 0x11b;
      
    }
  }
  return 1000;
}