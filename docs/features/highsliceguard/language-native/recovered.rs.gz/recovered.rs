#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn narrow_guard(mut a0: u64) -> u64
{
  match a0 >> 0x20 {
    0 => {
      return 3;
    }
    1 => {
      return 10;
    }
    2 => {
      return 0x11;
    }
    3 => {
      return 0x18;
    }
    4 => {
      return 0x1f;
    }
    5 => {
      return 0x26;
    }
    6 => {
      return 0x2d;
    }
    7 => {
      return 0x34;
    }
    8 => {
      return 0x3b;
    }
    9 => {
      return 0x42;
    }
    10 => {
      return 0x49;
    }
    0xb => {
      return 0x50;
    }
    0xc => {
      return 0x57;
    }
    0xd => {
      return 0x5e;
    }
    0xe => {
      return 0x65;
    }
    0xf => {
      return 0x6c;
    }
    0x10 => {
      return 0x73;
    }
    0x11 => {
      return 0x7a;
    }
    0x12 => {
      return 0x81;
    }
    0x13 => {
      return 0x88;
    }
    0x14 => {
      return 0x8f;
    }
    0x15 => {
      return 0x96;
    }
    0x16 => {
      return 0x9d;
    }
    0x17 => {
      return 0xa4;
    }
    0x18 => {
      return 0xab;
    }
    0x19 => {
      return 0xb2;
    }
    0x1a => {
      return 0xb9;
    }
    0x1b => {
      return 0xc0;
    }
    0x1c => {
      return 199;
    }
    0x1d => {
      return 0xce;
    }
    0x1e => {
      return 0xd5;
    }
    0x1f => {
      return 0xdc;
    }
    0x20 => {
      return 0xe3;
    }
    0x21 => {
      return 0xea;
    }
    0x22 => {
      return 0xf1;
    }
    0x23 => {
      return 0xf8;
    }
    0x24 => {
      return 0xff;
    }
    0x25 => {
      return 0x106;
    }
    0x26 => {
      return 0x10d;
    }
    0x27 => {
      return 0x114;
    }
    0x28 => {
      return 0x11b;
    }
    _ => {
      return 1000;
    }
    
  }
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn wide_guard(mut a0: u64) -> u64
{
  match a0 >> 0x20 {
    0 => {
      return 3;
    }
    1 => {
      return 10;
    }
    2 => {
      return 0x11;
    }
    3 => {
      return 0x18;
    }
    4 => {
      return 0x1f;
    }
    5 => {
      return 0x26;
    }
    6 => {
      return 0x2d;
    }
    7 => {
      return 0x34;
    }
    8 => {
      return 0x3b;
    }
    9 => {
      return 0x42;
    }
    10 => {
      return 0x49;
    }
    0xb => {
      return 0x50;
    }
    0xc => {
      return 0x57;
    }
    0xd => {
      return 0x5e;
    }
    0xe => {
      return 0x65;
    }
    0xf => {
      return 0x6c;
    }
    0x10 => {
      return 0x73;
    }
    0x11 => {
      return 0x7a;
    }
    0x12 => {
      return 0x81;
    }
    0x13 => {
      return 0x88;
    }
    0x14 => {
      return 0x8f;
    }
    0x15 => {
      return 0x96;
    }
    0x16 => {
      return 0x9d;
    }
    0x17 => {
      return 0xa4;
    }
    0x18 => {
      return 0xab;
    }
    0x19 => {
      return 0xb2;
    }
    0x1a => {
      return 0xb9;
    }
    0x1b => {
      return 0xc0;
    }
    0x1c => {
      return 199;
    }
    0x1d => {
      return 0xce;
    }
    0x1e => {
      return 0xd5;
    }
    0x1f => {
      return 0xdc;
    }
    0x20 => {
      return 0xe3;
    }
    0x21 => {
      return 0xea;
    }
    0x22 => {
      return 0xf1;
    }
    0x23 => {
      return 0xf8;
    }
    0x24 => {
      return 0xff;
    }
    0x25 => {
      return 0x106;
    }
    0x26 => {
      return 0x10d;
    }
    0x27 => {
      return 0x114;
    }
    0x28 => {
      return 0x11b;
    }
    _ => {
      return 1000;
    }
    
  }
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn explicit_zext(mut a0: u64) -> u64
{
  match ((a0 as u64) >> 0x20) as i32 {
    0 => {
      return 3;
    }
    1 => {
      return 10;
    }
    2 => {
      return 0x11;
    }
    3 => {
      return 0x18;
    }
    4 => {
      return 0x1f;
    }
    5 => {
      return 0x26;
    }
    6 => {
      return 0x2d;
    }
    7 => {
      return 0x34;
    }
    8 => {
      return 0x3b;
    }
    9 => {
      return 0x42;
    }
    10 => {
      return 0x49;
    }
    0xb => {
      return 0x50;
    }
    0xc => {
      return 0x57;
    }
    0xd => {
      return 0x5e;
    }
    0xe => {
      return 0x65;
    }
    0xf => {
      return 0x6c;
    }
    0x10 => {
      return 0x73;
    }
    0x11 => {
      return 0x7a;
    }
    0x12 => {
      return 0x81;
    }
    0x13 => {
      return 0x88;
    }
    0x14 => {
      return 0x8f;
    }
    0x15 => {
      return 0x96;
    }
    0x16 => {
      return 0x9d;
    }
    0x17 => {
      return 0xa4;
    }
    0x18 => {
      return 0xab;
    }
    0x19 => {
      return 0xb2;
    }
    0x1a => {
      return 0xb9;
    }
    0x1b => {
      return 0xc0;
    }
    0x1c => {
      return 199;
    }
    0x1d => {
      return 0xce;
    }
    0x1e => {
      return 0xd5;
    }
    0x1f => {
      return 0xdc;
    }
    0x20 => {
      return 0xe3;
    }
    0x21 => {
      return 0xea;
    }
    0x22 => {
      return 0xf1;
    }
    0x23 => {
      return 0xf8;
    }
    0x24 => {
      return 0xff;
    }
    0x25 => {
      return 0x106;
    }
    0x26 => {
      return 0x10d;
    }
    0x27 => {
      return 0x114;
    }
    0x28 => {
      return 0x11b;
    }
    _ => {
      return 1000;
    }
    
  }
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn byte_guard(mut a0: u64) -> u64
{
  match a0 >> 0x38 {
    0 => {
      return 3;
    }
    1 => {
      return 10;
    }
    2 => {
      return 0x11;
    }
    3 => {
      return 0x18;
    }
    4 => {
      return 0x1f;
    }
    5 => {
      return 0x26;
    }
    6 => {
      return 0x2d;
    }
    7 => {
      return 0x34;
    }
    8 => {
      return 0x3b;
    }
    9 => {
      return 0x42;
    }
    10 => {
      return 0x49;
    }
    0xb => {
      return 0x50;
    }
    0xc => {
      return 0x57;
    }
    0xd => {
      return 0x5e;
    }
    0xe => {
      return 0x65;
    }
    0xf => {
      return 0x6c;
    }
    0x10 => {
      return 0x73;
    }
    0x11 => {
      return 0x7a;
    }
    0x12 => {
      return 0x81;
    }
    0x13 => {
      return 0x88;
    }
    0x14 => {
      return 0x8f;
    }
    0x15 => {
      return 0x96;
    }
    0x16 => {
      return 0x9d;
    }
    0x17 => {
      return 0xa4;
    }
    0x18 => {
      return 0xab;
    }
    0x19 => {
      return 0xb2;
    }
    0x1a => {
      return 0xb9;
    }
    0x1b => {
      return 0xc0;
    }
    0x1c => {
      return 199;
    }
    0x1d => {
      return 0xce;
    }
    0x1e => {
      return 0xd5;
    }
    0x1f => {
      return 0xdc;
    }
    0x20 => {
      return 0xe3;
    }
    0x21 => {
      return 0xea;
    }
    0x22 => {
      return 0xf1;
    }
    0x23 => {
      return 0xf8;
    }
    0x24 => {
      return 0xff;
    }
    0x25 => {
      return 0x106;
    }
    0x26 => {
      return 0x10d;
    }
    0x27 => {
      return 0x114;
    }
    0x28 => {
      return 0x11b;
    }
    _ => {
      return 1000;
    }
    
  }
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn word_guard(mut a0: u64) -> u64
{
  match a0 >> 0x30 {
    0 => {
      return 3;
    }
    1 => {
      return 10;
    }
    2 => {
      return 0x11;
    }
    3 => {
      return 0x18;
    }
    4 => {
      return 0x1f;
    }
    5 => {
      return 0x26;
    }
    6 => {
      return 0x2d;
    }
    7 => {
      return 0x34;
    }
    8 => {
      return 0x3b;
    }
    9 => {
      return 0x42;
    }
    10 => {
      return 0x49;
    }
    0xb => {
      return 0x50;
    }
    0xc => {
      return 0x57;
    }
    0xd => {
      return 0x5e;
    }
    0xe => {
      return 0x65;
    }
    0xf => {
      return 0x6c;
    }
    0x10 => {
      return 0x73;
    }
    0x11 => {
      return 0x7a;
    }
    0x12 => {
      return 0x81;
    }
    0x13 => {
      return 0x88;
    }
    0x14 => {
      return 0x8f;
    }
    0x15 => {
      return 0x96;
    }
    0x16 => {
      return 0x9d;
    }
    0x17 => {
      return 0xa4;
    }
    0x18 => {
      return 0xab;
    }
    0x19 => {
      return 0xb2;
    }
    0x1a => {
      return 0xb9;
    }
    0x1b => {
      return 0xc0;
    }
    0x1c => {
      return 199;
    }
    0x1d => {
      return 0xce;
    }
    0x1e => {
      return 0xd5;
    }
    0x1f => {
      return 0xdc;
    }
    0x20 => {
      return 0xe3;
    }
    0x21 => {
      return 0xea;
    }
    0x22 => {
      return 0xf1;
    }
    0x23 => {
      return 0xf8;
    }
    0x24 => {
      return 0xff;
    }
    0x25 => {
      return 0x106;
    }
    0x26 => {
      return 0x10d;
    }
    0x27 => {
      return 0x114;
    }
    0x28 => {
      return 0x11b;
    }
    _ => {
      return 1000;
    }
    
  }
}
#[allow(non_snake_case, unused_mut, unused_variables, unused_parens, dead_code)]
unsafe fn signed_guard(mut a0: u64) -> u64
{
  if (((a0 >> 0x20) as i32) <= 0x28 && (0 <= (a0 as i64))) {
    match a0 >> 0x20 {
      0 => {
        return 3;
      }
      1 => {
        return 10;
      }
      2 => {
        return 0x11;
      }
      3 => {
        return 0x18;
      }
      4 => {
        return 0x1f;
      }
      5 => {
        return 0x26;
      }
      6 => {
        return 0x2d;
      }
      7 => {
        return 0x34;
      }
      8 => {
        return 0x3b;
      }
      9 => {
        return 0x42;
      }
      10 => {
        return 0x49;
      }
      0xb => {
        return 0x50;
      }
      0xc => {
        return 0x57;
      }
      0xd => {
        return 0x5e;
      }
      0xe => {
        return 0x65;
      }
      0xf => {
        return 0x6c;
      }
      0x10 => {
        return 0x73;
      }
      0x11 => {
        return 0x7a;
      }
      0x12 => {
        return 0x81;
      }
      0x13 => {
        return 0x88;
      }
      0x14 => {
        return 0x8f;
      }
      0x15 => {
        return 0x96;
      }
      0x16 => {
        return 0x9d;
      }
      0x17 => {
        return 0xa4;
      }
      0x18 => {
        return 0xab;
      }
      0x19 => {
        return 0xb2;
      }
      0x1a => {
        return 0xb9;
      }
      0x1b => {
        return 0xc0;
      }
      0x1c => {
        return 199;
      }
      0x1d => {
        return 0xce;
      }
      0x1e => {
        return 0xd5;
      }
      0x1f => {
        return 0xdc;
      }
      0x20 => {
        return 0xe3;
      }
      0x21 => {
        return 0xea;
      }
      0x22 => {
        return 0xf1;
      }
      0x23 => {
        return 0xf8;
      }
      0x24 => {
        return 0xff;
      }
      0x25 => {
        return 0x106;
      }
      0x26 => {
        return 0x10d;
      }
      0x27 => {
        return 0x114;
      }
      0x28 => {
        return 0x11b;
      }
      _ => {}
      
    }
  }
  return 1000;
}
fn main(){ let x: u64=std::env::args().nth(1).unwrap().parse().unwrap(); unsafe { println!("{} {} {} {} {} {}",narrow_guard(x),wide_guard(x),explicit_zext(x),byte_guard(x),word_guard(x),signed_guard(x)); }}
