unsigned long pick(unsigned long a0)
{
  int v1; // tmp
  
  if ((unsigned int)(a0 >> 0x20) <= 0x28) {
    v1 = dat_402000[a0 >> 0x20];
    return (*(unsigned long (*)(void *))(v1 + 0x402000L))((unsigned long (*)(void *))(v1 + 0x402000L)); // jump-as-call
  }
  return 1000;
}
